<div align="center">

<img src="docs/readme/header.svg" alt="Automações Web: um só programa com 20 automações do GCPJ; cada tela lê a sua base Access e salva no sistema" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: VB.NET" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET 4.8" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="base: Access" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** é um único programa com várias automações do GCPJ dentro. Cada automação é uma tela, e a tela só aparece no menu quando a base Access (`.mdb`) dela está na pasta do programa. Por isso o mesmo executável vira "aplicativos diferentes" conforme a base que foi entregue para cada área.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 20 telas de automação no executável; 5.000 registros por execução (S5); 25 pontos [S5] no código compilado; 22h: C@JH para e D@EO pausa" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Planilha com os dados de cada processo ➜ 2 Base Access, uma base .mdb por tela ➜ 3 Automações Web com Controle S5 lê as linhas pendentes da máquina ➜ 4 GCPJ no Internet Explorer ➜ 5 Resultado: linha marcada como feita e, em algumas telas, OBS" width="100%">
</picture>

### As duas telas do inventário

| Código | Nome no inventário | Tela no menu | O que faz |
| :---: | :--- | :--- | :--- |
| **`C@JH`** | AlteraAgCEF | **Altera_Ag_Conta** | Preenche no GCPJ o **banco, agência, conta e dígito** dos depósitos judiciais que estão sem conta (e a **operação**, quando o banco é a Caixa, código 104) |
| **`D@EO`** | INCLUSÃO/ATUALIZAÇÃO EVENTOS | **Inclusao_Evento** | **Inclui um evento** no processo do GCPJ a partir do **código do evento** |

### Todas as telas do executável

O nome no menu é o nome da tela sem o `Frm_`. Cada linha só aparece quando a base dela está na pasta.

| Tela no menu | O que faz no GCPJ | Base que libera a tela |
| :--- | :--- | :--- |
| **Altera_Ag_Conta** · `C@JH` | Preenche banco, agência, conta e dígito de depósitos judiciais sem conta | `BD_Altera_Ag_Conta.mdb` |
| **Inclusao_Evento** · `D@EO` | Inclui eventos pelo código do evento | `BD_Inserir_Evento.mdb` |
| Alteracao_Classificacao | Altera a classificação do processo cível (ação, subtipo, risco, fundamento, data do fato) | `BD_Alteracao_Classificacao.mdb` |
| Alterar_Procs_CI | Ajusta o **advogado da parte** (nome, OAB e UF) em processos cíveis, ativos ou baixados | `BD_Cadastro_Processos_CI.mdb` |
| Aprovacao_Encerramento | Aprova encerramentos no trâmite de pendências | `BD_Dados_Aprovacao_Encerramento.mdb` |
| Aprovar_Migracao | Dá ciência, em lotes, nas pendências de distribuição (não lê tabela) | `BD_Aprovar_Migracao.mdb` |
| Atualizacao_Evento_Realizado | Grava "Ciente" no resumo do evento pendente | `BD_Alterar_Evento.mdb` |
| Atualizar_Valor_Calculo | Atualiza valor do pedido e valor de risco | `BD_Atualizacao_Valor_Calculo.mdb` |
| Cadastro_Consultoria_Negocios | Importa planilha e cadastra processos internos de Consultoria e Negócios (pede login próprio) | `BD_Cadastro_Consultoria_Negocios.mdb` |
| Cadastro_Envolvido | Cadastra pessoa externa | `BD_Cadastro_Processos_CI.mdb` |
| Cadastro_Honorarios | Importa planilha de notas e cadastra atos de honorários | `BD_Cadastro_Honorarios.mdb` |
| Cadastro_Processos_CI | Cadastra processos cíveis novos | `BD_Cadastro_Processos_CI.mdb` |
| Captura_Fundamento | **Só consulta:** copia o fundamento da causa para a base | `BD_Dados_Fundamento.mdb` |
| Distribuicao | Distribui processos para advogado interno e escritório | `BD_Distribuicao.mdb` |
| Impressao_Planilha | **Só consulta:** busca o relatório do processo, conforme a área | `BD_Impressao_Planilha.mdb` |
| Inserir_Deposito | Inclui composição em depósito contabilizado | `BD_Inserir_Deposito.mdb` |
| Inserir_Evento_Pendencia | Inclui e valida eventos nas pendências do advogado | `BD_Tramite_Pendencias.mdb` |
| Migracao | Migração de processos em massa | `BD_Migracao.mdb` |
| Redistribuicao | Redistribui processos | `BD_Redistribuicao.mdb` |
| *(fora do menu)* Procs_CI_Alterar_Processo | Corrige o número de processos cíveis | `BDDados_Acerto_Processos_CI.mdb` |

> [!NOTE]
> Três telas existem na pasta mas **não entram no executável** (não estão no `.vbproj`): `Frm_Altera_Pessoa_Externa`, `Frm_Baixar_Comprovante` e `Frm_Inserir_Reclamante_Reclamada`. Elas também receberam o Controle S5, para já ficarem protegidas se um dia forem incluídas.

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `aajr-cmn-automacoeswebajustaadvpart` |
| **Inventário** | **C@JH** · AlteraAgCEF · *"Através da planilha preenchida identificando os dados de Banco/Agencia/Conta e digito dos depositos efetuados na Caixa Economica Federal (conta única), a automação insere/preenche os dados no GCPJ"*<br>**D@EO** · INCLUSÃO/ATUALIZAÇÃO EVENTOS · *"Incluir eventos no GCPJ (código e justificativa)"* |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em VB.NET Windows Forms, .NET Framework 4.8, compilado em **x86** |
| **Sistema que altera** | GCPJ (`www4.net.bradesco.com.br/gcpj`), pelo Internet Explorer |
| **Entrada** | Uma tabela dentro da base `.mdb` de cada tela. C@JH: `Depositos_Judiciais`. D@EO: `TB_Principa` |
| **Saída** | A própria linha da tabela é marcada como feita (C@JH: `ATUALIZADO`; D@EO: `IMPORTADO`). Outras telas também escrevem uma `OBS` |
| **Instalação C@JH** | `\\d4040s006\D4040_01\Publico\SISTEMAS\4040088\Controle_Depositos_BB_CaixaEconomica\AlteraAgenciaCef\` |
| **Instalação D@EO** | `\\d4040s005\D4040\Secoes\D4040S074\COMUM_S074\0. FERRAMENTAS\Inclusão de Eventos\` |
| **Horário** | C@JH **para** às 22h. D@EO **pausa** às 22h por 10 horas e, no sábado, por 48 horas |
| **Controle S5** | Até **5.000 registros por execução**, por máquina (Aprovar_Migracao: até **25 lotes**) |

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, igual em quase todas as telas:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Base preenchida ao lado do executável ➜ 2 Escolher a tela no menu Automações Web ➜ 3 Conectar no GCPJ ➜ 4 Escolher a máquina (opcional) ➜ 5 Processar (até 5.000 por execução, para ou pausa às 22h) ➜ 6 Conferir o resultado na base" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Confira se a planilha já está na tabela da base (C@JH: `Depositos_Judiciais`; D@EO: `TB_Principa`). **Essas duas telas não têm botão de importar:** os dados entram direto pelo Access |
| **2** | Abra o **Automações Web** e dê dois cliques na tela desejada (ou selecione e clique em *Selecione um Formulário na Grade Abaixo*). Se só existir uma base na pasta, a tela já abre sozinha |
| **3** | Clique em **Conectar GCPJ**. Se o GCPJ não estiver aberto, abre um Internet Explorer: faça login e clique em **Conectar GCPJ** de novo, até aparecer *"Conexão Efetuada!"*. Só então o botão de processar fica liberado |
| **4** | *(opcional)* Para dividir o trabalho, clique em **Distribuir Máquinas** e informe a quantidade. Depois, em cada máquina, escolha o **número dela** no campo *Máquina* |
| **5** | Clique em **Processar** (C@JH) ou **Processar Inclusão** (D@EO) e acompanhe pela lista da tela. Se passar de 5.000, o robô para sozinho e avisa (Controle S5) |
| **6** | Ao final aparece *"Acabou"* (C@JH) ou *"Acabou!"* (D@EO). Confira na base quais linhas ficaram marcadas |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e como a base deve estar</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com **Internet Explorer** e acesso ao GCPJ
- **Microsoft Access Database Engine 32 bits** (o projeto é x86, então o ACE OLEDB 12.0 tem que ser 32 bits)
- A base `.mdb` da tela **na mesma pasta** do executável

**C@JH · tabela `Depositos_Judiciais` (base `BD_Altera_Ag_Conta.mdb`)**

| Coluna | Para que serve |
| :--- | :--- |
| `GCPJ` | Número do processo usado na pesquisa |
| `DATA` | Data do depósito. O robô pesquisa com início e fim nesta data |
| `VALOR` | Usado para achar o depósito certo quando a pesquisa traz mais de um |
| `BANCO`, `AGENCIA`, `CONTA`, `DIGITO` | Dados gravados no GCPJ |
| `OPERACAO` | Só é usada quando `BANCO` = `104` (Caixa) |
| `ATUALIZADO` | Marcada pelo robô quando termina a linha. Só as desmarcadas são processadas |
| `MAQUINA` | Número da máquina, preenchido pelo *Distribuir Máquinas* |

**D@EO · tabela `TB_Principa` (base `BD_Inserir_Evento.mdb`)**

| Coluna | Para que serve |
| :--- | :--- |
| `GCPJ` | Número do processo usado na pesquisa |
| `EVENTO` | Código do evento que será incluído |
| `IMPORTADO` | Marcada pelo robô quando termina a linha. Só as desmarcadas são processadas |
| `MAQUINA` | Número da máquina, preenchido pelo *Distribuir Máquinas* |

> [!TIP]
> O campo **Máquina** vai de 1 a 12. **Em branco**, o robô processa **todas** as linhas pendentes da base. Com um número, só as linhas com aquele número na coluna `MAQUINA`.

> [!TIP]
> Deixe o **ClickYesWeb** ligado no menu principal (o botão mostra *ClickYesWeb Parar* quando está ligado). Ele clica sozinho em **OK** nas janelas *"Mensagem da página da web"* do GCPJ. Ele já liga sozinho quando o programa abre.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** cada linha da base só é marcada como feita (`ATUALIZADO` ou `IMPORTADO`) quando o robô termina ela. Então, quando chega uma RO sobre um processo, o primeiro passo é achar a linha dele na base da tela e ver se está marcada.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um processo ➜ 2 Abrir a base .mdb da tela usada no pedido ➜ 3 Achar a linha pelo número do GCPJ ➜ resultado verde (deu certo), amarelo (alguém precisa olhar) ou vermelho (não foi feito: corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que a conta de um depósito do processo 123456 não foi preenchida. Na `Depositos_Judiciais`, a linha dele está com `ATUALIZADO` **desmarcado**. Pelo quadro amarelo do C@JH, isso costuma acontecer quando o robô não achou o depósito e a pessoa clicou em *Sim*. Basta conferir `DATA` e `VALOR` na base e rodar de novo.

### C@JH · Altera_Ag_Conta

#### 🟢 Deu certo: não precisa fazer nada

| O que aparece | O que quer dizer |
| :--- | :--- |
| Coluna `ATUALIZADO` **marcada** | O robô salvou os dados da conta no GCPJ |
| *Conexão Efetuada!* | O robô achou o GCPJ aberto e já pode processar |
| *Distribuição Efetuada* | As linhas pendentes foram divididas entre as máquinas |

#### 🟡 Precisa que alguém olhe

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| *Sistema não conseguiu encontrar o Deposito.  Marque o Deposito Manualmente antes de clique em Sim. Ou clique em Não para cancelar o processo!* | A pesquisa (GCPJ + data) não trouxe um depósito com o mesmo **valor** da base, nem nas outras páginas da lista | **Atenção:** hoje o *Sim* **pula** esse depósito (nada é salvo e a linha continua pendente). O *Não* para a execução. Confira `DATA` e `VALOR` na base ou preencha manualmente no GCPJ |
| *A Tela não limpou. Deseja Continuar?* | Depois de salvar, o campo da agência continuou preenchido: o GCPJ pode não ter salvo | Olhe o GCPJ antes de responder. *Sim* **marca a linha como feita**. *Não* para e a linha continua pendente |
| *Acabou* logo depois do aviso do Controle S5 | A execução parou no limite, não no fim da base | Rodar de novo para continuar |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| *Horário após as 22:00* | O robô para às 22h | Rodar de novo no dia seguinte. Ele continua de onde parou |
| *Nenhum Processo Encontrado* (no *Distribuir Máquinas*) | Não há linha com `ATUALIZADO` desmarcado | Conferir se a base foi preenchida |
| Janela de erro do Windows e o robô para | Algum campo do GCPJ não apareceu (processo ou data inválidos, GCPJ fora do ar, sessão expirada) | Logar de novo, conferir a linha e rodar. A linha da vez continua pendente |

### D@EO · Inclusao_Evento

#### 🟢 Deu certo: não precisa fazer nada

| O que aparece | O que quer dizer |
| :--- | :--- |
| Coluna `IMPORTADO` **marcada** | O robô incluiu e salvou o evento no GCPJ |
| *Acabou!* | Terminou esta execução. Se antes apareceu o aviso do Controle S5, ainda há linhas pendentes |

#### 🟡 Precisa que alguém olhe

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| *A Tela não limpou. Deseja Continuar?* | Depois de clicar em *Incluir*, o campo de fase continuou preenchido: o evento pode não ter entrado (por exemplo, código inválido) | Olhe o GCPJ antes de responder. *Sim* **salva e marca a linha como feita**. *Não* para e a linha continua pendente |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| Janela de erro do Windows e o robô para | A rotina não tem tratamento de erro: processo inexistente, GCPJ lento ou sessão expirada derrubam a execução | Logar de novo, conferir `GCPJ` e `EVENTO` da linha e rodar. A linha da vez continua pendente |
| *Nenhum Processo Encontrado* (no *Distribuir Máquinas*) | Não há linha com `IMPORTADO` desmarcado | Conferir se a base foi preenchida |

> [!IMPORTANT]
> **Para refazer uma linha, ela precisa voltar a ficar pendente.** O robô só lê linhas com `ATUALIZADO` (C@JH) ou `IMPORTADO` (D@EO) **desmarcado**. No Access, abra a tabela, ache o processo pela coluna `GCPJ` e desmarque a caixinha. Linhas que o robô não terminou já ficam pendentes sozinhas.

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| A tela não aparece no menu | A base `.mdb` dela não está na pasta do executável | Copiar a base para a pasta (ver tabela *Todas as telas*) |
| O botão de processar está cinza | Ainda não conectou no GCPJ | Clicar em **Conectar GCPJ**, logar e clicar de novo até *"Conexão Efetuada!"* |
| Cliquei em processar e já veio *"Acabou"* | Não há linha pendente para o número escolhido em *Máquina* | Conferir a coluna `MAQUINA` ou deixar o campo em branco |
| O provedor *Microsoft.ACE.OLEDB.12.0* não está registrado | Falta o Access Database Engine 32 bits | Instalar a versão **32 bits** |
| D@EO "travou" depois das 22h ou no sábado | É a pausa programada: 10 horas a partir das 22h e 48 horas no sábado. A janela pode ficar como *Não está respondendo* | Esperar. Ao voltar, a lista mostra *"22:00!!! Aguardando até as 08:00 de amanha!"* ou *"Sabado!!! Só segunda as 08:00 ok??"* |
| C@JH parado depois de salvar, sem mensagem | O robô espera o aviso do GCPJ depois do *Salvar* e não tem limite de tempo | Fechar e abrir de novo. A linha da vez continua pendente |
| Aviso **Processamento Limitado - Controle S5** | Chegou a 5.000 registros nesta execução | Normal. Rodar de novo continua de onde parou |

<details>
<summary><b>Outras telas</b> &nbsp;·&nbsp; o que cada OBS quer dizer</summary>
<br>

Estas telas escrevem uma coluna `OBS` na base. Linha marcada **sem** OBS quer dizer que deu certo.

| Tela | O que está escrito na OBS | O que quer dizer |
| :--- | :--- | :--- |
| Aprovacao_Encerramento | Aprovação de Encerramento Efetuada | Deu certo |
| | Processo não Disponível para Encerramento | O processo não estava na lista de pendências de encerramento |
| | Erro ao Efetuar Encerramento | Depois de *Aprovar*, o GCPJ não voltou para a tela de pesquisa. Conferir manualmente |
| Atualizacao_Evento_Realizado | MAIS DE 1 EVENTO | Não conseguiu selecionar o evento na lista. Nada foi salvo, mas a linha foi marcada |
| Distribuicao | GCPJ Duplicado na Planilha | Mesmo GCPJ da linha anterior. Foi pulado |
| | A TELA NÃO LIMPOU | Depois de salvar, o campo do advogado continuou preenchido. Conferir no GCPJ |
| Cadastro_Honorarios | ATO CADASTRADO | Deu certo |
| | PROCESSO SEM DESTINATÁRIO | O GCPJ não trouxe o destinatário e o ato não foi incluído |
| | ERRO NO CADASTRO | O GCPJ não confirmou o cadastro |
| Inserir_Deposito | ERRO AO CADASTRAR | Depois de salvar, continuou na mesma tela |
| Alterar_Procs_CI | PROCESSO BAIXADO OU COM ERRO | Não conseguiu abrir a parte de envolvidos do processo |
| Cadastro_Envolvido | Erro ao Cadastrar | Depois de salvar, o nome continuou na tela |
| Procs_CI_Alterar_Processo | Processo Alterado pelo Advogado | O número no GCPJ já é diferente do `NRO_PROCESSO` da base. Não mexeu |
| | Erro ao Salvar Processo | O GCPJ não voltou para a pesquisa depois de salvar |
| Migracao | MIGRADO COM SUCESSO | Deu certo |
| Redistribuicao | REDISTRIBUIDO COM SUCESSO! | Deu certo |

</details>

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim. Os códigos `C@JH` e `D@EO` apontam para este executável, então o controle foi colocado em **todas** as telas que mexem no GCPJ, não só nas duas do inventário.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada linha o robô confere se já tratou 5.000; se não, trata e soma 1; se sim, para e avisa o usuário" width="100%">
</picture>

Quando o limite é atingido, aparece o aviso **Processamento Limitado - Controle S5** com o texto *"O limite de processamento de 5.000 registros foi atingido."* e *"Os itens restantes continuam pendentes e podem ser processados em uma nova execução."*. O que sobrou continua pendente na base `.mdb`. Na tela Aprovar_Migracao o aviso fala em **25 lotes**.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** (todas as telas) | `Mod_LimitadorS5.vb` | constante `LIMITE_OPERACOES_S5`, linha 25 |
| Limite de lotes (só Aprovar_Migracao) | `Mod_LimitadorS5.vb` | constante `LIMITE_LOTES_S5`, linha 31 |
| Mensagem do aviso | `Mod_LimitadorS5.vb` | função `LimiteS5Atingido`, linha 42 |
| Checagem do C@JH | `Frm_Altera_Ag_Conta.vb` | `BTProcessar_Click`, bloco `[S5]` na linha 158 |
| Checagem do D@EO | `Frm_Inclusao_Evento.vb` | `InclusaoEvento`, bloco `[S5]` na linha 291 |

> [!TIP]
> Para testar sem esperar 5.000 registros: troque `LIMITE_OPERACOES_S5` para `2`, deixe 3 linhas pendentes, rode, tire os prints com o relógio do Windows aparecendo e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra todos os pontos. As evidências oficiais estão em [`docs/Evidencias_S5_AutomacoesWeb.docx`](docs/Evidencias_S5_AutomacoesWeb.docx).

<details>
<summary><b>Todos os pontos <code>[S5]</code></b> &nbsp;·&nbsp; 30 checagens em 23 telas</summary>
<br>

Cada rotina tem uma linha que cria o contador (`Dim qtdOperacoesS5`, no começo da rotina) e um bloco de 3 linhas no começo do laço. A coluna **Linha** é a do `If LimiteS5Atingido(...)`.

| Arquivo | Rotina | Linha | No executável? |
| :--- | :--- | :---: | :--- |
| `Frm_Altera_Ag_Conta.vb` · **C@JH** | `BTProcessar_Click` | 158 | Sim |
| `Frm_Inclusao_Evento.vb` · **D@EO** | `InclusaoEvento` | 291 | Sim (é a rotina que o botão chama) |
| `Frm_Inclusao_Evento.vb` | `AtualizacaoEvento` | 85 | Sim, mas a chamada está comentada |
| `Frm_Inclusao_Evento.vb` | `InclusaoSineDee` | 203 | Sim, mas a chamada está comentada |
| `Frm_Inclusao_Evento.vb` | `AlterarDataEvento` | 460 | Sim, mas a chamada está comentada |
| `Frm_Alteracao_Classificacao.vb` | `BTProcessar_Click` | 63 | Sim |
| `Frm_Alterar_Procs_CI.vb` | `BTProcessar_Click` | 138 | Sim |
| `Frm_Aprovacao_Encerramento.vb` | `BTProcessar_Click` | 61 | Sim |
| `Frm_Aprovar_Migracao.vb` | `BTProcessar_Click` (por **lote**, `Exit Do`) | 78 | Sim |
| `Frm_Atualizacao_Evento_Realizado.vb` | `BTProcessar_Click` | 104 | Sim |
| `Frm_Atualizar_Valor_Calculo.vb` | `Rotina_Alteracao` | 77 | Sim, mas a chamada está comentada |
| `Frm_Atualizar_Valor_Calculo.vb` | `Rotina_Cadastro` | 237 | Sim |
| `Frm_Cadastro_Consultoria_Negocios.vb` | `BTCadastrar_Click` | 182 | Sim |
| `Frm_Cadastro_Envolvido.vb` | `BTProcessar_Click` | 121 | Sim |
| `Frm_Cadastro_Honorarios.vb` | `BTProcessar_Click` | 194 | Sim |
| `Frm_Cadastro_Processos_CI.vb` | `BTProcessar_Click` | 84 | Sim |
| `Frm_Captura_Fundamento.vb` | `BTProcessar_Click` | 80 | Sim |
| `Frm_Distribuicao.vb` | `BTProcessar_Click` | 103 | Sim |
| `Frm_Impressao_Planilha.vb` | `BTProcessar_Click` | 55 | Sim |
| `Frm_Inserir_Deposito.vb` | `BTProcessar_Click` | 83 | Sim |
| `Frm_Inserir_Evento_Pendencia.vb` | `BTProcessarInclusao_Click` (`Exit Do`) | 129 | Sim |
| `Frm_Inserir_Evento_Pendencia.vb` | `BTProcessarValidacao_Click` (`Exit Do`) | 324 | Sim |
| `Frm_Migracao.vb` | `MigrarProcessos_Click` | 65 | Sim |
| `Frm_Procs_CI_Alterar_Processo.vb` | `BTProcessar_Click` | 79 | Sim (tela fora do menu) |
| `Frm_Redistribuicao.vb` | `BtProcessarRedistribuicao_Click` | 183 | Sim |
| `Frm_Altera_Pessoa_Externa.vb` | `BTProcessar_Click` | 59 | Não (fora do `.vbproj`) |
| `Frm_Baixar_Comprovante.vb` | `BTProcessar_Click` | 92 | Não (fora do `.vbproj`) |
| `Frm_Inserir_Reclamante_Reclamada.vb` | `RodarEspecifico` (`Exit Do`) | 87 | Não (fora do `.vbproj`) |
| `Frm_Inserir_Reclamante_Reclamada.vb` | `ProcessaTR` (`Exit Do`) | 219 | Não (fora do `.vbproj`) |
| `Frm_Inserir_Reclamante_Reclamada.vb` | `ProcessaCI` (`Exit Do`) | 325 | Não (fora do `.vbproj`) |

**Regras usadas para posicionar o bloco:**

- O `Dim` fica na **primeira linha da rotina**, antes de qualquer rótulo. Assim um `GoTo` de volta não zera o contador.
- Quando o laço tem rótulo de "tentar de novo o mesmo registro", o bloco fica **antes** do rótulo, para a nova tentativa não contar duas vezes.
- Quando o rótulo serve para **pular para o próximo** registro (`index += 1` e `GoTo`), o bloco fica **depois** do rótulo, para o pulo também contar.
- O aviso do S5 tem título próprio, então o **ClickYesWeb não fecha** esse aviso (ele só clica em *"Mensagem da página da web"*).

</details>

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `Automacoes_Web.vbproj` (solução `Automacoes_Web.sln`). Tela inicial: `Frm_Principal`.

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `Frm_Principal.vb` | `Frm_Principal_Load` | 32 | Monta o menu: uma tela para cada base `.mdb` achada na pasta (linhas 33 a 51). Com uma só, abre direto (62) |
| | `MataMsgBox` | 74 | ClickYesWeb: clica OK em *"Mensagem da página da web"* |
| | `BTClickYes_Click` | 103 | Liga e desliga o ClickYesWeb. É acionado sozinho no `Load` (71) |
| | `Grade_DoubleClick` | 126 | Abre a tela escolhida dentro do menu |
| `Mod_Funcoes.vb` | `Espera_Ate_Que_Abra_Public` | 5 | Espera o IE carregar, com limite de 5 minutos |
| | `SQL_Texto` / `SQL_Data` | 46 / 27 | Montam valores para o SQL (tiram aspas simples) |
| `Mod_LimitadorS5.vb` | `LIMITE_OPERACOES_S5` / `LIMITE_LOTES_S5` | 25 / 31 | Controle S5 |
| | `LimiteS5Atingido` | 42 | Confere o contador e mostra o aviso |
| `Frm_Altera_Ag_Conta.vb` · **C@JH** | `Conexao` | 49 | Base `BD_Altera_Ag_Conta.mdb` |
| | `BTConectaGCPJ_Click` / `VerificaGCPJ` | 67 / 78 | Acha um IE com "GCPJ" no título ou abre um novo |
| | `BTDistribuir_Click` | 94 | Reparte as linhas pendentes entre as máquinas |
| | `BTProcessar_Click` | 129 | Ação **C@JH** |
| | `Espera_Ate_Que_Abra` / `MataMsgbox` | 57 / 37 | Espera o IE e fecha o aviso do GCPJ (sem limite de tempo) |
| `Frm_Inclusao_Evento.vb` · **D@EO** | `Conexao` | 8 | Base `BD_Inserir_Evento.mdb` |
| | `BTProcessar_Click` | 44 | Botão *Processar Inclusão*. Chama só `InclusaoEvento` (46) |
| | `InclusaoEvento` | 262 | Ação **D@EO** |
| | `AtualizacaoEvento` / `InclusaoSineDee` / `AlterarDataEvento` | 51 / 181 / 439 | Rotinas antigas, com a chamada comentada |
| | `BTDistribuir_Click` | 516 | Reparte as linhas pendentes entre as máquinas |
| `Frm_Login.vb` | `BTOk_Click` | 27 | Login próprio, usado só pela tela Cadastro_Consultoria_Negocios (`Frm_Cadastro_Consultoria_Negocios.vb`, linha 18) |

</details>

<details>
<summary><b>Como as telas do inventário funcionam por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>

**C@JH · Altera_Ag_Conta** (`BTProcessar_Click`)

1. Lê as linhas com `atualizado = false` (da máquina escolhida, se houver), em ordem de GCPJ e data (141 / 143).
2. Abre a tela de depósitos sem conta (`finDepFaltaConta?metodo=carregar`, linha 163). Se já passou das 22h, para (166).
3. Pesquisa pelo GCPJ com período de `DATA` a `DATA` (176 a 182).
4. Se veio um só depósito, marca ele (191). Se veio mais de um, procura na lista a linha com a mesma data e o mesmo `VALOR`, passando pelas páginas (197 a 253). Se não achar, mostra a pergunta *"Sistema não conseguiu encontrar o Deposito..."* (255).
5. Clica em *Detalhar* (265) e preenche banco, agência, conta e dígito (269 a 272). Se `BANCO` = 104, preenche também a operação (277 a 279). Escolhe o tipo de conta "Judicial" (286).
6. Clica em *Salvar* (290), fecha o aviso do GCPJ (293), confere se a tela limpou (297 a 300) e marca `ATUALIZADO` (305).

**D@EO · Inclusao_Evento** (`InclusaoEvento`)

1. Lê as linhas com `IMPORTADO = false` (da máquina escolhida, se houver), em ordem de GCPJ e evento (274 / 276).
2. A partir das 22h dorme 10 horas (297 a 303). No sábado dorme 48 horas (305 a 311).
3. Abre a tela de inclusão de evento (`traTraCpmisAtulzEvntoAction?acao=carregar`, linha 314) e pesquisa o GCPJ (324 e 325).
4. Escolhe a fase (segunda opção da lista, linha 330), informa o código `EVENTO` (331) e confirma pela lupa do código (333).
5. Clica em *Incluir* (345), confere se a tela limpou (349 e 350), clica em *Salvar* (354) e marca `IMPORTADO` (432).

</details>

<details>
<summary><b>Banco de dados</b> &nbsp;·&nbsp; uma base Access por tela</summary>
<br>

Todas as bases ficam na pasta do executável (`Application.StartupPath`), menos a de honorários, que fica numa subpasta com o nome do usuário do Windows.

| Tela | Base | Tabela | Coluna "feito" |
| :--- | :--- | :--- | :--- |
| **Altera_Ag_Conta** · C@JH | `BD_Altera_Ag_Conta.mdb` | `Depositos_Judiciais` | `ATUALIZADO` |
| **Inclusao_Evento** · D@EO | `BD_Inserir_Evento.mdb` | `TB_Principa` | `IMPORTADO` |
| Alteracao_Classificacao | `BD_Alteracao_Classificacao.mdb` | `TB_Alteracao_Classificacao` | `importado` |
| Alterar_Procs_CI | `BD_Cadastro_Processos_CI.mdb` | `Processos_CI` | `importado` + `obs` |
| Aprovacao_Encerramento | `BD_Dados_Aprovacao_Encerramento.mdb` | `TB_Aprovacao_Encerramento` | `ATUALIZADO` + `Obs` |
| Aprovar_Migracao | `BD_Aprovar_Migracao.mdb` (só libera o menu) | nenhuma | nenhuma |
| Atualizacao_Evento_Realizado | `BD_Alterar_Evento.mdb` | `TB_Principa` | `importado` + `obs` |
| Atualizar_Valor_Calculo | `BD_Atualizacao_Valor_Calculo.mdb` | `TB_Atualizacao_Calculo` | `importado` |
| Cadastro_Consultoria_Negocios | `BD_Cadastro_Consultoria_Negocios.mdb` | `TB_PROCS_INTERNO` (login em `TB_USUARIOS`) | `atualizado` + `obs` |
| Cadastro_Envolvido | `BD_Cadastro_Processos_CI.mdb` | `CADASTRO_ENVOLVIDO` | `importado` + `obs` |
| Cadastro_Honorarios | `<usuário>\BD_Cadastro_Honorarios.mdb` | `TB_NOTAS` e `Planilha_Importada` | `importado` + `Obs` |
| Cadastro_Processos_CI | `BD_Cadastro_Processos_CI.mdb` | `Processos_CI` | `importado` + `obs` |
| Captura_Fundamento | `BD_Dados_Fundamento.mdb` | `TB_FUNDAMENTO` | `importado` + `fundamento` |
| Distribuicao | `BD_Distribuicao.mdb` | `TB_Distribuicao` | `importado` + `OBS` |
| Impressao_Planilha | `BD_Impressao_Planilha.mdb` | `processos` | `importado` |
| Inserir_Deposito | `BD_Inserir_Deposito.mdb` | `Depositos` | `ATUALIZADO` + `obs` |
| Inserir_Evento_Pendencia | `BD_Tramite_Pendencias.mdb` | `TB_Ultimo_Evento_Futuro` (histórico em `Log_Geral`) | `Log_Geral` |
| Migracao | `BD_Migracao.mdb` | `tbMigracao` | `MIGRADO` + `OBS` |
| Procs_CI_Alterar_Processo | `BDDados_Acerto_Processos_CI.mdb` | `PROCESSOS_MENORES_20_DIGITOS_CI` | `importado` + `obs` |
| Redistribuicao | `BD_Redistribuicao.mdb` | `tbRedistribuicao` | `REDISTRIBUIDO` + `OBS` |

As bases **não estão no repositório**. A ligação planilha ➜ tabela de C@JH e D@EO é feita no Access, fora do programa.

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `Mod_LimitadorS5.vb` ➜ `LIMITE_OPERACOES_S5` |
| Liberar uma tela para um usuário | Copiar a base `.mdb` dela para a pasta do executável |
| Mudar a lista do menu | `Frm_Principal.vb` ➜ `Frm_Principal_Load` |
| Mudar o horário de parada do C@JH (22h) | `Frm_Altera_Ag_Conta.vb` ➜ linha 166 |
| Mudar a pausa do D@EO (22h e sábado) | `Frm_Inclusao_Evento.vb` ➜ linhas 297 a 311 |
| Trocar a rotina que o D@EO roda | `Frm_Inclusao_Evento.vb` ➜ `BTProcessar_Click` (linhas 44 a 49) |
| Mudar o tempo máximo de espera do IE | `Mod_Funcoes.vb` ➜ `Espera_Ate_Que_Abra_Public` |
| Mudar o "clicador" de mensagens | `Frm_Principal.vb` ➜ `MataMsgBox` / `BTClickYes_Click` |
| Mudar o endereço do GCPJ | Procure `www4.net.bradesco.com.br/gcpj` nas telas |
| Criar uma tela nova já com S5 | Crie o `Frm_` e a base `BD_...mdb`, adicione a linha no `Frm_Principal_Load`, coloque o `Dim qtdOperacoesS5` na primeira linha da rotina e o bloco `[S5]` no começo do laço |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **C@JH, o *Sim* da pergunta do depósito pula a linha.** A mensagem pede para marcar o depósito manualmente e clicar em *Sim*, mas o *Sim* vai direto para o próximo registro (`GoTo fim`, linha 259): não detalha, não salva e não marca a linha. O `update` que marcava a linha está comentado nas linhas 256 e 257.
- **C@JH pode ficar esperando para sempre.** `Espera_Ate_Que_Abra` (57) e `MataMsgbox` (37) não têm limite de tempo. Se o aviso do GCPJ não aparecer depois do *Salvar* (ou se outro clicador fechar ele antes), a tela fica parada.
- **D@EO pausa travando a janela.** A pausa usa `Thread.Sleep` de 10 horas (298) e de 48 horas (306) na própria tela, então ela fica *Não está respondendo*. A mensagem da pausa só aparece **depois** que a pausa termina.
- **D@EO preenche só fase e código.** O inventário fala em "código e justificativa", mas a rotina ativa (`InclusaoEvento`) informa a fase e o código do evento. O campo de data está comentado (332) e o texto de resumo só existe na rotina `AtualizacaoEvento`, que não é chamada.
- **Sem tratamento de erro nas rotinas do C@JH e do D@EO** (fora a busca do depósito). Qualquer campo que o GCPJ não mostrar derruba a execução com a janela de erro do Windows.
- **Tela fora do menu:** `Frm_Procs_CI_Alterar_Processo` está no executável, mas não há linha para ela no `Frm_Principal_Load`. As linhas 52 a 60 do menu estão vazias (`"\.mdb"`).
- **Honorários:** o menu procura `BD_Cadastro_Honorarios.mdb` na pasta do programa (linha 38 do `Frm_Principal.vb`), mas a tela abre a base dentro da subpasta do usuário (linha 8 do `Frm_Cadastro_Honorarios.vb`).
- **Aprovar_Migracao não tem fim natural** (`Do While x = 0`). O limite de 25 lotes do S5 é o que garante a parada.
- **SQL montado por concatenação** em todas as telas, inclusive o número da máquina e a `CHAVE_INTERNA`.
- **Distribuir Máquinas sem validação.** O valor digitado em *"Informe a Quantidade de Máquina"* vai direto para um número (linha 108 do C@JH, 530 do D@EO). Cancelar ou deixar em branco dá erro.
- **Dados reais versionados.** A pasta `bin/Debug/19028/` tem um e-mail de RO (`.msg`), uma página salva do GCPJ (`.mht`) e planilhas de depósitos. Também há planilhas `.xlsx` soltas em `bin/Debug/`. Esses arquivos deveriam sair do repositório.
- As pastas `bin`, `obj`, `publish` e `.vs` estão versionadas; são geradas pelo Visual Studio e podem ser ignoradas.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 2012 primeira versão (ano no AssemblyInfo); 01/2026 migração para o GitHub; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: revisar o Sim do C@JH" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 2012 | (sem registro) | Ano do `Copyright` no `AssemblyInfo.vb`. Não há histórico antes do GitHub |
| 01/2026 | Daniela Chirinian | Primeiro commit (migração para o GitHub) |
| 01/2026 | vogon-fleet-app[bot] | Criação do repositório e do `CODEOWNERS` via Terramate |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`Mod_LimitadorS5.vb`) em todas as telas e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
