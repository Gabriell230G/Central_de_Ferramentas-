<div align="center">

<img src="docs/readme/header.svg" alt="Envia Depósitos GCPJ: envia, um a um, todos os depósitos da lista Depósitos a Enviar do GCPJ, sem planilha" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: C#" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET 4.6.1" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="navegador: Internet Explorer" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o robô abre a lista **Depósitos a Enviar** do GCPJ e envia os depósitos um a um, sempre o primeiro da lista, até a lista acabar.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 2 botões na tela do robô; 1 lista do GCPJ (A Enviar); 5.000 depósitos por execução (Controle S5); 7 mensagens da grade explicadas" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Conectar GCPJ ➜ 2 Lista Depósitos a Enviar do Financeiro ➜ 3 Robô com Controle S5 marca o primeiro depósito ➜ 4 Clica em Enviar e no OK do aviso do GCPJ ➜ 5 Resultado: contagem na grade e lista vazia no GCPJ" width="100%">
</picture>

### Os dois botões

| Botão na tela | O que faz | Quando libera |
| :--- | :--- | :--- |
| **Conectar GCPJ** | Procura um Internet Explorer com "GCPJ" no título. Se não acha, abre um IE novo no GCPJ e pede para fazer login e clicar de novo | Sempre |
| **Enviar Depósitos** | Abre a tela *Depósitos a Enviar* do Financeiro e envia os depósitos um a um, contando na grade quantos já foram | Só depois que a grade mostrar *GCPJ localizado, prossiga com a automação* |

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `aajr-cmn-enviadepositogcpj-auto` |
| **Código no inventário** | `C@KR` · Automação envia depósito no GCPJ |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em C# Windows Forms, .NET Framework 4.6.1 |
| **Sistema que altera** | GCPJ, tela *Depósitos a Enviar* do Financeiro |
| **Entrada** | Nenhuma planilha: o robô trabalha com o que estiver na lista do GCPJ naquele momento |
| **Saída** | Depósitos enviados no GCPJ + mensagens na grade da tela do robô |
| **Base local** | Não usa |
| **Instalação** | `\\mz-vv-fs-138\D4040_4\Publico\Backup_sistemas\Contabilidade\_PADRAO\ENVIA_DEPOSITO_GCPJ\` |
| **Controle S5** | Até **5.000 depósitos por execução** |

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Abrir o sistema ➜ 2 Conectar GCPJ ➜ 3 Logar no IE (só se o GCPJ não estava aberto) ➜ 4 Conectar de novo ➜ 5 Enviar Depósitos (até a lista acabar ou chegar a 5.000) ➜ 6 Conferir a grade e a lista no GCPJ" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Abra o `EnviaDepositoGCPJ.exe` na pasta do sistema. A grade mostra *Bem vindo ao envia depósito, por favor conecte ao GCPJ* |
| **2** | Clique em **Conectar GCPJ**. Se o GCPJ já estava aberto e logado no Internet Explorer, a grade mostra *GCPJ localizado, prossiga com a automação* e você pula para a parada **5** |
| **3** | Se a grade mostrar *GCPJ não localizado, abrindo nova instância, favor fazer login e tentar novamente*, faça login no Internet Explorer que o robô abriu |
| **4** | Clique de novo em **Conectar GCPJ**. Com *GCPJ localizado, prossiga com a automação*, o botão **Enviar Depósitos** libera |
| **5** | Clique em **Enviar Depósitos**. A cada envio a grade mostra *Foram aprovados: N até o momento*. Se chegar a 5.000, o robô para sozinho e avisa (Controle S5) |
| **6** | Quando aparecer *Processamento realizado com sucesso!*, abra **Depósitos a Enviar** no GCPJ e confira se a lista ficou vazia |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e o que saber antes de clicar</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com **Internet Explorer** e acesso ao GCPJ (login próprio)
- **.NET Framework 4.6.1** ou mais novo
- Internet Explorer em **português**: o robô procura o aviso do GCPJ pelo título *Mensagem da página da web*

Não precisa de planilha, Access nem Excel.

> [!TIP]
> **Tudo o que estiver na lista será enviado.** O robô não escolhe depósito: ele sempre marca o primeiro da lista *Depósitos a Enviar* e clica em *Enviar*, até a lista acabar. Antes de clicar em **Enviar Depósitos**, abra a lista no GCPJ e confira se tudo ali pode mesmo ser enviado. Durante a execução, não use esse Internet Explorer.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** este robô não usa planilha e não grava histórico. As provas do que aconteceu são duas: a **grade** da tela do robô (enquanto a janela estiver aberta) e a lista **Depósitos a Enviar** do GCPJ. Se o depósito saiu da lista, o envio foi feito. Se continua lá, não foi.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um depósito ➜ 2 Ler a grade do robô, se a janela estiver aberta ➜ 3 Conferir a lista Depósitos a Enviar no GCPJ ➜ resultado verde (deu certo, nada a fazer), amarelo (rodar de novo ou enviar manualmente) ou vermelho (corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que um depósito não foi enviado. No GCPJ, ele ainda aparece em *Depósitos a Enviar*. Na grade do robô, logo depois de `Navegando para a tela de envio de depósitos` vem `Processamento realizado com sucesso!`, sem nenhum `Foram aprovados`. Pelo quadro vermelho, isso quer dizer que o robô não conseguiu marcar nenhum depósito na tela (por exemplo, o GCPJ pediu login de novo). Basta logar, clicar em **Conectar GCPJ** e rodar de novo.

> [!IMPORTANT]
> **A grade não guarda nada depois que o robô fecha.** Ela também não mostra o número do depósito, só a contagem. Se a execução precisar ser explicada depois, tire um print da grade **antes de fechar** o robô.

#### 🟢 Deu certo: não precisa fazer nada

| O que aparece | O que quer dizer |
| :--- | :--- |
| Na grade: *Foram aprovados: N até o momento* | O robô clicou em *Enviar* e no *OK* do aviso do GCPJ pela N-ésima vez nesta execução |
| Na grade: *Processamento realizado com sucesso!* depois de linhas *Foram aprovados*, e a lista do GCPJ vazia | O robô terminou e não sobrou nada para enviar |
| No GCPJ: o depósito da RO não está mais em *Depósitos a Enviar* | O envio desse depósito já foi feito |

#### 🟡 Precisa que alguém olhe

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| Na grade: *Controle S5: limite de 5.000 registros atingido. Processamento interrompido.* | Chegou ao limite do Controle S5 nesta execução | Normal. Rodar de novo: o que sobrou continua na lista do GCPJ |
| Na grade: *Processamento realizado com sucesso!*, mas a lista do GCPJ ainda tem depósitos | O robô parou de achar depósito para marcar antes de a lista acabar | Rodar de novo. Se sobrar sempre o mesmo depósito, enviar manualmente e ler a mensagem do GCPJ |
| A contagem *Foram aprovados* sobe, mas a lista do GCPJ não diminui | O robô sempre pega o **primeiro** da lista. Se o GCPJ não aceitar esse depósito, ele tenta o mesmo de novo | Encerrar o robô e enviar esse depósito manualmente, lendo a mensagem do GCPJ |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| Na grade: *Navegando para a tela de envio de depósitos* e logo em seguida *Processamento realizado com sucesso!*, sem nenhum *Foram aprovados* | Nenhum depósito foi marcado: a lista estava vazia ou a tela não abriu (por exemplo, sessão do GCPJ expirada) | Abrir *Depósitos a Enviar* no GCPJ. Se houver itens, logar de novo, clicar em **Conectar GCPJ** e rodar |
| Uma caixa com a palavra *erro!* | O robô não achou o botão *Enviar* na tela do GCPJ | Depois do *OK*, o robô fica esperando um aviso que não vem. Encerrar o robô, conferir o GCPJ e rodar de novo |
| A grade não muda por muito tempo | O robô está esperando a página carregar ou o aviso *Mensagem da página da web* aparecer | Olhar o Internet Explorer. Se a página deu erro ou a sessão caiu, encerrar o robô (pelo Gerenciador de Tarefas, se precisar), logar e rodar de novo |

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| *GCPJ não localizado, abrindo nova instância, favor fazer login e tentar novamente* | Não havia Internet Explorer aberto com "GCPJ" no título | Logar no IE que o robô abriu e clicar de novo em **Conectar GCPJ** |
| Cliquei em **Conectar GCPJ** e nenhum IE apareceu | O robô cria o IE novo sem mandar mostrar a janela (ver *Pontos de atenção*) | Clicar de novo em **Conectar GCPJ**: quando o robô acha a janela, ele a deixa visível. Fazer login antes de enviar |
| O botão **Enviar Depósitos** está cinza | Ele só libera depois de *GCPJ localizado, prossiga com a automação* | Clicar em **Conectar GCPJ** |
| *GCPJ localizado* apareceu, mas o envio não faz nada | O robô só confere o título da janela, não se o login foi feito | Logar no GCPJ e clicar em **Enviar Depósitos** de novo |
| O Windows diz que o programa *não está respondendo* | O robô trabalha na mesma linha da tela, então a janela pode parecer travada | Esperar e acompanhar pela lista do GCPJ. Só encerrar se nada andar por muito tempo |
| Aviso **Processamento Limitado - Controle S5** | Chegou a 5.000 depósitos nesta execução | Normal. Rodar de novo continua de onde parou |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim. O `C@KR` agora tem o controle: no máximo **5.000 depósitos por execução**. A rotina já tinha um contador de depósitos enviados (`contador`), e o Controle S5 usa esse mesmo contador.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada depósito o robô confere o contador; enquanto não chegou a 5.000, envia e soma 1; ao chegar em 5.000, para, avisa o usuário e anota na grade" width="100%">
</picture>

Quando o limite é atingido, aparece o aviso **Processamento Limitado - Controle S5** com o texto *"O limite de processamento de 5.000 registros foi atingido. Os itens restantes continuam pendentes e podem ser processados em uma nova execução."*, e a grade mostra *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*. Logo depois a grade também mostra *Processamento realizado com sucesso!*, porque essa linha aparece em todo fim de execução. O que sobrou continua na lista *Depósitos a Enviar* para a próxima execução.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `LimitadorS5.cs` | constante `LIMITE_OPERACOES`, linha 26 |
| Mensagem do aviso | `LimitadorS5.cs` | método `LimiteAtingido`, linha 35 |
| Texto que vai para a grade | `LimitadorS5.cs` | método `MensagemLog`, linha 47 |
| Checagem no laço de envio | `Form1.cs` | `btnEnvia_Click`, bloco `[S5]` na linha 61 |

> [!TIP]
> Para testar sem esperar 5.000 depósitos: troque `LIMITE_OPERACOES` para `2`, rode com pelo menos 3 depósitos na lista (os 2 primeiros **serão enviados de verdade**), tire os prints com o relógio do Windows aparecendo e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra o ponto de checagem. As evidências oficiais estão em [`docs/Evidencias_S5_EnviaDepositoGCPJ.docx`](docs/Evidencias_S5_EnviaDepositoGCPJ.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `EnviaDepositoGCPJ\EnviaDepositoGCPJ.csproj`

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `Form1.cs` | `toolStripButton1_Click` | 22 | Botão **Conectar GCPJ**: acha ou abre o IE e libera o **Enviar Depósitos** |
| | `preencheGrade` | 36 | Escreve uma linha na grade com data e hora |
| | `Form1_Load` | 47 | Mensagem de boas-vindas |
| | `btnEnvia_Click` | 52 | Botão **Enviar Depósitos**: o laço de envio |
| | bloco `[S5]` | 61 | Checagem do Controle S5 dentro do laço |
| `Form1.Designer.cs` | `btnEnvia.Enabled = false` | 74 | O botão de envio começa desligado |
| `Automacao.cs` | `localizarJanela` / `novaJanela` | 59 / 73 | Acha ou abre o IE do GCPJ |
| | `navegar` | 102 | Leva o IE para a URL da tela |
| | `clicar` | 165 | Clica num elemento do formulário pelo nome |
| | `espera` | 209 | Espera a página terminar de carregar |
| | `mataMsgBox` | 239 | Espera o aviso *Mensagem da página da web* e clica em *OK* |
| | `selecionarRadio` | 434 | Marca o rádio `itemSelecionado` de posição 0 (o primeiro da lista) |
| `LimitadorS5.cs` | `LIMITE_OPERACOES` | 26 | Controle S5 |
| | `LimiteAtingido` / `MensagemLog` | 35 / 47 | Aviso ao usuário e texto da grade |

O `Automacao.cs` é uma biblioteca genérica de automação de IE: só as 7 funções acima são usadas por este robô. O resto (anexos, cadastro PF/PJ, tabelas, validação de depósito do BB) não é chamado.

</details>

<details>
<summary><b>Como funciona por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>

**Conectar GCPJ**

1. `localizarJanela("GCPJ")` percorre as janelas do Internet Explorer abertas e pega a primeira cujo título contém `GCPJ`, deixando ela visível.
2. Se não achar, `novaJanela` cria um IE novo em `https://intranet85.net.bradesco.com.br/gcpj`, a grade pede login e o **Enviar Depósitos** fica desligado.

**Enviar Depósitos**

1. Zera o `contador` e navega para `.../gcpj/servlet/finDepAEnviarAction?metodo=carregar&origem=financeiro`.
2. Enquanto `selecionarRadio(0, "itemSelecionado")` conseguir marcar o primeiro rádio da lista:
   1. **[S5]** se `contador` já chegou em `LIMITE_OPERACOES`, avisa, escreve na grade e sai do laço;
   2. espera a página, clica no botão `btoEnviar` e fecha o aviso *Mensagem da página da web* com *OK*;
   3. soma 1 no `contador` e escreve *Foram aprovados: N até o momento*.
3. Quando não há mais rádio para marcar (lista vazia ou tela diferente), sai do laço e escreve *Processamento realizado com sucesso!*.

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `LimitadorS5.cs` ➜ `LIMITE_OPERACOES` |
| Mudar a tela do GCPJ que o robô abre | `Form1.cs` ➜ `btnEnvia_Click`, URL `finDepAEnviarAction` |
| Mudar o botão clicado no GCPJ | `Form1.cs` ➜ `Automacao.clicar("btoEnviar")` |
| Mudar qual item da lista é marcado | `Form1.cs` ➜ `Automacao.selecionarRadio(0, "itemSelecionado")` |
| Mudar o título do aviso que o robô fecha | `Automacao.cs` ➜ `mataMsgBox`, texto `Mensagem da página da web` |
| Mudar as mensagens da grade | `Form1.cs` ➜ chamadas de `preencheGrade` |
| Mudar o endereço do GCPJ | `Form1.cs` ➜ procure `intranet85.net.bradesco.com.br/gcpj` |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **O robô não lê a resposta do GCPJ.** Depois de clicar em *Enviar*, o `mataMsgBox` (`Automacao.cs`, linha 239) só clica em *OK* no aviso, sem ler o texto. O `contador` soma 1 de qualquer jeito (`Form1.cs`, linha 71). Ou seja: *Foram aprovados* conta **cliques**, não confirmações. Já existe no próprio `Automacao.cs` o `lerMsgBox` (linha 254), que lê o texto do aviso.
- **Sempre o primeiro da lista.** Se o GCPJ recusar o primeiro depósito e ele continuar na lista, o robô tenta o mesmo depósito de novo, até o Controle S5 parar em 5.000.
- **Esperas sem fim.** O `mataMsgBox` fica em laço até achar uma janela chamada *Mensagem da página da web* (linha 242), e o `espera` fica em laço enquanto o IE estiver carregando (linhas 212 e 217). Se o aviso não vier (por exemplo, depois do *erro!* do `clicar`, linha 181), o robô fica parado para sempre.
- **"Sucesso" em todo fim.** A linha *Processamento realizado com sucesso!* (`Form1.cs`, linha 75) aparece mesmo quando nada foi enviado ou quando o Controle S5 parou a execução.
- **IE novo sem `Visible = true`.** O `novaJanela` (`Automacao.cs`, linha 73) não manda mostrar a janela; só o `localizarJanela` faz isso (linha 66). Por isso pode ser preciso clicar duas vezes em **Conectar GCPJ** para ver o IE.
- **Login não é conferido.** O **Conectar GCPJ** só olha se o título da janela tem `GCPJ`.
- **Tela pode parecer travada.** O laço roda na mesma linha de execução da tela, sem `Application.DoEvents`, então o Windows pode marcar a janela como *não está respondendo* durante o envio.
- **Sem histórico.** Não há log em arquivo nem registro de usuário: o que aconteceu só fica na grade, até fechar o robô.
- **Referência fixa ao mshtml.** O `.csproj` aponta o `Microsoft.mshtml.dll` para a pasta do Visual Studio 10.0 (linha 39). Em outra máquina, pode ser preciso corrigir esse caminho para compilar.
- As pastas `bin`, `obj` e `.vs` estão versionadas; elas são geradas pelo Visual Studio e podem ser ignoradas. O `using System.Data.OleDb` do `Form1.cs` (linha 9) não é usado.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 10/2025 repositório criado no GitHub; 01/2026 código no GitHub; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: ler a resposta do GCPJ" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 10/2025 | vogon-fleet-app (automático) | Criação do repositório e do `CODEOWNERS` via Terramate |
| 01/2026 | Daniela Chirinian | Primeiro envio do código para o GitHub |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LimitadorS5.cs`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
