<div align="center">

<img src="docs/readme/header.svg" alt="Envio TED e Crédito em Conta: envia no GCPJ os depósitos judiciais que aguardam envio por TED ou por Crédito em Conta Bradesco" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: VB.NET" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET 4.8" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="base: Access" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o robô abre no GCPJ a lista de depósitos judiciais que estão aguardando envio e, linha por linha, envia os que são da área e da data escolhidas na tela, escrevendo na grade o que aconteceu com cada um.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 2 formas de envio no GCPJ; 5.000 envios por execução (Controle S5); áreas CI e TR filtradas pelo robô; 20 mensagens explicadas" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Data do depósito e área na tela ➜ 2 Lista Aguardando Envio no GCPJ ➜ 3 Robô com Controle S5 ➜ 4 Envio no GCPJ ➜ 5 Resultado na grade e no Tb_Log" width="100%">
</picture>

### Os dois envios

| Botão na tela | O que faz | Lista no GCPJ |
| :--- | :--- | :--- |
| **Enviar TED** | Envia por **TED** os depósitos da área e da data escolhidas | Financeiro Contábil ➜ Lançamentos ➜ Depósito Judicial ➜ *Aguardando Envio da TED* |
| **Enviar CRED** | Envia por **Crédito em Conta Bradesco** os depósitos da área e da data escolhidas | Financeiro Contábil ➜ Lançamentos ➜ Depósito Judicial ➜ *Aguardando Envio Crédito Bradesco* |

Os outros botões: **Conectar GCPJ** (acha o GCPJ aberto ou abre um novo e libera os dois envios) e **Cadastro Usuários** (novo usuário, editar nome, alterar senha).

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `aajr-cmn-enviotedecreditoemconta-a` |
| **Código no inventário** | `C@ZB` · Envio ted e crédito em conta |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em VB.NET Windows Forms, .NET Framework 4.8 |
| **Sistema que altera** | GCPJ (envio de depósitos judiciais) |
| **Entrada** | Data do depósito e área (**CI** ou **TR**), escolhidas na tela |
| **Saída** | Mensagens na grade da tela + histórico na `Tb_Log` |
| **Base local** | `BD\BD_DADOS.accdb`, ao lado do executável |
| **Acesso** | Login próprio, usuários na `Tb_Usuario` |
| **Instalação** | `\\d4040s006\d4040_01\Publico\SISTEMAS\4040006\EnvioTED_e_CreditoEmConta\` |
| **Projeto** | Pasta `ExcluiBaixa` (nome antigo, por herança); o executável gerado é o **EnvioTED** |
| **Controle S5** | Até **5.000 envios por execução** |

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Entrar no sistema ➜ 2 Conectar no GCPJ ➜ 3 Informar data e área ➜ 4 Escolher Enviar TED ou Enviar CRED ➜ 5 O robô trabalha (página por página, até 5.000 por execução) ➜ 6 Conferir o resultado" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Abra o sistema, confira a **matrícula** (já vem preenchida) e digite a **senha** |
| **2** | Clique em **Conectar GCPJ** e faça login no Internet Explorer, se ele pedir. Os botões de envio só acendem depois disso |
| **3** | Confira a **Data Depósito** (já vem com a data de hoje) e escolha a **Área**: CI ou TR |
| **4** | Clique em **Enviar TED** ou em **Enviar CRED** |
| **5** | Espere. O robô passa por todas as páginas da lista. Se chegar a 5.000 envios, ele para sozinho e avisa (Controle S5) |
| **6** | Leia o aviso final e as mensagens da grade. A grade some quando a tela fecha: tire um print se precisar guardar |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e como preencher a tela</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com **Internet Explorer** e acesso ao GCPJ
- **Microsoft Access Database Engine** (o provedor `Microsoft.ACE.OLEDB.12.0`)
- A pasta `BD` com o `BD_DADOS.accdb` **ao lado do executável**. Ela não está no repositório: use a da pasta de instalação
- Um **usuário cadastrado**. Quem já tem acesso cadastra em *Cadastro Usuários ➜ Novo*. A senha inicial é `1234`; troque em *Alterar Senha*

| Campo da tela | Exemplo | Regra |
| :--- | :--- | :--- |
| `Login` | `9123456` | A matrícula. Vem do usuário do Windows, trocando a primeira letra por número (A=1, B=2 ... I=9) |
| `Data Depósito` | `21/10/2026` | Tem que ser **igual** à data da lista do GCPJ, no formato dd/mm/aaaa, com o zero na frente |
| `Área` | `CI` ou `TR` | Escolhida na lista. Só os depósitos dessa área são enviados |

> [!TIP]
> Cada execução trata **uma data e uma área**. Para enviar CI e TR do mesmo dia, rode duas vezes, uma para cada área.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** o que foi enviado sai da lista *Aguardando Envio* do GCPJ; o que não foi, continua lá. Então, quando chega uma RO sobre um depósito, o primeiro passo é ver se ele ainda está na lista. Depois, a grade da tela e a `Tb_Log` dizem o motivo.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um depósito ➜ 2 Procurar no GCPJ se ainda aguarda envio ➜ 3 Ler a grade e a Tb_Log ➜ resultado verde (deu certo, nada a fazer), amarelo (alguém precisa olhar) ou vermelho (corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que a TED do GCPJ 123456 não saiu. No GCPJ, o depósito continua em *Aguardando Envio da TED*. Na grade, a linha dele diz `GCPJ 123456 - TED não enviada pois a Data do depósito é diferente da data escolhida.` Pelo quadro vermelho, a data digitada não era a do depósito. Basta rodar de novo com a data certa.

#### 🟢 Deu certo: não precisa fazer nada

| O que aparece | O que quer dizer |
| :--- | :--- |
| `GCPJ (número) - TED enviada com sucesso!`<br>`GCPJ (número) - CRED CONTA enviada com sucesso!`<br><sub>na grade</sub> | O robô marcou o depósito, clicou em enviar e fechou o aviso do GCPJ |
| `Operação realizada com sucesso!`<br><sub>aviso final</sub><br>`EXECUTOU ROTINA ENVIAR TED COM SUCESSO` (ou `ENVIAR CRED CONTA`)<br><sub>na Tb_Log</sub> | A execução terminou sem pular nenhuma linha |
| `Nenhum registro localizado para enviar.`<br><sub>aviso final</sub><br>`EXECUTOU ROTINA ENVIAR TED - NENHUM REGISTRO LOCALIZADO PARA ENVIAR` (ou `ENVIAR CRED CONTA`)<br><sub>na Tb_Log</sub> | A lista do GCPJ estava vazia. Não havia nada para enviar |

#### 🟡 Precisa que alguém olhe

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| `Operação realizada com sucesso!` `Alguns registros não puderam ser enviados. Verifique!`<br><sub>aviso final</sub><br>`EXECUTOU ROTINA ENVIAR TED COM SUCESSO - ALGUNS ITENS NÃO PUDERAM SER ENVIADOS` (ou `ENVIAR CRED CONTA`)<br><sub>na Tb_Log</sub> | O robô enviou e também **pulou** pelo menos uma linha. Isso aparece até quando as puladas eram só de outra área ou de outra data | Olhar a grade. Se as puladas são só de outra área ou data, está tudo certo. Se não, ver as linhas abaixo |
| O GCPJ **não aparece na grade** e continua em *Aguardando Envio* | O GCPJ não mostrou o aviso de confirmação a tempo, ou era um depósito repetido (mesmo GCPJ e mesmo valor do anterior). Nesses casos o robô pula sem escrever nada | Enviar manualmente no GCPJ |
| `enviada com sucesso!` na grade, mas o depósito **continua** em *Aguardando Envio* | O robô fecha o aviso do GCPJ **sem ler o texto**. O aviso pode ter sido de erro | Enviar manualmente e ler o aviso do GCPJ |
| `Controle S5: limite de 5.000 envios atingido. Processamento interrompido.`<br><sub>na grade</sub> | A execução chegou ao limite do Controle S5 | Rodar de novo. Ele continua com o que sobrou na lista |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| `GCPJ (número) - TED não enviada pois Área é diferente da Área escolhida.`<br>`GCPJ (número) - CRED CONTA não enviada pois Área é diferente da Área escolhida.`<br><sub>na grade</sub> | O depósito é da outra área (CI ou TR) | Rodar de novo escolhendo a outra área |
| `GCPJ (número) - TED não enviada pois a Data do depósito é diferente da data escolhida.`<br>`GCPJ (número) - CRED CONTA não enviada pois a Data do depósito é diferente da data escolhida.`<br><sub>na grade</sub> | A data do depósito no GCPJ não é a que foi digitada | Conferir a data (dd/mm/aaaa, com zero na frente, ex.: `01/10/2026`) e rodar de novo |

> [!IMPORTANT]
> **A grade não fica salva.** Quando a tela fecha, as mensagens linha por linha somem. A `Tb_Log` guarda só **como cada execução terminou** (usuário, texto e data e hora), não o resultado de cada GCPJ. Se precisar de evidência de um depósito, tire um print da grade antes de fechar. Para rodar de novo não precisa desmarcar nada: o que já foi enviado saiu da lista e o robô só pega o que ainda está aguardando.

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| Botões **Enviar TED** e **Enviar CRED** cinza | Ainda não clicou em **Conectar GCPJ** | Clicar em **Conectar GCPJ** |
| *GCPJ não localizado. Clique em Conectar GCPJ para continuar.* | Não achou uma janela do Internet Explorer com "GCPJ" | Clicar em **Conectar GCPJ** e logar |
| *ATENÇÃO! Obrigatório o preenchimento da data do depósito!*<br>*ATENÇÃO! Informe uma data válida no campo data do depósito.* | Data vazia ou digitada errado | Digitar no formato dd/mm/aaaa |
| *ATENÇÃO! Obrigatório o preenchimento da Área!* | Área não escolhida | Escolher CI ou TR |
| *Usuário não cadastrado.*<br>*Senha não confere.* | Matrícula fora da `Tb_Usuario` ou senha errada | Pedir o cadastro a quem já tem acesso, ou trocar a senha em *Alterar Senha* |
| Janela de erro do Windows logo ao clicar **OK** no login | O sistema não abriu o banco: falta a pasta `BD\BD_DADOS.accdb` ao lado do executável ou o Access Database Engine | Conferir a pasta `BD` e instalar o Access Database Engine |
| O robô "travou" e não termina | O GCPJ caiu ou a sessão expirou no meio. O robô fica tentando a mesma página sem parar | Fechar o sistema pelo Gerenciador de Tarefas, logar de novo no GCPJ, clicar em **Conectar GCPJ** e rodar de novo |
| Aviso **Processamento Limitado - Controle S5** | Chegou a 5.000 envios nesta execução | Normal. Rodar de novo continua com o que sobrou |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim. O `C@ZB` agora tem o controle nas **duas** rotinas de envio (TED e Crédito em Conta). O contador só soma quando o robô chega a clicar em enviar: linhas puladas por área, data ou repetição **não contam**.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada depósito o robô confere o contador; enquanto não chegou a 5.000, envia e soma 1; ao chegar em 5.000, para, avisa o usuário e grava na Tb_Log" width="100%">
</picture>

Quando o limite é atingido, aparece o aviso **Processamento Limitado - Controle S5** (*"O limite de processamento de 5.000 registros foi atingido. Os itens restantes continuam pendentes no GCPJ e podem ser processados em uma nova execução."*), a grade mostra *"Controle S5: limite de 5.000 envios atingido. Processamento interrompido."* e a `Tb_Log` recebe *"CONTROLE S5 - LIMITE DE OPERACOES ATINGIDO NA ROTINA ENVIAR TED"* (ou *ENVIAR CRED CONTA*). Em seguida vem o aviso final de sempre (*Operação realizada com sucesso!*). O que sobrou continua em *Aguardando Envio* para a próxima execução.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `Mod_LimitadorS5.vb` | constante `LIMITE_OPERACOES_S5`, linha 23 |
| Mensagem do aviso | `Mod_LimitadorS5.vb` | função `LimiteS5Atingido`, linha 32 |
| Checagem do Enviar TED | `frm_Principal.vb` | `btn_EnviarTED_Click`: contador na linha 86, bloco `[S5]` na linha 170 |
| Checagem do Enviar CRED | `frm_Principal.vb` | `Button1_Click`: contador na linha 282, bloco `[S5]` na linha 366 |

> [!TIP]
> Para testar sem esperar 5.000 envios: troque `LIMITE_OPERACOES_S5` para `2`, rode com pelo menos 3 depósitos da área e data escolhidas, tire os prints com o relógio do Windows aparecendo (código, aviso e `Tb_Log`) e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra todos os pontos. As evidências oficiais estão em [`docs/Evidencias_S5_EnvioTED.docx`](docs/Evidencias_S5_EnvioTED.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `ExcluiBaixa\EnvioTED.vbproj` (solução `EnvioTED.sln`). A tela inicial é o `frm_Login`.

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `frm_Login.vb` | `OK_Click` | 7 | Valida matrícula e senha na `Tb_Usuario` e grava *ACESSOU SISTEMA* na `Tb_Log` |
| | `LoginForm_Load` | 50 | Preenche a matrícula a partir do usuário do Windows (A=1 ... I=9) |
| `frm_Principal.vb` | `frm_Principal_Load` | 28 | Põe a data de hoje no campo *Data Depósito* |
| | `btn_GCPJ_Click` | 61 | Acha ou abre o IE do GCPJ e libera os dois envios |
| | `preencheGrade` | 72 | Escreve uma linha na grade, com data e hora |
| | `btn_EnviarTED_Click` | 77 | Rotina **Enviar TED** |
| | `VerificaGCPJ` | 220 | Procura uma janela do IE com "GCPJ" no nome |
| | `Espera_Ate_Que_Abra` | 237 | Espera a página do GCPJ terminar de carregar |
| | `MataMsgbox` | 252 | Espera o aviso *Mensagem da página da web* e clica em OK |
| | `Button1_Click` | 273 | Rotina **Enviar CRED** |
| `frm_Principal.Designer.vb` | `cb_Area` | 129 | Itens da lista de áreas: `CI` e `TR` |
| `frm_CadUsuario.vb` | `btn_Salvar_Click` | 18 | Novo usuário (senha `1234`) ou troca de nome |
| `frm_AltSenha.vb` | `btn_Alterar_Click` | 6 | Troca de senha |
| `cls_Conexao.vb` | `Conexao` | 5 | Caminho do banco: `BD\BD_DADOS.accdb` ao lado do `.exe` |
| `Mod_LimitadorS5.vb` | `LIMITE_OPERACOES_S5` / `LimiteS5Atingido` | 23 / 32 | Controle S5 |

</details>

<details>
<summary><b>Como cada envio funciona por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>

As duas rotinas são iguais; muda só a tela e o botão do GCPJ.

| | Enviar TED | Enviar CRED |
| :--- | :--- | :--- |
| Rotina | `btn_EnviarTED_Click` (linha 77) | `Button1_Click` (linha 273) |
| Tela | `finDepAguardEnvTedAction?metodo=carregar&origem=` (linha 119) | `finDepAguardEnvCredBradAction?metodo=carregar` (linha 315) |
| Botão clicado | `btoEnviarTed` (linha 182) | `btoEnviarCreditoConta` (linha 378) |

1. Confere a data (vazia ou inválida) e a área. Grava *ACESSOU ROTINA ENVIAR TED* na `Tb_Log` e confere se o GCPJ está aberto.
2. Abre a lista e lê a 4ª tabela da página (`objTable(3)`). As linhas de dados começam no índice 2. Se a tabela tem só 3 linhas, a lista está vazia.
3. Colunas usadas: **2** = GCPJ, **6** = área, **9** = data do depósito, **10** = valor.
4. Para cada linha: pula se for o **mesmo GCPJ e valor** do anterior; pula (e escreve na grade) se a **área** ou a **data** forem diferentes das escolhidas.
5. Bloco `[S5]`: se já enviou 5.000, para.
6. Marca a linha (coluna 1), clica no botão de envio e espera o aviso *Mensagem da página da web* para clicar em OK. Se o aviso não aparece, pula a linha sem escrever nada.
7. Depois do envio o depósito sai da lista, então o robô fica na mesma posição e lê o próximo.
8. No fim da página, chama `paginarFinanceiro('paginarGridFiltro')` para ir à próxima. Se a primeira linha não mudou, acabou.
9. Erro inesperado: o `Catch` pula uma linha e volta para o rótulo `inicio:`.
10. No fim, grava o resultado na `Tb_Log` e mostra o aviso final.

</details>

<details>
<summary><b>Banco de dados</b> &nbsp;·&nbsp; tabelas do Access e textos da Tb_Log</summary>
<br>

| Objeto | Tipo | Conteúdo |
| :--- | :--- | :--- |
| `Tb_Usuario` | Tabela | `ID_Usuario` (matrícula), `Nome`, `Senha` |
| `Tb_Log` | Tabela | `ID_Usuario`, `Log`, `DataHora` (gravada como texto `yyyy-MM-dd HH:mm:ss`) |

O arquivo `BD\BD_DADOS.accdb` **não está no repositório**; a estrutura acima vem das consultas do código.

| Texto gravado em `Tb_Log.Log` | Quando |
| :--- | :--- |
| `ACESSOU SISTEMA` | Login aceito |
| `ACESSOU ROTINA ENVIAR TED` | Início de qualquer um dos dois envios (ver Pontos de atenção) |
| `EXECUTOU ROTINA ENVIAR TED COM SUCESSO` / `... ENVIAR CRED CONTA COM SUCESSO` | Fim sem linha pulada |
| `... COM SUCESSO - ALGUNS ITENS NÃO PUDERAM SER ENVIADOS` | Fim com linha pulada |
| `... - NENHUM REGISTRO LOCALIZADO PARA ENVIAR` | Lista vazia |
| `CONTROLE S5 - LIMITE DE OPERACOES ATINGIDO NA ROTINA ENVIAR TED` / `... ENVIAR CRED CONTA` | Limite do Controle S5 |
| `ACESSOU CADASTRO USUÁRIO - (tela)`, `INSERIU USUÁRIO (matrícula)`, `ATUALIZOU NOME DO USUÁRIO`, `ALTEROU SENHA` | Cadastro de usuários |

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `Mod_LimitadorS5.vb` ➜ `LIMITE_OPERACOES_S5` |
| Mudar as áreas disponíveis (CI / TR) | `frm_Principal.Designer.vb` ➜ itens do `cb_Area` (linha 129) |
| Mudar as colunas lidas na lista do GCPJ | `frm_Principal.vb` ➜ `objTable(3).Rows(item_inicial).all.Item(n)` (2 = GCPJ, 6 = área, 9 = data, 10 = valor) |
| Mudar o endereço do GCPJ | `frm_Principal.vb` ➜ procure `intranet85.net.bradesco.com.br/gcpj` |
| Mudar o aviso do GCPJ que o robô fecha | `frm_Principal.vb` ➜ `MataMsgbox`, título *Mensagem da página da web* (linha 258) |
| Mudar o que vai para o log | `frm_Principal.vb` ➜ `INSERT INTO Tb_Log` |
| Mudar a senha inicial de novos usuários | `frm_CadUsuario.vb` ➜ linha 43 (e o aviso da linha 48) |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **Log errado no Enviar CRED:** a linha 302 do `frm_Principal.vb` grava `'ACESSOU ROTINA ENVIAR TED'` dentro da rotina de Crédito em Conta. Na `Tb_Log` não dá para saber pelo início qual envio foi usado. A correção é de uma linha (trocar por `ACESSOU ROTINA ENVIAR CRED CONTA`). Já vinha assim antes do Controle S5.
- **Título trocado:** no fim do Enviar CRED sem linha pulada, o aviso da linha 410 sai com o título *Sistema de Envio TED*. Só visual.
- **"enviada com sucesso" não confirma o envio.** O `MataMsgbox` (linha 252) clica em OK no primeiro aviso com título *Mensagem da página da web*, sem ler o texto. Se o GCPJ mostrar um erro nesse aviso, a grade escreve sucesso do mesmo jeito.
- **"Alguns registros não puderam ser enviados"** aparece quando `item_inicial > 2` (linhas 204 e 400), ou seja, quando houve linha pulada na última página tratada, mesmo que só de outra área ou data. Linhas puladas em páginas anteriores não entram nessa conta, porque `item_inicial` volta a 2 ao trocar de página (linhas 144 e 340).
- **Depósito repetido é pulado sem aviso:** se a linha tem o mesmo GCPJ e o mesmo valor da anterior (linhas 149 e 345), o robô entende que deu erro e pula, sem escrever na grade.
- **Pode ficar preso tentando:** o `Catch` volta para `inicio:` (linhas 196 e 392). Se o erro acontece antes da primeira linha (GCPJ fora do ar, sessão expirada), nada avança e o laço não termina.
- **Data comparada por texto exato** (linhas 164 e 360): `1/10/2026` é diferente de `01/10/2026`.
- **Login frágil:** se o banco não abre, o `GeraTBL` devolve `Nothing` e o login dá erro na linha 25 do `frm_Login.vb`. As senhas ficam em texto puro na `Tb_Usuario` e o SQL é montado por concatenação.
- **Duas rotinas quase iguais.** Mudou uma, confira a outra.
- **Depende do layout do GCPJ:** a lista é achada como a 4ª tabela da página e as colunas por posição. Se o GCPJ mudar a tela, o robô quebra.
- As pastas `bin`, `obj` e `.vs` estão versionadas. Cuidado ao limpar: as referências `Interop.ADODB` e `Interop.SHDocVw` apontam para `obj\Debug` (linhas 70 a 77 do `EnvioTED.vbproj`).

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 10/2025 repositório criado no GitHub; 12/2025 primeiro commit do código; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: corrigir o log do Enviar CRED (linha 302)" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 10/2025 | vogon-fleet-app (automação) | Criação do repositório e do `CODEOWNERS` via Terramate |
| 12/2025 | Daniela Chirinian | Primeiro commit do código no GitHub |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`Mod_LimitadorS5.vb`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
