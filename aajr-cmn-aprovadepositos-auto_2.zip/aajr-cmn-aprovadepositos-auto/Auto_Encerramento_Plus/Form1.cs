﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Threading;
using System.IO;

namespace Auto_Encerramento_Plus
{
    public partial class Form1 : Form
    {
        double Gl_ValorLimite;
        //StreamWriter sw;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, EventArgs e)
        {
            preencheGrade("Localizando GCPJ....");
            if (Automacao.localizarJanela("GCPJ") == false)
            {
                preencheGrade("GCPJ não localizado, abrindo nova janela.");
                Automacao.novaJanela("https://intranet85.net.bradesco.com.br/gcpj/");

            }
            preencheGrade("GCPJ localizado, prossiga com o procedimento");
        }

        private void preencheGrade(String texto)
        {
            Grade.Items.Add(DateTime.Now.ToShortDateString() + " - " + DateTime.Now.ToShortTimeString() + " " + texto);
            Grade.SelectedIndex = Grade.Items.Count - 1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            preencheGrade("Bem vindo ao aprova depósitos");
            preencheGrade("Conecte ao GCPJ para iniciar o processamento");

            OleDbDataReader dr = Conexao.consultar("SELECT * FROM SYS_VALOR_LIMITE");
            if (dr.HasRows)
            {
                dr.Read();
                Gl_ValorLimite = dr.GetDouble(0);
                preencheGrade("O valor limite para aprovação de encerramento é: R$ " + dr.GetDouble(0).ToString("N"));
            }
            dr.Close();
        }

        private void btnProcessar_Click(object sender, EventArgs e)
        {
            if (txtDataDeposito.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }

            //criando arquivo de log
            //sw = new StreamWriter(Application.StartupPath + "\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt", true);
            //sw.AutoFlush = true;
            //sw.WriteLine("++++++++++++++INICIO DO PROCESSAMENTO DEPÓSITOS AVULSOS+++++++++++++++++++");

            //sw.WriteLine("==APROVAÇÃO DE DEPÓSITOS AVULSO - TED==");
            processarAvulsosTED();
            preencheGrade("Depósitos avulsos TED aprovados com sucesso!");
            //sw.WriteLine("==APROVAÇÃO DE DEPÓSITOS AVULSO - CRÉDITO EM CONTA==");
        }

        private void processarAvulsosTED()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/depositoAguardAprovAction?metodo=carregarTed&origem=");
            Automacao.espera();

            int contagem = 2;
            int qtdOperacoesS5 = 0; // [S5] contador de itens tratados nesta execução

            while (contagem <= 100)
            {
                if (Automacao.selecionarTabelaValor("tab1", txtDataDeposito.Text, Gl_ValorLimite))
                {
                    // [S5] Limitador de operações: para o processamento ao atingir o limite (ver LimitadorS5.cs)
                    if (LimitadorS5.LimiteAtingido(qtdOperacoesS5))
                    {
                        preencheGrade(LimitadorS5.MensagemLog());
                        break;
                    }
                    qtdOperacoesS5++;

                    //selecionado depósito
                    Automacao.clicar("btoDetalhe");
                    Automacao.espera();
                    //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + Automacao.retornaValue("vrTotalGridComposicao"));
                    Automacao.clicar("btoAprov");
                    Automacao.mataMsgBox();
                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['paginaDeposito'].value=" + contagem + "");
                    Automacao.ExecutarJS("paginarFinanceiro('paginarDepositos')");
                    Automacao.espera();
                    contagem++;
                 }
            }
        }

        private void processarAvulsosCreditoConta()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/depositoAguardAprovAction?metodo=carregarCreditoBradesco&origem=");
            Automacao.espera();

            int contagem = 1;
            int qtdOperacoesS5 = 0; // [S5] contador de itens tratados nesta execução

            while (contagem <= 100)
            {
                if (Automacao.selecionarTabelaValor("tab1", txtDataDeposito.Text, Gl_ValorLimite))
                {
                    // [S5] Limitador de operações: para o processamento ao atingir o limite (ver LimitadorS5.cs)
                    if (LimitadorS5.LimiteAtingido(qtdOperacoesS5))
                    {
                        preencheGrade(LimitadorS5.MensagemLog());
                        break;
                    }
                    qtdOperacoesS5++;

                    //selecionado depósito
                    Automacao.clicar("btoDetalhe");
                    Automacao.espera();
                    //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + Automacao.retornaValue("vrTotalGridComposicao"));

                    Automacao.clicar("btoAprov");
                    Automacao.mataMsgBox();
                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['paginaDeposito'].value=" + contagem + "");
                    Automacao.ExecutarJS("paginarFinanceiro('paginarDepositos')");
                    Automacao.espera();
                    contagem++;
                }
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (txtDataSolicitacao.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }

            //criando arquivo de log
            //sw = new StreamWriter(Application.StartupPath + "\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt", true);
            //sw.AutoFlush = true;
            //sw.WriteLine("++++++++++++++INICIO DO PROCESSAMENTO ENCERRAMENTOS+++++++++++++++++++");

            //sw.WriteLine("==APROVAÇÃO DE ENCERRAMENTOS - TED==");
            
            aprovarEncerramentoTed();
            preencheGrade("Aprovados encerramentos por TED");

            //sw.WriteLine("==APROVAÇÃO DE ENCERRAMENTOS - CREDITO EM CONTA BRADESCO==");
            //sw.Close();
        }

        public void aprovarEncerramentoTed()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/menuTramitePendencias?metodo=carregar&origem=tramite");
            Automacao.espera();
            Automacao.ExecutarJS("enviarPendencia(103)");
            Automacao.espera();

            Automacao.selecionarRadio(0, "cdTpoPagamento");
            Automacao.clicar("btoDetalhar");
            Automacao.espera();

            int contagem = 2;
            int qtdOperacoesS5 = 0; // [S5] contador de itens tratados nesta execução
            List<double> ignorarN = new List<double>();

            while (contagem <= 200)
            {
                //estamos na tela de aprovação de encerramento com TED.
                if (Automacao.selecionarTabelaValorEncerramento("tab1", txtDataSolicitacao.Text, Gl_ValorLimite, ignorarN))
                {
                    // [S5] Limitador de operações: para o processamento ao atingir o limite (ver LimitadorS5.cs)
                    if (LimitadorS5.LimiteAtingido(qtdOperacoesS5))
                    {
                        preencheGrade(LimitadorS5.MensagemLog());
                        break;
                    }
                    qtdOperacoesS5++;

                    Automacao.clicar("btoDetalhar");
                    Automacao.espera();

                    Double valorPagamento = 0.0;

                    //verificando se existe valor base complementar
                    try
                    {
                        Automacao.campoExiste("valoresEncerramentoVO.vlDepositoComplementar");
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlDepositoComplementar"));
                    }
                    catch (Exception)
                    {
                        //nao existe valor base complementar.
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    if (valorPagamento == 0)
                    {
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    //verificando o valor....
                    if (valorPagamento <= Gl_ValorLimite)
                    {

                        //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + valorPagamento.ToString("N"));
                        Thread tr1 = new Thread(mataMensagem);
                        tr1.Start();
                        //estamos no valor para a provar... se não vamos voltar.
                        Automacao.clicar("btoSalvar");
                        //7286997
                        Automacao.espera();
                        Automacao.clicar("btoSalvar");
                        Automacao.mataPossivelMsgBox();
                        Thread.Sleep(750);
                        Automacao.espera();
                        Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrRecolIR?metodo=carregPopup");
                        Automacao.clicar("btoContinuar");
                        Automacao.espera();
                        Automacao.clicar("btoAprovar");
                        Automacao.mataPossivelMsgBox();
                        Automacao.mataPossivelMsgBox();
                        contagem = 2;

                    }
                    else
                    {
                        //voltar
                        ignorarN.Add(double.Parse(Automacao.RetornaConteudo("lnk1", "a")));
                        Automacao.clicar("btoVoltar");
                        Automacao.espera();

                        //resetando pagina
                        contagem = 2;
                    }

                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['pagina'].value=" + contagem + ";paginarEncerramento('paginar')");
                    Automacao.espera();
                    contagem++;
                }
            }
        }

        public void aprovarEncerramentoCCBradesco()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/menuTramitePendencias?metodo=carregar&origem=tramite");
            Automacao.espera();
            Automacao.ExecutarJS("enviarPendencia(103)");
            Automacao.espera();

            Automacao.selecionarRadio(1, "cdTpoPagamento");
            Automacao.clicar("btoDetalhar");
            Automacao.espera();

            int contagem = 2;
            int qtdOperacoesS5 = 0; // [S5] contador de itens tratados nesta execução
            List<double> ignorarN = new List<double>();

            while (contagem <= 80)
            {
                //estamos na tela de aprovação de encerramento com TED.
                if (Automacao.selecionarTabelaValorEncerramento("tab1", txtDataSolicitacao.Text, Gl_ValorLimite, ignorarN))
                {
                    // [S5] Limitador de operações: para o processamento ao atingir o limite (ver LimitadorS5.cs)
                    if (LimitadorS5.LimiteAtingido(qtdOperacoesS5))
                    {
                        preencheGrade(LimitadorS5.MensagemLog());
                        break;
                    }
                    qtdOperacoesS5++;

                    Automacao.clicar("btoDetalhar");
                    Automacao.espera();

                    Double valorPagamento = 0.0;

                    //verificando se existe valor base complementar
                    try
                    {
                        Automacao.campoExiste("valoresEncerramentoVO.vlDepositoComplementar");
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlDepositoComplementar"));
                    }
                    catch (Exception)
                    {
                        //nao existe valor base complementar.
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    if (valorPagamento == 0)
                    {
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    //verificando o valor....
                    if (valorPagamento <= Gl_ValorLimite)
                    {
                        //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + valorPagamento.ToString("N"));
                        Thread tr1 = new Thread(mataMensagem);
                        tr1.Start();
                        //estamos no valor para a provar... se não vamos voltar.
                        Automacao.clicar("btoSalvar");
                        //7286997
                        Automacao.espera();
                        Automacao.clicar("btoSalvar");
                        Automacao.mataPossivelMsgBox();
                        Thread.Sleep(750);
                        Automacao.espera();
                        Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrRecolIR?metodo=carregPopup");
                        Automacao.clicar("btoContinuar");
                        Automacao.espera();
                        Automacao.clicar("btoAprovar");
                        Automacao.mataPossivelMsgBox();
                        Automacao.mataPossivelMsgBox();
                        contagem = 2;

                    }
                    else
                    {
                        //voltar
                        ignorarN.Add(double.Parse(Automacao.RetornaConteudo("lnk1", "a")));
                        Automacao.clicar("btoVoltar");
                        Automacao.espera();

                        //resetando pagina
                        contagem = 2;
                    }

                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['pagina'].value=" + contagem + ";paginarEncerramento('paginar')");
                    Automacao.espera();
                    contagem++;
                }
            }
        }

        public void mataMensagem()
        {
            Automacao.mataPossivelMsgBox();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //sw.Close();
            }
            catch (Exception)
            {

            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (txtDataDeposito.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }
            processarAvulsosCreditoConta();
            preencheGrade("Depósitos avulsos crédito em conta aprovados com sucesso!");
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {

            if (txtDataSolicitacao.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }
            //sw.WriteLine("==APROVAÇÃO DE ENCERRAMENTOS - CREDITO EM CONTA BRADESCO==");

            aprovarEncerramentoCCBradesco();
            preencheGrade("Aprovados os encerramentos por Crédito em Conta Bradesco!");
        }

        private void processar_Click(object sender, EventArgs e)
        {
            btnProcessar_Click(sender, e);
            toolStripButton2_Click(sender, e);
        }

        private void encerrar_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(sender, e);
            toolStripButton3_Click(sender, e);

        }
    }
}
