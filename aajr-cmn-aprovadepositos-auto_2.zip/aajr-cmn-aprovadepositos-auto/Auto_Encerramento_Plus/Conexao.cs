﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Auto_Encerramento_Plus
{
    static class Conexao
    {
        public static string con = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\BD_DADOS.accdb";
        public static OleDbConnection conexao;
        public static OleDbDataReader da;
        public static OleDbCommand cmd;


        public static OleDbConnection conectar()
        {
            conexao = new OleDbConnection(con);
            conexao.Open();
            return conexao;
        }

        public static String bancoAtual()
        {
            return System.IO.Path.GetDirectoryName(Application.ExecutablePath) + "\\BD_DADOS.accdb";
        }

        public static void desconectar()
        {
            conexao.Close();
        }

        public static OleDbDataReader consultar(string comando)
        {
            cmd = new OleDbCommand();
            cmd.Connection = conectar();
            cmd.CommandText = comando;
            try 
	        {	        
		        da = cmd.ExecuteReader();
	        }
	        catch (Exception ex)
	        {
		
		        throw ex;
	        }
            return da;

        }

        public static Boolean executar(string comando)
        {
            cmd = new OleDbCommand();
            cmd.Connection = conectar();
            cmd.CommandText = comando;
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
            finally
            {
                desconectar();
            }
            return true;
        }

    }
}
