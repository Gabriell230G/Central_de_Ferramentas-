# Aprova Depósitos (aajr-cmn-aprovadepositos-auto)

Robô que aprova, no GCPJ, os **depósitos avulsos** e os **encerramentos** que estão aguardando aprovação, respeitando um valor máximo em R$ definido na base.

| Item | Valor |
|---|---|
| Código no inventário | **C@JX** (Aprovação de depósito) |
| Área | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| Linguagem | C# (Windows Forms) |
| Framework | .NET Framework 4.8 |
| Sistema alvo | GCPJ (Internet Explorer, via SHDocVw / mshtml) |
| Base local | `BD_DADOS.accdb` (mesma pasta do executável) |
| Controle S5 | Implementado (limite de **5.000** itens por execução) |

> A pasta do projeto se chama `Auto_Encerramento_Plus` por herança de outro sistema. O executável gerado é o **Aprova_Depositos**.

---

## Sumário

1. [O que o sistema faz](#1-o-que-o-sistema-faz)
2. [Como rodar](#2-como-rodar)
3. [Estrutura do projeto](#3-estrutura-do-projeto)
4. [Controle S5: Limitador de Operações](#4-controle-s5-limitador-de-operações)
5. [Guia rápido: quero mudar X, onde vou?](#5-guia-rápido-quero-mudar-x-onde-vou)
6. [Pontos de atenção](#6-pontos-de-atenção)
7. [Histórico](#7-histórico)

---

## 1. O que o sistema faz

Ao abrir, o sistema lê o **valor limite em R$** na tabela `SYS_VALOR_LIMITE` e mostra na tela. Só são aprovados itens com valor **até** esse limite.

| Botão | O que faz | Tela do GCPJ |
|---|---|---|
| **Conectar GCPJ** | Procura uma janela do GCPJ aberta; se não achar, abre uma nova | Página inicial |
| **Avulsos TED** | Aprova depósitos avulsos pagos por TED na data informada | Depósitos aguardando aprovação (TED) |
| **Avulso Cred Conta** | Mesmo processo, para crédito em conta Bradesco | Depósitos aguardando aprovação (Crédito) |
| **Processar Avulsos** | Roda os dois botões acima em sequência | - |
| **Encerramento TED** | Aprova encerramentos pagos por TED na data de solicitação | Trâmite de pendências (103) |
| **Encerramento Cred Conta** | Mesmo processo, para crédito em conta Bradesco | Trâmite de pendências (103) |
| **Processar Encerramentos** | Roda os dois botões acima em sequência | - |

Fluxo resumido de cada rotina:

```
Abre a tela do GCPJ ➜ procura na lista um item da data com valor <= limite
   ➜ achou: detalha, aprova e volta para a lista
   ➜ não achou: vai para a próxima página
   ➜ repete até acabar as páginas OU atingir o limite do Controle S5
```

## 2. Como rodar

1. Abra `Aprova_Depositos.sln` no Visual Studio.
2. Garanta que o **Microsoft Access Database Engine** (ACE OLEDB 12.0) está instalado.
3. Coloque o `BD_DADOS.accdb` na mesma pasta do executável (`bin\Debug` ou `bin\Release`).
4. Rode, clique em **Conectar GCPJ**, faça login no GCPJ se pedir, preencha a data e escolha a rotina.

## 3. Estrutura do projeto

| Arquivo | Para que serve |
|---|---|
| `Form1.cs` | Tela principal e **todas as rotinas de aprovação** (é aqui que a automação acontece) |
| `Form1.Designer.cs` | Layout da tela (botões, campos de data, grade de mensagens) |
| `Automacao.cs` | Funções que controlam o Internet Explorer (navegar, clicar, ler tabela, fechar pop-up) |
| `Conexao.cs` | Conexão com o `BD_DADOS.accdb` |
| `LimitadorS5.cs` | **Controle S5**: limite de operações por execução |
| `Program.cs` | Ponto de entrada |

## 4. Controle S5: Limitador de Operações

Exigência do normativo **05.1073** para aplicativos com C10 = Sim (automação que captura ou atualiza dados em sistema estruturado). O robô não pode rodar sem limite no GCPJ.

### Como funciona

```
Início da rotina ➜ contador = 0
   Para cada item que o robô vai tratar:
      contador já chegou no limite?  ➜ SIM: avisa o usuário e para
                                      ➜ NÃO: soma 1 e segue normalmente
```

Quando o limite é atingido aparece a mensagem **"Processamento Limitado - Controle S5"** e a grade registra a linha *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*. Os itens que sobraram continuam aguardando aprovação no GCPJ e entram na próxima execução.

### Onde mexer

| O que | Arquivo | Onde |
|---|---|---|
| **Valor do limite** | `LimitadorS5.cs` | constante `LIMITE_OPERACOES` (linha 30) |
| Mensagem exibida ao usuário | `LimitadorS5.cs` | método `LimiteAtingido` |
| Avulsos TED | `Form1.cs` | `processarAvulsosTED()`, bloco `[S5]` na linha 90 |
| Avulsos Crédito em Conta | `Form1.cs` | `processarAvulsosCreditoConta()`, bloco `[S5]` na linha 128 |
| Encerramento TED | `Form1.cs` | `aprovarEncerramentoTed()`, bloco `[S5]` na linha 197 |
| Encerramento Crédito em Conta | `Form1.cs` | `aprovarEncerramentoCCBradesco()`, bloco `[S5]` na linha 293 |

> Dica: no Visual Studio use **Ctrl+Shift+F** e pesquise `[S5]` para achar todos os pontos de uma vez.

> **Não confundir:** `Gl_ValorLimite` é o limite de **valor em R$** (já existia). O Controle S5 limita a **quantidade** de itens.

### Documento de evidências

O Word com as evidências do Controle S5 (trechos do código alterado, resultado dos testes e espaço para os prints do ambiente) fica em [`docs/Evidencias_S5_AprovaDepositos.docx`](docs/Evidencias_S5_AprovaDepositos.docx).

### Como testar e gerar a evidência

1. Em `LimitadorS5.cs`, troque temporariamente `LIMITE_OPERACOES = 5000` para `2`.
2. Rode uma das rotinas com pelo menos 3 itens disponíveis.
3. Confira: o robô trata 2 itens e mostra o aviso **Processamento Limitado - Controle S5**.
4. Tire os prints (sempre com o **relógio do Windows aparecendo**):
   - código no Visual Studio mostrando a constante e o bloco `[S5]`;
   - a mensagem de limite na tela do sistema.
5. **Volte o valor para 5000** antes de gerar a versão final.

## 5. Guia rápido: quero mudar X, onde vou?

| Quero... | Vá em |
|---|---|
| Mudar o limite de quantidade (S5) | `LimitadorS5.cs` ➜ `LIMITE_OPERACOES` |
| Mudar o limite de valor em R$ | tabela `SYS_VALOR_LIMITE` no `BD_DADOS.accdb` |
| Mudar a URL de uma tela do GCPJ | `Form1.cs` ➜ chamadas `Automacao.navegar(...)` |
| Mudar como o robô escolhe o item da lista | `Automacao.cs` ➜ `selecionarTabelaValor` / `selecionarTabelaValorEncerramento` |
| Mudar textos da tela | `Form1.Designer.cs` |

## 6. Pontos de atenção

- O robô usa **Internet Explorer** (COM). Se o GCPJ mudar o nome de um campo ou botão, a rotina quebra no `Automacao.clicar(...)` correspondente.
- Os botões **Processar Avulsos** e **Processar Encerramentos** chamam duas rotinas seguidas. O limite S5 vale **por rotina**.
- O log em arquivo `.txt` existe no código, mas está comentado.

## 7. Histórico

| Data | Autor | Alteração |
|---|---|---|
| 12/2025 | Daniela Chirinian | Primeiro commit (migração para o GitHub) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LimitadorS5.cs`) e novo README |

---

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
