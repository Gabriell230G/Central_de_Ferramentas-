<div align="center">

<img src="docs/readme/header.svg" alt="Atualiza Envolvidos: corrige CPF/CNPJ e inclui autores e réus PJ nos processos do GCPJ, a partir de uma planilha" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: C#" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET 4.8" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="base: Access" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o robô lê uma planilha de envolvidos e, processo por processo, ajusta o cadastro deles no GCPJ, deixando anotado em cada linha o que aconteceu.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 3 ações no GCPJ; 5.000 registros por execução (Controle S5); 19 respostas de OBS explicadas; pausa automática das 23h às 6h" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Planilha ATUALIZACAO_ENVOLVIDOS.xlsx ➜ 2 Banco Access TB_ENVOLVIDOS ➜ 3 Robô com Controle S5 ➜ 4 GCPJ no Internet Explorer ➜ 5 Resultado na coluna OBS e no TB_LOG" width="100%">
</picture>

### As três ações

| Botão na tela | Código | O que faz | Processos |
| :--- | :---: | :--- | :---: |
| **Atualizar CPF/CNPJ Envolvido** | `D@KQ` | Acha o envolvido pelo nome dentro do processo e grava o CPF/CNPJ correto. Se o documento não existir na base, corrige no cadastro de pessoa externa | Ativos e encerrados |
| **Inserir Demais Autores** | `D@KV` | Inclui o envolvido como **autor**. Se a pessoa ainda não existir, cadastra no INFRA antes | Ativos |
| **Inserir PJ RÉU** | `D@LM` | Inclui a empresa como **réu**. Se ainda não existir, cadastra no INFRA antes | Ativos |

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `aajr-cmn-atualizaenvolvidos` |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em C# Windows Forms, .NET Framework 4.8, compilado em **x86** |
| **Sistemas que altera** | GCPJ (e INFRA, quando precisa cadastrar a pessoa) |
| **Entrada** | Planilha `ATUALIZACAO_ENVOLVIDOS.xlsx`, aba `Planilha1` |
| **Saída** | Coluna `OBS` da `TB_ENVOLVIDOS` + histórico na `TB_LOG` |
| **Base local** | `BD\BD_DADOS.accdb`, ao lado do executável |
| **Horário** | Pausa sozinho das **23h às 6h** |
| **Controle S5** | Até **5.000 registros por execução**, por máquina |

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Importar a planilha ➜ 2 Distribuir máquinas (opcional) ➜ 3 Conectar no GCPJ ➜ 4 Escolher a ação D@KQ, D@KV ou D@LM ➜ 5 O robô trabalha (até 5.000 por execução, pausa das 23h às 6h) ➜ 6 Conferir a OBS" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Salve a planilha como `ATUALIZACAO_ENVOLVIDOS.xlsx` no diretório do sistema e clique em **Importar planilha** |
| **2** | *(opcional)* Digite a **quantidade** de máquinas no campo *Máquina* e clique em **Distribuir Máquinas**. Depois, em cada máquina, digite o **número dela** (1, 2, 3...) |
| **3** | Clique em **Conectar GCPJ** e faça login no Internet Explorer que abrir |
| **4** | Clique na ação desejada e confirme |
| **5** | Acompanhe pela grade de baixo. Se passar de 5.000, o robô para sozinho e avisa (Controle S5) |
| **6** | Clique em **Exportar para Excel** e confira a coluna **OBS** de cada linha |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e como montar a planilha</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com **Internet Explorer** e acesso ao GCPJ
- **Microsoft Access Database Engine 32 bits** (o projeto é x86, então o ACE OLEDB 12.0 tem que ser 32 bits)
- **Excel**, só para o link *Exportar para Excel*

| Coluna da planilha | Exemplo | Regra |
| :--- | :--- | :--- |
| `BRADESCO` | `123456789` | Número do processo no GCPJ |
| `ENVOLVIDO` | `MARIA DA SILVA` | Nome **igual** ao que está no GCPJ (com ou sem acento) |
| `CPF_CNPJ` | `123456789` | Só a raiz: 9 dígitos para CPF, 8 para CNPJ |
| `FILIAL` | `0` ou `1` | `0` = pessoa física. Para empresa, o número da filial |
| `DIGITO` | `09` | Os 2 dígitos verificadores |

> [!TIP]
> O campo **Máquina** tem dois usos: no *Distribuir Máquinas* ele é a **quantidade** de máquinas; nas ações ele é o **número desta máquina**. Cada máquina só trata as linhas com o número dela na coluna `MAQUINA`.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** para cada linha da planilha, o robô escreve na coluna **OBS** o que aconteceu com ela. Então, quando chega uma RO sobre um processo, a resposta quase sempre já está escrita ali.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um processo ➜ 2 Exportar para Excel ➜ 3 Ler a coluna OBS ➜ resultado verde (deu certo, nada a fazer), amarelo (alguém precisa olhar) ou vermelho (corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que o autor não foi incluído no processo 123456. No Excel, a OBS desse processo diz `NOME DO ENVOLVIDO NÃO LOCALIZADO`. Pelo quadro vermelho, isso quer dizer que o nome na planilha está diferente do nome no GCPJ. Basta corrigir o nome e rodar de novo.

#### 🟢 Deu certo: não precisa fazer nada

| O que está escrito na OBS | O que quer dizer |
| :--- | :--- |
| ATUALIZAÇÃO EFETUADA COM SUCESSO | O robô fez a alteração no GCPJ |
| CPF/CNPJ JÁ CADASTRADO PARA O ENVOLVIDO INFORMADO | O documento já estava certo, não precisou mexer |
| O ENVOLVIDO JÁ ESTÁ RELACIONADO COMO AUTOR (ou RÉU) NESSE PROCESSO | A pessoa já estava no processo, não precisou incluir |

#### 🟡 Precisa que alguém olhe

| O que está escrito na OBS | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| ...PORÉM COM UMA DIVERGÊNCIA NO NOME | Gravou, mas o nome no GCPJ é um pouco diferente do da planilha | Conferir se é a mesma pessoa |
| MAIS DE UM ENVOLVIDO LOCALIZADO COM O DOCUMENTO INFORMADO | Existe mais de uma pessoa com esse documento e o robô não sabe qual escolher | Fazer manualmente no GCPJ |
| DOCUMENTO PERTENCE A OUTRO ENVOLVIDO JÁ RELACIONADO | Esse documento já está cadastrado em outra pessoa do mesmo processo | Analisar com a área antes de mexer |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que está escrito na OBS | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| NOME DO ENVOLVIDO NÃO LOCALIZADO<br>ERRO AO LOCALIZAR O NOME DO ENVOLVIDO | O nome da planilha não bate com nenhum envolvido do processo | Corrigir o nome (espaço a mais, abreviação) |
| ERRO AO ACESSAR O PROCESSO<br>FALHA AO PESQUISAR O PROCESSO | O processo não abriu no GCPJ | Conferir o número. *Inserir Autores* e *Inserir PJ Réu* só funcionam em processo **ativo** |
| DOCUMENTO INVALIDO<br>NAO LOCALIZADO<br>NÃO FOI POSSÍVEL CADASTRAR ENVOLVIDO | O GCPJ ou o INFRA não aceitou o documento | Conferir CPF/CNPJ, filial e dígito na planilha |
| ERRO TELA DO ENVOLVIDO<br>ERRO AO SALVAR | O GCPJ deu erro na hora de salvar | Rodar de novo. Se repetir, fazer manualmente |
| ERRO AO ATUALIZAR DOCUMENTO DO ENVOLVIDO<br>ERRO AO INSERIR ENVOLVIDO<br>ERRO AO INSERIR PJ RÉU | Erro inesperado, quase sempre GCPJ lento ou fora do ar | Rodar de novo |

> [!IMPORTANT]
> **Para rodar de novo, a linha precisa voltar a ficar pendente.** O robô marca toda linha que já passou por ele (até as que deram erro) e não mexe nela de novo. No Access, abra a `TB_ENVOLVIDOS` e desmarque a coluna `ATUALIZADO` das linhas que quer refazer. Se forem muitas, esta consulta desmarca de uma vez todas as que deram erro:
> ```sql
> UPDATE TB_ENVOLVIDOS SET ATUALIZADO = FALSE, OBS = NULL WHERE OBS LIKE 'ERRO*';
> ```

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| *Erro ao importar o arquivo* | Planilha fora do lugar, com outro nome ou com colunas diferentes | Conferir nome, aba `Planilha1` e colunas. No Access, conferir o vínculo da tabela `ATUALIZACAO_ENVOLVIDOS` em *Dados Externos ➜ Gerenciador de Tabelas Vinculadas* |
| *ATENÇÃO: Conecte ao GCPJ para continuar.* | Não achou uma janela do IE com "GCPJ" no título | Clicar em **Conectar GCPJ** e logar |
| Clico na ação e nada acontece | Não há linha pendente para o número digitado em *Máquina* | Conferir a coluna `MAQUINA` e o campo *Máquina* |
| O provedor *Microsoft.ACE.OLEDB.12.0* não está registrado | Falta o Access Database Engine 32 bits | Instalar a versão **32 bits** |
| O robô "travou" à noite | É a pausa programada das 23h às 6h | Esperar. Ele volta sozinho a partir das 6h |
| Aviso **Processamento Limitado - Controle S5** | Chegou a 5.000 registros nesta execução | Normal. Rodar de novo continua de onde parou |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim. Os três códigos (`D@KQ`, `D@KV`, `D@LM`) foram apontados por Riscos Digitais como **Risco Inerente Moderado sem S5** e agora têm o controle.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada registro o robô confere o contador; enquanto não chegou a 5.000, trata o registro e soma 1; ao chegar em 5.000, para, avisa o usuário e grava no TB_LOG" width="100%">
</picture>

Quando o limite é atingido, aparece o aviso **Processamento Limitado - Controle S5**, a grade mostra *"Controle S5: limite de 5.000 registros atingido"* e a `TB_LOG` recebe *"CONTROLE S5 - LIMITE DE OPERACOES ATINGIDO - (ação) - MÁQUINA (n)"*. O que sobrou continua pendente para a próxima execução.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `LimitadorS5.cs` | constante `LIMITE_OPERACOES`, linha 28 |
| Mensagem do aviso | `LimitadorS5.cs` | método `LimiteAtingido` |
| Checagem do D@KQ | `Form1.cs` | `btnAtualizaCPF_Click`, bloco `[S5]` na linha 255 |
| Checagem do D@KV | `Form1.cs` | `btn_InsereEnvolvido_Click`, bloco `[S5]` na linha 532 |
| Checagem do D@LM | `Form1.cs` | `btn_InserePjReu_Click`, bloco `[S5]` na linha 809 |

> [!TIP]
> Para testar sem esperar 5.000 registros: troque `LIMITE_OPERACOES` para `2`, rode com 3 linhas, tire os prints com o relógio do Windows aparecendo e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra todos os pontos. As evidências oficiais estão em [`docs/Evidencias_S5_AtualizaEnvolvidos.docx`](docs/Evidencias_S5_AtualizaEnvolvidos.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `ComplementaCadastro\ATUALIZA_ENVOLVIDOS.csproj`

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `Form1.cs` | `gravaLOG` | 16 | Grava uma linha na `TB_LOG` (usuário do Windows, ação, data e hora) |
| | `btn_Importar_Click` | 49 | Roda as procedures `000_LIMPAR_TB_ENVOLVIDOS` e `001_ACRESCIMO_TB_ENVOLVIDOS` |
| | `btnDistribuir_Click` | 102 | Reparte as linhas pendentes entre as máquinas (rodízio 1, 2, 3...) |
| | `IniciaProcessamento` | 203 | Confere se o GCPJ está aberto e se o campo *Máquina* é um número |
| | `btnAtualizaCPF_Click` | 232 | Ação **D@KQ** |
| | `btn_InsereEnvolvido_Click` | 512 | Ação **D@KV** |
| | `btn_InserePjReu_Click` | 789 | Ação **D@LM** |
| | `ObterStringSemAcentosECaracteresEspeciais` | 496 | Tira acentos para comparar nomes |
| `Automacao.cs` | `localizarJanela` / `novaJanela` | 49 / 63 | Acha ou abre o IE do GCPJ |
| | `navegar`, `setaValorNome`, `clicar`, `espera` | 92 a 199 | Comandos básicos de tela |
| | `lerMsgBox` / `mataPossivelMsgBox` | 241 / 314 | Lê e fecha os alertas do GCPJ |
| | `cadastrarPF` / `cadastrarPJ` | 623 / 679 | Cadastro da pessoa no INFRA |
| | `selecionarTabelaEnvolvido` | 747 | Procura o envolvido na tabela do processo pelo nome |
| `Conexao.cs` | `con` | 13 | Caminho do banco: `BD\BD_DADOS.accdb` ao lado do `.exe` |
| `LimitadorS5.cs` | `LIMITE_OPERACOES` | 28 | Controle S5 |

</details>

<details>
<summary><b>Como cada ação funciona por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>

**D@KQ · Atualizar CPF/CNPJ**

1. Abre *Alteração De/Para* (`cadMantemCadProcAlteracaoAction`, estímulo `alteracaoDePara`) e pesquisa o processo.
2. Procura o nome do envolvido na tabela (com e sem acento) e descobre se ele é **autor** ou **réu**.
3. Se o documento já é o mesmo, grava *CPF/CNPJ JÁ CADASTRADO* e segue.
4. Escolhe PF ou PJ pelo campo `FILIAL` e preenche o documento de destino.
5. Se o documento não existe na base, vai em *Pessoa Externa* (`pessoaExternaBradescoAction`), altera o cadastro e salva.
6. Salva e grava a OBS conforme o retorno do GCPJ.

**D@KV · Inserir Demais Autores** e **D@LM · Inserir PJ Réu**

1. Abre a alteração de processos **ativos** (estímulo `alteracaoAtivos`) e pesquisa o processo.
2. Vai na aba do envolvido, informa o documento e clica em buscar.
3. Se a pessoa não existe, abre o cadastro (`openTelasCadastro`) e cadastra no INFRA com `cadastrarPF` ou `cadastrarPJ`.
4. Clica em *Incluir*. Se o GCPJ disser que já está relacionado, grava isso na OBS.
5. Salva. Se a tela não mudar depois do *Salvar*, grava *ERRO AO SALVAR*.

</details>

<details>
<summary><b>Banco de dados</b> &nbsp;·&nbsp; tabelas e procedures do Access</summary>
<br>

| Objeto | Tipo | Conteúdo |
| :--- | :--- | :--- |
| `TB_ENVOLVIDOS` | Tabela | `CNRO_PROCS_BDSCO` (processo), `NOME`, `CPF/CNPJ`, `FILIAL (PJ)`, `DIGITO`, `ATUALIZADO`, `OBS`, `MAQUINA` |
| `TB_LOG` | Tabela | `ID_Usuario`, `Log`, `DataHora` |
| `ATUALIZACAO_ENVOLVIDOS` | Tabela vinculada | Aponta para a planilha `ATUALIZACAO_ENVOLVIDOS.xlsx`, aba `Planilha1` |
| `000_LIMPAR_TB_ENVOLVIDOS` | Procedure | Apaga a importação anterior |
| `001_ACRESCIMO_TB_ENVOLVIDOS` | Procedure | Copia a planilha vinculada para a `TB_ENVOLVIDOS` |

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `LimitadorS5.cs` ➜ `LIMITE_OPERACOES` |
| Mudar as colunas da planilha | Procedure `001_ACRESCIMO_TB_ENVOLVIDOS` no Access |
| Mudar o horário da pausa (23h às 6h) | `Form1.cs` ➜ início do `while (dr.Read())` de cada ação |
| Mudar como o nome é comparado | `ObterStringSemAcentosECaracteresEspeciais` e `Automacao.selecionarTabelaEnvolvido` |
| Mudar o cadastro no INFRA | `Automacao.cs` ➜ `cadastrarPF` / `cadastrarPJ` |
| Mudar o endereço do GCPJ | `Form1.cs` e `Automacao.cs` ➜ procure `intranet85.net.bradesco.com.br/gcpj` |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **Inserir Demais Autores, documento recusado no INFRA:** na linha 627 do `Form1.cs` a comparação usa `"CPF / CNPJ INVALIDO"` (com espaços), mas o `cadastrarPF` devolve `"CPF/CNPJ INVALIDO"` (sem espaços). Por isso, nesse caso o robô não marca a falha ali e segue o fluxo. A ação D@LM (linha 905) está certa. A correção é de uma linha e já está indicada num comentário `// ATENÇÃO` no fim da própria linha 627.
- **Nome é comparado por texto exato.** Espaço duplo, abreviação ou nome cortado no GCPJ fazem o robô não achar o envolvido.
- **SQL montado por concatenação.** Nome com aspas simples (ex.: `D'AVILA`) pode dar erro ao gravar a OBS.
- **Depende do layout do GCPJ.** Os campos são achados pelo nome no HTML. Se o GCPJ mudar a tela, o robô quebra naquele passo.
- A pasta `obj` está versionada; ela é gerada na compilação e pode ser ignorada.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 10/2025 migração do Bitbucket para o GitHub; 07/2026 ajuste no tipo de envolvido; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: corrigir a linha 627" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 10/2025 | Beatriz Santos | Migração do Bitbucket |
| 07/2026 | Kaylane Machado | `Trim` na seleção do tipo de envolvido |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LimitadorS5.cs`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
