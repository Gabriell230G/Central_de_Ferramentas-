Attribute VB_Name = "Mod_GCPJ"
'Desenvolvido por Francielle B Queiroz em Julho/2020

'[64 bits] As declara��es abaixo funcionam no Excel 32 bits e no 64 bits.
'          #If VBA7 = Office 2010 ou mais novo (32 ou 64 bits); #Else = Office antigo (s� 32 bits).
#If VBA7 Then
    Public Declare PtrSafe Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As LongPtr, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As LongPtr
    Public Declare PtrSafe Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

    Private Declare PtrSafe Function FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, _
        ByVal lpWindowName As String) As LongPtr
    Private Declare PtrSafe Function FindWindowEx Lib "user32" Alias "FindWindowExA" (ByVal hWnd1 As LongPtr, _
        ByVal hWnd2 As LongPtr, ByVal lpsz1 As String, ByVal lpsz2 As String) As LongPtr

    Declare PtrSafe Function SendMessageBynum Lib "user32" Alias "SendMessageA" (ByVal hwnd As LongPtr, ByVal wMsg As Long, ByVal wParam As LongPtr, ByVal lParam As LongPtr) As LongPtr
#Else
    Public Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hwnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long
    Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

    Private Declare Function FindWindow Lib "user32" Alias "FindWindowA" (ByVal lpClassName As String, _
        ByVal lpWindowName As String) As Long
    Private Declare Function FindWindowEx Lib "user32" Alias "FindWindowExA" (ByVal hWnd1 As Long, _
    ByVal hWnd2 As Long, ByVal lpsz1 As String, ByVal lpsz2 As String) As Long

    Declare Function SendMessageBynum Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
#End If
    

Public Const WM_CLOSE = &H10
Private Const BM_CLICK As Integer = &HF5
Private Const WM_ACTIVATE As Integer = &H6
Private Const WA_ACTIVE As Integer = 1

'==============================================================================
'  CONTROLE S5 - LIMITADOR DE OPERA��ES
'  Normativo 05.1073 - Sistemas/Aplicativos Mantidos em Ambiente Departamental
'------------------------------------------------------------------------------
'  O QUE FAZ: limita quantos dep�sitos a macro trata no GCPJ em UMA execu��o.
'  Ao atingir o limite a macro para, avisa o usu�rio, registra na planilha e
'  os dep�sitos que sobraram continuam aguardando aprova��o no GCPJ.
'
'  COMO MUDAR O LIMITE: altere SOMENTE a constante LIMITE_OPERACOES_S5 abaixo.
'  ONDE � USADO: pesquise por "[S5]" (Ctrl+F no editor VBA).
'==============================================================================
Public Const LIMITE_OPERACOES_S5 As Long = 5000
    
Sub Verifica()
    Dim ie          As InternetExplorer
    Dim n           As Integer
    Dim cont        As Integer
    Dim qtdOperacoesS5 As Long  '[S5] contador de dep�sitos tratados nesta execu��o

    'Verifica se foi informada a data do dep�sito
    If Trim(Range("G4").Value) = "" Then
        MsgBox "Informe a data dos dep�sitos que devem ser aprovados.", vbExclamation + vbOKOnly, "Aten��o"
        Range("G4").Select
        Exit Sub
    ElseIf Not IsDate(Trim(Range("G4").Value)) Then
        MsgBox "Informe uma data v�lida!", vbExclamation + vbOKOnly, "Aten��o"
        Range("G4").Select
        Exit Sub
    End If
    
    Dim oShell
    Set oShell = CreateObject("WScript.Shell")
    oShell.AppActivate "aruser"
    
    Call Limpar
    
    Application.ScreenUpdating = False
    
    tempo_i = CDate(Now)

    'Instancia um objeto do Internet Explorer
    Set ie = New InternetExplorerMedium 'Tirei essa opcao(medium) para tendimento da RO 43232
    'Torna a tela visivel
    ie.Visible = False
    ie.Navigate ("https://intranet85.net.bradesco.com.br/gcpj")
    ie.Visible = True
    fechaGCPJ
    
    'Pagina do SISTEMA GCPJ
    ie.Navigate "https://intranet85.net.bradesco.com.br/gcpj/servlet/depositoAguardAprovAction?metodo=carregarTed&origem="
    Sleep 350
    Do While ie.Busy
    Loop
    Sleep 350
    
        
    'Verifica erro
    mm = 1
    Do
        mm = mm + 1
        a = ie.Document.all.Item(mm).innertext
        
        If mm > 60 Then
            MsgBox "Fa�a o login MANUALMENTE no Sistema GCPJ e tente novamente", vbCritical + vbOKOnly
            Exit Sub
        End If
    Loop Until ie.Document.all.Item(mm).innertext = "Financeiro Cont�bil / Lan�amentos / Dep�sito Judicial " & vbNewLine & "Aguardando Aprova��o - TED "
            
            
    n = 9
    cont = 0
    pagina = 1
    
retorno:
    pegarGCPJ = False
    Set objTable = ie.Document.getElementsByTagName("table")
        
        For lngTable = 1 To objTable.Length - 1
            For lngrow = 0 To objTable(lngTable).Rows.Length - 1
                If Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext) = "Dep�sito Judicial" Then
                     pegarGCPJ = True
                     primeiro_gcpj = ""
                     
                  ElseIf Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 3) = "[1]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 3) = "[6]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 4) = "[11]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 4) = "[16]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 4) = "[21]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 4) = "[26]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 4) = "[31]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 4) = "[36]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 4) = "[41]" Or _
                  Mid(Trim(objTable(lngTable).Rows(lngrow).Cells(0).innertext), 1, 5) = "1 [2]" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 3) = "1 2" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 4) = "11 1" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 4) = "16 1" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 4) = "21 2" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 4) = "26 2" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 4) = "31 3" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 4) = "36 3" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 4) = "41 4" Or _
                  Mid(Trim(Replace(Replace(objTable(lngTable).Rows(lngrow).Cells(0).innertext, "[", ""), "]", "")), 1, 3) = "6 7" Then
                    pagina = pagina + 1
                    Call ie.Document.parentWindow.execScript("document.forms[0].elements['paginaDeposito'].value=" & pagina & ";paginarFinanceiro('paginarDepositos')", "JavaScript")
                    
                    Do While ie.Busy
                    Loop
                    Sleep 800
                    GoTo retorno
                  
                  ElseIf pegarGCPJ = True Then
                    gcpj = Trim(objTable(lngTable).Rows(lngrow).Cells(1).innertext)
                    
                    If gcpj <> "Processo" Then
                        If primeiro_gcpj = "" Then
                            primeiro_gcpj = gcpj
                            If primeiro_gcpj = primeiro_gcpj_ant And primeiro_gcpj_ant <> "" Then
                                primeiro_gcpj_ant = ""
                                Exit For
                            ElseIf gcpj <> "" Then
                                primeiro_gcpj_ant = gcpj
                            End If
                        'ElseIf primeiro_gcpj = gcpj And Trim(objTable(lngTable).Rows(lngrow).Cells(7).innertext) = Trim(objTable(lngTable).Rows(lngrow - 1).Cells(7).innertext) Then
                        '    Exit For
                        End If
                        If Trim(objTable(lngTable).Rows(lngrow).Cells(3).innertext) = "TR" And _
                        (Trim(objTable(lngTable).Rows(lngrow).Cells(7).innertext) = "10.986,80" Or Trim(objTable(lngTable).Rows(lngrow).Cells(7).innertext) = "21.973,60") Or _
                        (Trim(objTable(lngTable).Rows(lngrow).Cells(7).innertext) = "13.813,83" Or Trim(objTable(lngTable).Rows(lngrow).Cells(7).innertext) = "27.627,66") Then
                        'If Trim(objTable(lngTable).Rows(lngrow).Cells(3).innertext) = "TR" Then
                            '[S5] Limitador de opera��es: antes de tratar o pr�ximo dep�sito, confere se o limite
                            '     da execu��o j� foi atingido (ver LimiteS5Atingido no fim deste m�dulo)
                            If LimiteS5Atingido(qtdOperacoesS5) Then
                                Range("I" & n).Value = "CONTROLE S5: PROCESSAMENTO INTERROMPIDO (LIMITE DE " & Format(LIMITE_OPERACOES_S5, "#,##0") & " REGISTROS)"
                                GoTo FimProcessamentoS5
                            End If
                            qtdOperacoesS5 = qtdOperacoesS5 + 1

                            cont = cont + 1
                            Range("B" & n).Value = gcpj
                            Range("C" & n).Value = Trim(objTable(lngTable).Rows(lngrow).Cells(4).innertext)
                            Range("D" & n).Value = Format(objTable(lngTable).Rows(lngrow).Cells(5).innertext, "mm/dd/yyyy")
                            Range("E" & n).Value = Format(objTable(lngTable).Rows(lngrow).Cells(6).innertext, "mm/dd/yyyy")
                            Range("F" & n).Value = Trim(objTable(lngTable).Rows(lngrow).Cells(7).innertext)
                                               
                            objTable(lngTable).Rows(lngrow).all.Item(1).Click
                            Do While ie.Busy: Loop
                             
                            'Verifica a data
                            If Format(objTable(lngTable).Rows(lngrow).Cells(6).innertext, "mm/dd/yyyy") = Format(Now(), "mm/dd/yyyy") Then
                                Range("I" & n).Value = "N�O FOI APROVADA DEVIDO A DATA DO DEP�SITO = HOJE"
                            ElseIf Format(objTable(lngTable).Rows(lngrow).Cells(6).innertext, "mm/dd/yyyy") = Format(objTable(lngTable).Rows(lngrow).Cells(5).innertext, "mm/dd/yyyy") Then
                                Range("I" & n).Value = "N�O FOI APROVADA DEVIDO A DATA SOLICITA��O = DATA DO DEP�SITO"
                            ElseIf Format(objTable(lngTable).Rows(lngrow).Cells(6).innertext, "mm/dd/yyyy") <> Format(Trim(Range("G4").Value), "mm/dd/yyyy") Then
                                Range("I" & n).Value = "N�O FOI APROVADA DEVIDO A DATA DO DEP�SITO SER DIFERENTE DA DATA INFORMADA"
                            Else
                                ie.Document.all.Item("btoDetalhe").Click
                                Do While ie.Busy: Loop
                                Sleep (1500)
                                
                                'Se aprovar a linha sai da grid, ent�o volta uma linha
                                If aprova(ie, ie.Document.all.Item("SelFinalidade").Value, n) Then
                                    lngrow = lngrow - 1
                                End If
                                Sleep (500)
                                
                                Set objTable = ie.Document.getElementsByTagName("table")
                            End If
                            n = n + 1
                        End If
                                                                        
                    End If
                   
                End If
                              
            Next lngrow
           
            Sleep (500)
        Next lngTable

FimProcessamentoS5:   '[S5] destino quando o limite de opera��es � atingido (sai dos dois la�os)
        
    tempo_f = CDate(Now)
    tempo_t = CDate(tempo_f) - CDate(tempo_i)
     Application.ScreenUpdating = True
'-----------------------------------------------------------------------------------------...
    If cont = 0 Then
        MsgBox "Fim do Processo." & Chr(13) & "Nenhum registro localizado dentro dos par�metros para aprova��o" & Chr(13) & "Tempo: " & CDate(tempo_t), vbInformation + vbOKOnly, "Fim"
    Else
        MsgBox "Fim do Processo." & Chr(13) & cont & " registro(s) localizado(s)." & Chr(13) & "Tempo: " & CDate(tempo_t), vbInformation + vbOKOnly, "Fim"
    End If
'-----------------------------------------------------------------------------------------...
  
End Sub

Function aprova(ie As Object, id As Integer, lin As Integer) As Boolean
     Dim reclamada As String
     
     'Pega finalidade
     Set objCollection = ie.Document.all.Item("SelFinalidade").Document.getElementsByTagName("option")
     a = 0
     While a < objCollection.Length
         If objCollection(a).Value = id Then
            Range("G" & lin).Value = objCollection(a).innertext
            a = objCollection.Length
         End If
      a = a + 1
     Wend
     
    'Pega reclamada
    Set objTable = ie.Document.getElementsByTagName("table")(1)
    For Each linha In objTable.all.tags("tr")
        If Trim(linha.all.tags("td")(0).innertext) = "Reclamada:" Then
            reclamada = Trim(linha.all.tags("td")(1).innertext)
            Range("H" & lin).Value = reclamada
            Exit For
        End If
    Next
       
    'Verifica reclamada
    If InStr(reclamada, "Funda��o Bradesco") > 0 Or InStr(reclamada, "Fimaden") > 0 Or InStr(reclamada, "Hospital Edmundo Vasconcelos") > 0 Then
        Range("I" & lin).Value = "N�O FOI APROVADA DEVIDO A RECLAMADA"
        ie.Document.all.Item("btoVoltar").Click
        Do While ie.Busy: Loop
        Exit Function
    End If
    
    'Verifica o valor x finalidade
    If Range("F" & lin).Value = "27.627,66" And (Range("G" & lin).Value = "RECURSO DE REVISTA" Or Range("G" & lin).Value = "AGRAVO DE INSTRUMENTO RR") Or _
    Range("F" & lin).Value = "13.813,83" And (Range("G" & lin).Value = "RECURSO ORDINARIO" Or Range("G" & lin).Value = "AGRAVO DE INSTRUMENTO RO") Or _
    Range("F" & lin).Value = "27.627,66" And (Range("G" & lin).Value = "RECURSO DE REVISTA" Or Range("G" & lin).Value = "AGRAVO DE INSTRUMENTO RR") Or _
    Range("F" & lin).Value = "13.813,83" And (Range("G" & lin).Value = "RECURSO ORDINARIO" Or Range("G" & lin).Value = "AGRAVO DE INSTRUMENTO RO") Or _
    Range("F" & lin).Value = "13.813,83" And (Range("G" & lin).Value = "RECURSO ORDINARIO" Or Range("G" & lin).Value = "AGRAVO DE INSTRUMENTO RR") Then
        ie.Document.all.Item("btoAprov").Click
        Do While ie.Busy
            Application.Wait (Now + TimeValue("0:00:01"))
            winHwnd = FindWindow(vbNullString, "Mensagem da p�gina da web")
            If winHwnd <> 0 Then
                btn = FindWindowEx(winHwnd, 0, "Button", "OK")
                Call SendMessageBynum(btn, WM_ACTIVATE, WA_ACTIVE, 0)
                Call SendMessageBynum(btn, BM_CLICK, 1, 0)
            End If
        Loop
       Range("I" & lin).Value = "TED APROVADA"
       aprova = True
       Exit Function
    Else
        Range("I" & lin).Value = "N�O FOI APROVADA DEVIDO A FINALIDADE x VALOR"
        ie.Document.all.Item("btoVoltar").Click
        Do While ie.Busy: Loop
    End If
    aprova = False
End Function


Sub fechaGCPJ()
    Dim objSW As ShellWindows
    Set objSW = New ShellWindows
    Dim objIE As InternetExplorer

      
    For Each x In objSW
        If x.LocationName = "(GCPJ) Gest�o e Controle de Processos Jur�dicos" Or _
        x.LocationName = "(GCPJ) Gest�o Controle de Processos Jur�dicos" Then
              Sleep (250)
              Set objIE = x
              objIE.Application.Quit
        End If
    Next x
  
End Sub


'[S5] Retorna True quando a execu��o j� chegou no limite do Controle S5 e, nesse caso, avisa o usu�rio.
'     Uso dentro do la�o:  If LimiteS5Atingido(qtdOperacoesS5) Then GoTo FimProcessamentoS5
Public Function LimiteS5Atingido(ByVal qtdOperacoes As Long) As Boolean
    If qtdOperacoes < LIMITE_OPERACOES_S5 Then Exit Function

    MsgBox "O limite de processamento de " & Format(LIMITE_OPERACOES_S5, "#,##0") & " registros foi atingido." & vbCrLf & vbCrLf & _
           "Os dep�sitos restantes continuam aguardando aprova��o no GCPJ e podem ser processados em uma nova execu��o.", _
           vbExclamation + vbOKOnly, "Processamento Limitado - Controle S5"
    LimiteS5Atingido = True
End Function
