﻿Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_ClickYes
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function

    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1
    Private t1 As Thread

    Private Sub Frm_Principal_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Me.Left = ((Screen.PrimaryScreen.WorkingArea.Width - Me.Width))
        Me.Top = ((Screen.PrimaryScreen.WorkingArea.Height - Me.Height))

        t1 = New Thread(AddressOf Me.MataMsgBox)
        t1.Start()

    End Sub

    Private Sub MataMsgBox()
        If BTInicio.Text = "Start" Then Exit Sub

        Dim winHwnd As Long
        Do Until winHwnd <> 0
            System.Windows.Forms.Application.DoEvents()
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
            Thread.Sleep(1000)
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)

        MataMsgBox()

    End Sub


    Private Sub MenuAbrirArquivo_Click(sender As System.Object, e As System.EventArgs) Handles MenuAbrirArquivo.Click
        End
    End Sub

    Private Sub BTSair_Click(sender As System.Object, e As System.EventArgs) Handles BTSair.Click
        End
    End Sub


    Private Sub BTInicio_Click(sender As System.Object, e As System.EventArgs) Handles BTInicio.Click
        If BTInicio.Text = "Start" Then
            BTInicio.Text = "Stop"
            BTInicio.ForeColor = Color.DarkRed
            PictureBox1.Visible = True
            t1 = New Thread(AddressOf Me.MataMsgBox)
            t1.Start()
        Else
            BTInicio.Text = "Start"
            BTInicio.ForeColor = Color.LimeGreen
            PictureBox1.Visible = False


        End If

    End Sub
End Class
