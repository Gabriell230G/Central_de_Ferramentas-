﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_ClickYes
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_ClickYes))
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.MenuSuspenso = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.MenuAbrirArquivo = New System.Windows.Forms.ToolStripMenuItem()
        Me.BTSair = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.BTInicio = New System.Windows.Forms.Button()
        Me.MenuSuspenso.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.ContextMenuStrip = Me.MenuSuspenso
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "ClickYes Web"
        Me.NotifyIcon1.Visible = True
        '
        'MenuSuspenso
        '
        Me.MenuSuspenso.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuAbrirArquivo})
        Me.MenuSuspenso.Name = "ContextMenuStrip1"
        Me.MenuSuspenso.Size = New System.Drawing.Size(94, 26)
        '
        'MenuAbrirArquivo
        '
        Me.MenuAbrirArquivo.Image = CType(resources.GetObject("MenuAbrirArquivo.Image"), System.Drawing.Image)
        Me.MenuAbrirArquivo.Name = "MenuAbrirArquivo"
        Me.MenuAbrirArquivo.Size = New System.Drawing.Size(93, 22)
        Me.MenuAbrirArquivo.Text = "Sair"
        '
        'BTSair
        '
        Me.BTSair.BackColor = System.Drawing.Color.Transparent
        Me.BTSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTSair.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTSair.ForeColor = System.Drawing.Color.DarkRed
        Me.BTSair.Image = CType(resources.GetObject("BTSair.Image"), System.Drawing.Image)
        Me.BTSair.Location = New System.Drawing.Point(149, 58)
        Me.BTSair.Name = "BTSair"
        Me.BTSair.Size = New System.Drawing.Size(60, 36)
        Me.BTSair.TabIndex = 1
        Me.BTSair.Text = "Sair"
        Me.BTSair.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.BTSair.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(46, 19)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(135, 22)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "ClickYes Web"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(95, 58)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(45, 34)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'BTInicio
        '
        Me.BTInicio.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BTInicio.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTInicio.ForeColor = System.Drawing.Color.LimeGreen
        Me.BTInicio.Location = New System.Drawing.Point(12, 58)
        Me.BTInicio.Name = "BTInicio"
        Me.BTInicio.Size = New System.Drawing.Size(77, 36)
        Me.BTInicio.TabIndex = 4
        Me.BTInicio.Text = "Start"
        Me.BTInicio.UseVisualStyleBackColor = True
        '
        'Frm_Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(215, 100)
        Me.Controls.Add(Me.BTInicio)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BTSair)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frm_Principal"
        Me.Opacity = 0.8R
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ClickYes Web"
        Me.TopMost = True
        Me.MenuSuspenso.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents NotifyIcon1 As System.Windows.Forms.NotifyIcon
    Friend WithEvents MenuSuspenso As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents MenuAbrirArquivo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BTSair As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents BTInicio As System.Windows.Forms.Button

End Class
