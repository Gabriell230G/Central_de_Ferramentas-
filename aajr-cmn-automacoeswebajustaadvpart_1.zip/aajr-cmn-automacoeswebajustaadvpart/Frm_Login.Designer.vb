﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
<Global.System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1726")> _
Partial Class Frm_Login
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Login))
        Me.Palheta = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Senha = New System.Windows.Forms.TextBox()
        Me.Login = New System.Windows.Forms.TextBox()
        Me.PasswordLabel = New System.Windows.Forms.Label()
        Me.UsernameLabel = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.NovaSenhaConfirmacao = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.NovaSenha = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SenhaAtual = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.BTOk = New System.Windows.Forms.Button()
        Me.BTCancelar = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Palheta.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Palheta
        '
        Me.Palheta.Controls.Add(Me.TabPage1)
        Me.Palheta.Controls.Add(Me.TabPage2)
        Me.Palheta.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Palheta.Location = New System.Drawing.Point(5, 62)
        Me.Palheta.Name = "Palheta"
        Me.Palheta.SelectedIndex = 0
        Me.Palheta.Size = New System.Drawing.Size(198, 115)
        Me.Palheta.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.Controls.Add(Me.Senha)
        Me.TabPage1.Controls.Add(Me.Login)
        Me.TabPage1.Controls.Add(Me.PasswordLabel)
        Me.TabPage1.Controls.Add(Me.UsernameLabel)
        Me.TabPage1.ImeMode = System.Windows.Forms.ImeMode.Off
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(190, 89)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Login"
        '
        'Senha
        '
        Me.Senha.Location = New System.Drawing.Point(53, 49)
        Me.Senha.Name = "Senha"
        Me.Senha.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.Senha.Size = New System.Drawing.Size(122, 20)
        Me.Senha.TabIndex = 1
        '
        'Login
        '
        Me.Login.Enabled = False
        Me.Login.Location = New System.Drawing.Point(53, 22)
        Me.Login.Name = "Login"
        Me.Login.Size = New System.Drawing.Size(122, 20)
        Me.Login.TabIndex = 0
        '
        'PasswordLabel
        '
        Me.PasswordLabel.AutoSize = True
        Me.PasswordLabel.Location = New System.Drawing.Point(6, 49)
        Me.PasswordLabel.Name = "PasswordLabel"
        Me.PasswordLabel.Size = New System.Drawing.Size(41, 13)
        Me.PasswordLabel.TabIndex = 6
        Me.PasswordLabel.Text = "&Senha:"
        Me.PasswordLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'UsernameLabel
        '
        Me.UsernameLabel.AutoSize = True
        Me.UsernameLabel.Location = New System.Drawing.Point(6, 22)
        Me.UsernameLabel.Name = "UsernameLabel"
        Me.UsernameLabel.Size = New System.Drawing.Size(36, 13)
        Me.UsernameLabel.TabIndex = 4
        Me.UsernameLabel.Text = "Login:"
        Me.UsernameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TabPage2
        '
        Me.TabPage2.AutoScroll = True
        Me.TabPage2.BackColor = System.Drawing.Color.White
        Me.TabPage2.Controls.Add(Me.NovaSenhaConfirmacao)
        Me.TabPage2.Controls.Add(Me.Label3)
        Me.TabPage2.Controls.Add(Me.NovaSenha)
        Me.TabPage2.Controls.Add(Me.Label2)
        Me.TabPage2.Controls.Add(Me.SenhaAtual)
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(190, 89)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Trocar Senha"
        '
        'NovaSenhaConfirmacao
        '
        Me.NovaSenhaConfirmacao.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.NovaSenhaConfirmacao.Location = New System.Drawing.Point(78, 65)
        Me.NovaSenhaConfirmacao.Name = "NovaSenhaConfirmacao"
        Me.NovaSenhaConfirmacao.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.NovaSenhaConfirmacao.Size = New System.Drawing.Size(104, 20)
        Me.NovaSenhaConfirmacao.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(7, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Confirmação:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'NovaSenha
        '
        Me.NovaSenha.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.NovaSenha.Location = New System.Drawing.Point(78, 39)
        Me.NovaSenha.Name = "NovaSenha"
        Me.NovaSenha.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.NovaSenha.Size = New System.Drawing.Size(104, 20)
        Me.NovaSenha.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(7, 33)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(175, 23)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Nova Senha:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'SenhaAtual
        '
        Me.SenhaAtual.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.SenhaAtual.Location = New System.Drawing.Point(78, 13)
        Me.SenhaAtual.Name = "SenhaAtual"
        Me.SenhaAtual.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.SenhaAtual.Size = New System.Drawing.Size(104, 20)
        Me.SenhaAtual.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(7, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Senha Atual:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Arial", 9.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(117, 24)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(191, 33)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Cadastro de Processos Internos"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'BTOk
        '
        Me.BTOk.Location = New System.Drawing.Point(210, 116)
        Me.BTOk.Name = "BTOk"
        Me.BTOk.Size = New System.Drawing.Size(96, 25)
        Me.BTOk.TabIndex = 9
        Me.BTOk.Text = "Ok"
        Me.BTOk.UseVisualStyleBackColor = True
        '
        'BTCancelar
        '
        Me.BTCancelar.Location = New System.Drawing.Point(210, 148)
        Me.BTCancelar.Name = "BTCancelar"
        Me.BTCancelar.Size = New System.Drawing.Size(96, 25)
        Me.BTCancelar.TabIndex = 10
        Me.BTCancelar.Text = "Cancelar"
        Me.BTCancelar.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Silver
        Me.Label5.Location = New System.Drawing.Point(110, 186)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(196, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Informática Sistemas e Banco de Dados"
        '
        'Frm_Login
        '
        Me.AcceptButton = Me.BTOk
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ClientSize = New System.Drawing.Size(313, 204)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.BTCancelar)
        Me.Controls.Add(Me.BTOk)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Palheta)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Frm_Login"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        Me.Palheta.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Senha As System.Windows.Forms.TextBox
    Friend WithEvents Login As System.Windows.Forms.TextBox
    Friend WithEvents PasswordLabel As System.Windows.Forms.Label
    Friend WithEvents UsernameLabel As System.Windows.Forms.Label
    Friend WithEvents NovaSenha As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents SenhaAtual As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NovaSenhaConfirmacao As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Palheta As System.Windows.Forms.TabControl
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents BTOk As System.Windows.Forms.Button
    Friend WithEvents BTCancelar As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label

End Class
