# Automações Web (aajr-cmn-automacoeswebajustaadvpart)

Um **único executável** com várias automações do GCPJ dentro. Cada automação é uma tela (`Frm_...`) e só aparece no menu quando a base `.mdb` dela está na pasta do executável. Ou seja: o mesmo programa vira "aplicativos diferentes" dependendo de qual base foi distribuída para o usuário.

| Item | Valor |
|---|---|
| Códigos no inventário | **C@JH** AlteraAgCEF (`Frm_Altera_Ag_Conta`) · **D@EO** Inclusão/Atualização Eventos (`Frm_Inclusao_Evento` / `Frm_Atualizacao_Evento_Realizado`, a confirmar) |
| Área | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| Linguagem | VB.NET (Windows Forms, MDI) |
| Framework | .NET Framework 4.8 |
| Sistema alvo | GCPJ (Internet Explorer, via SHDocVw) |
| Bases locais | um `.mdb` por automação (tabela abaixo) |
| Controle S5 | Implementado em **todas** as automações que mexem no GCPJ (limite de **5.000** registros por execução) |

---

## Sumário

1. [Como o sistema funciona](#1-como-o-sistema-funciona)
2. [Como rodar](#2-como-rodar)
3. [Mapa das automações](#3-mapa-das-automações)
4. [Controle S5: Limitador de Operações](#4-controle-s5-limitador-de-operações)
5. [Guia rápido: quero mudar X, onde vou?](#5-guia-rápido-quero-mudar-x-onde-vou)
6. [Como criar uma automação nova já com S5](#6-como-criar-uma-automação-nova-já-com-s5)
7. [Pontos de atenção](#7-pontos-de-atenção)
8. [Histórico](#8-histórico)

---

## 1. Como o sistema funciona

```
Abre o Frm_Principal (menu)
   ➜ para cada base .mdb encontrada na pasta, lista a tela correspondente
   ➜ se só existe 1 base, já abre a tela direto
   ➜ liga o "ClickYesWeb" (thread que clica OK sozinho nas mensagens "Mensagem da página da web")

Dentro de cada tela (padrão de quase todas):
   Conectar GCPJ ➜ (opcional) Distribuir Máquinas ➜ Processar
      ➜ lê da base os registros pendentes (ex.: atualizado = false)
      ➜ para cada registro: abre a tela do GCPJ, preenche, salva
      ➜ marca o registro como feito na base
      ➜ para às 22h, quando acabam os registros OU quando atinge o limite do Controle S5
```

O botão **Distribuir Máquinas** divide os registros pendentes entre várias máquinas (coluna `maquina`). No **Processar**, cada máquina pega só o seu número.

## 2. Como rodar

1. Abra `Automacoes_Web.sln` no Visual Studio.
2. Instale o **Microsoft Access Database Engine** (ACE OLEDB 12.0).
3. Copie para a pasta do executável a(s) base(s) `.mdb` da automação que vai usar.
4. Rode, escolha a tela no menu, clique em **Conectar GCPJ** e depois em **Processar**.

## 3. Mapa das automações

| Tela (`.vb`) | O que faz no GCPJ | Base | Tabela | Bloco `[S5]` |
|---|---|---|---|---|
| `Frm_Altera_Ag_Conta` | Corrige banco/agência/conta de depósitos judiciais (**C@JH**) | `BD_Altera_Ag_Conta.mdb` | `Depositos_Judiciais` | `BTProcessar_Click` |
| `Frm_Alteracao_Classificacao` | Altera a classificação do processo | `BD_Alteracao_Classificacao.mdb` | `TB_Alteracao_Classificacao` | `BTProcessar_Click` |
| `Frm_Alterar_Procs_CI` | Altera dados de processos Cível | `BD_Cadastro_Processos_CI.mdb` | `Processos_CI` | `BTProcessar_Click` |
| `Frm_Aprovacao_Encerramento` | Aprova encerramentos no trâmite de pendências | `BD_Dados_Aprovacao_Encerramento.mdb` | `TB_Aprovacao_Encerramento` | `BTProcessar_Click` |
| `Frm_Aprovar_Migracao` | Dá ciência em lote nas pendências de distribuição | `BD_Aprovar_Migracao.mdb` | - | `BTProcessar_Click` (por **lote**) |
| `Frm_Atualizacao_Evento_Realizado` | Atualiza eventos realizados (**D@EO**, a confirmar) | `BD_Alterar_Evento.mdb` | `TB_Principa` | `BTProcessar_Click` |
| `Frm_Atualizar_Valor_Calculo` | Cadastra/atualiza valor de cálculo | `BD_Atualizacao_Valor_Calculo.mdb` | `TB_Atualizacao_Calculo` | `Rotina_Alteracao` e `Rotina_Cadastro` |
| `Frm_Cadastro_Consultoria_Negocios` | Cadastra processos internos (Consultoria e Negócios) | `BD_Cadastro_Consultoria_Negocios.mdb` | `TB_PROCS_INTERNO` | `BTCadastrar_Click` |
| `Frm_Cadastro_Envolvido` | Cadastra pessoa externa | `BD_Cadastro_Processos_CI.mdb` | `CADASTRO_ENVOLVIDO` | `BTProcessar_Click` |
| `Frm_Cadastro_Honorarios` | Cadastra notas de honorários | `<usuário>\BD_Cadastro_Honorarios.mdb` | `TB_NOTAS` / `Planilha_Importada` | `BTProcessar_Click` |
| `Frm_Cadastro_Processos_CI` | Cadastra processos Cível | `BD_Cadastro_Processos_CI.mdb` | `Processos_CI` | `BTProcessar_Click` |
| `Frm_Captura_Fundamento` | Captura o fundamento do processo (leitura) | `BD_Dados_Fundamento.mdb` | `TB_FUNDAMENTO` | `BTProcessar_Click` |
| `Frm_Distribuicao` | Distribui processos | `BD_Distribuicao.mdb` | `TB_Distribuicao` | `BTProcessar_Click` |
| `Frm_Impressao_Planilha` | Gera/salva a planilha do processo (leitura) | `BD_Impressao_Planilha.mdb` | `processos` | `BTProcessar_Click` |
| `Frm_Inclusao_Evento` | Inclui eventos (**D@EO**, a confirmar) | `BD_Inserir_Evento.mdb` | `TB_Principa` | `AtualizacaoEvento`, `InclusaoSineDee`, `InclusaoEvento`, `AlterarDataEvento` |
| `Frm_Inserir_Deposito` | Inclui depósitos contabilizados | `BD_Inserir_Deposito.mdb` | `Depositos` | `BTProcessar_Click` |
| `Frm_Inserir_Evento_Pendencia` | Inclui e valida eventos de pendência | `BD_Tramite_Pendencias.mdb` | `Log_Geral` | `BTProcessarInclusao_Click` e `BTProcessarValidacao_Click` |
| `Frm_Migracao` | Migração de processos em massa | `BD_Migracao.mdb` | `tbMigracao` | `MigrarProcessos_Click` |
| `Frm_Procs_CI_Alterar_Processo` | Acerto de processos Cível | `BDDados_Acerto_Processos_CI.mdb` | - | `BTProcessar_Click` |
| `Frm_Redistribuicao` | Redistribui processos | `BD_Redistribuicao.mdb` | `tbRedistribuicao` | `BtProcessarRedistribuicao_Click` |

Telas que **existem na pasta mas não estão no projeto** (não entram no executável hoje). Também receberam o bloco `[S5]` para já ficarem protegidas se forem incluídas:
`Frm_Altera_Pessoa_Externa`, `Frm_Baixar_Comprovante`, `Frm_Inserir_Reclamante_Reclamada`.

## 4. Controle S5: Limitador de Operações

Exigência do normativo **05.1073** para aplicativos com C10 = Sim (automação que captura ou atualiza dados em sistema estruturado).

### Como funciona

Tudo fica centralizado em **um arquivo**: `Mod_LimitadorS5.vb`. Cada rotina só chama a função dele.

```
Clique em Processar ➜ qtdOperacoesS5 = 0
   Para cada registro do laço:
      LimiteS5Atingido(qtdOperacoesS5)?  ➜ SIM: avisa o usuário e sai do laço
                                          ➜ NÃO: soma 1 e processa normalmente
```

Ao atingir o limite aparece a mensagem **"Processamento Limitado - Controle S5"**. Os registros que sobraram continuam pendentes na base `.mdb` e entram na próxima execução.

### Onde mexer

| O que | Arquivo | Onde |
|---|---|---|
| **Limite de registros** (todas as telas) | `Mod_LimitadorS5.vb` | constante `LIMITE_OPERACOES_S5` (linha 25) |
| **Limite de lotes** (só Aprovar Migração) | `Mod_LimitadorS5.vb` | constante `LIMITE_LOTES_S5` (linha 31) |
| Mensagem exibida ao usuário | `Mod_LimitadorS5.vb` | função `LimiteS5Atingido` |
| Pontos de checagem | cada `Frm_...vb` | coluna **Bloco `[S5]`** do mapa acima |

> Dica: **Ctrl+Shift+F** e pesquise `[S5]`. Cada rotina tem 1 linha de declaração e 1 bloco de 3 linhas.

O bloco padrão é sempre este:

```vb
' início da Sub
Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução

' primeira coisa dentro do laço
'[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
qtdOperacoesS5 += 1
```

Detalhes que importam:

- O `Dim` fica na **primeira linha da Sub**, antes de qualquer rótulo (`Inicio:`). Assim um `GoTo Inicio` não zera o contador.
- Quando o laço tem rótulo de "tentar de novo o mesmo registro" (ex.: `inicio:`, `forIni:`), o bloco fica **antes** do rótulo para a nova tentativa não contar duas vezes.
- Quando o rótulo é usado para **pular para o próximo** registro (`index += 1 : GoTo forIn`), o bloco fica **depois** do rótulo, para o pulo também contar.

### Documento de evidências

O Word com as evidências do Controle S5 (trechos do código alterado, resultado dos testes e espaço para os prints do ambiente) fica em [`docs/Evidencias_S5_AutomacoesWeb.docx`](docs/Evidencias_S5_AutomacoesWeb.docx).

### Como testar e gerar a evidência

1. Em `Mod_LimitadorS5.vb`, troque temporariamente `LIMITE_OPERACOES_S5 = 5000` para `2`.
2. Escolha a tela, deixe pelo menos 3 registros pendentes na base e clique em **Processar**.
3. Confira: 2 registros processados e o aviso **Processamento Limitado - Controle S5**.
4. Tire os prints com o **relógio do Windows aparecendo**: código e mensagem.
5. **Volte o valor para 5000** antes de gerar a versão final.

## 5. Guia rápido: quero mudar X, onde vou?

| Quero... | Vá em |
|---|---|
| Mudar o limite do Controle S5 | `Mod_LimitadorS5.vb` |
| Liberar uma automação para um usuário | copiar a base `.mdb` dela para a pasta do executável |
| Mudar a lista do menu | `Frm_Principal.vb` ➜ `Frm_Principal_Load` |
| Mudar o horário de parada (22h) | dentro do laço de cada tela, `If Date.Now >= ... "22:00:00"` |
| Mudar o "clicador" automático de mensagens | `Frm_Principal.vb` ➜ `MataMsgBox` / `BTClickYes_Click` |
| Mudar a espera de carregamento do IE | `Mod_Funcoes.vb` ➜ `Espera_Ate_Que_Abra_Public` |
| Mudar o login | `Frm_Login.vb` (usa `TB_USUARIOS` do `BD_Cadastro_Consultoria_Negocios.mdb`) |

## 6. Como criar uma automação nova já com S5

1. Crie o `Frm_NomeDaTela.vb` e a base `BD_NomeDaTela.mdb`.
2. Em `Frm_Principal_Load`, adicione a linha que lista a tela quando a base existir.
3. Na Sub que processa, coloque o `Dim qtdOperacoesS5` na primeira linha e o bloco `[S5]` como primeira coisa dentro do laço.
4. Atualize a tabela do item 3 deste README.

## 7. Pontos de atenção

- O `ClickYesWeb` precisa estar ligado em várias telas. Ele só clica em janelas com o título **"Mensagem da página da web"**, então **não** fecha o aviso do Controle S5.
- `Frm_Inclusao_Evento` tem 4 rotinas, mas o botão hoje chama só `InclusaoEvento`. As outras estão comentadas e já têm o bloco `[S5]`.
- `Frm_Atualizar_Valor_Calculo` hoje chama só `Rotina_Cadastro`.
- `Frm_Aprovar_Migracao` não tem fim natural (`Do While x = 0`). O limite de lotes é o que garante a parada.
- As pastas `bin`, `obj` e `publish` estão versionadas; são geradas na compilação.

## 8. Histórico

| Data | Autor | Alteração |
|---|---|---|
| 01/2026 | Daniela Chirinian | Primeiro commit (migração para o GitHub) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`Mod_LimitadorS5.vb`) em todas as telas e novo README |

---

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
