﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Baixar_Comprovante
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Baixar_Comprovante))
        Me.Grade = New System.Windows.Forms.ListBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.BTConectaGCPJ = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BTProcessar = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.PalavraChave = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grade
        '
        Me.Grade.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Grade.FormattingEnabled = True
        Me.Grade.Location = New System.Drawing.Point(0, 25)
        Me.Grade.Name = "Grade"
        Me.Grade.Size = New System.Drawing.Size(965, 429)
        Me.Grade.TabIndex = 10
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BTConectaGCPJ, Me.ToolStripSeparator1, Me.BTProcessar, Me.ToolStripSeparator2, Me.ToolStripLabel1, Me.PalavraChave})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(965, 25)
        Me.ToolStrip1.TabIndex = 11
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'BTConectaGCPJ
        '
        Me.BTConectaGCPJ.Image = CType(resources.GetObject("BTConectaGCPJ.Image"), System.Drawing.Image)
        Me.BTConectaGCPJ.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTConectaGCPJ.Name = "BTConectaGCPJ"
        Me.BTConectaGCPJ.Size = New System.Drawing.Size(105, 22)
        Me.BTConectaGCPJ.Text = "Conectar GCPJ"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BTProcessar
        '
        Me.BTProcessar.Enabled = False
        Me.BTProcessar.Image = CType(resources.GetObject("BTProcessar.Image"), System.Drawing.Image)
        Me.BTProcessar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTProcessar.Name = "BTProcessar"
        Me.BTProcessar.Size = New System.Drawing.Size(77, 22)
        Me.BTProcessar.Text = "Processar"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(84, 22)
        Me.ToolStripLabel1.Text = "Palavra Chave:"
        '
        'PalavraChave
        '
        Me.PalavraChave.Name = "PalavraChave"
        Me.PalavraChave.Size = New System.Drawing.Size(200, 25)
        Me.PalavraChave.Text = "COMPROVANTE DEPOSITO"
        '
        'Frm_Baixar_Comprovante
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(965, 454)
        Me.Controls.Add(Me.Grade)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "Frm_Baixar_Comprovante"
        Me.Text = "Frm_Baixar_Comprovante"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Grade As System.Windows.Forms.ListBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents BTConectaGCPJ As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BTProcessar As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents PalavraChave As System.Windows.Forms.ToolStripTextBox
End Class
