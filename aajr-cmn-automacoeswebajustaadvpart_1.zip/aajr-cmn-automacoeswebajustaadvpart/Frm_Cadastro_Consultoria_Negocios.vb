﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Imports ADODB
Imports System.Text
Imports excel = Microsoft.Office.Interop.Excel

Public Class Frm_Cadastro_Consultoria_Negocios

    Dim EnvolvidoErro As String

    Dim VarSair As Boolean = False
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Cadastro_Consultoria_Negocios.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Cadastro_Consultoria_Negocios_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Frm_Login.ShowDialog()

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()

        AlimentarAreas()
        AlimentarSegmento()
        CarregarGrade()

    End Sub
    Private Sub CarregarGrade()
        Dim VsQl2 As String = "SELECT TB_PROCS_INTERNO.CHAVE_INTERNA, TB_PROCS_INTERNO.JUNCAO, TB_PROCS_INTERNO.AREA_CONSULTA, TB_PROCS_INTERNO.SEGMENTO, TB_PROCS_INTERNO.DATA_ENVIO, TB_PROCS_INTERNO.ENVOLVIDO1, TB_PROCS_INTERNO.CPF1, TB_PROCS_INTERNO.FILIAL1, TB_PROCS_INTERNO.DIGITO1, TB_PROCS_INTERNO.ENVOLVIDO2, TB_PROCS_INTERNO.CPF2, TB_PROCS_INTERNO.FILIAL2, TB_PROCS_INTERNO.DIGITO2, TB_PROCS_INTERNO.ENVOLVIDO3, TB_PROCS_INTERNO.CPF3, TB_PROCS_INTERNO.FILIAL3, TB_PROCS_INTERNO.DIGITO3, TB_PROCS_INTERNO.ENVOLVIDO4, TB_PROCS_INTERNO.CPF4, TB_PROCS_INTERNO.FILIAL4, TB_PROCS_INTERNO.DIGITO4, TB_PROCS_INTERNO.ENVOLVIDO5, TB_PROCS_INTERNO.CPF5, TB_PROCS_INTERNO.FILIAL5, TB_PROCS_INTERNO.DIGITO5, TB_PROCS_INTERNO.ENVOLVIDO6, TB_PROCS_INTERNO.CPF6, TB_PROCS_INTERNO.FILIAL6, TB_PROCS_INTERNO.DIGITO6, TB_PROCS_INTERNO.ENVOLVIDO7, TB_PROCS_INTERNO.CPF7, TB_PROCS_INTERNO.FILIAL7, TB_PROCS_INTERNO.DIGITO7, TB_PROCS_INTERNO.ENVOLVIDO8, TB_PROCS_INTERNO.CPF8, TB_PROCS_INTERNO.FILIAL8, TB_PROCS_INTERNO.DIGITO8, TB_PROCS_INTERNO.ENVOLVIDO9, TB_PROCS_INTERNO.CPF9, TB_PROCS_INTERNO.FILIAL9, TB_PROCS_INTERNO.DIGITO9, TB_PROCS_INTERNO.ENVOLVIDO10, TB_PROCS_INTERNO.CPF10, TB_PROCS_INTERNO.FILIAL10, TB_PROCS_INTERNO.DIGITO10, TB_PROCS_INTERNO.RESUMO" & _
                            " FROM(TB_PROCS_INTERNO) WHERE (((TB_PROCS_INTERNO.ATUALIZADO)=False)) order by envolvido1"

        Grade2.DataSource = Nothing
        Grade2.Rows.Clear()
        Grade2.Columns.Clear()

        Dim DA2 As New OleDbDataAdapter(VsQl2, Conexao)
        Dim TB2 As New DataTable()
        TB2.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA2.Fill(TB2)
        BindingSource1.DataSource = TB2
        Grade2.DataSource = BindingSource1
        Grade2.Refresh()

        Dim ImgExcluir As New DataGridViewImageColumn
        ImgExcluir.Name = " "
        ImgExcluir.DataPropertyName = "Excluir"
        ImgExcluir.Image = PicExcluir.Image
        Grade2.Columns.Insert(1, ImgExcluir)

        Grade2.Columns(0).Visible = False

        'AutoSize em todas as colunas
        Grade2.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
    End Sub


    'para reconhecer o clicke do botão
    Private Sub Grade2_CellContentClick(sender As System.Object, e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Grade2.CellContentClick
        If TypeOf Grade2.Columns(e.ColumnIndex) Is DataGridViewImageColumn Then
            If Grade2.Columns(e.ColumnIndex).DataPropertyName = "Excluir" Then
                If MsgBox("Deseja excluir o registro selecionado?", vbYesNo + vbQuestion) <> vbYes Then Exit Sub

                Try
                    Dim Cmd As New OleDbCommand("delete * from TB_PROCS_INTERNO where chave_interna = " & Grade2.Rows(Grade2.CurrentRow.Index).Cells("chave_interna").Value.ToString, Conexao)
                    Cmd.ExecuteNonQuery()
                Catch ex As Exception
                    MsgBox(ex.Message, vbCritical)
                    Exit Sub
                End Try
                CarregarGrade()
            End If
        End If
    End Sub


    Private Sub AlimentarAreas()
        Dim Table As New DataTable()
        Dim dataAdapter As New OleDbDataAdapter("select * from TB_AREAS_DE_CONSULTA", Conexao)
        Table.Locale = System.Globalization.CultureInfo.InvariantCulture
        dataAdapter.Fill(Table)
        'Combo.ComboBox.BindingContext = Me.BindingContext   'CASO SEJA UMA COMBO DE UMA TOOLSTRIP
        AreaConsulta.DataSource = Table
        AreaConsulta.DisplayMember = "NOM_AREA" ' - Campo que será exibido ao user
        'AreaConsulta.ValueMember = "Codigo" ' - Valor do Index de cada Nome.
        AreaConsulta.SelectedIndex = -1

    End Sub

    Private Sub AlimentarSegmento()
        Dim Table As New DataTable()
        Dim dataAdapter As New OleDbDataAdapter("select * from TB_SEGMENTO", Conexao)
        Table.Locale = System.Globalization.CultureInfo.InvariantCulture
        dataAdapter.Fill(Table)
        'Combo.ComboBox.BindingContext = Me.BindingContext   'CASO SEJA UMA COMBO DE UMA TOOLSTRIP
        Segmento.DataSource = Table
        Segmento.DisplayMember = "SEGMENTO" ' - Campo que será exibido ao user
        'Segmento.ValueMember = "Codigo" ' - Valor do Index de cada Nome.
        Segmento.SelectedIndex = -1

    End Sub

    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTCadastrar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function



    Private Sub BTCadastrar_Click(sender As System.Object, e As System.EventArgs) Handles BTCadastrar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        If FecharThread = True Then
            MsgBox("Clique no procecimento ClickYes ", vbCritical)
            Exit Sub
        End If

        If MsgBox("Deseja iniciar o procedimento de cadastro?", vbYesNo + vbCritical) <> vbYes Then Exit Sub

        Dim VsQl As String
        VsQl = "select  * from TB_PROCS_INTERNO where atualizado = false order by envolvido1"

        Dim VarGCPJ As String = ""
        Dim VarGCPJ_ANTIGO As String = ""

        'Abrindo Tabela
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        If TB.Rows.Count = 0 Then
            MsgBox("Não existem processos a serem cadastrados.", vbCritical)
            Exit Sub
        End If




        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadProcInternoCNProcessoAction?acao=carregar&sessao=limpar")
        Espera_Ate_Que_Abra_Public(objIndex)

        Try
            AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer fornecido por Banco Bradesco S.A")
        Catch ex As Exception
        End Try


        'verifica se a dependencia é o 4040
        If objIndex.Document.Forms(0).elements("cdDepartamentoJuridico").Value <> 4040 Then
            MsgBox("Usuario de Cadastro não está no 4040", vbCritical)
            Exit Sub
        End If


        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            'IDENTIFICANDO GCPJ
            Dim elemCollection As Object
            Dim obj As Object
            elemCollection = objIndex.Document.Forms(0).getElementsByTagName("B")
            For Each obj In elemCollection
                If IsNumeric(obj.innertext) Then
                    VarGCPJ = obj.innertext
                    Exit For
                End If
            Next obj
            If VarGCPJ = "" Then
                MsgBox("Atenção, o sistema não conseguiu identificar o GCPJ", vbInformation)
                Exit Sub
            End If

            'Alimentando Grade de Status
            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  GCPJ: " & VarGCPJ & "   -    Chave Interna: " & TB.Rows(index)("chave_interna").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()



            objIndex.Document.Forms(0).elements("cdEmpresaGrupo").innertext = 237 'TB.Rows(0)("EMPRESA_GRUPO").ToString
            objIndex.Document.Forms(0).elements("cdProcedenciaSolicitante").innertext = TB.Rows(index)("JUNCAO").ToString

            'SELECIONANDO A AREA DE CONSULTA
            Try

                For I = 1 To 100
                    objIndex.Document.Forms(0).elements("cdAreaConsulta")(I).SELECTED = True

                    If objIndex.Document.Forms(0).elements("cdAreaConsulta")(I).INNERTEXT = TB.Rows(index)("AREA_CONSULTA").ToString Then
                        Exit For
                    End If

                Next
            Catch ex As Exception
                MsgBox("Área Informada não existe no GCPJ", vbCritical)
                Exit Sub
            End Try

            objIndex.Document.Forms(0).elements("btoContinuar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)



            'TELA(2) EMVOLVIDOS
            'para os Envolvidos em branco, cadastra o solicitante


            If Len(TB.Rows(index)("envolvido1").ToString) = 0 Then
                'a tela ja carrega com a dependencia selecionada
                objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("JUNCAO").ToString
                objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
                Espera_Ate_Que_Abra_Public(objIndex)

            Else

                'CADASTRAR 1º ENVOLVIDO
                If InsereEnvolvido(TB.Rows(index)("envolvido1").ToString, TB.Rows(index)("cpf1").ToString, TB.Rows(index)("filial1").ToString, TB.Rows(index)("digito1").ToString) = False Then
                    If MsgBox("Envolvido não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                End If

                'VERIFICANDO 2º Envolvido
                If Len(TB.Rows(index)("envolvido2").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido2").ToString, TB.Rows(index)("cpf2").ToString, TB.Rows(index)("filial2").ToString, TB.Rows(index)("digito2").ToString) = False Then
                        If MsgBox("Envolvido 2 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 3º Envolvido
                If Len(TB.Rows(index)("envolvido3").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido3").ToString, TB.Rows(index)("cpf3").ToString, TB.Rows(index)("filial3").ToString, TB.Rows(index)("digito3").ToString) = False Then
                        If MsgBox("Envolvido 3 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 4º Envolvido
                If Len(TB.Rows(index)("envolvido4").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido4").ToString, TB.Rows(index)("cpf4").ToString, TB.Rows(index)("filial4").ToString, TB.Rows(index)("digito4").ToString) = False Then
                        If MsgBox("Envolvido 4 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 5º Envolvido
                If Len(TB.Rows(index)("envolvido5").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido5").ToString, TB.Rows(index)("cpf5").ToString, TB.Rows(index)("filial5").ToString, TB.Rows(index)("digito5").ToString) = False Then
                        If MsgBox("Envolvido 5 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 6º Envolvido
                If Len(TB.Rows(index)("envolvido6").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido6").ToString, TB.Rows(index)("cpf6").ToString, TB.Rows(index)("filial6").ToString, TB.Rows(index)("digito6").ToString) = False Then
                        If MsgBox("Envolvido 6 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 7º Envolvido
                If Len(TB.Rows(index)("envolvido7").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido7").ToString, TB.Rows(index)("cpf7").ToString, TB.Rows(index)("filial7").ToString, TB.Rows(index)("digito7").ToString) = False Then
                        If MsgBox("Envolvido 7 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 8º Envolvido
                If Len(TB.Rows(index)("envolvido8").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido8").ToString, TB.Rows(index)("cpf8").ToString, TB.Rows(index)("filial8").ToString, TB.Rows(index)("digito8").ToString) = False Then
                        If MsgBox("Envolvido 8 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 9º Envolvido
                If Len(TB.Rows(index)("envolvido9").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido9").ToString, TB.Rows(index)("cpf9").ToString, TB.Rows(index)("filial9").ToString, TB.Rows(index)("digito9").ToString) = False Then
                        If MsgBox("Envolvido 9 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If

                'VERIFICANDO 10º Envolvido
                If Len(TB.Rows(index)("envolvido10").ToString) > 0 Then
                    If InsereEnvolvido(TB.Rows(index)("envolvido10").ToString, TB.Rows(index)("cpf10").ToString, TB.Rows(index)("filial10").ToString, TB.Rows(index)("digito10").ToString) = False Then
                        If MsgBox("Envolvido 10 não cadastrado. Cadastre manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro." & vbCrLf & vbCrLf & EnvolvidoErro, vbYesNo) <> vbYes Then Exit Sub
                    End If
                End If
            End If

            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Clica em Incluir Autor
            Espera_Ate_Que_Abra_Public(objIndex)


            'TELA 3 DOC ENVIADOS
            objIndex.Document.Forms(0).elements("nmDocumentoProcesso").innertext = "PARECER"
            Try            'SELECIONANDO MEIO DE ENVIO
                For I = 1 To 100
                    If objIndex.Document.Forms(0).elements("cdMeioEnvioDocumento")(I).INNERTEXT = "E-MAIL" Then
                        objIndex.Document.Forms(0).elements("cdMeioEnvioDocumento")(I).SELECTED = True
                        objIndex.Document.Forms(0).elements("cdMeioEnvioDocumento").onchange()
                        Exit For
                    End If
                Next
            Catch ex As Exception
                MsgBox("E-Mail não está disponível na listagem.", vbCritical)
                Exit Sub
            End Try
            objIndex.Document.Forms(0).elements("dtEnvioDocumento").innertext = FormatDateTime(TB.Rows(index)("DATA_ENVIO").ToString, DateFormat.ShortDate)
            objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
            Espera_Ate_Que_Abra_Public(objIndex)


            ''INSERINDO SEGMENTO
            'objIndex.Document.Forms(0).elements("nmDocumentoProcesso").innertext = TB.Rows(index)("SEGMENTO").ToString
            'Try            'SELECIONANDO MEIO DE ENVIO
            '    For I = 1 To 100
            '        If objIndex.Document.Forms(0).elements("cdMeioEnvioDocumento")(I).INNERTEXT = "SEGMENTO" Then
            '            objIndex.Document.Forms(0).elements("cdMeioEnvioDocumento")(I).SELECTED = True
            '            objIndex.Document.Forms(0).elements("cdMeioEnvioDocumento").onchange()
            '            Exit For
            '        End If
            '    Next
            'Catch ex As Exception
            '    MsgBox("SEGMENTO não está disponível na listagem.", vbCritical)
            '    Exit Sub
            'End Try
            'objIndex.Document.Forms(0).elements("dtEnvioDocumento").innertext = Date.Now.ToShortDateString
            'objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
            'Espera_Ate_Que_Abra_Public(objIndex)
            


            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Clica em Incluir Autor
            Espera_Ate_Que_Abra_Public(objIndex)

            'TELA 4 DOC ANEXOS
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Clica em Incluir Autor
            Espera_Ate_Que_Abra_Public(objIndex)

            'TELA 5 RESUMO
            objIndex.Document.Forms(0).elements("dsResumo").innertext = TB.Rows(index)("RESUMO").ToString
            Espera_Ate_Que_Abra_Public(objIndex)

            'SALVANDO

            'If MsgBox("O Registro foi preenchido com sucesso?" & vbCrLf & "GCPJ salvo por último: " & VarGCPJ, vbQuestion + vbYesNo) <> vbYes Then Exit Sub



            objIndex.Document.Forms(0).elements("botSalvar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'CONSISTENCIA COM gcpj PARA VERIFICAR SE A TELA MUDOU
            VarGCPJ_ANTIGO = VarGCPJ
            'IDENTIFICANDO GCPJ
            elemCollection = objIndex.Document.Forms(0).getElementsByTagName("B")
            For Each obj In elemCollection
                If IsNumeric(obj.innertext) Then
                    VarGCPJ = obj.innertext
                    Exit For
                End If
            Next obj
            If VarGCPJ = VarGCPJ_ANTIGO Then
                MsgBox("Erro ao concluir cadastro!", vbInformation)
                If MsgBox("O sistema não conseguiu identificar se o processo foi salvo." & vbCrLf & "Caso tenha sido salvo clique em OK. Caso contrário clique em cancelar.", vbQuestion + vbOKCancel) <> vbOK Then Exit Sub
            End If

            'FINALIZANDO NA TABELA
            cmd.CommandText = "update TB_PROCS_INTERNO set GCPJ = " & VarGCPJ_ANTIGO & ", data_cadastro = " & SQL_Data(Date.Now) & ", atualizado = true, obs = 'GCPJ: " & VarGCPJ_ANTIGO & "' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

            'If MsgBox("Deseja ir para o próximo?", vbQuestion + vbYesNo) <> vbYes Then Exit Sub


            'If Len(TB.Rows(index)("segmento").ToString) > 0 Then
            '    'Alterar Processo
            '    AlterarProcesso(VarGCPJ_ANTIGO, TB.Rows(index)("segmento").ToString)
            'End If


            CarregarGrade()



        Next

        Grade.Items.Add(Date.Now & " Processamento Finalizado!")
        Grade.SelectedIndex = Grade.Items.Count - 1


    End Sub
    Private Function AlterarProcesso(ByVal varGCPJ As Double, ByVal varSegmento As String) As Boolean
        Return True
    End Function


    Private Function InsereEnvolvido(ByVal Envolvido As String, ByVal CPF_CNPJ As String, ByVal Filial As String, ByVal Digito As String) As Boolean
        'verifica se eh por nome
        If Len(CPF_CNPJ) = 0 Then
            objIndex.Document.Forms(0).elements("select3").Item(3).Selected = True
            Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,5,true);", "JavaScript")
            'insere o nome do envolvido
            objIndex.Document.Forms(0).elements("dsnome").innertext = Envolvido
            Call objIndex.Document.parentWindow.execScript("porNome = 1;", "JavaScript")
            objIndex.Document.Forms(0).elements("btoNome").Click() ' lupa do bt salvar
            IdentificarAutor()
        End If

        'verifica se é pessoa Fisica
        If Len(CPF_CNPJ) > 0 And (Len(Filial) = 0 Or Filial = "0") Then
            objIndex.Document.Forms(0).elements("select3").Item(3).Selected = True
            Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,5,true);", "JavaScript")
            'objIndex.Document.Forms(0).elements("dsnome").innertext = Envolvido
            objIndex.Document.Forms(0).elements("cdCodigo").innertext = CPF_CNPJ
            objIndex.Document.Forms(0).elements("cdControle").innertext = Digito
            ' Call objIndex.Document.parentWindow.execScript("porCodigo = 1;", "JavaScript")
        End If

        'verifica se é pessoa Jurídica
        If Len(CPF_CNPJ) > 0 And Len(Filial) > 0 And Filial <> "0" Then
            objIndex.Document.Forms(0).elements("select3").Item(4).Selected = True
            Call objIndex.Document.parentWindow.execScript("alteraDivTipo(4,5,true);", "JavaScript")
            objIndex.Document.Forms(0).elements("cdCodigo").innertext = CPF_CNPJ
            objIndex.Document.Forms(0).elements("cdFilial").innertext = Filial
            objIndex.Document.Forms(0).elements("cdControle").innertext = Digito
        End If


        objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
        Espera_Ate_Que_Abra_Public(objIndex)


CadastraEnvolvido:
        'Verifica se o Envolvido no processo foi registrado
        'VERIFICA SE ESTÁ SELECIONADO A OPÇÃO "DEPENDENCIA"
        'POIS SE ESTIVER SIGNIFICA QUE O ENVOLVIDO FOI INCLUÍDO E A TELA LIMPOU
        If objIndex.Document.Forms(0).elements("select3").VALUE = 4 Then
            Return True
        Else
            'tentando efetuar o cadastro do envolvido
            If CadastrarEnvolvido(Envolvido, CPF_CNPJ, Filial, Digito) = True Then
                objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Incluir Autor
                Espera_Ate_Que_Abra_Public(objIndex)
                Return True
            Else

                'seleciona ex-funcionario para destravar a tela
                If Len(CPF_CNPJ) > 0 And (Len(Filial) = 0 Or Filial = "0") Then
                    objIndex.Document.Forms(0).elements("select3").Item(1).Selected = True
                    Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,1,true);", "JavaScript")
                    objIndex.Document.Forms(0).elements("dsnome").innertext = Envolvido
                    objIndex.Document.Forms(0).elements("cdCodigo").innertext = CPF_CNPJ
                    objIndex.Document.Forms(0).elements("cdControle").innertext = Digito

                    'Call objIndex.Document.parentWindow.execScript("porcodigo = 1;", "JavaScript")
                    'objIndex.Document.Forms(0).elements("btonome").Click() ' lupa do bt salvar
                    'IdentificarAutor()
                    'objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
                    'Espera_Ate_Que_Abra_Public(objIndex)

                    If objIndex.Document.Forms(0).elements("select3").VALUE <> 4 Then
                        EnvolvidoErro = Envolvido & "  " & CPF_CNPJ & IIf(Len(Filial) > 0, "/000" & Filial, "") & "-" & Digito
                        Return False
                    End If
                End If
                EnvolvidoErro = Envolvido & "  " & CPF_CNPJ & IIf(Len(Filial) > 0, "/000" & Filial, "") & "-" & Digito
                Return False
            End If
        End If


    End Function


    Private Function CadastrarEnvolvido(ByRef vNome As String, ByVal vCPF As String, ByVal vFilial As String, ByVal vDigito As String) As Boolean


        'Clicando em Novo
        Dim elemCollection As Object
        elemCollection = objIndex.Document.Forms(0).getElementsByTagName("A")
        For Each obj In elemCollection
            If obj.innertext = "Novo" Then
                obj.click()
                Exit For
            End If
        Next

        'Identificando Tela de cadastro de envolvido
        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell
        Dim Achou As Boolean = False

InicioVerificacao:
        For Each objIndex2 In objShell2.Windows
            If objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&origem=origemCivel&dsTipoPessoa=PESSOA FISICA" Or objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&origem=origemCivel&dsTipoPessoa=PESSOA JURIDICA" Then
                objIndex2.Visible = True
                Achou = True
                Exit For
            End If
        Next objIndex2

        If Achou = False Then GoTo InicioVerificacao

        Espera_Ate_Que_Abra_Public(objIndex2)


        'Inicio do Cadastro
        Thread.Sleep(2000)
        'Inserindo Pessoa Fisica com CPF
        If Len(vFilial) = 0 Then
            'inserindo nome
            objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = "" & vNome
            objIndex2.Document.Forms(0).elements("cdCpfPessoaExterna").innertext = "" & vCPF
            objIndex2.Document.Forms(0).elements("cdControleCpfPessoaExterna").innertext = "" & vDigito

            'Clicando no botão Salvar
            objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar

            Espera_Ate_Que_Abra_Public(objIndex2)


            Thread.Sleep(1000)

            'Verifica se a tela limpou
            Try
                If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                    'caso não limpou então retira o CPF, pois o mesmo deve estar errado
                    objIndex2.Document.Forms(0).elements("cdCpfPessoaExterna").innertext = ""
                    objIndex2.Document.Forms(0).elements("cdControleCpfPessoaExterna").innertext = ""

                    'Clicando no botão Salvar novamente
                    objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar
                    Espera_Ate_Que_Abra_Public(objIndex2)
                    Thread.Sleep(1000)

                    'Verifica se a tela limpou novamente
                    Try
                        If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                            objIndex2.Quit()
                            Return False
                        End If
                    Catch ex2 As Exception
                    End Try

                End If

            Catch ex As Exception
            End Try




        Else
            'Inserindo Pessoa Juridica com CPF
            objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = "" & vNome
            objIndex2.Document.Forms(0).elements("cdCnpjPessoaExterna").innertext = "" & vCPF
            objIndex2.Document.Forms(0).elements("cdFilialCnpjPessoaExterna").innertext = "" & vFilial
            objIndex2.Document.Forms(0).elements("cdControleCnpjPessoaExterna").innertext = "" & vDigito

            'Clicando no botão Salvar
            objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar
            Espera_Ate_Que_Abra_Public(objIndex2)


            'Verifica se a tela limpou
            Try
                If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                    'caso não limpou então retira o cnpj, pois o mesmo deve estar errado
                    objIndex2.Document.Forms(0).elements("cdCnpjPessoaExterna").innertext = ""
                    objIndex2.Document.Forms(0).elements("cdFilialCnpjPessoaExterna").innertext = ""
                    objIndex2.Document.Forms(0).elements("cdControleCnpjPessoaExterna").innertext = ""

                    'Clicando no botão Salvar novamente
                    objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar
                    Espera_Ate_Que_Abra_Public(objIndex2)

                    'Verifica se a tela limpou novamente
                    Try
                        If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                            objIndex2.Quit()
                            Return False
                        End If
                    Catch ex2 As Exception
                    End Try

                End If

            Catch ex As Exception
            End Try


        End If

        Thread.Sleep(2000)
        Return True

    End Function


    Private Function IdentificarAutor() As Boolean
        'Conectando a variável à janela popup
        Thread.Sleep(3000)

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell

        For Each objIndex2 In objShell2.Windows
            If InStr(objIndex2.LocationURL, "http://www4.net.bradesco.com.br/gcpj/servlet/cadProcInternoEnvolvidoAction?acao=carregarPopupFuncionarioNome&popupClassName=") Then

                objIndex2.Visible = True
                Dim elemCollection As Object
                elemCollection = objIndex2.Document.Forms(0).getElementsByTagName("a")

                'selecionando o primeiro encontrado
                For Each obj In elemCollection
                    obj.Click()
                    Return True
                Next
                objIndex2.Quit()
                Return False
            End If
        Next objIndex2
        Return False
        'Call objIndex2.Document.parentWindow.execScript("paginacao('0');", "JavaScript")

    End Function


    Private Sub BTRelatorio_Click(sender As System.Object, e As System.EventArgs) Handles BTRelatorio.Click
        Dim Vdata As String

inicio:
        Vdata = InputBox("Informe a data do Cadastro:", "Relatório", FormatDateTime(Date.Now, DateFormat.ShortDate))
        If Vdata = "" Then Exit Sub
        If Len(Vdata) <> 10 Then
            MsgBox("Informe a data no Formato DD/MM/YYYY", vbCritical)
            GoTo inicio
        End If
        If Not IsDate(Vdata) Then
            MsgBox("Data Incorreta. Informe a data no Formato DD/MM/YYYY", vbCritical)
            GoTo inicio
        End If

        Dim VsQl As String = "SELECT TB.GCPJ, TB.DATA_CADASTRO, TB.JUNCAO, TB.AREA_CONSULTA, TB.DATA_ENVIO, tb.resumo, TB.ENVOLVIDO1, TB.CPF1, TB.FILIAL1, TB.DIGITO1,TB.ENVOLVIDO2,TB.CPF2,TB.FILIAL2,TB.DIGITO2,TB.ENVOLVIDO3,TB.CPF3,TB.FILIAL3,TB.DIGITO3,TB.ENVOLVIDO4,TB.CPF4,TB.FILIAL4,TB.DIGITO4,TB.ENVOLVIDO5,TB.CPF5,TB.FILIAL5,TB.DIGITO5,TB.ENVOLVIDO6,TB.CPF6,TB.FILIAL6,TB.DIGITO6,TB.ENVOLVIDO7,TB.CPF7,TB.FILIAL7,TB.DIGITO7,TB.ENVOLVIDO8,TB.CPF8,TB.FILIAL8,TB.DIGITO8,TB.ENVOLVIDO9,TB.CPF9,TB.FILIAL9,TB.DIGITO9,TB.ENVOLVIDO10,TB.CPF10,TB.FILIAL10,TB.DIGITO10  " & _
        " FROM TB_PROCS_INTERNO as TB " & _
        " where DATA_CADASTRO = " & SQL_Data(Vdata) & _
        " ORDER BY TB.GCPJ"

        ExportExcel(VsQl)

    End Sub

    Public Sub ExportExcel(ByVal VarSQL As String)


        Dim stcon As String = Conexao.ConnectionString
        Dim stsql As String = VarSQL
        Dim cnt As New ADODB.Connection
        Dim rst As New ADODB.Recordset
        Dim fld As ADODB.Field



        'Abre a conexão com o banco de dados
        cnt.Open(stcon)
        'Abre o recordset
        With rst
            .CursorLocation = CursorLocationEnum.adUseClient
            .Open(stsql, cnt, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)
            .ActiveConnection = Nothing
        End With
        'Fecha a conexão com o banco de dados
        cnt.Close()
        'Define variáveis para o Excel: Application(Excel),WorkBook(pasta de trabalho),WorkSheet(Planilha)
        'Range(intervalo de células)
        Dim xlapp As New excel.Application
        Dim xlwbook As excel.Workbook = xlapp.Workbooks.Add(excel.XlWBATemplate.xlWBATWorksheet)
        Dim xlwsheet As excel.Worksheet = CType(xlwbook.Worksheets(1), excel.Worksheet)
        Dim xlrange As excel.Range = xlwsheet.Range("A1")
        'define modo de cálculo : xlCalculationAutomatic , xlCalculationManual, xlCalculationSemiautomatic
        Dim xlcalc As excel.XlCalculation
        'Desabilita temporariamente o calculo automatico passando para manual
        With xlapp
            xlcalc = .Calculation
            .Calculation = excel.XlCalculation.xlCalculationManual
        End With
        Dim contadorCampos As Integer = Nothing

        'Escreve os nomes dos campos na planilha
        For Each fld In rst.Fields
            xlrange.Offset(0, contadorCampos).Value = fld.Name
            contadorCampos = contadorCampos + 1
        Next

        'Copia o recordset para a planilha
        xlrange.Offset(1, 0).CopyFromRecordset(rst)
        'Fecha o recordset.
        rst.Close()
        With xlapp
            .Visible = True
            .UserControl = True
            'Restaura o calculo
            .Calculation = xlcalc
        End With
        'libera os objetos
        fld = Nothing
        rst = Nothing
        cnt = Nothing
        xlrange = Nothing
        xlwsheet = Nothing
        xlwbook = Nothing
        xlapp = Nothing

    End Sub


    Private Sub ImportarComSegmento()
        Dim VarCaminhoPlanilha As String
        OpenFileDialog1.Title = "Importar Planilha 1"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Excel 2007 / 2010|*.xlsx"

        OpenFileDialog1.ShowDialog()

        If OpenFileDialog1.FileName = "" Then Exit Sub
        VarCaminhoPlanilha = OpenFileDialog1.FileName

        If MsgBox("Atenção, durante este procedimento todas as planilhas em excel serão automaticamente fechadas." & vbCrLf & "Deseja continuar?", vbYesNo + vbInformation) <> vbYes Then Exit Sub

        'VERIFICA SE ALGUM ARQUIVO EM EXCELL ESTÁ ABERTO
        'Verifica se o sistema já está aberto para pode-lo maximizar
        For Each p In Process.GetProcesses
            If UCase(p.ProcessName) = "EXCEL" Then
                For Each p2 In Process.GetProcesses
                    If UCase(p2.ProcessName) = "EXCEL" Then
                        p2.Kill()
                    End If
                Next
            End If
        Next

        Grade.DataSource = Nothing

        If ImportarParaGrade(VarCaminhoPlanilha) = False Then
            MsgBox("Erro na importação da planilha!", vbCritical)
            CarregarGrade()
            Exit Sub
        End If

        If Grade2.RowCount = 0 Then
            CarregarGrade()
            MsgBox("A Planilha está vazia", vbCritical)
            Exit Sub
        End If

        'MAPA DAS COLUNAS
        'Grade2.Rows(index).Cells(0).Value  SOLICITANTE         A
        'Grade2.Rows(index).Cells(1).Value  AREA DE CONSULTA    B
        'Grade2.Rows(index).Cells(2).Value  SEGMENTO            C
        'Grade2.Rows(index).Cells(3).Value  DATA ENVIO          D
        'Grade2.Rows(index).Cells(4).Value  RESUMO              E
        'Grade2.Rows(index).Cells(5).Value  NOME DO ENVOLVIDO1  F
        'Grade2.Rows(index).Cells(6).Value  CPF1                G
        'Grade2.Rows(index).Cells(7).Value  FILIAL1             H
        'Grade2.Rows(index).Cells(8).Value  DIGITO1             I


        For index = 0 To Grade2.RowCount - 1

            'Consistencias Coluna A Solicitante
            If Len(Grade2.Rows(index).Cells(0).Value.ToString) = 0 Then
                MsgBox("A coluna 'A' possui dados em branco. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If
            If Not IsNumeric(Grade2.Rows(index).Cells(0).Value.ToString) Then
                MsgBox("A coluna 'A' possui dados não numéricos. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If

            'Consistencia coluna B Area de Consulta
            AreaConsulta.SelectedIndex = -1
            AreaConsulta.Text = Trim(Grade2.Rows(index).Cells(1).Value.ToString)
            If AreaConsulta.SelectedIndex = -1 Then
                MsgBox("A coluna 'B' (Área de Consulta), possui dados que não estão na listagem da planilha." & vbCrLf & " A Planilha não será importada" & vbCrLf & vbCrLf & "Dado Divergente: " & Trim(Grade2.Rows(index).Cells(1).Value.ToString), vbCritical)
                CarregarGrade()
                Exit Sub
            End If

            'Consistencia coluna C Segmento
            Segmento.SelectedIndex = -1
            Segmento.Text = Trim(Grade2.Rows(index).Cells(2).Value.ToString)
            If Segmento.SelectedIndex = -1 Then
                MsgBox("A coluna 'C' (Segmento), possui dados que não estão na listagem da planilha." & vbCrLf & " A Planilha não será importada" & vbCrLf & vbCrLf & "Dado Divergente: " & Trim(Grade2.Rows(index).Cells(2).Value.ToString), vbCritical)
                CarregarGrade()
                Exit Sub
            End If

            'consistencia coluna D DATA
            If Len(Grade2.Rows(index).Cells(3).Value.ToString) = 0 Then
                MsgBox("A coluna 'D' possui dados em branco. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If
            If Not IsDate(Grade2.Rows(index).Cells(3).Value.ToString) Then
                MsgBox("A coluna 'D' possui data inválida. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If





        Next



        'IMPORTANDO PARA O BANCO
        Dim vSqL As String = ""
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao
        Dim vDATA As Date = Date.Now


        For index = 0 To Grade2.RowCount - 1
            vSqL = "insert into TB_PROCS_INTERNO (JUNCAO,AREA_CONSULTA,segmento,DATA_ENVIO,RESUMO,DATA_IMPORTACAO,HORA_IMPORTACAO,LOGIN,ENVOLVIDO1,CPF1,FILIAL1,DIGITO1,ENVOLVIDO2,CPF2,FILIAL2,DIGITO2,ENVOLVIDO3,CPF3,FILIAL3,DIGITO3,ENVOLVIDO4,CPF4,FILIAL4,DIGITO4,ENVOLVIDO5,CPF5,FILIAL5,DIGITO5,ENVOLVIDO6,CPF6,FILIAL6,DIGITO6,ENVOLVIDO7,CPF7,FILIAL7,DIGITO7,ENVOLVIDO8,CPF8,FILIAL8,DIGITO8,ENVOLVIDO9,CPF9,FILIAL9,DIGITO9,ENVOLVIDO10,CPF10,FILIAL10,DIGITO10) values " & _
            "(" & SQL_Numero(Grade2.Rows(index).Cells(0).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(1).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(2).Value.ToString()) & _
            "," & SQL_Data(Grade2.Rows(index).Cells(3).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(4).Value.ToString()) & _
            "," & SQL_Data(vDATA) & _
            "," & SQL_Hora(vDATA) & _
            "," & SQL_Texto(Environment.UserName) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(5).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(6).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(7).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(8).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(9).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(10).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(11).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(12).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(13).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(14).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(15).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(16).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(17).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(18).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(19).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(20).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(21).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(22).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(23).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(24).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(25).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(26).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(27).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(28).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(29).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(30).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(31).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(32).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(33).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(34).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(35).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(36).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(37).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(38).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(39).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(40).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(41).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(42).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(43).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(44).Value.ToString()) & _
            ")"


            Try
                cmd.CommandText = vSqL
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                'se deu erro na importação, então limpa o que já foi importado
                cmd.CommandText = "delete * from TB_PROCS_INTERNO where DATA_IMPORTACAO = " & SQL_Data(vDATA) & " and HORA_IMPORTACAO = " & SQL_Hora(vDATA)
                cmd.ExecuteNonQuery()

                MsgBox("Erro ao importar esta remessa! Inicie a importação novamente." & vbCrLf & ex.Message, vbCritical)
                CarregarGrade()
                Exit Sub
            End Try

        Next




        CarregarGrade()
        MsgBox("Imortação Efetuada com sucesso", vbInformation)

    End Sub

    Function ImportarParaGrade(ByRef varCaminhoPlanilha2 As String) As Boolean
        'abrindo o Excel e alterando determinadas celulas para evitar o problema de existir algum Número com formatação de Texto
        Try
            Dim app As New excel.Application
            Dim WB As excel.Workbook = app.Workbooks.Open(varCaminhoPlanilha2)
            If WB IsNot Nothing Then
                Dim ws As excel.Worksheet = WB.Worksheets.Item(1)
                For index = 2 To 49
                    Try
                        If IsNumeric(ws.Range("A" & index).Value) Then ws.Range("A" & index).Value = ws.Range("A" & index).Value * 1 'Coluna Agencia
                        If IsNumeric(ws.Range("G" & index).Value) Then ws.Range("G" & index).Value = ws.Range("G" & index).Value * 1 'CPF 
                        If IsNumeric(ws.Range("H" & index).Value) Then ws.Range("H" & index).Value = ws.Range("H" & index).Value * 1 'FILIAL
                        If IsNumeric(ws.Range("I" & index).Value) Then ws.Range("I" & index).Value = ws.Range("I" & index).Value * 1 'DIGITO
                    Catch ex As Exception
                    End Try
                Next
            End If
            WB.Save()
            WB.Close()
        Catch ex As Exception

        End Try



        Dim da As OleDbDataAdapter
        Dim dt As DataTable
        Dim conexao_Excel As String
        Thread.Sleep(1000)
        'Importando Planilha 
        conexao_Excel = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & varCaminhoPlanilha2 & ";Extended Properties='Excel 12.0 Xml;HDR=yes;ReadOnly=False';"

        Try
            da = New OleDbDataAdapter("SELECT * FROM [CADASTRO$] Where [SOLICITANTE (Apenas Código)]  Is Not Null ", conexao_Excel)
            dt = New DataTable
            da.Fill(dt)
        Catch ex As Exception
            MsgBox("Erro ao Importar planilha. O Problema está relacionado ao nome da Pasta de Trabalho ou ao nome das Colunas." & vbCrLf & Err.Description, vbCritical)
            Return False
        End Try


        Grade2.DataSource = Nothing
        Grade2.Rows.Clear()
        Grade2.Columns.Clear()
        Grade2.DataSource = dt.DefaultView

        Me.Grade2.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan

        Try
            If UCase(Grade2.Columns(2).HeaderText) <> "DATA DE ENVIO" Or UCase(Grade2.Columns(43).HeaderText) <> "DIGITO 10" Then 'sem segmento
                'If UCase(Grade2.Columns(2).HeaderText) <> "SEGMENTO" Or UCase(Grade2.Columns(44).HeaderText) <> "DIGITO 10" Then 'com segmento
                MsgBox("A quantidade de colunas ou a ordem das colunas não bate com a planilha original.", vbCritical)
                Return False
            End If
        Catch ex As Exception
            MsgBox("A quantidade de colunas ou a ordem das colunas não bate com a planilha original.", vbCritical)
            Return False
        End Try

        Return True

    End Function
    Private Sub ImportarSemSegmento()
        Dim VarCaminhoPlanilha As String
        OpenFileDialog1.Title = "Importar Planilha 1"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Excel 2007 / 2010|*.xlsx"

        OpenFileDialog1.ShowDialog()

        If OpenFileDialog1.FileName = "" Then Exit Sub
        VarCaminhoPlanilha = OpenFileDialog1.FileName

        If MsgBox("Atenção, durante este procedimento todas as planilhas em excel serão automaticamente fechadas." & vbCrLf & "Deseja continuar?", vbYesNo + vbInformation) <> vbYes Then Exit Sub

        'VERIFICA SE ALGUM ARQUIVO EM EXCELL ESTÁ ABERTO
        'Verifica se o sistema já está aberto para pode-lo maximizar
        For Each p In Process.GetProcesses
            If UCase(p.ProcessName) = "EXCEL" Then
                For Each p2 In Process.GetProcesses
                    If UCase(p2.ProcessName) = "EXCEL" Then
                        p2.Kill()
                    End If
                Next
            End If
        Next

        Grade.DataSource = Nothing

        If ImportarParaGrade(VarCaminhoPlanilha) = False Then
            MsgBox("Erro na importação da planilha!", vbCritical)
            CarregarGrade()
            Exit Sub
        End If


        'MAPA DAS COLUNAS
        'Grade2.Rows(index).Cells(0).Value  SOLICITANTE         A
        'Grade2.Rows(index).Cells(1).Value  AREA DE CONSULTA    B
        'Grade2.Rows(index).Cells(2).Value  DATA ENVIO          C
        'Grade2.Rows(index).Cells(3).Value  RESUMO              D
        'Grade2.Rows(index).Cells(4).Value  NOME DO ENVOLVIDO1  E
        'Grade2.Rows(index).Cells(5).Value  CPF1                F
        'Grade2.Rows(index).Cells(6).Value  FILIAL1             G
        'Grade2.Rows(index).Cells(7).Value  DIGITO1             H


        For index = 0 To Grade2.RowCount - 1

            'Consistencias Coluna A Solicitante
            If Len(Grade2.Rows(index).Cells(0).Value.ToString) = 0 Then
                MsgBox("A coluna 'A' possui dados em branco. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If
            If Not IsNumeric(Grade2.Rows(index).Cells(0).Value.ToString) Then
                MsgBox("A coluna 'A' possui dados não numéricos. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If

            'Consistencia coluna B Area de Consulta
            AreaConsulta.SelectedIndex = -1
            AreaConsulta.Text = Trim(Grade2.Rows(index).Cells(1).Value.ToString)
            If AreaConsulta.SelectedIndex = -1 Then
                MsgBox("A coluna 'B' (Área de Consulta), possui dados que não estão na listagem da planilha." & vbCrLf & " A Planilha não será importada" & vbCrLf & vbCrLf & "Dado Divergente: " & Trim(Grade2.Rows(index).Cells(1).Value.ToString), vbCritical)
                CarregarGrade()
                Exit Sub
            End If

            'consistencia coluna C DATA
            If Len(Grade2.Rows(index).Cells(2).Value.ToString) = 0 Then
                MsgBox("A coluna 'C' possui dados em branco. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If
            If Not IsDate(Grade2.Rows(index).Cells(2).Value.ToString) Then
                MsgBox("A coluna 'C' possui data inválida. A Planilha não será importada", vbCritical)
                CarregarGrade()
                Exit Sub
            End If


        Next



        'IMPORTANDO PARA O BANCO
        Dim vSqL As String = ""
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao
        Dim vDATA As Date = Date.Now


        For index = 0 To Grade2.RowCount - 1
            'CAPTURANDO CÓDIGO DA CUSTA
            vSqL = "insert into TB_PROCS_INTERNO (JUNCAO,AREA_CONSULTA,DATA_ENVIO,RESUMO,DATA_IMPORTACAO,HORA_IMPORTACAO,LOGIN,ENVOLVIDO1,CPF1,FILIAL1,DIGITO1,ENVOLVIDO2,CPF2,FILIAL2,DIGITO2,ENVOLVIDO3,CPF3,FILIAL3,DIGITO3,ENVOLVIDO4,CPF4,FILIAL4,DIGITO4,ENVOLVIDO5,CPF5,FILIAL5,DIGITO5,ENVOLVIDO6,CPF6,FILIAL6,DIGITO6,ENVOLVIDO7,CPF7,FILIAL7,DIGITO7,ENVOLVIDO8,CPF8,FILIAL8,DIGITO8,ENVOLVIDO9,CPF9,FILIAL9,DIGITO9,ENVOLVIDO10,CPF10,FILIAL10,DIGITO10) values " & _
            "(" & SQL_Numero(Grade2.Rows(index).Cells(0).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(1).Value.ToString()) & _
            "," & SQL_Data(Grade2.Rows(index).Cells(2).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(3).Value.ToString()) & _
            "," & SQL_Data(vDATA) & _
            "," & SQL_Hora(vDATA) & _
            "," & SQL_Texto(Environment.UserName) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(4).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(5).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(6).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(7).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(8).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(9).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(10).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(11).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(12).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(13).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(14).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(15).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(16).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(17).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(18).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(19).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(20).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(21).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(22).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(23).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(24).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(25).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(26).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(27).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(28).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(29).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(30).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(31).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(32).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(33).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(34).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(35).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(36).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(37).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(38).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(39).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(40).Value.ToString(), 50) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(41).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(42).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(43).Value.ToString()) & _
            ")"


            Try
                cmd.CommandText = vSqL
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                'se deu erro na importação, então limpa o que já foi importado
                cmd.CommandText = "delete * from TB_PROCS_INTERNO where DATA_IMPORTACAO = " & SQL_Data(vDATA) & " and HORA_IMPORTACAO = " & SQL_Hora(vDATA)
                cmd.ExecuteNonQuery()

                MsgBox("Erro ao importar esta remessa! Inicie a importação novamente." & vbCrLf & ex.Message, vbCritical)
                CarregarGrade()
                Exit Sub
            End Try

        Next


        CarregarGrade()
        MsgBox("Imortação Efetuada com sucesso", vbInformation)

    End Sub

    

    Private Sub BTImportar_Click(sender As System.Object, e As System.EventArgs) Handles BTImportar.Click

        ImportarSemSegmento()
        'ImportarComSegmento()
    End Sub
End Class