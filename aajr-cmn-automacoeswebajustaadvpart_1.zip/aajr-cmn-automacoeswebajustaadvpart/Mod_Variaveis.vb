﻿Module Mod_Variaveis
    Public FecharThread As Boolean = False

End Module
