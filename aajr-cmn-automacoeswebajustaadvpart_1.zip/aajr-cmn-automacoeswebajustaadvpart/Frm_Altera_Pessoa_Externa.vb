﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Altera_Pessoa_Externa
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Altera_Pessoa_Externa.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Altera_Pessoa_Externa_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()

    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        Grade.Items.Add("Conexão Efetuada!")
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String
        Dim VarErro As String
        VsQl = "select   * from PRINCIPAL where alterado = false  order by COD_PESSOA_EXTERNA"

        
        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=carregar")
            Espera_Ate_Que_Abra_Public(objIndex)

            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            Grade.Items.Add(Date.Now & " Alterando Envolvido: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("COD_PESSOA_EXTERNA").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            objIndex.Document.Forms(0).elements("cdPessoaExternaBradesco").innertext = TB.Rows(index)("COD_PESSOA_EXTERNA").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()

            Espera_Ate_Que_Abra_Public(objIndex)
            Thread.Sleep(1000)

            'selecionando o iten encontrado
            Try
                objIndex.Document.Forms(0).elements("Selecionados").Checked = True
                objIndex.Document.Forms(0).elements("btoAlterar").Click()
            Catch ex As Exception
                MsgBox("Atenção apenas 1 envolvido deve ser retornado na pesquisa", vbCritical)
                Exit Sub
            End Try

            Espera_Ate_Que_Abra_Public(objIndex)

            'Alimentando Dados
            Thread.Sleep(1000)
            objIndex.Document.Forms(0).elements("cdDddPessoaExterna").innertext = TB.Rows(index)("ddd").ToString
            objIndex.Document.Forms(0).elements("cdTelefonePessoaExterna").innertext = TB.Rows(index)("fone").ToString
            Thread.Sleep(1000)


            'salvando
            'objIndex.Document.Forms(0).elements("btoSalvar").Click()
            Call objIndex.Document.parentWindow.execScript("salvarEnvolvido()", "JavaScript")

            Espera_Ate_Que_Abra_Public(objIndex)
            Thread.Sleep(2000)

            Espera_Ate_Que_Abra_Public(objIndex)

            Try
                VarErro = objIndex.Document.Forms(0).elements("cdTelefonePessoaExterna").value
                cmd.CommandText = "update PRINCIPAL set alterado = true, obs = 'ERRO' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()

            Catch ex As Exception
                cmd.CommandText = "update PRINCIPAL set alterado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()

            End Try



        Next

    End Sub
End Class