﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Alteracao_Classificacao
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Alteracao_Classificacao.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Alteracao_Classificacao_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Sleep.SelectedIndex = 1
    End Sub


    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select   * from TB_Alteracao_Classificacao where IMPORTADO = false  order by gcpj"
        Else
            VsQl = "select * from TB_Alteracao_Classificacao where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj"
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            'objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=opcaoConsulta")
            'Espera_Ate_Que_Abra()
            'MsgBox(TB.Rows(index)("GCPJ").ToString.PadLeft(10, "0"))

            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilClassificacaoAction?acao=carregarTramiteAlterarClassif&cdNumeroProcessoBradesco=" & TB.Rows(index)("GCPJ").ToString.PadLeft(10, "0"))
            Espera_Ate_Que_Abra_Public(objIndex)

            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Adcionando Dados
            'objIndex.Document.Forms(0).elements("dtFatoGeradorProcessoCivel").innertext = FormatDateTime(TB.Rows(index)("DATA_FATO").ToString, DateFormat.ShortDate)
            objIndex.Document.Forms(0).elements("cdTipoAcao").innertext = TB.Rows(index)("codacao").ToString
            Call objIndex.Document.parentWindow.execScript("validarTipoAcaoCodigo()", "JavaScript")
            objIndex.Document.Forms(0).elements("cdSubtipoAcao").innertext = TB.Rows(index)("codsub").ToString
            Call objIndex.Document.parentWindow.execScript("validarSubTipoAcaoCodigo()", "JavaScript")

            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("nmAcaoProcessoCivel").innertext = TB.Rows(index)("NOME_ACAO").ToString
            objIndex.Document.Forms(0).elements("cmdTipoProcesso")(3).SELECTED = True
            objIndex.Document.Forms(0).elements("cmdTipoProcesso").onchange()

            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("dsResumoProcessoJudicial").innertext = TB.Rows(index)("FUNDAMENTO_CAUSA").ToString
            Select Case UCase(TB.Rows(index)("RISCO_ACAO").ToString)
                Case "POSSÍVEL", "POSSIVEL"
                    objIndex.Document.Forms(0).elements("cmdRitoAcao")(1).SELECTED = True
                Case "PROVAVEL", "PROVÁVEL"
                    objIndex.Document.Forms(0).elements("cmdRitoAcao")(2).SELECTED = True
                Case "REMOTO"
                    objIndex.Document.Forms(0).elements("cmdRitoAcao")(3).SELECTED = True
                Case Else
                    objIndex.Document.Forms(0).elements("cmdRitoAcao")(4).SELECTED = True
            End Select
            objIndex.Document.Forms(0).elements("cmdRitoAcao").onchange()

            Espera_Ate_Que_Abra_Public(objIndex)

            Thread.Sleep(Sleep.Text)
            objIndex.Document.Forms(0).elements("Submit32").Click()

            'MataMsgbox()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("cdTipoAcao").value) > 0 Then
            'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If

            cmd.CommandText = "update TB_Alteracao_Classificacao set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()
        Next
        MsgBox("Acabou!")
    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from TB_Alteracao_Classificacao where  importado = false   ORDER BY GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If

        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE TB_Alteracao_Classificacao SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next


        MsgBox("Distribuição Efetuada")
    End Sub

    Private Sub Grade_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles Grade.SelectedIndexChanged

    End Sub
End Class