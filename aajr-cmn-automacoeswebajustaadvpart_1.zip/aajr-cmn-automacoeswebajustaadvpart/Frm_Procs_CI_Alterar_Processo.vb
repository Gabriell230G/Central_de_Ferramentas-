﻿Imports System.Data.OleDb
Imports System.Threading

Public Class Frm_Procs_CI_Alterar_Processo
    Dim VarFundamento As String
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BDDados_Acerto_Processos_CI.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Espera_Ate_Que_Abra()
        'Thread.Sleep(1000)

        Do While objIndex.ReadyState = 0 Or objIndex.ReadyState = 1 Or objIndex.ReadyState = 3
            'Espera até que abra
        Loop
        Do While objIndex.Busy = True
            'Espera até que abra
        Loop
    End Sub

    Private Sub Frm_Procs_CI_Alterar_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True

        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        'Abrindo Tabela
        Dim VsQl As String
        VsQl = "select  * from PROCESSOS_MENORES_20_DIGITOS_CI where IMPORTADO = false   order by GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")

        Espera_Ate_Que_Abra()

        Thread.Sleep(1000)
        Try
            AppActivate("(GCPJ) Gestão Controle de Processos Jurídicos - Windows Internet Explorer")
        Catch ex As Exception

        End Try

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
forIn:
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()



            '"#### Tela de Pesquisa
            objIndex.Document.Forms(0).elements("nrProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click() ' lupa do bt salvar

            Espera_Ate_Que_Abra()

            'Verificando se o processo foi alterado pelo advogado
            If objIndex.Document.Forms(0).elements("cdProcessoJudicialNumero").value <> TB.Rows(index)("NRO_PROCESSO").ToString Then
                'MsgBox(TB.Rows(index)("gcpj").ToString & "   -   " & objIndex.Document.Forms(0).elements("cdProcessoJudicialNumero").value & "  -  " & TB.Rows(index)("NRO_PROCESSO").ToString)

                cmd.CommandText = "update PROCESSOS_MENORES_20_DIGITOS_CI set importado = true, obs = 'Processo Alterado pelo Advogado'  where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
                Espera_Ate_Que_Abra()

                Thread.Sleep(1000)
                index = index + 1
                GoTo forIn 'Volta para o Início
            End If

            'Inserindo Processo e Clicando em Continuar
            objIndex.Document.Forms(0).elements("cdProcessoJudicialNumero").innertext = TB.Rows(index)("PROCESSO_ACERTADO").ToString 'dejur
            objIndex.Document.Forms(0).elements("btoSalvar").Click() ' lupa do bt salvar


            Try
                AppActivate("(GCPJ) Gestão Controle de Processos Jurídicos - Windows Internet Explorer")
            Catch ex As Exception

            End Try

            Do Until objIndex.Busy = False
                'Do While objIndex.ReadyState = SHDocVw.tagREADYSTATE.READYSTATE_INTERACTIVE
                Thread.Sleep(3000)
                SendKeys.Send("{Enter}")
                'Espera até que abra Acionando o Enter
                'Loop
            Loop

            'Força uma digitação no GCPJ da tela de pesquisa para verificar deu algum erro
            Espera_Ate_Que_Abra()
            Try
                objIndex.Document.Forms(0).elements("nrProcessoBradesco").innertext = 0
                cmd.CommandText = "update PROCESSOS_MENORES_20_DIGITOS_CI set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                cmd.CommandText = "update PROCESSOS_MENORES_20_DIGITOS_CI set importado = true, obs = 'Erro ao Salvar Processo'  where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
                Espera_Ate_Que_Abra()
                Thread.Sleep(1000)
                'MsgBox("Erro ao salvar Processo")
                'Exit Sub
            End Try

        Next

    End Sub

End Class