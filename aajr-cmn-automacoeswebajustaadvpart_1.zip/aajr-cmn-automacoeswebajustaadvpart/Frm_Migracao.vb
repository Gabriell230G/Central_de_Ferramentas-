﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices


Public Class Frm_Migracao


    Dim objIndex As SHDocVw.InternetExplorer
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Migracao.mdb")



    Private Sub ConectarGCPJ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConectarGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        ConectarGCPJ.Enabled = False
        MigrarProcessos.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub MigrarProcessos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MigrarProcessos.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim vRegistros As Integer
        Dim vContador As Integer
        Dim vCursor As Integer

        'Abrindo Tabela
        Dim VsQl As String
        VsQl = "select * from tbMigracao where MIGRADO = false order by GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        vRegistros = TB.Rows.Count

        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/disMigracaoMassaAction?acao=carregar")
        objIndex.Visible = True

        'AGUARDANDO CARREGAR
        Espera_Ate_Que_Abra_Public(objIndex)

        For vContador = 0 To vRegistros - 1 Step 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

forIni:

            Grade.Items.Add(Date.Now & " Processo: " & vContador + 1 & " Faltam mais " & TB.Rows.Count - vContador & "  -  " & TB.Rows(vContador)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            '1	"EXT.JURID.B.HORIZONT"
            '2	"EXT.JURID.BAURU"
            '3	"EXT.JURID.BELEM"
            '4	"EXT.JURID.BRAS-T.SUP"
            '5	"EXT.JURID.BRASILIA"
            '6	"EXT.JURID.CAMPINAS"
            '7	"EXT.JURID.CUIABA"
            '8	"EXT.JURID.CURITIBA"
            '9	"EXT.JURID.FLORIANOP."
            '10	"EXT.JURID.FORTALEZA"
            '11	"EXT.JURID.GOIANIA"
            '12	"EXT.JURID.ITABUNA"
            '13	"EXT.JURID.LONDRINA"
            '14	"EXT.JURID.MANAUS"
            '15	"EXT.JURID.OSASCO"
            '16	"EXT.JURID.PTO.ALEGRE"
            '17	"EXT.JURID.R.JANEIRO"
            '18	"EXT.JURID.RECIFE"
            '19	"EXT.JURID.S.J.R.PRET"
            '20	"EXT.JURID.S.PAULO"
            '21	"EXT.JURID.SALVADOR"
            '22	"EXT.JURID.SAO LUIS"
            '23	"EXT.JURID.STO.ANDRE"
            '24	"G.PROC.RECUP.CREDITO"
            '25	"GES.PROC.JUD.TERCEIR."
            '26	"JURIDICO-MATRIZ"
            '27	"NEGOCIOS BRAM"
            '28	"NEGOCIOS FUNDOS-DAC"

            '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            'TRECHO QUE DEVE SER ALTERADO, QUANDO DA MUDANÇA DE REGIONAL!!!!
            '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            'APENAS O NUMERO DEVE SER ALTERADO!
            'objIndex.Document.forms(0).elements("selDependencia")(24).selected = True
            'objIndex.Document.forms(0).elements("selDependencia").onchange()

            'selecionando regional de origem
            Select Case TB.Rows(vContador)("cod_dejur").ToString
                Case 4042 'EXT.JURID.B.HORIZONT
                    objIndex.Document.forms(0).elements("selDependencia")(1).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4043 'EXT.JURID.BELEM
                    objIndex.Document.forms(0).elements("selDependencia")(3).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4044 'EXT.JURID.BRASILIA
                    objIndex.Document.forms(0).elements("selDependencia")(5).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4045 'EXT.JURID.CAMPINAS
                    objIndex.Document.forms(0).elements("selDependencia")(6).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4048 'EXT.JURID.CUIABA
                    objIndex.Document.forms(0).elements("selDependencia")(7).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4049 'EXT.JURID.CURITIBA
                    objIndex.Document.forms(0).elements("selDependencia")(8).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4053 'EXT.JURID.BAURU
                    objIndex.Document.forms(0).elements("selDependencia")(2).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4548 'EXT.JURID.S.PAULO
                    objIndex.Document.forms(0).elements("selDependencia")(20).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4780 'Florianopolis
                    objIndex.Document.forms(0).elements("selDependencia")(9).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4781 'FORTALEZA
                    objIndex.Document.forms(0).elements("selDependencia")(10).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4783 'GOIANIA
                    objIndex.Document.forms(0).elements("selDependencia")(11).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4784 'ITABUNA
                    objIndex.Document.forms(0).elements("selDependencia")(12).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4785 'TERCEIRIZAÇÃO
                    objIndex.Document.forms(0).elements("selDependencia")(25).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4786 'LONDRINA
                    objIndex.Document.forms(0).elements("selDependencia")(13).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4787 'MANAUS
                    objIndex.Document.forms(0).elements("selDependencia")(14).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4788 'P ALEGRE
                    objIndex.Document.forms(0).elements("selDependencia")(16).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4790 'RECIFE
                    objIndex.Document.forms(0).elements("selDependencia")(18).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4792 ' R JANEIRO
                    objIndex.Document.forms(0).elements("selDependencia")(17).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4793 'SALVADOR
                    objIndex.Document.forms(0).elements("selDependencia")(21).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4795 'STO ANDRE
                    objIndex.Document.forms(0).elements("selDependencia")(23).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4796 ' S J RIO PRETO
                    objIndex.Document.forms(0).elements("selDependencia")(19).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
                Case 4797 'SAO LUIZ
                    objIndex.Document.forms(0).elements("selDependencia")(22).selected = True
                    objIndex.Document.forms(0).elements("selDependencia").onchange()
            End Select

            'seleciona Area Civel
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.forms(0).elements("selArea")(3).selected = True
            objIndex.Document.forms(0).elements("selArea").onchange()

            'Seleciona Classificação Por Processo
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.forms(0).elements("selClassificacao")(3).selected = True
            objIndex.Document.forms(0).elements("selClassificacao").onchange()

            'Inserindo número do Processo
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.forms(0).elements("cdNumeroProcessoBradesco").innerText = TB.Rows(vContador)("GCPJ").ToString
            objIndex.Document.forms(0).elements("selSituacao")(0).selected = True
            objIndex.Document.forms(0).elements("selSituacao").onchange()

            'selecionando Regional
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.forms(0).elements("selDependenciaDestino")(25).selected = True
            objIndex.Document.forms(0).elements("selDependenciaDestino").onChange()
            'AGUARDANDO CARREGAR

            Espera_Ate_Que_Abra_Public(objIndex)
            vCursor = 0
            Do Until vCursor = 99
                Try
                    objIndex.Document.forms(0).elements("selAdvogadoChefeDestino")(vCursor).selected = True
                    objIndex.Document.forms(0).elements("selAdvogadoChefeDestino").onchange()

                    If objIndex.Document.forms(0).elements("nmAdvogadoChefeInstanciaDestino").value = TB.Rows(vContador)("ADVOGADO").ToString Then
                        'If objIndex.Document.forms(0).elements("nmAdvogadoChefeInstanciaDestino").value = "EDILENE DE LIMA PEREIRA" Then
                        vCursor = 99
                        Exit Do
                    End If
                    vCursor += 1
                Catch ex As Exception

                    MsgBox("Advogado: " & TB.Rows(vContador)("ADVOGADO").ToString & " não encontrado na lista de Advogados Chefe.  PROCESSAMENTO PARADO", vbInformation)
                    Exit Sub
                    'If Conexao.State = ConnectionState.Closed Then Conexao.Open()
                    'Dim Cmd As New OleDbCommand("UPDATE tbMigracao SET MIGRADO = true, OBS = 'ADVOGADO NAO LOCALIZADO' WHERE GCPJ = " & TB.Rows(vContador)("GCPJ"), Conexao)
                    'Cmd.ExecuteNonQuery()
                    'vContador += 1
                    'GoTo forIni

                End Try
            Loop


            'AGUARDANDO CARREGAR
            Espera_Ate_Que_Abra_Public(objIndex)

            'CONSISTENCIA AO SALVAR
            'SELECIONADO POR PROCESSO
            If objIndex.Document.forms(0).elements("selClassificacao").value = 5 Then
                'SALVANDO
                objIndex.Document.forms(0).elements("btoSalvar").click()
            Else
                'VOLTANDO AO MESMO PROCESSO
                'CLICANDO EM LIMPAR
                objIndex.Document.forms(0).elements("btoLimpar").click()
                'AGUARDANDO CARREGAR
                Espera_Ate_Que_Abra_Public(objIndex)
                'ATUALIZANDO GRADE
                Grade.Items.Add("REPROCESSANDO REGISTRO: " & TB.Rows(vContador)("GCPJ").ToString)
                Grade.SelectedIndex = Grade.Items.Count - 1
                System.Windows.Forms.Application.DoEvents()
                'VOLTANDO...
                GoTo forIni
            End If

            'AGUARDANDO(CARREGAR)
            Espera_Ate_Que_Abra_Public(objIndex)

            'aguardando
            Thread.Sleep(1000)

            Espera_Ate_Que_Abra_Public(objIndex)


            If Conexao.State = ConnectionState.Closed Then
                Conexao.Open()
            End If


            Dim Cmd3 As New OleDbCommand("UPDATE tbMigracao SET MIGRADO = true, OBS = 'MIGRADO COM SUCESSO' WHERE GCPJ = " & TB.Rows(vContador)("GCPJ"), Conexao)
            Cmd3.ExecuteNonQuery()

        Next


        MsgBox("Foi", vbExclamation)

    End Sub




End Class
