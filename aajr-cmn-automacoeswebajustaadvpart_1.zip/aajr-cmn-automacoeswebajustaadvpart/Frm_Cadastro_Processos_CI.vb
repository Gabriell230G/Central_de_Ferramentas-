﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Public Class Frm_Cadastro_Processos_CI



    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb")
    Dim objIndex As SHDocVw.InternetExplorer
    'Dim objIndex2 As SHDocVw.InternetExplorer = Nothing




    Private Sub Frm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ("GCPJ") = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
   
    Private Function VerificaGCPJ(ByVal nomeJanela As String) As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        For Each ie As SHDocVw.InternetExplorer In New SHDocVw.ShellWindows
            If InStr(ie.LocationName.ToString, nomeJanela) Then
                objIndex = ie
                Return True
            End If
        Next
        Return False
    End Function

    Private Sub Frm_Cadastro_Processos_CI_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        If FecharThread = True Then
            MsgBox("Inicie o procedimento ClickYes", vbInformation)
            Exit Sub
        End If

        Dim vsql As String

        If CMBMaquina.SelectedIndex = -1 Then
            vsql = "select  * from Processos_CI where importado = false  ORDER BY envolvido "
        Else
            vsql = "select * from Processos_CI where importado = false and maquina = " & CMBMaquina.Text & "  ORDER BY envolvido "
        End If

        Dim DA As New OleDbDataAdapter(vsql, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        If TB.Rows.Count = 0 Then
            MsgBox("Não encontrado nenhum processo para a importação", vbCritical)
            Exit Sub
        End If

        Grade.Items.Add(Date.Now & "   Abrindo Tela de Cadastro")
        Grade.SelectedIndex = Grade.Items.Count - 1

        Dim VarGCPJ As String = ""
        Dim VarGCPJ_ANTIGO As String = ""

        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilProcessoAction?acao=carregar&sessao=limpar")

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            Espera_Ate_Que_Abra_Public(objIndex)

            'IDENTIFICANDO GCPJ
            Dim elemCollection As Object
            Dim obj As Object
            elemCollection = objIndex.Document.Forms(0).getElementsByTagName("B")
            For Each obj In elemCollection
                If IsNumeric(obj.innertext) Then
                    VarGCPJ = obj.innertext
                    Exit For
                End If
            Next obj
            If VarGCPJ = "" Then
                MsgBox("Atenção, o sistema não conseguiu identificar o GCPJ", vbInformation)
                Exit Sub
            End If


            'verifica se a dependencia é o 4429 ou 4785
            'If TB.Rows(index)("BANCO_AUTOR").ToString = True Then
            ' If objIndex.Document.Forms(0).elements("cdDependenciaProc").Value <> 4429 Then
            ' MsgBox("Usuario não está no ParW como 4429")
            ' Exit Sub
            ' End If
            ' Else
            'If objIndex.Document.Forms(0).elements("cdDependenciaProc").Value <> 4785 Then
            ''MsgBox("Usuario não está no ParW como 4785")
            'Exit Sub
            'End If
            'End If


            'Alimentando Grade de Status
            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  GCPJ: " & VarGCPJ & "   -    Chave Interna: " & TB.Rows(index)("chave_interna").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()


            '1ª tela
            If TB.Rows(index)("BANCO_AUTOR").ToString = True Then
                objIndex.Document.Forms(0).radioReuAutor(1).Checked = True
                Call objIndex.Document.parentWindow.execScript("processarFormaParticipacaoProcesso('Autor', document.forms[0].totRegGridReu.value, document.forms[0].totRegGridAutor.value , document.forms[0].rdReuAutor.value);", "JavaScript")
                Call objIndex.Document.parentWindow.execScript("obtemValorAtualizado();", "JavaScript")
            End If


            objIndex.Document.Forms(0).elements("dtMovimento").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate) 'dejur
            'objIndex.Document.Forms(0).Elements("cdDependenciaProc").innertext = TBProcessos!COD_DEJUR 'dejur
            objIndex.Document.Forms(0).elements("cdEmpresaGrupoProc").innertext = TB.Rows(index)("empresa_grupo").ToString 'dejur
            objIndex.Document.Forms(0).elements("cdDependenciaEnvolvida").innertext = TB.Rows(index)("DEP_ENVOLVIDA").ToString 'dejur
            objIndex.Document.Forms(0).elements("cdOrgaoPublico").innertext = TB.Rows(index)("COD_ORGAO").ToString 'dejur
            objIndex.Document.Forms(0).elements("cdProcessoJudicialNumero").innertext = TB.Rows(index)("processo").ToString 'dejur
            'objIndex.Document.Forms(0).elements("dtInicioHistoricoProcesso").focus()
            'objIndex.Document.Forms(0).elements("cdProcessoJudicialNumero").focus()



            objIndex.Document.Forms(0).elements("dtInicioHistoricoProcesso").innertext = FormatDateTime(TB.Rows(index)("DATA_ORGAO").ToString, DateFormat.ShortDate) 'dejur
            objIndex.Document.Forms(0).elements("dtInicioHistoricoProcesso").onblur()
            Thread.Sleep(1000)
            Espera_Ate_Que_Abra_Public(objIndex)

            'objIndex.Document.Forms(0).elements("dtFatoGeradorProcessoCivel").innertext = FormatDateTime(TB.Rows(index)("DATA_fato").ToString, DateFormat.ShortDate) 'dejur
            'objIndex.Document.Forms(0).elements("dtFatoGeradorProcessoCivel").onblur()
            Thread.Sleep(1000)
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("Vlr_causa").ToString, 2)
            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").onblur()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Calcular Valor Atualizado
            Call objIndex.Document.parentWindow.execScript("obtemValorAtualizado();", "JavaScript")

            Thread.Sleep(1000)
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra_Public(objIndex)

            Try
                objIndex.Document.Forms(0).elements("select3").focus()
            Catch ex As Exception
                MsgBox("Tela do Processo não foi Preenchida corretamente.", vbCritical)
                Exit Sub
            End Try

            'TELA 2 Autor
            'objIndex.Document.Forms(0).elements("select3").focus()

            If TB.Rows(index)("BANCO_AUTOR").ToString = False Then ''se o banco autor for falso, então seleciona pessoa fisica
                'verifica se eh por nome
                If Len(TB.Rows(index)("cpf").ToString) = 0 Then
                    objIndex.Document.Forms(0).elements("select3").Item(4).Selected = True
                    Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,5,true);", "JavaScript")
                    'insere o nome do envolvido
                    objIndex.Document.Forms(0).elements("dsnome").innertext = TB.Rows(index)("envolvido").ToString
                    Call objIndex.Document.parentWindow.execScript("porNome = 1;", "JavaScript")
                    objIndex.Document.Forms(0).elements("btoNome").Click() ' lupa do bt salvar
                    If IdentificarAutor() = False Then GoTo CadastraEnvolvido
                End If

                'verifica se é pessoa Fisica
                If Len(TB.Rows(index)("cpf").ToString) > 0 And (Len(TB.Rows(index)("filial").ToString) = 0 Or TB.Rows(index)("filial").ToString = 0) Then
                    objIndex.Document.Forms(0).elements("select3").Item(4).Selected = True
                    Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,5,true);", "JavaScript")
                    objIndex.Document.Forms(0).elements("dsnome").innertext = TB.Rows(index)("envolvido").ToString
                    objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("cpf").ToString
                    objIndex.Document.Forms(0).elements("cdControle").innertext = TB.Rows(index)("digito").ToString

                End If

                'verifica se é pessoa Jurídica
                If Len(TB.Rows(index)("cpf").ToString) > 0 And Len(TB.Rows(index)("filial").ToString) > 0 And TB.Rows(index)("filial").ToString <> 0 Then
                    objIndex.Document.Forms(0).elements("select3").Item(5).Selected = True
                    Call objIndex.Document.parentWindow.execScript("alteraDivTipo(4,5,true);", "JavaScript")
                    objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("cpf").ToString
                    objIndex.Document.Forms(0).elements("cdFilial").innertext = TB.Rows(index)("filial").ToString
                    objIndex.Document.Forms(0).elements("cdControle").innertext = TB.Rows(index)("digito").ToString
                End If

                objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Incluir Autor
                Espera_Ate_Que_Abra_Public(objIndex)


CadastraEnvolvido:
                'Verifica se o Envolvido no processo foi registrado
                Try
                    objIndex.Document.Forms(0).elements("selecionados").Checked = True
                Catch ex As Exception
                    'significa que nenhum envolvido foi registrado
                    If CadastrarEnvolvido(TB.Rows(index)("envolvido").ToString, TB.Rows(index)("cpf").ToString, TB.Rows(index)("filial").ToString, TB.Rows(index)("digito").ToString) = True Then
                        objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Incluir Autor
                        Espera_Ate_Que_Abra_Public(objIndex)
                    Else

                        If MsgBox("Envolvido não selecionado. Selecione manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro.", vbYesNo) <> vbYes Then Exit Sub
                        objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Incluir Autor
                    End If
                End Try

            Else
                objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("DEP_ENVOLVIDA1").ToString
                objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
                Espera_Ate_Que_Abra_Public(objIndex)
                'caso não tenha mais de 1 dependincia, desmarque os procedimentos abaixo

                'Thread.Sleep(1000)
                'objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("DEP_ENVOLVIDA2").ToString
                'objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
                'MataPossivelMsgbox()
                'Espera_Ate_Que_Abra()
                'Thread.Sleep(1000)
                'objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("DEP_ENVOLVIDA3").ToString
                'objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
                'MataPossivelMsgbox()
                'Espera_Ate_Que_Abra()
            End If

            Espera_Ate_Que_Abra_Public(objIndex)

            'Inserindo Contrato se Tiver
            If Len(TB.Rows(index)("CONTRATO").ToString) > 0 Then
                objIndex.Document.Forms(0).elements("btoContratos").Click()
                Call Inserir_Contrato(TB.Rows(index)("CONTRATO").ToString, TB.Rows(index)("CONTRATO_DIGITO").ToString, TB.Rows(index)("ENVOLVIDO").ToString)
            End If

            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 3 Reu

            Try
                objIndex.Document.Forms(0).elements("tiporeu").focus()
            Catch ex As Exception
                MsgBox("a tela Autor não foi Preenchida Corretamente", vbCritical)
                Exit Sub
            End Try

            If TB.Rows(index)("BANCO_AUTOR").ToString = False Then ''se o banco autor for falso, então seleciona pessoa fisica
                'insere primeiro réu se tiver
                'If TB.Rows(index)("DEP_ENVOLVIDA").ToString <> TB.Rows(index)("DEP_ENVOLVIDA1").ToString Then
                'objIndex.Document.Forms(0).elements("cdSequencia").innertext = "0"
                'objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("DEP_ENVOLVIDA1").ToString
                'objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Continuar
                'Espera_Ate_Que_Abra_Public(objIndex)
                'objIndex.Document.Forms(0).elements("btoRenumerar").Click() ' Continuar
                'Espera_Ate_Que_Abra_Public(objIndex)
                'End If

                'objIndex.Document.Forms(0).elements("tiporeu").focus()
            Else
                'verifica se eh por nome
                If Len(TB.Rows(index)("cpf").ToString) = 0 Then
                    objIndex.Document.Forms(0).elements("tiporeu").Item(5).Selected = True
                    Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,5,true);", "JavaScript")
                    'insere o nome do envolvido
                    objIndex.Document.Forms(0).elements("dsnome").innertext = TB.Rows(index)("envolvido").ToString
                    Call objIndex.Document.parentWindow.execScript("porNome = 1;", "JavaScript")
                    objIndex.Document.Forms(0).elements("btoNome").Click() ' lupa do bt salvar
                    IdentificarAutor()


                End If

                'verifica se é pessoa Fisica
                If Len(TB.Rows(index)("cpf").ToString) > 0 And (Len(TB.Rows(index)("filial").ToString) = 0 Or TB.Rows(index)("filial").ToString = 0) Then
                    objIndex.Document.Forms(0).elements("tiporeu").Item(5).Selected = True
                    Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,5,true);", "JavaScript")
                    objIndex.Document.Forms(0).elements("dsnome").innertext = TB.Rows(index)("envolvido").ToString
                    objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("cpf").ToString
                    objIndex.Document.Forms(0).elements("cdControle").innertext = TB.Rows(index)("digito").ToString
                End If

                'verifica se é pessoa Jurídica
                If Len(TB.Rows(index)("cpf").ToString) > 0 And Len(TB.Rows(index)("filial").ToString) > 0 And TB.Rows(index)("filial").ToString <> 0 Then
                    objIndex.Document.Forms(0).elements("tiporeu").Item(6).Selected = True
                    Call objIndex.Document.parentWindow.execScript("alteraDivTipo(4,5,true);", "JavaScript")
                    objIndex.Document.Forms(0).elements("cdCodigo").innertext = TB.Rows(index)("cpf").ToString
                    objIndex.Document.Forms(0).elements("cdFilial").innertext = TB.Rows(index)("filial").ToString
                    objIndex.Document.Forms(0).elements("cdControle").innertext = TB.Rows(index)("digito").ToString
                End If

                objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
                Espera_Ate_Que_Abra_Public(objIndex)

                Try 'Verifica se o Envolvido no processo foi registrado marcando ele na lista
                    objIndex.Document.Forms(0).elements("selecionados").Checked = True
                Catch ex As Exception 'caso dê erro significa que não encontrou o reclamante na lista
                    If Len(TB.Rows(index)("cpf").ToString) = 0 Then 'Verifica se é pesquisa por nome
                        If MsgBox("Envolvido não selecionado. Selecione manualmente antes de clicar em OK" & vbCrLf & "Ou clique em Não para cancelar o cadastro.", vbYesNo) <> vbYes Then Exit Sub
                        objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Incluir Autor
                    Else
                        objIndex.Document.Forms(0).elements("btoNome").Click() 'sendo assim pesquisa pelo nome
                        IdentificarAutor() 'Seleciona o primeiro da lista
                        objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
                    End If
                End Try
            End If


            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar

            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 4 Audiencia
            objIndex.Document.Forms(0).elements("cboAudiencia").focus()
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 5 Documentos
            objIndex.Document.Forms(0).elements("cboTipoEnvolvido").focus()
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 6 Anexos
            objIndex.Document.Forms(0).elements("nmDocumento").focus()
            objIndex.Document.Forms(0).elements("Submit32").Click() ' Continuar

            Espera_Ate_Que_Abra_Public(objIndex)
            Thread.Sleep(200)

            'FecharTodasPopUps

            'Tela 7 Resumo
            'SendKeys.SendWait(TB.Rows(index)("RESUMO").ToString)
            objIndex.Document.forms(0).elements("dsResumo").value = TB.Rows(index)("RESUMO").ToString


            objIndex.Document.Forms(0).elements("button2").Click() ' SALVAR PROCESSO
            Thread.Sleep(1000)

            Espera_Ate_Que_Abra_Public(objIndex)

            'CONSISTENCIA COM gcpj PARA VERIFICAR SE A TELA MUDOU
            VarGCPJ_ANTIGO = VarGCPJ
            'IDENTIFICANDO GCPJ

            elemCollection = objIndex.Document.Forms(0).getElementsByTagName("B")
            For Each obj In elemCollection
                If IsNumeric(obj.innertext) Then
                    VarGCPJ = obj.innertext
                    Exit For
                End If
            Next obj
            If VarGCPJ = VarGCPJ_ANTIGO Then
                MsgBox("A TELA NÃO MUDOU")
            End If

            'If MsgBox("O Registro foi salvo com sucesso?" & vbCrLf & "GCPJ salvo por último: " & VarGCPJ, vbQuestion + vbYesNo) <> vbYes Then Exit Sub

            cmd.CommandText = "update Processos_CI set gcpj = " & VarGCPJ_ANTIGO & ", data_cadastro = " & SQL_Data(Date.Now) & ", importado = true, obs = 'GCPJ: " & VarGCPJ_ANTIGO & "' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

            'If MsgBox("Deseja ir para o proximo?", vbQuestion + vbYesNo) <> vbYes Then Exit Sub

            VarGCPJ = ""
        Next

        MsgBox("Acabou", vbInformation)
    End Sub



    Private Function IdentificarAutor() As Boolean
        'Conectando a variável à janela popup
        Thread.Sleep(3000)

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell

        For Each objIndex2 In objShell2.Windows
            If InStr(objIndex2.LocationURL, "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilReuAction?acao=carregarPopupFuncionario") Or InStr(objIndex2.LocationURL, "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopupFuncionario") Then

                objIndex2.Visible = True
                Dim elemCollection As Object
                elemCollection = objIndex2.Document.Forms(0).getElementsByTagName("a")

                'selecionando o primeiro encontrado
                For Each obj In elemCollection
                    obj.Click()
                    Return True
                Next
                objIndex2.Quit()
                Return False
            End If
        Next objIndex2
        Return False
        'Call objIndex2.Document.parentWindow.execScript("paginacao('0');", "JavaScript")

    End Function
    Private Sub Inserir_Contrato(ByVal VarContrato As String, ByVal VarDigito As String, ByVal VarNome As String)
        Thread.Sleep(3000)

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell
        Dim Contador As Integer
        Contador = 1

        For Each objIndex2 In objShell2.Windows
            If objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilClassificacaoAction?acao=montarTelaContrato" Then

                objIndex2.Document.Forms(0).elements("cdContrato").innertext = VarContrato
                If Len(VarDigito) > 0 Then objIndex2.Document.Forms(0).elements("cdDigContrato").innertext = VarDigito
                objIndex2.Document.forms(0).elements("rdEnvolvido")(1).checked = True
                objIndex2.Document.forms(0).elements("rdEnvolvido")(1).onclick()

                Espera_Ate_Que_Abra_Public(objIndex2)

                objIndex2.Document.Forms(0).elements("dsNome").innertext = VarNome
                objIndex2.Document.Forms(0).elements("btoincluir").Click()

                Espera_Ate_Que_Abra_Public(objIndex2)

                objIndex2.Document.Forms(0).elements("Submit32").Click()
                Thread.Sleep(1000)
                Try
                    objIndex2.Quit()
                Catch ex As Exception
                End Try


                Exit For
            End If
        Next objIndex2



    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from Processos_CI where  importado = false   ORDER BY envolvido"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If


        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE Processos_CI SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1
        Next



        MsgBox("Distribuição Efetuada")
    End Sub

    Private Function CadastrarEnvolvido(ByRef vNome As String, ByVal vCPF As String, ByVal vFilial As String, ByVal vDigito As String) As Boolean


        'Clicando em Novo
        Dim elemCollection As Object
        elemCollection = objIndex.Document.Forms(0).getElementsByTagName("A")
        For Each obj In elemCollection
            If obj.innertext = "Novo" Then
                obj.click()
                Exit For
            End If
        Next

        'Identificando Tela de cadastro de envolvido
        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell
        Dim Achou As Boolean = False

InicioVerificacao:
        For Each objIndex2 In objShell2.Windows
            If objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&origem=origemCivel&dsTipoPessoa=PESSOA FISICA" Or objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&origem=origemCivel&dsTipoPessoa=PESSOA JURIDICA" Then
                objIndex2.Visible = True
                Achou = True
                Exit For
            End If
        Next objIndex2

        If Achou = False Then GoTo InicioVerificacao

        Espera_Ate_Que_Abra_Public(objIndex2)


        'Inicio do Cadastro
        Thread.Sleep(2000)
        'Inserindo Pessoa Fisica com CPF
        If Len(vFilial) = 0 Then
            'inserindo nome
            objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = "" & vNome
            objIndex2.Document.Forms(0).elements("cdCpfPessoaExterna").innertext = "" & vCPF
            objIndex2.Document.Forms(0).elements("cdControleCpfPessoaExterna").innertext = "" & vDigito

            'Clicando no botão Salvar
            objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar

            Espera_Ate_Que_Abra_Public(objIndex2)


            Thread.Sleep(1000)

            'Verifica se a tela limpou
            Try
                If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                    'caso não limpou então retira o CPF, pois o mesmo deve estar errado
                    objIndex2.Document.Forms(0).elements("cdCpfPessoaExterna").innertext = ""
                    objIndex2.Document.Forms(0).elements("cdControleCpfPessoaExterna").innertext = ""

                    'Clicando no botão Salvar novamente
                    objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar
                    Espera_Ate_Que_Abra_Public(objIndex2)
                    Thread.Sleep(1000)

                    'Verifica se a tela limpou novamente
                    Try
                        If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                            MsgBox("Não foi possível cadastrar o Envolvido")
                            Return False
                        End If
                    Catch ex2 As Exception
                    End Try

                End If

            Catch ex As Exception
            End Try




        Else
            'Inserindo Pessoa Juridica com CPF
            objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = "" & vNome
            objIndex2.Document.Forms(0).elements("cdCnpjPessoaExterna").innertext = "" & vCPF
            objIndex2.Document.Forms(0).elements("cdFilialCnpjPessoaExterna").innertext = "" & vFilial
            objIndex2.Document.Forms(0).elements("cdControleCnpjPessoaExterna").innertext = "" & vDigito

            'Clicando no botão Salvar
            objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar
            Espera_Ate_Que_Abra_Public(objIndex2)


            'Verifica se a tela limpou
            Try
                If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                    'caso não limpou então retira o cnpj, pois o mesmo deve estar errado
                    objIndex2.Document.Forms(0).elements("cdCnpjPessoaExterna").innertext = ""
                    objIndex2.Document.Forms(0).elements("cdFilialCnpjPessoaExterna").innertext = ""
                    objIndex2.Document.Forms(0).elements("cdControleCnpjPessoaExterna").innertext = ""

                    'Clicando no botão Salvar novamente
                    objIndex2.Document.Forms(0).elements("btoSalvar").Click() ' Salvar
                    Espera_Ate_Que_Abra_Public(objIndex2)

                    'Verifica se a tela limpou novamente
                    Try
                        If Len(objIndex2.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                            MsgBox("Não foi possível cadastrar o Envolvido")
                            Return False
                        End If
                    Catch ex2 As Exception
                    End Try

                End If

            Catch ex As Exception
            End Try


        End If

        Thread.Sleep(2000)
        Return True

    End Function

End Class