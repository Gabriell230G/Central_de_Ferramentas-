﻿'==============================================================================
'  CONTROLE S5 - LIMITADOR DE OPERAÇÕES
'  Normativo 05.1073 - Sistemas/Aplicativos Mantidos em Ambiente Departamental
'------------------------------------------------------------------------------
'  O QUE FAZ
'    Limita quantos registros o robô pode processar no GCPJ em UMA execução.
'    Quando o limite é atingido:
'      1. o laço da automação para (Exit For / Exit Do);
'      2. o usuário recebe o aviso "Processamento Limitado - Controle S5";
'      3. os registros que sobraram continuam pendentes na base (.mdb) e
'         podem ser processados numa nova execução.
'
'  COMO MUDAR O LIMITE
'    Altere SOMENTE as constantes abaixo. Todas as telas do Automações Web
'    usam estes mesmos valores, não precisa mexer em mais nenhum lugar.
'
'  ONDE ELE É USADO
'    Ctrl+Shift+F no Visual Studio e pesquise por "[S5]". Cada rotina tem:
'      - 1 linha de declaração do contador (início da Sub);
'      - 1 bloco de 3 linhas no começo do laço que mexe no GCPJ.
'==============================================================================
Module Mod_LimitadorS5

    ''' <summary>Máximo de registros processados no GCPJ por execução.</summary>
    Public Const LIMITE_OPERACOES_S5 As Integer = 5000

    ''' <summary>
    ''' Máximo de lotes por execução, usado apenas na tela Aprovar Migração,
    ''' onde cada volta do laço salva várias telas de uma vez (não é 1 registro).
    ''' </summary>
    Public Const LIMITE_LOTES_S5 As Integer = 25

    ''' <summary>
    ''' Retorna True quando a execução já chegou no limite do Controle S5
    ''' e, nesse caso, avisa o usuário. Uso dentro do laço:
    '''     If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
    '''     qtdOperacoesS5 += 1
    ''' </summary>
    ''' <param name="qtdOperacoes">Quantos registros já foram processados nesta execução.</param>
    ''' <param name="limite">Limite a aplicar (padrão: LIMITE_OPERACOES_S5).</param>
    ''' <param name="unidade">Texto usado no aviso (padrão: "registros").</param>
    Public Function LimiteS5Atingido(ByVal qtdOperacoes As Integer, _
                                     Optional ByVal limite As Integer = LIMITE_OPERACOES_S5, _
                                     Optional ByVal unidade As String = "registros") As Boolean
        If qtdOperacoes < limite Then Return False

        MsgBox("O limite de processamento de " & Format(limite, "#,##0") & " " & unidade & " foi atingido." & vbCrLf & vbCrLf & _
               "Os itens restantes continuam pendentes e podem ser processados em uma nova execução.", _
               vbExclamation, "Processamento Limitado - Controle S5")
        Return True
    End Function

End Module
