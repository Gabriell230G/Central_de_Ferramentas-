﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Inclusao_Evento


    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Inserir_Evento.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Inclusao_Evento_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub


    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessarInclusao.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessarInclusao.Click
        'AlterarDataEvento()
        InclusaoEvento()
        'InclusaoSineDee()
        'AtualizacaoEvento()
    End Sub

    Private Sub AtualizacaoEvento()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim vRadios As Object, vRadio As Object
        Dim vTrs As Object
        Dim vTds As Object, vTd As Object
        Dim vIgnorar As Integer = 2
        Dim vBase As Object

        If FecharThread = True Then
            Frm_Principal.BTClickYes.PerformClick()
        End If



        Dim VsQl As String

        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select  * from TB_Principa where IMPORTADO = false order by gcpj, EVENTO"
        Else
            VsQl = "select * from TB_Principa where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj, EVENTO"
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            System.Windows.Forms.Application.DoEvents()

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If


            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'TRECHO NOVO PARA A ATUALIZACAO DO EVENTO
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraPendAtulzResAction?acao=carregar")
            Espera_Ate_Que_Abra_Public(objIndex)

            'inserindo gcpj
            objIndex.Document.forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString
            objIndex.Document.forms(0).elements("btoPesquisar").click()
            Espera_Ate_Que_Abra_Public(objIndex)
            Thread.Sleep(1500)

            Try
                'casos um só evento
                objIndex.Document.forms(0).elements("selecionados").checked = True
                Thread.Sleep(200)
                objIndex.Document.forms(0).elements("btoDetalhar").click()
                Espera_Ate_Que_Abra_Public(objIndex)
                'RESUMO
                objIndex.Document.forms(0).elements("dsResumoEventoJudicial").innertext = TB.Rows(index)("RESUMO").ToString
                Thread.Sleep(200)
                'SALVAR
                objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
                Espera_Ate_Que_Abra_Public(objIndex)
            Catch ex As Exception
                'localizando(evento)
                vRadios = objIndex.Document.getelementsbytagname("input")
                Thread.Sleep(500)

                'looping
                For Each vRadio In vRadios

                    If vRadio.type = "radio" Then
                        vBase = vRadio.parentElement
                        vTrs = vBase.parentElement
                        Thread.Sleep(100)
                        vTds = vTrs.getelementsbytagname("td")
                        Thread.Sleep(100)

                        For Each vTd In vTds
                            Do While vIgnorar <> 0
                                vIgnorar -= 1
                                Continue For
                            Loop
                            'se nao encontrar
                            If InStr(vTd.innertext, TB.Rows(index)("nome_evento").ToString) = 0 Then
                                Exit For
                            End If

                            'se encontrou
                            vRadio.checked = True
                            Thread.Sleep(200)
                            objIndex.Document.forms(0).elements("btoDetalhar").click()
                            Espera_Ate_Que_Abra_Public(objIndex)
                            'RESUMO
                            objIndex.Document.forms(0).elements("dsResumoEventoJudicial").innertext = TB.Rows(index)("RESUMO").ToString
                            Thread.Sleep(200)
                            'SALVAR
                            objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
                            Espera_Ate_Que_Abra_Public(objIndex)
                            'GRAVANDO NO BD
                            cmd.CommandText = "update TB_Principa set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                            cmd.ExecuteNonQuery()
                            Thread.Sleep(50)
                            GoTo fim
                        Next
                        vTd = Nothing
                        vTds = Nothing
                        vIgnorar = 2
                    End If
                    Thread.Sleep(50)
                Next

            End Try


            cmd.CommandText = "update TB_Principa set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

fim:
        Next
    End Sub
    Private Sub InclusaoSineDee()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String

        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select  * from TB_Principa where IMPORTADO = false order by gcpj, EVENTO"
        Else
            VsQl = "select * from TB_Principa where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj, EVENTO"
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            System.Windows.Forms.Application.DoEvents()

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraCpmisAtulzEvntoAction?acao=carregar")

            Espera_Ate_Que_Abra_Public(objIndex)

            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'inserindo evento
            objIndex.Document.Forms(0).elements("cdFaseProcessoEvento")(1).SELECTED = True
            objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext = 255
            objIndex.Document.Forms(0).elements("btoPopupEventoCodigo").onClick()
            Espera_Ate_Que_Abra_Public(objIndex)


            'Incluindo
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoIncluir").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            ''Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("cdFaseProcessoEvento").value) > 0 Then
            '    If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If

            'FINALIZANDO INCLUSÃO
            objIndex.Document.Forms(0).elements("btoSalvar").Click()

            Espera_Ate_Que_Abra_Public(objIndex)



            cmd.CommandText = "update TB_Principa set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

fim:
        Next
        MsgBox("Acabou!")
    End Sub

    Private Sub InclusaoEvento()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim vRadios As Object, vRadio As Object
        Dim vTrs As Object
        Dim vTds As Object, vTd As Object
        Dim vIgnorar As Integer = 2
        Dim vBase As Object


        Dim VsQl As String

        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select  * from TB_Principa where IMPORTADO = false order by gcpj, EVENTO"
        Else
            VsQl = "select * from TB_Principa where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj, EVENTO"
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            System.Windows.Forms.Application.DoEvents()

            If Date.Now.Hour >= 22 Then
                Thread.Sleep(36000000)
                Grade.Items.Add("22:00!!! Aguardando até as 08:00 de amanha!")
                Grade.SelectedIndex = Grade.Items.Count - 1
                System.Windows.Forms.Application.DoEvents()
                'aguarndado 10 horas.
            End If

            If Today.DayOfWeek = DayOfWeek.Saturday Then
                Thread.Sleep(172800000)
                'aguardando 48 horas
                Grade.Items.Add("Sabado!!! Só segunda as 08:00 ok??")
                Grade.SelectedIndex = Grade.Items.Count - 1
                System.Windows.Forms.Application.DoEvents()
            End If


            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraCpmisAtulzEvntoAction?acao=carregar")
            Espera_Ate_Que_Abra_Public(objIndex)

            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'inserindo evento
            objIndex.Document.Forms(0).elements("cdFaseProcessoEvento")(1).SELECTED = True
            objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext = TB.Rows(index)("evento").ToString
            'objIndex.Document.Forms(0).elements("dtEventoJudicialProcesso").innertext = FormatDateTime(TB.Rows(index)("data").ToString, DateFormat.ShortDate)
            objIndex.Document.Forms(0).elements("btoPopupEventoCodigo").onClick()
            Espera_Ate_Que_Abra_Public(objIndex)


            'objIndex.Document.Forms(0).elements("selecHora")(23).SELECTED = True
            'objIndex.Document.Forms(0).elements("selecHora").onChange()
            'Espera_Ate_Que_Abra_Public(objIndex)
            'objIndex.Document.Forms(0).elements("selecMinuto")(1).SELECTED = True
            'objIndex.Document.Forms(0).elements("selecMinuto").onChange()

            'Incluindo
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoIncluir").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            If Len(objIndex.Document.Forms(0).elements("cdFaseProcessoEvento").value) > 0 Then
                If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            End If

            'FINALIZANDO INCLUSÃO
            objIndex.Document.Forms(0).elements("btoSalvar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            ''TRECHO NOVO PARA A ATUALIZACAO DO EVENTO
            'objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraPendAtulzResAction?acao=carregar")
            'Espera_Ate_Que_Abra_Public(objIndex)

            ''inserindo gcpj
            'objIndex.Document.forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString
            'objIndex.Document.forms(0).elements("btoPesquisar").click()
            'Espera_Ate_Que_Abra_Public(objIndex)
            'Thread.Sleep(1500)

            'Try
            '    'casos um só evento
            '    objIndex.Document.forms(0).elements("selecionados").checked = True
            '    Thread.Sleep(200)
            '    objIndex.Document.forms(0).elements("btoDetalhar").click()
            '    Espera_Ate_Que_Abra_Public(objIndex)
            '    'RESUMO
            '    objIndex.Document.forms(0).elements("dsResumoEventoJudicial").innertext = TB.Rows(index)("RESUMO").ToString
            '    Thread.Sleep(200)
            '    'SALVAR
            '    objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
            '    Espera_Ate_Que_Abra_Public(objIndex)
            'Catch ex As Exception
            '    'localizando(evento)
            '    vRadios = objIndex.Document.getelementsbytagname("input")
            '    Thread.Sleep(500)

            '    'looping
            '    For Each vRadio In vRadios

            '        If vRadio.type = "radio" Then
            '            vBase = vRadio.parentElement
            '            vTrs = vBase.parentElement
            '            Thread.Sleep(100)
            '            vTds = vTrs.getelementsbytagname("td")
            '            Thread.Sleep(100)

            '            For Each vTd In vTds
            '                Do While vIgnorar <> 0
            '                    vIgnorar -= 1
            '                    Continue For
            '                Loop
            '                'se nao encontrar
            '                If InStr(vTd.innertext, TB.Rows(index)("nome_evento").ToString) = 0 Then
            '                    Exit For
            '                End If

            '                'se encontrou
            '                vRadio.checked = True
            '                Thread.Sleep(200)
            '                objIndex.Document.forms(0).elements("btoDetalhar").click()
            '                Espera_Ate_Que_Abra_Public(objIndex)
            '                'RESUMO
            '                objIndex.Document.forms(0).elements("dsResumoEventoJudicial").innertext = TB.Rows(index)("RESUMO").ToString
            '                Thread.Sleep(200)
            '                'SALVAR
            '                objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
            '                Espera_Ate_Que_Abra_Public(objIndex)
            '                'GRAVANDO NO BD
            '                cmd.CommandText = "update TB_Principa set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            '                cmd.ExecuteNonQuery()
            '                Thread.Sleep(50)
            '                GoTo fim
            '            Next
            '            vTd = Nothing
            '            vTds = Nothing
            '            vIgnorar = 2
            '        End If
            '        Thread.Sleep(50)
            '    Next

            'End Try


            cmd.CommandText = "update TB_Principa set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

fim:
        Next
        MsgBox("Acabou!")
    End Sub
    Private Sub AlterarDataEvento()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            MsgBox("Selecione a maquina", vbCritical)
            Exit Sub
        End If

        'Abrindo Tabela
        Dim VsQl As String
        VsQl = "select * from TB_Principa where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            System.Windows.Forms.Application.DoEvents()

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraCpmisAtulzEvntoAction?acao=carregar")
            Espera_Ate_Que_Abra_Public(objIndex)

            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Selecionando o Primeiro Encontrado
            Try

                objIndex.Document.Forms(0).elements("selecionados").Checked = True
                objIndex.Document.Forms(0).elements("btoAlterar").onClick()
                Espera_Ate_Que_Abra_Public(objIndex)
                objIndex.Document.Forms(0).elements("dtEventoJudicialProcesso").innertext = FormatDateTime(TB.Rows(index)("data").ToString, DateFormat.ShortDate)
                objIndex.Document.Forms(0).elements("btoIncluir").Click()

                Espera_Ate_Que_Abra_Public(objIndex)

                'Verifica se a Tela Limpou
                If Len(objIndex.Document.Forms(0).elements("cdFaseProcessoEvento").value) > 0 Then
                    If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
                End If

                objIndex.Document.Forms(0).elements("btoSalvar").Click()
                Espera_Ate_Que_Abra_Public(objIndex)

                cmd.CommandText = "update TB_Principa set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                cmd.CommandText = "update TB_Principa set importado = true, obs = 'MAIS DE 1 EVENTO' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()

            End Try


        Next
        MsgBox("Acabou!")

    End Sub
    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from TB_Principa where  importado = false   ORDER BY GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If

        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE TB_Principa SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next


        MsgBox("Distribuição Efetuada")
    End Sub

  
End Class