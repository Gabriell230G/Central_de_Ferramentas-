﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Public Class Frm_Alterar_Procs_CI
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function
    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function
    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1
    Private Sub MataMsgbox()
        Dim winHwnd As Long
        Do Until winHwnd <> 0
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
    End Sub

    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb")
    Dim objIndex As SHDocVw.InternetExplorer
    'Dim objIndex2 As SHDocVw.InternetExplorer = Nothing


    Private Sub Frm_Alterar_Procs_CI_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTConectaGCPJ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function
    Private Sub BTProcessar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        If FecharThread = True Then
            MsgBox("Inicie o procedimento ClickYes", vbInformation)
            Exit Sub
        End If

        'Dim vLog As New Log
        Dim vIndex As Integer = 0
        Dim vTables As Object
        Dim vTable As Object
        Dim vTrs As Object
        Dim vTr As Object
        Dim vCampos As Object
        Dim vCampo As Object
        Dim vLinhas As Object
        Dim vLinha As Object
        Dim vContador As Integer = 0
        Dim vRadios As Object
        Dim vRadio As Object

        Dim vsql As String

        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            'vsql = "select top 3 * from CADASTRO_ENVOLVIDO where importado = false  ORDER BY envolvido "
            If baixado.CheckState = CheckState.Checked Then
                vsql = "select  * from Processos_CI where importado = false AND BAIXADO = TRUE ORDER BY gcpj "
            Else
                vsql = "select  * from Processos_CI where importado = false AND BAIXADO = FALSE ORDER BY gcpj "
            End If

        Else
            If baixado.CheckState = CheckState.Checked Then
                vsql = "select  * from Processos_CI where importado = false AND BAIXADO = TRUE and maquina = " & CMBMaquina.ComboBox.Text & " ORDER BY gcpj "
            Else
                vsql = "select  * from Processos_CI where importado = false AND BAIXADO = FALSE and maquina = " & CMBMaquina.ComboBox.Text & " ORDER BY gcpj "
            End If

            'vsql = "select * from CADASTRO_ENVOLVIDO where importado = false and maquina = " & CMBMaquina.ComboBox.Text & "  ORDER BY envolvido "
        End If
        

        '        vsql = "select  * from Processos_CI where importado = false  ORDER BY gcpj "

        Dim DA As New OleDbDataAdapter(vsql, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        If TB.Rows.Count = 0 Then
            MsgBox("Não encontrado nenhum processo para a importação", vbCritical)
            Exit Sub
        End If

        Grade.Items.Add(Date.Now & "   Abrindo Tela de alteração")
        Grade.SelectedIndex = Grade.Items.Count - 1

        Dim VarGCPJ As String = ""
        Dim VarGCPJ_ANTIGO As String = ""

        If baixado.CheckState = CheckState.Checked Then
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoEncerrados")
        Else
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
        End If

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            Espera_Ate_Que_Abra_Public(objIndex)

            'Alimentando Grade de Status
            Grade.Items.Add(Date.Now & " Alterando Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  GCPJ: " & TB.Rows(index)("gcpj").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()


            'PESQUISANDO PROCESSO
            objIndex.Document.Forms(0).elements("nrProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            ' pula direto para tela envolvido - adv parte
            Try
                Call objIndex.Document.parentWindow.execScript("paginar(2);", "JavaScript")
            Catch ex As Exception
                cmd.CommandText = "update Processos_CI set importado = true, obs = 'PROCESSO BAIXADO OU COM ERRO' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                GoTo erro
            End Try

            Espera_Ate_Que_Abra_Public(objIndex)
            'TODO: alterar campos 'elements' para os campos reais na tela de cadastro 
            ' ADV - OAB - UF

            '            objIndex.Document.Forms(0).elements("selecionados")(1).checked()
            '
            '
            '
            '            objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("NOME_DO_ADV_PARTE").ToString
            '           objIndex.Document.Forms(0).elements("cdNumeroDocumentoAdvogado").innertext = TB.Rows(index)("OAB_ADV_PARTE").ToString
            ''           objIndex.Document.Forms(0).elements("selCdSiglaUF").innertext = TB.Rows(index)("UF_OAB_ADV_PARTE").ToString



            vTables = objIndex.Document.forms(0).getelementsbytagname("table")
            Thread.Sleep(100)
            'localizando minha tabela
            For Each vTable In vTables
                If vTable.className = "tab1" Then
                    'preencheGrade("Tabela localizada!")
                    Exit For
                End If
            Next

            'localizando as linhas
            vTrs = vTable.children
            Thread.Sleep(100)
            vContador = 0
            Dim proximo As Integer
            For Each vTr In vTrs
                'consultando os campos
                vLinhas = vTr.children
                Thread.Sleep(100)
                For Each vLinha In vLinhas
                    'procurando so campos
                    vCampos = vLinha.children
                    Thread.Sleep(100)

                    For Each vCampo In vCampos
                        ' MsgBox(vCampo.innertext)
                        If proximo = 1 Then
                            proximo = 0
                            GoTo marcar
                        End If
                        If InStr(vCampo.innertext, "Seq.") Then
                            proximo = 1
                        End If
                        'GoTo marcar
                        'End If
                    Next
                    vContador = vContador + 1
                Next
            Next

marcar:
            vRadios = vLinha.getelementsbytagname("INPUT")
            'vRadios = vLinha(1).getelementsbytagname("INPUT")

            Thread.Sleep(100)
            For Each vRadio In vRadios
                vRadio.checked = True
            Next

            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoAlterar").Click()

            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("NOME_DO_ADV_PARTE").ToString
            objIndex.Document.Forms(0).elements("cdNumeroDocumentoAdvogado").innertext = TB.Rows(index)("OAB_ADV_PARTE").ToString
            'objIndex.Document.Forms(0).elements("selCdSiglaUF").innertext = TB.Rows(index)("UF_OAB_ADV_PARTE").ToString

            For i = 1 To 200
                objIndex.Document.forms(0).elements("selCdSiglaUF")(i).selected = True
                If InStr(objIndex.Document.forms(0).elements("selCdSiglaUF")(i).innertext, TB.Rows(index)("UF_OAB_ADV_PARTE").ToString) Then
                    objIndex.Document.forms(0).elements("selCdSiglaUF").onchange()
                    Exit For
                End If
            Next

            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoIncluir").Click()



            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoSalvar").Click()
            'If CheckProcesso.CheckState = CheckState.Checked Then

            'Else
            '    objIndex.Document.Forms(0).elements("btoContinuar").Click() ' lupa do bt salvar
            '    Espera_Ate_Que_Abra_Public(objIndex)
            'End If



            ''TELA 2 CLASSIFICAÇÃO
            'If CheckClassificacao.CheckState = CheckState.Checked Then
            '    Espera_Ate_Que_Abra_Public(objIndex)
            '    'TIPO
            '    objIndex.Document.forms(0).elements("cdTipoAcao").innertext = TB.Rows(index)("CODIGO_ACAO").ToString
            '    Call objIndex.Document.parentWindow.execScript("validarTipoAcaoCodigo();", "JavaScript")
            '    Espera_Ate_Que_Abra_Public(objIndex)
            '    'MataMsgbox()

            '    'SUBTIPO
            '    objIndex.Document.forms(0).elements("cdSubtipoAcao").innertext = TB.Rows(index)("CODIGO_SUBTIPO").ToString
            '    Call objIndex.Document.parentWindow.execScript("validarSubTipoAcaoCodigo();", "JavaScript")
            '    Espera_Ate_Que_Abra_Public(objIndex)

            '    objIndex.Document.Forms(0).elements("Submit32").Click() ' lupa do bt salvar
            '    Espera_Ate_Que_Abra_Public(objIndex)

            'Else
            '    objIndex.Document.Forms(0).elements("Submit32").Click() ' lupa do bt salvar
            '    Espera_Ate_Que_Abra_Public(objIndex)
            'End If

            'pula para tela de RESUMO
            'Call objIndex.Document.parentWindow.execScript("paginar(7);", "JavaScript")

            'TELA 3 Autor

            'If CheckAutor.CheckState = CheckState.Checked Then
            '
            '            Else
            '            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            '            Espera_Ate_Que_Abra_Public(objIndex)
            '            End If
            '
            '            'Tela 4 Reu
            '           If CheckReu.CheckState = CheckState.Checked Then
            '
            'Else'
            'objI() 'ndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            'Espera_Ate_Que_Abra_Public(objIndex)
            'End If
            '
            '            'Tela 5 Audiencia
            '            objIndex.Document.Forms(0).elements("cboAudiencia").focus()
            '            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            '            Espera_Ate_Que_Abra_Public(objIndex)
            '
            ''Tela 6 Documentos
            'objIndex.Document.Forms(0).elements("dsDocumentoExcepcional").focus()
            ''objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            'Espera_Ate_Que_Abra_Public(objIndex)
            ''
            '''Tela 7 Anexos
            ''objIndex.Document.Forms(0).elements("nmDocumento").focus()
            'objIndex.Document.Forms(0).elements("Submit32").Click() ' Continuar
            '
            '            Espera_Ate_Que_Abra_Public(objIndex)
            '

            'Tela 8 Resumo
            'InserirResumo:
            '            If CheckResumo.CheckState = CheckState.Checked Then
            '                Try
            '                    Thread.Sleep(1000)
            '                    objIndex.Document.Forms(0).elements("dsResumo").innertext = TB.Rows(index)("RESUMO").ToString
            '                    Espera_Ate_Que_Abra_Public(objIndex)
            '                Catch ex As Exception
            '                    GoTo InserirResumo
            '                End Try
            '            End If
            '            Espera_Ate_Que_Abra_Public(objIndex)
            '            Thread.Sleep(1000)
            'Espera_Ate_Que_Abra_Public(objIndex)

            'objIndex.Document.Forms(0).elements("button2").Click() ' SALVAR PROCESSO
            'Thread.Sleep(1000)

            Espera_Ate_Que_Abra_Public(objIndex)

            'CONSISTENCIA COM gcpj PARA VERIFICAR SE A TELA MUDOU
            VarGCPJ_ANTIGO = VarGCPJ
            'IDENTIFICANDO GCPJ


            'If MsgBox("O Registro foi salvo com sucesso?" & vbCrLf & "GCPJ salvo por último: " & VarGCPJ, vbQuestion + vbYesNo) <> vbYes Then Exit Sub

            cmd.CommandText = "update Processos_CI set importado = true, obs = '' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

            'If MsgBox("Deseja ir para o proximo?", vbQuestion + vbYesNo) <> vbYes Then Exit Sub
erro:
        Next

        MsgBox("Acabou", vbInformation)
    End Sub

    Private Sub CheckAutor_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BTDistribuir_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from Processos_CI where  importado = false   ORDER BY envolvido"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If


        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE Processos_CI SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1
        Next



        MsgBox("Distribuição Efetuada")
    End Sub
End Class