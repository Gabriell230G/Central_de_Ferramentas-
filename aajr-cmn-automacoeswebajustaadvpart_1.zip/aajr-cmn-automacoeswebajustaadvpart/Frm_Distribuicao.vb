﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Distribuicao

    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Distribuicao.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Distribuicao_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub


    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String
        Dim GCPJAnterior As Double = 0

        If FecharThread = True Then
            MsgBox("Inicie o Procedimento ClickYes")
            Exit Sub
        End If

        'Abrindo Processos
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select  * from TB_Distribuicao where IMPORTADO = false order by gcpj"
        Else
            VsQl = "select  * from TB_Distribuicao where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "  order by gcpj"
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/disDistribuicaoAction?acao=carregar")
        Espera_Ate_Que_Abra_Public(objIndex)

        'selecionando area de consulta
        Try
            For I = 1 To 100
                If objIndex.Document.Forms(0).elements("selAreaConsulta")(I).INNERTEXT = "CIVEL" Then
                    objIndex.Document.Forms(0).elements("selAreaConsulta")(I).SELECTED = True
                    objIndex.Document.Forms(0).elements("selAreaConsulta").onchange()
                    Exit For
                End If
            Next
        Catch ex As Exception
            MsgBox("Área CIVEL não está disponível no GCPJ", vbCritical)
            Exit Sub
        End Try


        objIndex.Document.Forms(0).elements("btoPesquisar").Click()

        Try
            AppActivate("GCPJ - Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")
        Catch ex As Exception
            Try
                AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Internet Explorer")
            Catch ex2 As Exception
            End Try
        End Try

        Espera_Ate_Que_Abra_Public(objIndex)


        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            'Verificando horario após as 22 e aguardando um período de 4 horas
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                Grade.Items.Add("Horário após as 22:00")
                Grade.SelectedIndex = Grade.Items.Count - 1
                Dim Vdata As Date = Date.Now
EsperandoRestart:
                If DateDiff(DateInterval.Hour, Vdata, Date.Now) < 4 Then
                    Grade.Items.Add(Date.Now & "  Aguardando intervalo de 4 horas..")
                    Grade.SelectedIndex = Grade.Items.Count - 1
                    Thread.Sleep(600000)
                    GoTo EsperandoRestart
                End If
            End If

            'Verificando se o GCPJ é duplicado
            If GCPJAnterior = TB.Rows(index)("gcpj").ToString Then
                Grade.Items.Add("GCPJ Duplicado na Planilha")
                cmd.CommandText = "update TB_Distribuicao set importado = true, OBS = 'GCPJ Duplicado na Planilha' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                GoTo fim
            End If

            GCPJAnterior = TB.Rows(index)("gcpj").ToString

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Adcionando numero do processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()

            'MataPossivelMsgbox()

            Espera_Ate_Que_Abra_Public(objIndex)


            objIndex.Document.Forms(0).elements("cdAdvogadoInternoBradesco").innertext = TB.Rows(index)("cod_interno").ToString
            objIndex.Document.Forms(0).elements("cdPessoaExternaBradesco").innertext = "" & TB.Rows(index)("COD_ESCRITORIO").ToString


            objIndex.Document.Forms(0).elements("selectAll").checked = True
            objIndex.Document.Forms(0).elements("selectAll").onclick()

            objIndex.Document.Forms(0).elements("btoSalvar").Click()



            'Thread.Sleep(5000)
            'SendKeys.Send("{Enter}")

            'MataMsgbox()

            Espera_Ate_Que_Abra_Public(objIndex)



            'Verifica se a Tela Limpou
            If Len(objIndex.Document.Forms(0).elements("cdAdvogadoInternoBradesco").value) > 0 Then
                'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
                Grade.Items.Add("A TELA NÃO LIMPOU")
                cmd.CommandText = "update TB_Distribuicao set importado = true, OBS = 'A TELA NÃO LIMPOU' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            Else
                cmd.CommandText = "update TB_Distribuicao set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            End If

            'If MsgBox("Continuar?", vbYesNo) <> vbYes Then Exit Sub
fim:
        Next
        Grade.Items.Add(Date.Now & " - Processo Finalizado!")
        Grade.SelectedIndex = Grade.Items.Count - 1

    End Sub




    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from TB_Distribuicao where  importado = false   ORDER BY GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If


        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE TB_Distribuicao SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next



        MsgBox("Distribuição Efetuada")
    End Sub


End Class