﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Public Class Frm_Inserir_Reclamante_Reclamada
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Inserir_Reclamante_Reclamada.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Inserir_Reclamante_Reclamada_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        cmbTipo.Text = "Reu"
        CmbArea.Text = "CI"
    End Sub
    Private Sub btnConectar_Click(sender As System.Object, e As System.EventArgs) Handles btnConectar.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        'BTConectaGCPJ.Enabled = False
        btnProcessar.Enabled = True

        Grade.Items.Add("Conexão Efetuada!")
    End Sub
    Private Sub preencheGrade(ByVal vTexto As String)
        Grade.Items.Add(Date.Now & " " & vTexto)
        Grade.SelectedIndex = Grade.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function


    Private Sub btnProcessar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcessar.Click
        RodarEspecifico()
        Exit Sub


        If cmbTipo.SelectedIndex = -1 Then
            MsgBox("Selecione um tipo de envolvimento!", vbExclamation)
            Exit Sub
        End If

        If CmbArea.SelectedIndex = -1 Then
            MsgBox("Selecione uma área!", vbExclamation)
            Exit Sub
        End If

        Select Case CmbArea.Text
            Case "CI"
                ProcessaCI()
            Case "TR"
                ProcessaTR()
        End Select

    End Sub

    Private Sub RodarEspecifico()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim vcontador As Integer = 0
        Dim vTb As New DataSet
        Dim vComando As New OleDbCommand
        Dim vCmd As New OleDbDataAdapter("SELECT  * FROM TB_ALTERAR WHERE Alterado = FALSE order by Bradesco", Conexao)
        vCmd.Fill(vTb)
        Dim elemCollection As Object

        Dim VdataDistribuicao As Date
        Dim VdataFato As Date
        Dim VdataMovto As Date

        Do While vcontador < vTb.Tables(0).Rows.Count
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit Do
            qtdOperacoesS5 += 1

Inicio:
            'Try
            'TELA DE ALTERACAO ATIVOS
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
            Espera_Ate_Que_Abra_Public(objIndex)
            'PESQUISANDO
            Try

                objIndex.Document.forms(0).elements("nrProcessoBradesco").innertext = vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
                objIndex.Document.forms(0).elements("btoPesquisar").click()
            Catch ex As Exception
                GoTo inicio
            End Try



            'SE NAO  LOCALIZADO VAI PROXIMO
            Espera_Ate_Que_Abra_Public(objIndex)

            Try
                'PRIMEIRO CONTINUAR
                'verifica se a data da distribuicao eh maior que a data do fato ou data distribuicao for maior que data movto
                VdataDistribuicao = FormatDateTime(objIndex.Document.forms(0).elements("dtInicioHistoricoProcesso").value, DateFormat.ShortDate)
                VdataFato = FormatDateTime(objIndex.Document.forms(0).elements("dtFatoGeradorProcessoCivel").value, DateFormat.ShortDate)
                VdataMovto = FormatDateTime(objIndex.Document.forms(0).elements("dtMovimento").value, DateFormat.ShortDate)

                If VdataFato > VdataDistribuicao Or VdataDistribuicao > VdataMovto Then
                    vComando.CommandText = "UPDATE TB_ALTERAR SET Alterado = TRUE, jatem = 'ERRO' WHERE BRADESCO = " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
                    vComando.Connection = Conexao
                    vComando.ExecuteNonQuery()
                    preencheGrade("Erro ao atualizar o GCPJ nro: " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString)
                    GoTo fim
                End If
            Catch ex2 As Exception
            End Try


            'Alterando dep. envolvida
            '
            objIndex.Document.FORMS(0).ELEMENTS("cdDependenciaEnvolvida").VALUE() = vTb.Tables(0).Rows(vcontador)("codDependencia").ToString

            objIndex.Document.forms(0).elements("btoContinuar").click()
            'SE DER ALGUM ERRO DE CONSISTENCIAS
            Espera_Ate_Que_Abra_Public(objIndex)


            'SEGUNDO CONTINUAR BANCO AUTOR
            objIndex.Document.FORMS(0).ELEMENTS("Submit32").CLICK()
            Espera_Ate_Que_Abra_Public(objIndex)

            'TERCEIRO CONTINUAR BANCO REU
            objIndex.Document.FORMS(0).ELEMENTS("btoContinuar").CLICK()
            Espera_Ate_Que_Abra_Public(objIndex)

            'excluindo todas as dependencias
inicioExclusao:
            Try
                objIndex.Document.Forms(0).elements("selecionados").Checked = True
                objIndex.Document.FORMS(0).ELEMENTS("btoExcluir").CLICK()
                Espera_Ate_Que_Abra_Public(objIndex)

            Catch ex As Exception
                Try
                    objIndex.Document.Forms(0).elements("selecionados")(0).Checked = True
                Catch ex2 As Exception
                End Try

                objIndex.Document.FORMS(0).ELEMENTS("btoExcluir").CLICK()
                Espera_Ate_Que_Abra_Public(objIndex)
                GoTo inicioExclusao
            End Try


            'PREENCHENDO DEPENDENCIA BANCO AUTOR
            objIndex.Document.FORMS(0).ELEMENTS("cdCodigo").VALUE = vTb.Tables(0).Rows(vcontador)("codDependencia").ToString
            objIndex.Document.FORMS(0).ELEMENTS("btoIncluir").CLICK()
            Espera_Ate_Que_Abra_Public(objIndex)

            ''Preenchendo 4120
            'objIndex.Document.FORMS(0).ELEMENTS("cdCodigo").VALUE = 4120
            'objIndex.Document.FORMS(0).ELEMENTS("btoIncluir").CLICK()
            'Espera_Ate_Que_Abra_Public(objIndex)

            'SALVANDO
            objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
            Espera_Ate_Que_Abra_Public(objIndex)


            Thread.Sleep(1000)
            'Catch ex As Exception
            ' preencheGrade("REPROCESSANDO ")
            ' GoTo Inicio
            ' End Try



proximo:
            Try
                vComando.CommandText = "UPDATE TB_ALTERAR SET Alterado = TRUE WHERE BRADESCO = " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
                vComando.Connection = Conexao
                vComando.ExecuteNonQuery()
            Catch ex As Exception
                preencheGrade("Erro ao atualizar o GCPJ nro: " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString)
            End Try

            preencheGrade("GCPJ " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString & " Atualizado com sucesso!  -  Faltam: " & vTb.Tables(0).Rows.Count - vcontador)

fim:
            vcontador += 1
        Loop

        MsgBox("Processamento realizado com sucesso!", vbExclamation)

    End Sub

    Private Sub ProcessaTR()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim vcontador As Integer = 0
        Dim vTb As New DataSet
        Dim vComando As New OleDbCommand
        vComando.Connection = Conexao
        Dim Verro As String = ""

        Dim vCmd As New OleDbDataAdapter("SELECT * FROM TB_ALTERAR WHERE Alterado = FALSE order by Bradesco", Conexao)
        vCmd.Fill(vTb)


        Do While vcontador < vTb.Tables(0).Rows.Count
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit Do
            qtdOperacoesS5 += 1

Inicio:
            'Try
            'TELA DE ALTERACAO ATIVOS
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
            Espera_Ate_Que_Abra_Public(objIndex)
            'PESQUISANDO
            objIndex.Document.forms(0).elements("nrProcessoBradesco").innertext = vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
            objIndex.Document.forms(0).elements("btoPesquisar").click()
            Espera_Ate_Que_Abra_Public(objIndex)
            'SE NAO  LOCALIZADO VAI PROXIMO


            'Primeira Tela

            'insere a dependencia

            objIndex.Document.forms(0).elements("Submit322").click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'verifica se a tela mudou
            Try
                Verro = objIndex.Document.FORMS(0).ELEMENTS("cdCodigo").VALUE()
            Catch ex As Exception
                'caso de erro, significa que a tela principal não mudou
                vComando.CommandText = "UPDATE TB_ALTERAR SET Alterado = TRUE, jatem = 'ERRO TR' WHERE BRADESCO = " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
                vComando.ExecuteNonQuery()
                preencheGrade("Erro ao atualizar o GCPJ nro: " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString)
                GoTo fim

            End Try



            'Verificando se eh pra inserir no autor:
            If cmbTipo.Text = "Autor" Then
                'PREENCHENDO DEPENDENCIA BANCO AUTOR
                objIndex.Document.FORMS(0).ELEMENTS("cdCodigo").VALUE = vTb.Tables(0).Rows(vcontador)("codDependencia").ToString
                objIndex.Document.FORMS(0).ELEMENTS("btoIncluir").CLICK()

                Espera_Ate_Que_Abra_Public(objIndex)

                'SALVANDO
                objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
                Espera_Ate_Que_Abra_Public(objIndex)

            Else

                'INDO PARA A TELA REU
                objIndex.Document.FORMS(0).ELEMENTS("btoContinuar").CLICK()

                Espera_Ate_Que_Abra_Public(objIndex)


                'incluindo dependencia
                objIndex.Document.forms(0).elements("cdEmpresaIncorporadaBrad").value = 237
                objIndex.Document.FORMS(0).ELEMENTS("cdCodigo").VALUE = vTb.Tables(0).Rows(vcontador)("codDependencia").ToString
                objIndex.Document.FORMS(0).ELEMENTS("btoIncluir").CLICK()
                Espera_Ate_Que_Abra_Public(objIndex)
                'JA EXISTE ESSA DEPENDENCIA PARA O PROCESSO

                'SALVANDO
                objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
                Espera_Ate_Que_Abra_Public(objIndex)
            End If


proximo:

            Espera_Ate_Que_Abra_Public(objIndex)
            Try
                Verro = objIndex.Document.forms(0).elements("nrProcessoBradesco").value
            Catch ex As Exception
                GoTo proximo
            End Try



            vComando.CommandText = "UPDATE TB_ALTERAR SET Alterado = TRUE WHERE BRADESCO = " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
            vComando.ExecuteNonQuery()
            preencheGrade("GCPJ - " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString & " Atualizado com sucesso!  -  Faltam: " & vTb.Tables(0).Rows.Count - vcontador)
fim:
            vcontador += 1
        Loop

        MsgBox("Processamento realizado com sucesso!", vbExclamation)

    End Sub


    Private Sub ProcessaCI()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim vcontador As Integer = 0
        Dim vTb As New DataSet
        Dim vComando As New OleDbCommand
        Dim vCmd As New OleDbDataAdapter("SELECT * FROM TB_ALTERAR WHERE Alterado = FALSE order by Bradesco", Conexao)
        vCmd.Fill(vTb)

        Dim VdataDistribuicao As Date
        Dim VdataFato As Date
        Dim VdataMovto As Date

        Do While vcontador < vTb.Tables(0).Rows.Count
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit Do
            qtdOperacoesS5 += 1

Inicio:
            Try
                'TELA DE ALTERACAO ATIVOS
                objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
                Espera_Ate_Que_Abra_Public(objIndex)
                'PESQUISANDO
                objIndex.Document.forms(0).elements("nrProcessoBradesco").innertext = vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
                objIndex.Document.forms(0).elements("btoPesquisar").click()

                'SE NAO  LOCALIZADO VAI PROXIMO
                Espera_Ate_Que_Abra_Public(objIndex)

                Try
                    'PRIMEIRO CONTINUAR
                    'verifica se a data da distribuicao eh maior que a data do fato ou data distribuicao for maior que data movto
                    VdataDistribuicao = FormatDateTime(objIndex.Document.forms(0).elements("dtInicioHistoricoProcesso").value, DateFormat.ShortDate)
                    VdataFato = FormatDateTime(objIndex.Document.forms(0).elements("dtFatoGeradorProcessoCivel").value, DateFormat.ShortDate)
                    VdataMovto = FormatDateTime(objIndex.Document.forms(0).elements("dtMovimento").value, DateFormat.ShortDate)

                    If VdataFato > VdataDistribuicao Or VdataDistribuicao > VdataMovto Then
                        vComando.CommandText = "UPDATE TB_ALTERAR SET Alterado = TRUE, jatem = 'ERRO' WHERE BRADESCO = " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
                        vComando.Connection = Conexao
                        vComando.ExecuteNonQuery()
                        preencheGrade("Erro ao atualizar o GCPJ nro: " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString)
                        GoTo fim
                    End If
                Catch ex2 As Exception
                End Try


                'Alterando dep. envolvida
                '
                objIndex.Document.FORMS(0).ELEMENTS("cdDependenciaEnvolvida").VALUE() = vTb.Tables(0).Rows(vcontador)("codDependencia").ToString

                objIndex.Document.forms(0).elements("btoContinuar").click()
                'SE DER ALGUM ERRO DE CONSISTENCIAS
                Espera_Ate_Que_Abra_Public(objIndex)

                'SEGUNDO CONTINUAR
                objIndex.Document.FORMS(0).ELEMENTS("Submit32").CLICK()
                'SE DER ALGUM ERRO DE CONSISTENCIAS
                Espera_Ate_Que_Abra_Public(objIndex)

                'Verificando se eh pra inserir no autor:
                If cmbTipo.SelectedIndex = 0 Then
                    'PREENCHENDO DEPENDENCIA BANCO AUTOR
                    objIndex.Document.FORMS(0).ELEMENTS("cdCodigo").VALUE = vTb.Tables(0).Rows(vcontador)("codDependencia").ToString
                    objIndex.Document.FORMS(0).ELEMENTS("btoIncluir").CLICK()

                    'JA EXISTE ESSA DEPENDENCIA PARA O PROCESSO
                Espera_Ate_Que_Abra_Public(objIndex)

                    'SALVANDO
                    objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
                    Espera_Ate_Que_Abra_Public(objIndex)

                Else

                    'INDO PARA A TELA REU
                    objIndex.Document.FORMS(0).ELEMENTS("btoContinuar").CLICK()
                    Espera_Ate_Que_Abra_Public(objIndex)

                    'incluindo dependencia
                    objIndex.Document.forms(0).elements("cdEmpresaGrupoDep").value = 237
                    objIndex.Document.FORMS(0).ELEMENTS("cdCodigo").VALUE = vTb.Tables(0).Rows(vcontador)("codDependencia").ToString
                    objIndex.Document.FORMS(0).ELEMENTS("btoIncluir").CLICK()

                    'JA EXISTE ESSA DEPENDENCIA PARA O PROCESSO
                Espera_Ate_Que_Abra_Public(objIndex)

                    'SALVANDO
                    objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
                End If

                Thread.Sleep(1000)
            Catch ex As Exception
                preencheGrade("REPROCESSANDO ")
                GoTo Inicio
            End Try



proximo:
            Try
                vComando.CommandText = "UPDATE TB_ALTERAR SET Alterado = TRUE WHERE BRADESCO = " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString
                vComando.Connection = Conexao
                vComando.ExecuteNonQuery()
            Catch ex As Exception
                preencheGrade("Erro ao atualizar o GCPJ nro: " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString)
            End Try

            preencheGrade("GCPJ " & vTb.Tables(0).Rows(vcontador)("Bradesco").ToString & " Atualizado com sucesso!  -  Faltam: " & vTb.Tables(0).Rows.Count - vcontador)

fim:
            vcontador += 1
        Loop

        MsgBox("Processamento realizado com sucesso!", vbExclamation)

    End Sub


End Class