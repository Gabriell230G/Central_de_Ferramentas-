﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Public Class Frm_Cadastro_Envolvido
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function
    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function
    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1
    Private Sub MataMsgbox()
        Dim winHwnd As Long
        Do Until winHwnd <> 0
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
    End Sub
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb")
    Dim objIndex As SHDocVw.InternetExplorer
    Private Sub Espera_Ate_Que_Abra()
        ' Thread.Sleep(5000)
        Do While objIndex.ReadyState = 0 Or objIndex.ReadyState = 1 Or objIndex.ReadyState = 3
            'Espera até que abra
        Loop
        Do While objIndex.Busy = True
            'Espera até que abra
        Loop
    End Sub
    Private Sub Frm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificarGCPJ("GCPJ") = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificarGCPJ(ByVal nomeJanela As String) As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        For Each ie As SHDocVw.InternetExplorer In New SHDocVw.ShellWindows
            If InStr(ie.LocationName.ToString, nomeJanela) Then
                objIndex = ie
                Return True
            End If
        Next
        Return False
    End Function
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub Frm_Cadastro_Envolvido_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select top 3 * from CADASTRO_ENVOLVIDO where importado = false  ORDER BY envolvido "
        Else
            VsQl = "select * from CADASTRO_ENVOLVIDO where importado = false and maquina = " & CMBMaquina.ComboBox.Text & "  ORDER BY envolvido "
        End If


        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        If TB.Rows.Count = 0 Then
            MsgBox("Não encontrado nenhum envolvido para cadastro", vbCritical)
            Exit Sub
        End If


        Grade.Items.Add(Date.Now & "   Abrindo Tela de Cadastro")
        Grade.SelectedIndex = Grade.Items.Count - 1

        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=filtroIncluir&paginaCorrente=pessoaExternaBradescoFiltrar&cdPessoaExternaBradesco=&cdCpfPessoaExterna=&cdControleCpfPessoaExterna=&cdCnpjPessoaExterna=&cdFilialCnpjPessoaExterna=&cdControleCnpjPessoaExterna=&nmPessoaExternaProcesso=")

        Espera_Ate_Que_Abra()


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            'Alimentando Grade de Status
            Grade.Items.Add(Date.Now & " Inserindo Reclamante: " & index + 1 & " Faltam mais " & TB.Rows.Count - index)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo Pessoa Fisica com CPF
            If TB.Rows(index)("tipo").ToString = "PESSOA FÍSICA" Then

                For i = 0 To 99
                    If Trim(objIndex.Document.Forms(0).elements("combo")(i).innertext) = TB.Rows(index)("TIPO").ToString Then
                        objIndex.Document.Forms(0).elements("combo").Item(i).Selected = True
                        Exit For
                    End If
                Next
                Call objIndex.Document.parentWindow.execScript("tratarTipoPessoa();", "JavaScript")
                'inserindo nome
                objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("envolvido").ToString
                objIndex.Document.Forms(0).elements("cdCpfPessoaExterna").innertext = TB.Rows(index)("cpf").ToString
                objIndex.Document.Forms(0).elements("cdControleCpfPessoaExterna").innertext = TB.Rows(index)("digito").ToString
            End If

            'Inserindo Pessoa Juridica com CPF
            If TB.Rows(index)("tipo").ToString = "PESSOA JURÍDICA" Then
                objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(8).Selected = True
                'objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(6).Selected = True
                For i = 0 To 99
                    If Trim(objIndex.Document.Forms(0).elements("cdTipoPessoaExterna")(i).innertext) = TB.Rows(index)("TIPO").ToString Then
                        objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(i).Selected = True
                        Exit For
                    End If
                Next
                Call objIndex.Document.parentWindow.execScript("tratarTipoPessoa();", "JavaScript")
                'inserindo nome
                objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("envolvido").ToString
                objIndex.Document.Forms(0).elements("cdCnpjPessoaExterna").innertext = TB.Rows(index)("cpf").ToString
                objIndex.Document.Forms(0).elements("cdFilialCnpjPessoaExterna").innertext = TB.Rows(index)("filial").ToString
                objIndex.Document.Forms(0).elements("cdControleCnpjPessoaExterna").innertext = TB.Rows(index)("digito").ToString

            End If

            'Inserindo Pessoa Fisica Sem CPF
            If TB.Rows(index)("tipo").ToString = "PESSOA FISICA SEM CPF" Then
                For i = 0 To 99
                    If Trim(objIndex.Document.Forms(0).elements("cdTipoPessoaExterna")(i).innertext) = TB.Rows(index)("TIPO").ToString Then
                        objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(i).Selected = True
                        Exit For
                    End If
                Next
                'objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(5).Selected = True
                Call objIndex.Document.parentWindow.execScript("tratarTipoPessoa();", "JavaScript")
                objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("envolvido").ToString
            End If


            If TB.Rows(index)("tipo").ToString = "ADVOGADO PARTE CONTRÁRIA" Then

                objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(1).Selected = True
                'For i = 0 To 99
                'If Trim(objIndex.Document.Forms(0).elements("cdTipoPessoaExterna")(i).innertext) = TB.Rows(index)("TIPO").ToString Then
                '   objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(i).Selected = True
                ' Exit For
                'End If
                'Next
                Call objIndex.Document.parentWindow.execScript("tratarTipoPessoa();", "JavaScript")
                Espera_Ate_Que_Abra()
                objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("ADV_PARTE").ToString
                'MsgBox(TB.Rows(index)("OAB").ToString)
                objIndex.Document.Forms(0).elements("cdDocumentoPessoaExterna").innertext = TB.Rows(index)("OAB").ToString
                For i = 0 To 99
                    If Trim(objIndex.Document.Forms(0).elements("cdSiglaUFOab")(i).innertext) = TB.Rows(index)("UF").ToString Then
                        objIndex.Document.Forms(0).elements("cdSiglaUFOab").Item(i).Selected = True
                        Exit For
                    End If
                Next

            End If

            'Exit Sub

            'Clicando no botão Salvar
            objIndex.Document.Forms(0).elements("btoSalvar").Click() ' Salvar

            MataMsgbox()

            Espera_Ate_Que_Abra()

            If Len(objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                cmd.CommandText = "update CADASTRO_ENVOLVIDO set  importado = true, obs = 'Erro ao Cadastrar' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            Else
                cmd.CommandText = "update CADASTRO_ENVOLVIDO set  importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            End If

            Thread.Sleep(1000)

            'X = MsgBox("O Registro foi salvo com sucesso?" & vbCrLf & "GCPJ salvo por último: " & VarGCPJ, vbQuestion + vbYesNo)
            'If X <> vbYes Then Exit Sub



            'X = MsgBox("Deseja ir para o proximo?", vbQuestion + vbYesNo)
            'If X <> vbYes Then Exit Sub

        Next

        MsgBox("Fim")
    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from CADASTRO_ENVOLVIDO where  importado = false   ORDER BY envolvido"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If


        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE CADASTRO_ENVOLVIDO SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1
        Next



        MsgBox("Distribuição Efetuada")
    End Sub
End Class