﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Principal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Principal))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BTAbrirTela = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BTClickYes = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.Grade = New System.Windows.Forms.ListBox()
        Me.Barra_Rodape = New System.Windows.Forms.ToolStrip()
        Me.Status = New System.Windows.Forms.ToolStripProgressBar()
        Me.TXTStatus = New System.Windows.Forms.ToolStripLabel()
        Me.ImageStart = New System.Windows.Forms.PictureBox()
        Me.ToolStrip1.SuspendLayout()
        Me.Barra_Rodape.SuspendLayout()
        CType(Me.ImageStart, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Dock = System.Windows.Forms.DockStyle.Left
        Me.ToolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripSeparator2, Me.BTAbrirTela, Me.ToolStripSeparator4, Me.ToolStripSeparator1, Me.BTClickYes, Me.ToolStripSeparator3})
        Me.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip1.Size = New System.Drawing.Size(249, 444)
        Me.ToolStrip1.Stretch = True
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Margin = New System.Windows.Forms.Padding(0, 20, 0, 0)
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(246, 6)
        '
        'BTAbrirTela
        '
        Me.BTAbrirTela.Image = CType(resources.GetObject("BTAbrirTela.Image"), System.Drawing.Image)
        Me.BTAbrirTela.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTAbrirTela.Name = "BTAbrirTela"
        Me.BTAbrirTela.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.BTAbrirTela.Size = New System.Drawing.Size(246, 25)
        Me.BTAbrirTela.Text = "Selecione um Formulário na Grade Abaixo"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(246, 6)
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(246, 6)
        '
        'BTClickYes
        '
        Me.BTClickYes.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.BTClickYes.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BTClickYes.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.BTClickYes.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTClickYes.Name = "BTClickYes"
        Me.BTClickYes.Padding = New System.Windows.Forms.Padding(0, 5, 0, 0)
        Me.BTClickYes.Size = New System.Drawing.Size(246, 24)
        Me.BTClickYes.Text = "ClickYesWeb Agendar"
        Me.BTClickYes.ToolTipText = "ClickYesWeb"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(246, 6)
        '
        'Grade
        '
        Me.Grade.BackColor = System.Drawing.SystemColors.Control
        Me.Grade.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Grade.ForeColor = System.Drawing.Color.DodgerBlue
        Me.Grade.FormattingEnabled = True
        Me.Grade.ItemHeight = 14
        Me.Grade.Location = New System.Drawing.Point(12, 72)
        Me.Grade.Name = "Grade"
        Me.Grade.Size = New System.Drawing.Size(209, 312)
        Me.Grade.TabIndex = 3
        '
        'Barra_Rodape
        '
        Me.Barra_Rodape.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Barra_Rodape.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Status, Me.TXTStatus})
        Me.Barra_Rodape.Location = New System.Drawing.Point(0, 444)
        Me.Barra_Rodape.Name = "Barra_Rodape"
        Me.Barra_Rodape.Size = New System.Drawing.Size(591, 25)
        Me.Barra_Rodape.TabIndex = 5
        Me.Barra_Rodape.Text = "ToolStrip2"
        '
        'Status
        '
        Me.Status.Margin = New System.Windows.Forms.Padding(1, 3, 10, 1)
        Me.Status.Name = "Status"
        Me.Status.Size = New System.Drawing.Size(100, 21)
        Me.Status.Visible = False
        '
        'TXTStatus
        '
        Me.TXTStatus.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TXTStatus.ForeColor = System.Drawing.Color.DarkRed
        Me.TXTStatus.Name = "TXTStatus"
        Me.TXTStatus.Size = New System.Drawing.Size(62, 22)
        Me.TXTStatus.Text = "TxtStatus"
        Me.TXTStatus.Visible = False
        '
        'ImageStart
        '
        Me.ImageStart.Image = CType(resources.GetObject("ImageStart.Image"), System.Drawing.Image)
        Me.ImageStart.Location = New System.Drawing.Point(99, 335)
        Me.ImageStart.Name = "ImageStart"
        Me.ImageStart.Size = New System.Drawing.Size(68, 56)
        Me.ImageStart.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ImageStart.TabIndex = 7
        Me.ImageStart.TabStop = False
        Me.ImageStart.Visible = False
        '
        'Frm_Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(591, 469)
        Me.Controls.Add(Me.ImageStart)
        Me.Controls.Add(Me.Grade)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Controls.Add(Me.Barra_Rodape)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Name = "Frm_Principal"
        Me.Text = "Automações Web  -   Menu Principal"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.Barra_Rodape.ResumeLayout(False)
        Me.Barra_Rodape.PerformLayout()
        CType(Me.ImageStart, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BTAbrirTela As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Grade As System.Windows.Forms.ListBox
    Friend WithEvents Barra_Rodape As System.Windows.Forms.ToolStrip
    Friend WithEvents TXTStatus As System.Windows.Forms.ToolStripLabel
    Friend WithEvents Status As System.Windows.Forms.ToolStripProgressBar
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BTClickYes As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ImageStart As System.Windows.Forms.PictureBox

End Class
