﻿Imports System.Data.OleDb
Imports System.Threading

Public Class Frm_Impressao_Planilha
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Impressao_Planilha.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Impressao_Planilha_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        Grade.Items.Add("Conexão Efetuada!")
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function


    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String
        VsQl = "select * from processos where IMPORTADO = false   order by GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        Dim caminhoConsulta As String = ""
        Dim caminhoRelatorio As String = ""

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()


            Select Case TB.Rows(index)("AREA").ToString
                Case "TR"
                    caminhoConsulta = "http://www4.net.bradesco.com.br/gcpj/servlet/relatPlanilhaAction?metodo=carregarFiltro&index=301"
                    caminhoRelatorio = "http://www4.net.bradesco.com.br/gcpj/servlet/relatTrabContenciosoAction"
                Case "TA"
                    caminhoConsulta = "http://www4.net.bradesco.com.br/gcpj/servlet/relatPlanilhaAction?metodo=carregarFiltro&index=302"
                    caminhoRelatorio = "http://www4.net.bradesco.com.br/gcpj/servlet/RelatAdministrativoAction"
                Case "TO"
                    caminhoConsulta = "http://www4.net.bradesco.com.br/gcpj/servlet/relatPlanilhaAction?metodo=carregarFiltro&index=303"
                    caminhoRelatorio = "http://www4.net.bradesco.com.br/gcpj/servlet/relatTrabOutrasAcoesAcAction"
                Case "CI"
                    caminhoConsulta = "http://www4.net.bradesco.com.br/gcpj/servlet/relatPlanilhaAction?metodo=carregarFiltro&index=304"
                    caminhoRelatorio = "http://www4.net.bradesco.com.br/gcpj/servlet/relatCivelAction"
                Case "PE"
                    caminhoConsulta = "http://www4.net.bradesco.com.br/gcpj/servlet/relatPlanilhaAction?metodo=carregarFiltro&index=305"
                    caminhoRelatorio = "http://www4.net.bradesco.com.br/gcpj/servlet/relatProcsPenalAction"


            End Select

            objIndex.Navigate(caminhoConsulta)
            Espera_Ate_Que_Abra_Public(objIndex)



            objIndex.Document.Forms(0).elements("relatorioOnLineVO.processoVO.cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoListar").Click()


            Espera_Ate_Que_Abra_Public(objIndex)
            If IdentificarPlanilha(TB.Rows(index)("GCPJ").ToString, caminhoRelatorio, TB.Rows(index)("area").ToString) = False Then
                MsgBox("relatório não encontrado")
            Else
                Dim Cmd As New OleDbCommand("update processos set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString, Conexao)
                Cmd.ExecuteNonQuery()
            End If



        Next

    End Sub

    Public Function IdentificarPlanilha(VarGCPJ As Double, VarCaminhoRelatorio As String, VarArea As String) As Boolean
        'Conectando a variável à janela popup
        IdentificarPlanilha = False

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell

inicio_verificacao:
        For Each objIndex2 In objShell2.Windows
            If objIndex2.LocationURL = VarCaminhoRelatorio Then
                objIndex2.Visible = True
                IdentificarPlanilha = True
                Exit For
            End If
            'MsgBox(objIndex2.LocationURL)
        Next objIndex2

        If IdentificarPlanilha = False Then
            GoTo inicio_verificacao
        End If

        Espera_Ate_Que_Abra_Public(objIndex2)

        AppActivate(VarCaminhoRelatorio)

        Try
            'acionando Ctrl + P
            Thread.Sleep(7000)
            SendKeys.SendWait("^p")

            'acionando Enter para imprimir
            Thread.Sleep(3000)
            SendKeys.SendWait("{Enter}")

            'na tela do PDF, aciona 8 tabs para chegar no campo caminho
            Thread.Sleep(10000)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)

            'inserindo caminho
            SendKeys.SendWait("C:\Planilhas_PDF\" & VarArea & " - " & VarGCPJ & ".pdf")

            'aicionando mais 3 tab para chegar na tecla Create
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)
            SendKeys.SendWait("{Tab}")
            Thread.Sleep(300)

            '
            SendKeys.SendWait("{Enter}")
            Thread.Sleep(2000)


            objIndex2.Quit()

        Catch ex As Exception
            objIndex2.Quit()
            Return False

        End Try

    End Function

End Class