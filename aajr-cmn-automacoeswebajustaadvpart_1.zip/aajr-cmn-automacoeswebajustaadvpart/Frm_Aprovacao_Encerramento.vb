﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Aprovacao_Encerramento



    Dim VarFundamento As String
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Dados_Aprovacao_Encerramento.mdb")
    Dim objIndex As SHDocVw.InternetExplorer
    Private Sub Frm_Aprovacao_Encerramento_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução

        'Abrindo Tabela
        Dim VsQl As String
        VsQl = "select   * from TB_Aprovacao_Encerramento where Atualizado = false   order by Bradesco"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
forIn:
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("Bradesco").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()


            'Abrindo Tela de Pesquisa
            Try
                objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/menuTramitePendencias?metodo=carregar&origem=tramite") 'produção
            Catch ex As Exception
                MsgBox("Erro na Abertura da tela de pesquisa. " & vbCrLf & ex.Message, vbInformation)
                Exit Sub
            End Try
            Espera_Ate_Que_Abra_Public(objIndex)

            'Try
            AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")
            Call objIndex.Document.parentWindow.execScript("enviarPendencia(103);", "JavaScript")
            Espera_Ate_Que_Abra_Public(objIndex)
            'Thread.Sleep(1000)

            objIndex.Document.Forms(0).elements("cdTpoPagamento").Item(2).Click()
            objIndex.Document.Forms(0).elements("btoDetalhar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'inserindo numero do processo e clicando em pesquisar
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("Bradesco").ToString 'inserindo bradesco
            Call objIndex.Document.parentWindow.execScript("document.forms[0].metodo.value='pesquisarPorProcesso';", "JavaScript")
            objIndex.Document.Forms(0).submit()
            Espera_Ate_Que_Abra_Public(objIndex)

            Try
                'selecionando o primeiro da lista e clicando em detalhar
                objIndex.Document.Forms(0).elements("selecionados").Checked = True
                objIndex.Document.Forms(0).elements("btoDetalhar").Click()
                Espera_Ate_Que_Abra_Public(objIndex)
            Catch ex As Exception
                cmd.CommandText = "update TB_Aprovacao_Encerramento set ATUALIZADO = true, Obs = 'Processo não Disponível para Encerramento' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()

                'Caso o  Sistema não encontre o processo para o encerramento
                Thread.Sleep(1000)
                index = index + 1
                GoTo forIn 'Volta para o Início
            End Try



            'Clicando em Salver na tela "Valores de Encerramento"
            objIndex.Document.Forms(0).elements("btoSalvar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Identificar e fechar PopUp
            Identificar_e_FecharPopUp()

            'Clicando em Salver na tela "Recolhimento de IR"
            objIndex.Document.Forms(0).elements("btoSalvar").Click()

            'fecha possíveis mensagens
            'Thread.Sleep(8000)
            'AppActivate("(GCPJ) Tramite - Encerramento - Windows Internet Explorer")
            'SendKeys.Send("{Enter}")

            Espera_Ate_Que_Abra_Public(objIndex)

            Thread.Sleep(3000)

            'Clica em BTContinuar na tela de: Composição do Encerramento
            objIndex.Document.Forms(0).elements("btoContinuar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'Clica em aprovar
            objIndex.Document.Forms(0).elements("btoAprovar").Click()
            'AppActivate "(GCPJ) Tramite - Encerramento - Windows Internet Explorer", True

            'fecha possíveis mensagens
            'Thread.Sleep(8000)
            'SendKeys.Send("{Enter}")

            Espera_Ate_Que_Abra_Public(objIndex)

            'Verificando se a proxima tela é a tela de pesquisa..  
            'Pois se for a Tela de pesquisa está tudo certo...
            Try
                objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = 0
            Catch ex As Exception
                cmd.CommandText = "update TB_Aprovacao_Encerramento set ATUALIZADO = true, Obs = 'Erro ao Efetuar Encerramento' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                'Caso o  Sistema não encontre o processo para o encerramento
                Thread.Sleep(1000)
                index = index + 1
                GoTo forIn 'Volta para o Início
            End Try

            cmd.CommandText = "update TB_Aprovacao_Encerramento set ATUALIZADO = true, Obs = 'Aprovação de Encerramento Efetuada' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

        Next

    End Sub


    Private Sub Identificar_e_FecharPopUp()
        'Conectando a variável à janela popup
        Thread.Sleep(3000)

        Dim objIndex2 As SHDocVw.InternetExplorer
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell


        For Each objIndex2 In objShell2.Windows
            'If TypeName(objIndex2.Document) = "HTMLDocumentClas" Then
            If objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/traEncerrRecolIR?metodo=carregPopup" Then
                If InStr(1, objIndex2.Document.Title, "GCPJ - Gestão e Controle de Processos Jurídicos") > 0 Then
                    objIndex2.Visible = True
                    objIndex2.Quit()
                    Exit For
                End If
            End If
        Next objIndex2



    End Sub

End Class