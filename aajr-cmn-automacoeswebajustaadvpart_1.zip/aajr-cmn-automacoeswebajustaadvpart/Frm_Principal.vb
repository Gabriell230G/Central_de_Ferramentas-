﻿Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Principal
    Dim DTInicio As Date

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function

    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1

    Private Sub Frm_Principal_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        End
    End Sub



    Private Sub Frm_Principal_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Dir(Application.StartupPath & "\BD_Alteracao_Classificacao.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Alteracao_Classificacao", 5, 50))
        If Dir(Application.StartupPath & "\BD_Alterar_Evento.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Atualizacao_Evento_Realizado", 5, 50))
        If Dir(Application.StartupPath & "\BD_Dados_Aprovacao_Encerramento.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Aprovacao_Encerramento", 5, 50))
        If Dir(Application.StartupPath & "\BD_Aprovar_Migracao.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Aprovar_Migracao", 5, 50))
        If Dir(Application.StartupPath & "\BD_Atualizacao_Valor_Calculo.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Atualizar_Valor_Calculo", 5, 50))
        If Dir(Application.StartupPath & "\BD_Cadastro_Honorarios.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Cadastro_Honorarios", 5, 50))
        If Dir(Application.StartupPath & "\BD_Dados_Fundamento.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Captura_Fundamento", 5, 50))
        If Dir(Application.StartupPath & "\BD_Distribuicao.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Distribuicao", 5, 50))
        If Dir(Application.StartupPath & "\BD_Inserir_Evento.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Inclusao_Evento", 5, 50))
        If Dir(Application.StartupPath & "\BD_Inserir_Deposito.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Inserir_Deposito", 5, 50))
        If Dir(Application.StartupPath & "\BD_Tramite_Pendencias.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Inserir_Evento_Pendencia", 5, 50))
        If Dir(Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Cadastro_Processos_CI", 5, 50))
        If Dir(Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Alterar_Procs_CI", 5, 50))
        If Dir(Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Cadastro_Envolvido", 5, 50))
        If Dir(Application.StartupPath & "\BD_Redistribuicao.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Redistribuicao", 5, 50))
        If Dir(Application.StartupPath & "\BD_Altera_Ag_Conta.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Altera_Ag_Conta", 5, 50))
        If Dir(Application.StartupPath & "\BD_Cadastro_Consultoria_Negocios.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Cadastro_Consultoria_Negocios", 5, 50))
        If Dir(Application.StartupPath & "\BD_Impressao_Planilha.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Impressao_Planilha", 5, 50))
        If Dir(Application.StartupPath & "\BD_Migracao.mdb") <> "" Then Grade.Items.Add(Mid("Frm_Migracao", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))
        If Dir(Application.StartupPath & "\.mdb") <> "" Then Grade.Items.Add(Mid("", 5, 50))

        If Grade.Items.Count = 1 Then
            Grade.SelectedIndex = 0
            Grade_DoubleClick(sender, e)
        End If

        'Dim t1 = New Thread(AddressOf Me.AbrirClickYes)
        't1.Start()

        ImageStart.Top = Barra_Rodape.Top - 120
        BTClickYes.PerformClick()
    End Sub

    Private Sub MataMsgBox()
        If BTClickYes.Text = "ClickYesWeb Agendar" Then
            FecharThread = True
        End If

        DTInicio = Date.Now
        Dim winHwnd As Long

        Do Until winHwnd <> 0
            Thread.Sleep(1000)

            System.Windows.Forms.Application.DoEvents()
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")

            'se o procedimento ficar ocioso por 5 minutos então  é pausado
            'If DateDiff(DateInterval.Minute, DTInicio, Date.Now) >= 5 Then
            '    FecharThread = True
            'End If
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)

        MataMsgBox()

    End Sub

    Private Sub BTClickYes_Click(sender As System.Object, e As System.EventArgs) Handles BTClickYes.Click
        If BTClickYes.Text = "ClickYesWeb Agendar" Then
            BTClickYes.ForeColor = Color.DarkRed
            ImageStart.Visible = True
            BTClickYes.Text = "ClickYesWeb Parar"
            FecharThread = False
            Dim t1 = New Thread(AddressOf Me.MataMsgBox)
            t1.Start()
            Do While FecharThread = False
                System.Windows.Forms.Application.DoEvents()
            Loop
            t1.Abort()

            BTClickYes.Text = "ClickYesWeb Agendar"
            BTClickYes.ForeColor = Color.LimeGreen
            ImageStart.Visible = False

        Else
            FecharThread = True
        End If
    End Sub


    Private Sub Grade_DoubleClick(sender As Object, e As System.EventArgs) Handles Grade.DoubleClick




        Dim frms As Object
        Dim p As System.Reflection.PropertyInfo
        frms = My.Forms
        For Each p In frms.GetType.GetProperties
            If p.DeclaringType.Name.ToUpper = "MYFORMS" Then
                Dim obj As New Object
                obj = p.GetValue(frms, Nothing)
                If CType(obj, Form).Name = "Frm_" & Grade.Text Then
                    'CType(obj, Form).FormBorderStyle = Windows.Forms.FormBorderStyle.None
                    CType(obj, Form).MdiParent = Me
                    CType(obj, Form).Show()
                    CType(obj, Form).Top = 0
                    CType(obj, Form).Left = 0
                    'f.Width = Barra_Titulo.Width - 5
                    CType(obj, Form).Height = Barra_Rodape.Top - 5
                End If
            End If
        Next
    End Sub

    Private Sub BTAbrirTela_Click(sender As System.Object, e As System.EventArgs) Handles BTAbrirTela.Click
        Grade_DoubleClick(sender, e)
    End Sub




End Class
