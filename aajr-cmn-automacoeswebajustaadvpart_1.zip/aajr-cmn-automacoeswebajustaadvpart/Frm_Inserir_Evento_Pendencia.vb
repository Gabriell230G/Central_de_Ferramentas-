﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Public Class Frm_Inserir_Evento_Pendencia
    Dim VarSair As Boolean = False

    
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Tramite_Pendencias.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        'BTConectaGCPJ.Enabled = False
        BTProcessarInclusao.Enabled = True
        BTProcessarValidacao.Enabled = True
        BTProcessaTudo.Enabled = True

        Grade.Items.Add("Conexão Efetuada!")
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessarInclusao_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessarInclusao.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução

        If FecharThread = True Then
            MsgBox("Iniciar Procedimento ClickYes!", vbInformation)
            Exit Sub
        End If


        If Tela.TextLength > 0 And Linha.TextLength = 0 Then
            MsgBox("Atenção. Como a tela está preenchida, favor informar a linha.", vbCritical)
            Exit Sub
        End If

INICIO:

        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraPendAdvogInclEvntoAction?acao=gridVoltar&mensagem=&paginaChamadora=&paginaCorrente=filtro&tableGridPagina=")
        Espera_Ate_Que_Abra_Public(objIndex)


        'Entrando na tela de Pendencias
        Call objIndex.Document.parentWindow.execScript("enviarPendencia(2)", "JavaScript")

        Espera_Ate_Que_Abra_Public(objIndex)


        'Selecionando o GCPJ
        'Dim elemCollection As Object
        'Dim VarContagem As Double = 0
        'Dim Encontrou As Boolean = False
        Dim Bradesco As Double
        Dim varNomFunc As String = ""
        Dim elemCollection As Object
        Dim Pagina_Pesquisa As Integer = 1

        'elemCollection = objIndex.Document.Forms(0).getElementsByTagName("TD")
        'For Each obj In elemCollection
        'If Trim(1300128835) = Trim(obj.innertext) Then
        'objIndex.Document.Forms(0).elements("selecionados")(VarContagem).Checked = True
        'Encontrou = True
        'Exit For
        'Else
        'Encontrou = False
        'End If
        'If IsNumeric(obj.innertext) Then VarContagem = VarContagem + 1
        'Next



        VarSair = False
        Do Until VarSair = True

            'Verificando horario após as 22 e aguardando um período de 4 horas
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                Grade.Items.Add("Horário após as 22:00")
                Grade.SelectedIndex = Grade.Items.Count - 1
                Dim Vdata As Date = Date.Now
EsperandoRestart:
                If DateDiff(DateInterval.Hour, Vdata, Date.Now) < 4 Then
                    Grade.Items.Add(Date.Now & "  Aguardando intervalo de 4 horas..")
                    Grade.SelectedIndex = Grade.Items.Count - 1
                    Thread.Sleep(600000)
                    GoTo EsperandoRestart
                Else
                    GoTo INICIO
                End If
            End If



            'selecionando o primeiro da lista
            Try
                objIndex.Document.Forms(0).elements("selecionados").Checked = True
            Catch ex As Exception
                Try
                    objIndex.Document.Forms(0).elements("selecionados")(0).Checked = True
                Catch ex2 As Exception
                    'Grade.Items.Add("Não existem mais pendencias para Inclusão de Eventos.")
                    'Grade.SelectedIndex = Grade.Items.Count - 1
                    Exit Do
                End Try
            End Try

            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit Do
            qtdOperacoesS5 += 1

            'selecionando tela específica
            Try

                If IsNumeric(Tela.Text) Then
                    Dim VtelaAtual As Integer = 1
                    Dim Vtela As Integer = Tela.Text
                    For index = 2 To Vtela
                        Call objIndex.Document.parentWindow.execScript("paginacao('7');", "JavaScript")
                        Espera_Ate_Que_Abra_Public(objIndex)
                        Thread.Sleep(500)
                    Next
                End If

            Catch ex As Exception
                MsgBox(ex.Message)
            End Try

            'selecionando linha específica
            Try
                If Linha.TextLength > 0 Then
                    If IsNumeric(Linha.Text) Then
                        Dim Vlinha As Integer = Linha.Text
                        objIndex.Document.Forms(0).elements("selecionados")(Vlinha).Checked = True
                    End If
                End If
            Catch ex As Exception
                Exit Do
            End Try

            'Clicando em detalhar
            objIndex.Document.Forms(0).elements("btoExecutar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)



            'Capturando o nome do Funcionario
            If varNomFunc = "" Then
                varNomFunc = objIndex.Document.forms(0).elements("nmAdvogado").value
            End If
            If varNomFunc = "" Then
                MsgBox("Não foi possível capturar o nome do funcionário.", vbCritical)
                Exit Sub
            End If

            Grade.Items.Add(Date.Now & "   Inserindo Evento: " & Grade.Items.Count + 1 & "   -  " & objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").value & "  -  " & varNomFunc)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()



            'inserindo Campos
            objIndex.Document.Forms(0).elements("cdFaseProcessoEvento")(1).SELECTED = True
            objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext = 70
            objIndex.Document.Forms(0).elements("btoPopupCdTipo").onClick()
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("dtEventoJudicialProcesso").innertext = FormatDateTime(Date.Now.AddYears(1), DateFormat.ShortDate)

            objIndex.Document.Forms(0).elements("selecHora")(9).SELECTED = True
            objIndex.Document.Forms(0).elements("selecHora").onChange()
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("selecMinuto")(1).SELECTED = True
            objIndex.Document.Forms(0).elements("selecMinuto").onChange()

            Bradesco = objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").value

            System.Windows.Forms.Application.DoEvents()
            If VarSair = True Then Exit Do
Salvando:
            objIndex.Document.Forms(0).elements("btoSalvar").onClick()
            Espera_Ate_Que_Abra_Public(objIndex)

            'verificando se a tela limpou
            Try
                If Len(objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").Value) > 0 Then
                    objIndex.Document.Forms(0).elements("btoLimpar").onClick()
                    Espera_Ate_Que_Abra_Public(objIndex)
                    GoTo Salvando
                End If
            Catch ex As Exception

            End Try



            System.Windows.Forms.Application.DoEvents()
            If VarSair = True Then Exit Do


            Dim Cmd As New OleDbCommand("insert into Log_Geral (GCPJ,DT_PROCESSAMENTO,HR_PROCESSAMENTO,USUARIO,OPERACAO,MAQUINA) values (" & _
            Bradesco & _
            "," & SQL_Data(Date.Now) & _
            "," & SQL_Hora(Date.Now) & _
            "," & SQL_Texto(Mid(varNomFunc, 1, 49)) & _
            ",'INCLUSÃO'" & _
            "," & SQL_Texto(Environment.MachineName) & ")", Conexao)

            Cmd.ExecuteNonQuery()

        Loop

        Grade.Items.Add(Date.Now & "  -  INCLUSÃO FINALIZADA!")
        Grade.SelectedIndex = Grade.Items.Count - 1


    End Sub

    Private Sub BTParar_Click(sender As System.Object, e As System.EventArgs) Handles BTParar.Click
        For Each p In Process.GetProcesses
            If LCase(p.ProcessName) = "iexplore" Then
                p.Kill()
            End If
        Next
        Grade.DataSource = Nothing
        Grade.Items.Clear()
        Thread.Sleep(2000)
        BTConectaGCPJ.PerformClick()
    End Sub

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs)

    End Sub

    Private Sub BTProcessarValidacao_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessarValidacao.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        If FecharThread = True Then
            MsgBox("Iniciar Procedimento ClickYes!", vbInformation)
            Exit Sub
        End If

        If Tela.TextLength > 0 And Linha.TextLength = 0 Then
            MsgBox("Atenção. Como a tela está preenchida, favor informar a linha.", vbCritical)
            Exit Sub
        End If

        Dim ContadorErro As Integer = 0
INICIO:

        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraPendAdvogInclEvntoAction?acao=gridVoltar&mensagem=&paginaChamadora=&paginaCorrente=filtro&tableGridPagina=")
        Espera_Ate_Que_Abra_Public(objIndex)



        'Entrando na tela de Pendencias
        Call objIndex.Document.parentWindow.execScript("enviarPendencia(3)", "JavaScript")

        Espera_Ate_Que_Abra_Public(objIndex)


        Dim BradescoAntigo As Double = 0
        Dim Bradesco As Double
        Dim VarNomFunc As String = ""

        VarSair = False
        Do Until VarSair = True
            'Verificando horario após as 22 e aguardando um período de 4 horas
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                Grade.Items.Add("Horário após as 22:00")
                Grade.SelectedIndex = Grade.Items.Count - 1
                Dim Vdata As Date = Date.Now
EsperandoRestart:
                If DateDiff(DateInterval.Hour, Vdata, Date.Now) < 4 Then
                    Grade.Items.Add(Date.Now & "  Aguardando intervalo de 4 horas..")
                    Grade.SelectedIndex = Grade.Items.Count - 1
                    Thread.Sleep(600000)
                    GoTo EsperandoRestart
                Else
                    GoTo INICIO
                End If
            End If

            'selecionando o primeiro da lista
            Try
                objIndex.Document.Forms(0).elements("selecionados").Checked = True
            Catch ex As Exception
                Try
                    objIndex.Document.Forms(0).elements("selecionados")(0).Checked = True
                Catch ex2 As Exception
                    If ContadorErro < 2 Then
                        ContadorErro += 1
                        GoTo inicio
                    Else
                        'Grade.Items.Add("Não existem mais pendencias para Validação de Eventos.")
                        'Grade.SelectedIndex = Grade.Items.Count - 1
                        Exit Do
                    End If
                End Try
            End Try
            ContadorErro = 0

            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit Do
            qtdOperacoesS5 += 1

            'selecionando tela específica
            Try

                If IsNumeric(Tela.Text) Then
                    Dim VtelaAtual As Integer = 1
                    Dim Vtela As Integer = Tela.Text
                    For index = 2 To Vtela
                        Call objIndex.Document.parentWindow.execScript("paginacao('7');", "JavaScript")
                        Espera_Ate_Que_Abra_Public(objIndex)
                        Thread.Sleep(500)
                    Next
                End If

            Catch ex As Exception
                Exit Do
            End Try

            'selecionando linha específica
            Try
                If Linha.TextLength > 0 Then
                    If IsNumeric(Linha.Text) Then
                        Dim Vlinha As Integer = Linha.Text
                        objIndex.Document.Forms(0).elements("selecionados")(Vlinha).Checked = True
                    End If
                End If
            Catch ex As Exception
                Exit Do
            End Try




            'Clicando em detalhar

            objIndex.Document.Forms(0).elements("btoExecutar").Click()

            Espera_Ate_Que_Abra_Public(objIndex)

            'Abrindo Tabela de eventos para Identificar os dados
            'Dim VsQl As String
            'VsQl = "select * from TB_Ultimo_Evento_Futuro where bradesco = " & objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").value
            'Dim DA As New OleDbDataAdapter(VsQl, Conexao)
            'Dim TB As New DataTable()
            'TB.Locale = System.Globalization.CultureInfo.InvariantCulture
            'DA.Fill(TB)
            'If TB.Rows.Count = 0 Then
            'MsgBox("Evento não encontrado na tabela de Eventos.", vbInformation)
            'Exit Sub
            'End If


            'Capturando o nome do Funcionario
            If VarNomFunc = "" Then
                VarNomFunc = objIndex.Document.forms(0).elements("nmAdvogado").value
            End If
            If VarNomFunc = "" Then
                MsgBox("Não foi possível capturar o nome do funcionário.", vbCritical)
                Exit Sub
            End If

            'Alimentando Grade
            Grade.Items.Add(Date.Now & "   Validando Evento: " & Grade.Items.Count + 1 & "   -   " & objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").value & "  -  " & VarNomFunc)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'inserindo Campos
            Select Case objIndex.Document.forms(0).elements("cdNumeroInstanciaProcesso").value
                Case 1 'Conhecimento
                    objIndex.Document.Forms(0).elements("cdFaseProcessoEvento")(1).SELECTED = True
                Case 2 'Execução
                    objIndex.Document.Forms(0).elements("cdFaseProcessoEvento")(2).SELECTED = True
            End Select

            'Codigo para Tratar erro no GCPJ
            'pos o GCPJ apresentou evento 70 na fase de execução..   e o mesmo não existe.
            If objIndex.Document.forms(0).elements("cdTipoEventoAnterior").value = 70 Then
                objIndex.Document.Forms(0).elements("cdFaseProcessoEvento")(1).SELECTED = True
            End If


            Select Case objIndex.Document.forms(0).elements("cdTipoEventoAnterior").value
                Case 250
                    objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext = 530
                Case 63, 0
                    objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext = 70
                Case 112, 120 'muda a fase para execução pois este evento nao existe na fase conhecimento (Falha do GCPJ)
                    'Grade.Items.Add("achou 112")
                    objIndex.Document.Forms(0).elements("cdFaseProcessoEvento")(2).SELECTED = True
                    objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext = objIndex.Document.forms(0).elements("cdTipoEventoAnterior").value
                Case Else

                    objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext = objIndex.Document.forms(0).elements("cdTipoEventoAnterior").value
            End Select

            objIndex.Document.Forms(0).elements("btoPopupCodigo").onClick()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verificando se a data é anterior a data de hoje
            If FormatDateTime(objIndex.Document.forms(0).elements("dtEventoJudicialAnterior").value, DateFormat.ShortDate) <= Date.Now Then
                objIndex.Document.Forms(0).elements("dtEventoJudicialProcesso").innertext = FormatDateTime(Date.Now.AddYears(1), DateFormat.ShortDate)
            Else
                objIndex.Document.Forms(0).elements("dtEventoJudicialProcesso").innertext = FormatDateTime(objIndex.Document.forms(0).elements("dtEventoJudicialAnterior").value, DateFormat.ShortDate)
            End If


            '### Inserindo Hora
            For index = 0 To 24
                Try
                    objIndex.Document.forms(0).elements("Hora")(index).selected = True
                    objIndex.Document.Forms(0).elements("Hora").onChange()
                    If Trim(objIndex.Document.forms(0).elements("Hora").value) = Mid(objIndex.Document.forms(0).elements("hrEventoJudicialAnterior").value, 1, 2) Then
                        index = 24
                        Exit For
                    End If
                Catch ex As Exception
                    MsgBox("Hora não Encontrada", vbCritical)
                    Exit Sub
                End Try
            Next
            '### Fim inserindo hora
            Espera_Ate_Que_Abra_Public(objIndex)
            '### Inserindo Minuto
            For index = 0 To 60
                Try
                    objIndex.Document.forms(0).elements("minuto")(index).selected = True
                    objIndex.Document.Forms(0).elements("minuto").onChange()
                    If Trim(objIndex.Document.forms(0).elements("minuto").value) = Mid(objIndex.Document.forms(0).elements("hrEventoJudicialAnterior").value, 4, 2) Then
                        index = 24
                        Exit For
                    End If
                Catch ex As Exception
                    MsgBox("Minuto não Encontrado", vbCritical)
                    Exit Sub
                End Try
            Next

            Bradesco = objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").value

            'verificando se a data é maior que 2050
            Dim vDataLimite As Date = "01/01/2030"
            If FormatDateTime(objIndex.Document.forms(0).elements("dtEventoJudicialAnterior").value, DateFormat.ShortDate) > vDataLimite Then
                objIndex.Document.Forms(0).elements("dtEventoJudicialProcesso").innertext = FormatDateTime(Date.Now.AddYears(1), DateFormat.ShortDate)
                Grade.Items.Add("Alterando data " & FormatDateTime(objIndex.Document.forms(0).elements("dtEventoJudicialAnterior").value, DateFormat.ShortDate))
                Grade.SelectedIndex = Grade.Items.Count - 1
            End If


            System.Windows.Forms.Application.DoEvents()
            If VarSair = True Then Exit Do

            Dim vString As String
            Thread.Sleep(1000)

            vString = "document.forms[0].cdIndicativoAtulzEventoAnterior.value = '1'; " & vbCrLf
            vString = vString & "document.forms[0].dsTipoEventoAnterior.value = document.forms[0].dsTipoEventoJudicial.value; " & vbCrLf
            vString = vString & "document.forms[0].dtEventoJudicialAnterior.value = document.forms[0].dtEventoJudicialProcesso.value; " & vbCrLf
            vString = vString & "document.forms[0].hrEventoJudicialAnterior.value = document.forms[0].hrEventoJudicialProcesso.value;"

            Call objIndex.Document.parentWindow.execScript(vString, "JavaScript")
            Call objIndex.Document.parentWindow.execScript("enviar( 'execucaoSalvar', true );", "JavaScript")

            'objIndex.Document.Forms(0).elements("btoSalvar").onClick()
            'objIndex.Document.Forms(0).elements("btoVoltar").onClick()
            'MataPossivelMsgbox()

            'Thread.Sleep(1000)

            Espera_Ate_Que_Abra_Public(objIndex)


            'Verificando se ainda continua na mesma tela
            Try
                Dim varint As Integer = Len(objIndex.Document.Forms(0).elements("cdIdentificacaoTipoEvento").innertext)
                'Grade.Items.Add("A tela não Limpou")
                'Grade.SelectedIndex = Grade.Items.Count - 1
                'System.Windows.Forms.Application.DoEvents()
                'GoTo inicio
                MsgBox("A tela não Limpou", vbCritical)
                Exit Sub
            Catch ex As Exception
            End Try


            'Verificando se o GCPJ está sendo processado novamente
            If Bradesco = BradescoAntigo Then
                MsgBox("Atenção.. O mesmo processo está sendo processado novamente!", vbCritical)
                Exit Sub
            End If

            Dim Cmd As New OleDbCommand("insert into Log_Geral (GCPJ,DT_PROCESSAMENTO,HR_PROCESSAMENTO,USUARIO,OPERACAO,MAQUINA) values (" & _
            Bradesco & _
            "," & SQL_Data(Date.Now) & _
            "," & SQL_Hora(Date.Now) & _
            "," & SQL_Texto(Mid(VarNomFunc, 1, 49)) & _
            ",'VALIDAÇÃO'" & _
            "," & SQL_Texto(Environment.MachineName) & ")", Conexao)

            Cmd.ExecuteNonQuery()

            BradescoAntigo = Bradesco

            System.Windows.Forms.Application.DoEvents()
            If VarSair = True Then Exit Do
        Loop

        Grade.Items.Add(Date.Now & "  -  VALIDAÇÃO FINALIZADO")
        Grade.SelectedIndex = Grade.Items.Count - 1


    End Sub

    Private Sub BTAcompanhamento_Click(sender As System.Object, e As System.EventArgs) Handles BTAcompanhamento.Click
        Grade.DataSource = Nothing
        Grade.Items.Clear()
        Grade.Items.Add("Carregando Aguarde!!!")
        System.Windows.Forms.Application.DoEvents()


        Dim TB As New DataTable()
        Dim Vsql As String
        Vsql = "SELECT Max(Log_Geral.HR_PROCESSAMENTO) & '  -  Total: ' & format( Count(Log_Geral.GCPJ),'0000') &  '  -  ' & Log_Geral.MAQUINA & '  -  ' &  Log_Geral.OPERACAO    & '  -  ' &  Log_Geral.USUARIO as acompanhamento " & _
        " FROM(Log_Geral)" & _
" WHERE (((Log_Geral.DT_PROCESSAMENTO)=Date()))" & _
" GROUP BY Log_Geral.USUARIO, Log_Geral.OPERACAO, Log_Geral.MAQUINA" & _
" ORDER BY Max(Log_Geral.HR_PROCESSAMENTO) DESC"

        Dim DA As New OleDbDataAdapter(Vsql, Conexao)
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Grade.DataSource = TB
        Grade.DisplayMember = "acompanhamento" ' - Campo que será exibido ao user
        'Grade.ValueMember = "Código" ' - Valor do Index de cada Nome.
        Grade.SelectedIndex = -1



    End Sub

    Private Sub BTProcessaTudo_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessaTudo.Click
        If FecharThread = True Then
            MsgBox("Iniciar Procedimento ClickYes!", vbInformation)
            Exit Sub
        End If
        BTProcessarInclusao.PerformClick()
        BTProcessarValidacao.PerformClick()
    End Sub
End Class