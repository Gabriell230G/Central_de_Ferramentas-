﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Atualizar_Valor_Calculo


    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Atualizacao_Valor_Calculo.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Atualizar_Valor_Calculo_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click

        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        'Rotina_Alteracao()
        Rotina_Cadastro()
    End Sub

    Private Sub Rotina_Alteracao()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String = ""

        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            '            VsQl = "select * from TB_Atualizacao_Calculo where IMPORTADO = false order by gcpj"
            'VsQl = "select * from TB_Atualizacao_Calculo where gcpj = 1300018142 and IMPORTADO = false order by gcpj"
        Else
            VsQl = "select * from TB_Atualizacao_Calculo where VLR_RISCO > 0 and IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj"
        End If

        Dim Encontrou As Boolean = False
        Dim elemCollection As Object = Nothing
        Dim Contagem As Double = 0


        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            System.Windows.Forms.Application.DoEvents()

            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraCpmisAtulzValorCalcAction?acao=carregar")

            Espera_Ate_Que_Abra_Public(objIndex)


            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'procura (22 - VALOR DO RISCO - CI)
            If TB.Rows(index)("vlr_risco").ToString <> 0 Then
                Encontrou = False
                Contagem = 0
                elemCollection = objIndex.Document.Forms(0).getElementsByTagName("TR")
                For Each obj In elemCollection
                    If InStr(obj.innertext, "22 - VALOR DO RISCO - CI") > 0 And Contagem > 13 Then
                        objIndex.Document.Forms(0).elements("selecionados")(Contagem - 16).Checked = True
                        Encontrou = True
                        Exit For
                    Else
                        Contagem += 1
                        Encontrou = False
                    End If
                Next

                If Encontrou = False Then 'caso não encontrou então cadastra o valor de Risco
                    objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 22
                    Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
                    Espera_Ate_Que_Abra_Public(objIndex)

                    objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = "17/04/2013"
                    objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_RISCO").ToString, 2)
                    objIndex.Document.Forms(0).elements("btoCalcular").Click()
                    Espera_Ate_Que_Abra_Public(objIndex)

                Else 'Penas altes os dados
                    'Clica em Alterar
                    objIndex.Document.Forms(0).elements("btoAlterar").Click()
                    Espera_Ate_Que_Abra_Public(objIndex)
                    objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = "17/04/2013"
                    objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_RISCO").ToString, 2)
                    objIndex.Document.Forms(0).elements("btoCalcular").Click()
                    Espera_Ate_Que_Abra_Public(objIndex)

                End If


                'verifica se realmente o valor selecionado é o valor de risco
                'If objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").value <> 22 Then
                'MsgBox("O Valor selecionado não é o valor de Risco")
                'Exit Sub
                'End If

                objIndex.Document.Forms(0).elements("btoIncluir").Click()
                Espera_Ate_Que_Abra_Public(objIndex)

                'Verifica se a Tela Limpou
                'If Len(objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").value) > 0 Then
                'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
                'End If

            End If

            'pocura (21 - VALOR DO PEDIDO - CI)
            'If TB.Rows(index)("vlr_PEDIDO").ToString <> 0 Then
            'Encontrou = False
            'Contagem = 0
            'elemCollection = objIndex.Document.Forms(0).getElementsByTagName("TR")
            'For Each obj In elemCollection
            'If InStr(obj.innertext, "21 - VALOR DO PEDIDO - CI") > 0 And Contagem > 13 Then
            'objIndex.Document.Forms(0).elements("selecionados")(Contagem - 16).Checked = True
            'Encontrou = True
            'Exit For
            'Else
            'Contagem += 1
            'Encontrou = False
            'End If
            'Next

            'Clica em Alterar
            'objIndex.Document.Forms(0).elements("btoAlterar").Click()
            'Espera_Ate_Que_Abra()
            'objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_PEDIDO").ToString, 2)
            'objIndex.Document.Forms(0).elements("btoCalcular").Click()
            'Espera_Ate_Que_Abra()

            'objIndex.Document.Forms(0).elements("btoIncluir").Click()
            'MataPossivelMsgbox()
            'Espera_Ate_Que_Abra()
            'Thread.Sleep(1000)


            'Verifica se a Tela Limpou
            'Try
            'If Len(objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").value) > 0 Then
            'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If
            'Catch ex As Exception
            'MsgBox("Erro ao Verificar se a tela está em branco. Verifique antes de Clicar em OK")
            'End Try


            objIndex.Document.Forms(0).elements("btoSalvar").Click()

            Thread.Sleep(1000)
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("cdTipoAcao").value) > 0 Then
            'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If

            cmd.CommandText = "update TB_Atualizacao_Calculo set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()



        Next
        MsgBox("Acabou!")

    End Sub

    Private Sub Rotina_Cadastro()
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select * from TB_Atualizacao_Calculo where IMPORTADO = false  order by gcpj"
        Else
            VsQl = "select * from TB_Atualizacao_Calculo where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj"
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            System.Windows.Forms.Application.DoEvents()

            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraCpmisAtulzValorCalcAction?acao=carregar")
            Espera_Ate_Que_Abra_Public(objIndex)

            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'inserindo Valor Pedido
            objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 21
            Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_PEDIDO").ToString, 2)
            objIndex.Document.Forms(0).elements("btoCalcular").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("btoIncluir").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").value) > 0 Then
            '    If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If


            'inserindo Valor rISCO
            objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 22
            Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_Risco").ToString, 2)
            objIndex.Document.Forms(0).elements("btoCalcular").Click()
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoIncluir").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").value) > 0 Then
            '    If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If


            objIndex.Document.Forms(0).elements("btoSalvar").Click()


            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("cdTipoAcao").value) > 0 Then
            'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If

            cmd.CommandText = "update TB_Atualizacao_Calculo set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()
        Next
        MsgBox("Acabou!")

    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from TB_Atualizacao_Calculo where  importado = false   ORDER BY GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If

        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE TB_Atualizacao_Calculo SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next


        MsgBox("Distribuição Efetuada")
    End Sub


End Class