﻿
Module Mod_Funcoes

   
    Public Sub Espera_Ate_Que_Abra_Public(ByVal VarobjIndex As SHDocVw.InternetExplorer)
        Dim DTInicio As Date = Date.Now
        ' Thread.Sleep(5000)
        Do While VarobjIndex.ReadyState = 0 Or VarobjIndex.ReadyState = 1 Or VarobjIndex.ReadyState = 3
            'Espera até que abra
            System.Windows.Forms.Application.DoEvents()
            If DateDiff(DateInterval.Minute, DTInicio, Date.Now) >= 5 Then
                'MsgBox("Sistema Ocioso por mais de 3 minutos", vbInformation)
                Exit Sub
            End If
        Loop
        Do While VarobjIndex.Busy = True
            'Espera até que abra
            System.Windows.Forms.Application.DoEvents()
            If DateDiff(DateInterval.Minute, DTInicio, Date.Now) >= 5 Then
                'MsgBox("Sistema Ocioso por mais de 3 minutos", vbInformation)
                Exit Sub
            End If
        Loop
    End Sub


    Function SQL_Data(ByVal XData As String)
        If Not IsDate(XData) Then
            Return "NULL"
        Else
            Dim VarData As Date
            VarData = XData
            Return "#" & Format(VarData, "MM/dd/yyyy") & "#"
        End If
    End Function
    Function SQL_Hora(ByVal XHora As String)
        If Not IsDate(XHora) Then
            Return "NULL"
        Else
            Dim VarHora As Date
            VarHora = XHora
            Return "#" & Format(VarHora, "HH:mm:ss") & "#"
        End If
    End Function

    Function SQL_Texto(ByVal XTexto As String, Optional ByVal XTamanho As Integer = 0)
        If XTamanho = 0 Then
            Return "'" & Replace(Trim(XTexto), "'", "") & "'"
        Else
            Return "'" & Replace(Trim(Mid(XTexto, 1, XTamanho)), "'", "") & "'"
        End If
    End Function

    Function SQL_Numero(ByVal XNumero As String)
        If Not IsNumeric(XNumero) Then
            Return "NULL"
        Else
            XNumero = Replace(XNumero, ".", "")
            Return Replace(XNumero, ",", ".")
        End If
    End Function

    Function Converter_Login(ByVal VarLogin As String)
        Select Case UCase(Mid(VarLogin, 1, 1))
            Case "A"
                Return "1" & Mid(VarLogin, 2, Len(VarLogin))
            Case "B"
                Return "2" & Mid(VarLogin, 2, Len(VarLogin))
            Case "C"
                Return "3" & Mid(VarLogin, 2, Len(VarLogin))
            Case "D"
                Return "4" & Mid(VarLogin, 2, Len(VarLogin))
            Case "E"
                Return "5" & Mid(VarLogin, 2, Len(VarLogin))
            Case "F"
                Return "6" & Mid(VarLogin, 2, Len(VarLogin))
            Case "G"
                Return "7" & Mid(VarLogin, 2, Len(VarLogin))
            Case "H"
                Return "8" & Mid(VarLogin, 2, Len(VarLogin))
            Case "I"
                Return "9" & Mid(VarLogin, 2, Len(VarLogin))
            Case Else
                Return "0" & Mid(VarLogin, 2, Len(VarLogin))
        End Select
    End Function
End Module
