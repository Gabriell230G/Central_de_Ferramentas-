﻿Imports System.Data.OleDb
Imports System.Threading

Public Class Frm_Captura_Fundamento
    Dim VarFundamento As String
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Dados_Fundamento.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Calcular_Tempo(ByVal Qtde_Segundos As Integer, ByVal VarQtde_Registros As Double, ByVal VarTotalRegistros As Double, ByVal VarPosicaoAtual As Double)

        Dim Total_Segundos As Double = 0
        Dim Horas As Integer = 0
        Dim Minutos As Integer = 0
        Dim Segundos As Integer = 0
        Dim Resto As Double = 0
        Total_Segundos = Qtde_Segundos * VarQtde_Registros
        Horas = Int(Total_Segundos / 3600)
        Resto = Total_Segundos Mod 3600
        Minutos = Int(Resto / 60)
        Segundos = Resto Mod 60

        Frm_Principal.TXTStatus.Visible = True
        Frm_Principal.Status.Visible = True
        Frm_Principal.Status.Maximum = VarTotalRegistros
        Frm_Principal.Status.Value = VarPosicaoAtual

        Dim dt1 As TimeSpan = New TimeSpan(Date.Now.Hour + Horas, Date.Now.Minute + Minutos, 0)


        '& ":" & Format(Minutos, "00") & ":" & Format(Segundos, "00")
        Frm_Principal.TXTStatus.Text = "Tempo Estimado: " & Format(Horas, "00") & ":" & Format(Minutos, "00") & ":" & Format(Segundos, "00") & "      -     Hora Estimada: " & dt1.Hours & ":" & Format(dt1.Minutes, "00")
    End Sub


    Private Sub Frm_Captura_Fundamento_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()

    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        'Abrindo Tabela
        Dim VsQl As String
        VsQl = "select * from TB_FUNDAMENTO where IMPORTADO = false   order by GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        Dim InicioProcedimento As Date
        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            'Verificando horario após as 22 e aguardando um período de 4 horas
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                Grade.Items.Add("Horário após as 22:00")
                Grade.SelectedIndex = Grade.Items.Count - 1
                Dim Vdata As Date = Date.Now
EsperandoRestart:
                If DateDiff(DateInterval.Hour, Vdata, Date.Now) < 4 Then
                    Grade.Items.Add(Date.Now & "  Aguardando intervalo de 4 horas..")
                    Grade.SelectedIndex = Grade.Items.Count - 1
                    Thread.Sleep(600000)
                    GoTo EsperandoRestart
                End If
            End If

            InicioProcedimento = Date.Now

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

inicio:

            'Abrindo Tela de Pesquisa
            Try
                objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=opcaoConsulta") 'produção
                Espera_Ate_Que_Abra_Public(objIndex)

                    '1ª tela de pesquisa
                    AppActivate("(GCPJ) Gestão Controle de Processos Jurídicos - Windows Internet Explorer")
                    objIndex.Document.Forms(0).elements("nrProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString 'inserindo bradesco
                    objIndex.Document.Forms(0).elements("btoPesquisar").Click() ' lupa do bt salvar

                
                Espera_Ate_Que_Abra_Public(objIndex)

                '2ª Tela -- Resultado da Pesquisa
                objIndex.Document.Forms(0).elements("Button").Click() ' clicando no botão resumo

                Espera_Ate_Que_Abra_Public(objIndex)

                If IdentificarFundamento(TB.Rows(index)("GCPJ").ToString) = False Then
                    Grade.Items.Add("REPROCESSANDO")
                    GoTo inicio
                Else
                    Dim Cmd As New OleDbCommand("update TB_FUNDAMENTO set importado = true, fundamento =  '" & Replace(VarFundamento, "'", "") & "' where chave_interna = " & TB.Rows(index)("chave_interna").ToString, Conexao)
                    Cmd.ExecuteNonQuery()
                End If


                Calcular_Tempo(DateDiff(DateInterval.Second, InicioProcedimento, Date.Now), TB.Rows.Count - index, TB.Rows.Count, index)
                Me.Text = Me.Text & "    Tempo médio por processo: " & DateDiff(DateInterval.Second, InicioProcedimento, Date.Now) & " Segundos"

            Catch ex As Exception
                Grade.Items.Add("REPROCESSANDO")
                GoTo inicio
            End Try

        Next
        objIndex.Quit()
        MsgBox("Processamento Efetuado com Sucesso!", vbInformation)
    End Sub


    Public Function IdentificarFundamento(VarGCPJ As Double) As Boolean
        'Conectando a variável à janela popup
        IdentificarFundamento = False

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell

inicio_verificacao:
        For Each objIndex2 In objShell2.Windows
            If objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcConsultaTodosAction?acao=obterResumoProcesso&cdNumeroProcessoBradesco=" & VarGCPJ Then
                objIndex2.Visible = True
                IdentificarFundamento = True
                Exit For
            End If
            'MsgBox(objIndex2.LocationURL)
        Next objIndex2

        If IdentificarFundamento = False Then
            GoTo inicio_verificacao
        End If

        Try

            'link do fundamento
            objIndex2.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcConsultaTodosAction?acao=obterResumoProcessoFundamentoCausa")

            Do While objIndex.ReadyState = 0 Or objIndex.ReadyState = 1 Or objIndex.ReadyState = 3
                'Espera até que abra
            Loop
            Do While objIndex.Busy = True
                'Espera até que abra
            Loop
            Thread.Sleep(2000)

            VarFundamento = objIndex2.Document.Forms(0).elements("dsResumo").innertext
            objIndex2.Quit()
            Return True

        Catch ex As Exception
            objIndex2.Quit()
            Return False

        End Try

    End Function


End Class