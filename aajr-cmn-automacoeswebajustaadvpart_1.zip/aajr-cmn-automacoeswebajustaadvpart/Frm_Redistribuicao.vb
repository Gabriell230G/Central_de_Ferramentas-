﻿Imports System.Runtime.InteropServices
Imports System.Data.OleDb
Imports System.Threading

Public Class Frm_Redistribuicao
    Dim objIndex As SHDocVw.InternetExplorer
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Redistribuicao.mdb")


    Private Sub tbConectarGCPJRedistribuica_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)

    End Sub

    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function
    Private Sub frm_Redistribuicao_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub


    Sub preencheCampo(ByVal campo As String, ByVal valor As String)
        objIndex.Document.forms(0).elements(campo.ToString).innerText = valor.ToString
    End Sub

    Sub preencheCampoF(ByVal campo As String, ByVal valor As String, ByVal formulario As Integer)
        objIndex.Document.forms(formulario).elements(campo.ToString).innerText = valor.ToString
    End Sub
    Sub preencheCampoID(ByVal campo As String, ByVal valor As String)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto.innertext = valor.ToString
    End Sub

    Sub clicaBotao(ByVal campo As String)
        objIndex.Document.forms(0).elements(campo.ToString).click()
    End Sub
    Sub clicaBotaoF(ByVal campo As String, ByVal formulario As Integer)
        objIndex.Document.forms(formulario).elements(campo.ToString).click()
    End Sub
    Sub clicaBotaoID(ByVal campo As String)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto.click()
    End Sub

    Sub atualizarTroca(ByVal campo As String)
        objIndex.Document.forms(0).elements(campo.ToString).onchange()
    End Sub
    Sub atualizaTrocaF(ByVal campo As String, ByVal formulario As Integer)
        objIndex.Document.forms(formulario).elements(campo.ToString).onchange()
    End Sub
    Sub atualizaTrocaID(ByVal campo As String)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto.onchange()
    End Sub

    Sub onBlurCampos(ByVal campo As String)
        objIndex.Document.forms(0).elements(campo.ToString).onblur()
    End Sub

    Sub onBlurCamposF(ByVal campo As String, ByVal formulario As Integer)
        objIndex.Document.forms(formulario).elements(campo.ToString).onblur()
    End Sub
    Sub onBlurCamposID(ByVal campo As String)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto.onblur()
    End Sub

    Sub selecionaCombo(ByVal campo As String, ByVal indice As Integer)
        objIndex.Document.forms(0).elements(campo.ToString)(indice).selected = True
    End Sub
    Sub selecionaComboF(ByVal campo As String, ByVal indice As Integer, ByVal formulario As Integer)
        objIndex.Document.forms(formulario).elements(campo.ToString)(indice).selected = True
    End Sub
    Sub selecionaComboID(ByVal campo As String, ByVal indice As Integer)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto(indice).selected = True
    End Sub

    Sub onChangeCombo(ByVal campo As String)
        objIndex.Document.forms(0).elements(campo.ToString).onchange()
    End Sub

    Sub onClickBotoes(ByVal campo As String)
        objIndex.Document.forms(0).elements(campo.ToString).onclick()
    End Sub

    Sub onClickBotoesF(ByVal campo As String, ByVal formulario As Integer)
        objIndex.Document.forms(formulario).elements(campo.ToString).onclick()
    End Sub
    Sub onClickBotoesID(ByVal campo As String)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto.onclick()
    End Sub

    Sub submeterForm(ByVal indiceForm As Integer)
        objIndex.Document.forms(indiceForm).submit()
    End Sub
    Sub submeterFormID(ByVal campo As String)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto.submit()
    End Sub

    Sub checarBotao(ByVal campo As String, ByVal indice As Integer)
        objIndex.Document.forms(0).elements(campo.ToString)(indice).checked = True
    End Sub
    Sub checarBotaoF(ByVal campo As String, ByVal indice As Integer, ByVal formulario As Integer)
        objIndex.Document.forms(formulario).elements(campo.ToString)(indice).checked = True
    End Sub
    Sub checarBotaoID(ByVal campo As String, ByVal indice As Integer)
        Dim objeto As Object
        objeto = objIndex.Document.getelementbyid(campo.ToString)
        objeto(indice).checked = True
    End Sub

    Sub rodarJS(ByVal comando As String)
        Call objIndex.Document.parentWindow.execScript(comando, "JavaScript")
    End Sub



    Private Sub BtProcessarRedistribuicao_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        If FecharThread = True Then
            Frm_Principal.BTClickYes.PerformClick()
        End If
        objIndex.Visible = True

        Dim vContador As Integer

        'Abrindo Tabela

        Dim VsQl As String
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select * from tbRedistribuicao where REDISTRIBUIDO = false order by GCPJ"
        Else
            VsQl = "select * from tbRedistribuicao where REDISTRIBUIDO = false  and maquina = " & CMBMaquina.ComboBox.Text & "  order by GCPJ"
        End If


        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        'ACESSANDO TELA DO GCPJ
        objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/disRedistribuicaoAction?acao=carregar")
        Espera_Ate_Que_Abra_Public(objIndex)

        'ACESSANDO REGISTROS

        For vContador = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                Grade.Items.Add("Horário após as 22:00")
                Exit Sub
            End If


            'ATUALIZANDO A GRADE
            Grade.Items.Add(Date.Now & " Processo: " & vContador + 1 & " Faltam mais " & TB.Rows.Count - vContador & "  -  " & TB.Rows(vContador)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'POR PROCESSO
            selecionaCombo("selClassificacao", 3)
            Espera_Ate_Que_Abra_Public(objIndex)
            onChangeCombo("selClassificacao")
            Espera_Ate_Que_Abra_Public(objIndex)

            'Baixados
            selecionaCombo("selSituacao", 1)
            Espera_Ate_Que_Abra_Public(objIndex)
            onChangeCombo("selSituacao")
            Espera_Ate_Que_Abra_Public(objIndex)


            'INSERINDO GCPJ
            preencheCampo("cdNumeroProcessoBradesco", TB.Rows(vContador)("GCPJ").ToString)
            onBlurCampos("cdNumeroProcessoBradesco")
            Espera_Ate_Que_Abra_Public(objIndex)


            'CLICANDO EM PESQUISAR
            clicaBotao("btoPesquisar")
            Espera_Ate_Que_Abra_Public(objIndex)


            '!!!!!!!MUDARMPARA TROCAR O TIPO DE DISTRIBUICAO!!!!!!!!!!
            'SELECIONANDO MANTER ADV INTERNO ALTERAR CONTRATADO
            'checarBotao("cdIndicativoOpcaoRedistribuicao", 2)
            'Espera_Ate_Que_Abra_Public(objIndex)

            'SELECIONANDO ALTERAR ADV INTERNO E MANTER O CONTRATADO
            checarBotao("cdIndicativoOpcaoRedistribuicao", 1)
            Espera_Ate_Que_Abra_Public(objIndex)


            'INSERINDO ADV INTERNO
            preencheCampo("cdAdvogadoInternoBradescoDestino", TB.Rows(vContador)("COD_INTERNO").ToString)
            Espera_Ate_Que_Abra_Public(objIndex)
            onClickBotoes("btoCodAdvogado")
            Espera_Ate_Que_Abra_Public(objIndex)

            'INSERINDO CODIGO CONTRATADO
            'preencheCampo("cdPessoaExternaBradescoDestino", TB.Rows(vContador)("COD_CONTRATADO").ToString)
            'Espera_Ate_Que_Abra_Public(objIndex)
            'onClickBotoes("btoCodAdvogContr")
            'Espera_Ate_Que_Abra_Public(objIndex)


            'SELECIONANDO O PROCESSO
            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")
            objIndex.Document.forms(0).elements("selectAll").checked = True
            onClickBotoes("selectAll")
            Espera_Ate_Que_Abra_Public(objIndex)

            'CLICANDO EM SALVAR
            clicaBotao("btoSalvar")
            Espera_Ate_Que_Abra_Public(objIndex)
            Thread.Sleep(500)
            Espera_Ate_Que_Abra_Public(objIndex)
            Thread.Sleep(500)


            'ATUALIZANDO A TABELA
            Dim Cmd3 As New OleDbCommand("UPDATE tbRedistribuicao SET REDISTRIBUIDO = true, OBS='REDISTRIBUIDO COM SUCESSO!' WHERE GCPJ = " & TB.Rows(vContador)("GCPJ"), Conexao)
            Cmd3.ExecuteNonQuery()

            'Exit Sub

            'CLICANDO EM VOLTAR
            clicaBotao("btoVoltar")
            Espera_Ate_Que_Abra_Public(objIndex)
        Next

        MsgBox("Foi!", vbExclamation)

    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from tbRedistribuicao where  REDISTRIBUIDO = false   ORDER BY GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If


        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE tbRedistribuicao SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND REDISTRIBUIDO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next



        MsgBox("Redistribuição Efetuada")
    End Sub
End Class
