﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Altera_Ag_Conta
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function
    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function
    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1
    Private Sub MataPossivelMsgbox()
        Dim winHwnd As Long
        Do Until winHwnd <> 0
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
            'If (objIndex.ReadyState <> 0 And objIndex.ReadyState <> 1 And objIndex.ReadyState <> 3) Then Exit Sub
            If objIndex.Busy = False Then
                Thread.Sleep(1000)
                Exit Sub
            End If
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
    End Sub
    Private Sub MataMsgbox()
        Dim winHwnd As Long
        Do Until winHwnd <> 0
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
    End Sub

    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Altera_Ag_Conta.mdb")
    Dim objIndex As SHDocVw.InternetExplorer


    Private Sub Frm_Altera_Ag_Conta_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub
    Private Sub Espera_Ate_Que_Abra()
        ' Thread.Sleep(5000)
        Do While objIndex.ReadyState = 0 Or objIndex.ReadyState = 1 Or objIndex.ReadyState = 3
            'Espera até que abra
        Loop
        Do While objIndex.Busy = True
            'Espera até que abra
        Loop
    End Sub

    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from Depositos_Judiciais where  ATUALIZADO = false   ORDER BY bradesco"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If

        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE Depositos_Judiciais SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND ATUALIZADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next
        MsgBox("Distribuição Efetuada")
    End Sub



    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim Encontrou As Boolean = False
        Dim EncontrouData As Boolean = False
        Dim ValorEncontrado As Double = 0
        Dim ContagemDepositos As Integer = 0
        Dim elemCollection As Object
        Dim Pagina_Pesquisa As Integer = 1
        Dim VarGCPJ As Double = 0

        Dim VsQl As String
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select  * from Depositos_Judiciais where atualizado = false order by gcpj, data"
        Else
            VsQl = "select  * from Depositos_Judiciais where atualizado = false and maquina = " & CMBMaquina.ComboBox.Text & "  order by gcpj, data"
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

inicio:

            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/finDepFaltaConta?metodo=carregar&origem=")
            Espera_Ate_Que_Abra()

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If
            'Alimentando Grade
            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  GCPJ: " & TB.Rows(index)("GCPJ").ToString & "  Data " & FormatDateTime(TB.Rows(index)("data").ToString, DateFormat.ShortDate) & "  Valor: " & FormatNumber(TB.Rows(index)("valor").ToString, 2))
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            '1ª tela de pesquisa
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString 'inserindo bradesco
            objIndex.Document.Forms(0).elements("dtPeriodoInic").innertext = TB.Rows(index)("Data").ToString 'inserindo bradesco
            objIndex.Document.Forms(0).elements("dtPeriodoFim").innertext = TB.Rows(index)("Data").ToString 'inserindo bradesco



            objIndex.Document.Forms(0).elements("btoPesquisar").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra()

            'marca o primeiro da lista
            Pagina_Pesquisa = 0

SelecionandoDeposito:
            Pagina_Pesquisa += 1
            Try
                objIndex.Document.Forms(0).elements("itemSelecionado").Checked = True
            Catch ex As Exception
                'caso dê erro, significa que encontrou mais de uma
                Encontrou = False
                EncontrouData = False
                ContagemDepositos = -1
                elemCollection = objIndex.Document.Forms(0).getElementsByTagName("TD")
                For Each obj In elemCollection

                    'Verifica se é começo de linha para somar na contagem
                    Try
                        VarGCPJ = TB.Rows(index)("gcpj")
                        If obj.innertext = VarGCPJ Then
                            'MsgBox(obj.innertext)
                            ContagemDepositos += 1
                        End If
                    Catch ex2 As Exception
                    End Try

                    If EncontrouData = True Then
                        Try
                            ValorEncontrado = obj.innertext

                            If FormatNumber(TB.Rows(index)("VALOR").ToString, 2) = FormatNumber(ValorEncontrado, 2) Then
                                Encontrou = True
                                Exit For
                            End If
                        Catch ex2 As Exception

                        End Try

                        Encontrou = False
                    End If

                    If IsDate(obj.innertext) And InStr(obj.innertext, "/") Then
                        'MsgBox(obj.value)
                        If FormatDateTime(TB.Rows(index)("DATA").ToString, DateFormat.ShortDate) = FormatDateTime(obj.innertext, DateFormat.ShortDate) Then
                            'MsgBox(IsDate(obj.innertext))
                            EncontrouData = True
                            'Exit For
                        End If
                    End If

                Next obj
                If Encontrou = True Then
                    ' MsgBox(ContagemDepositos & " - " & Int(ContagemDepositos / 2))
                    objIndex.Document.Forms(0).elements("itemSelecionado")(ContagemDepositos).Checked = True
                Else
                    elemCollection = objIndex.Document.Forms(0).getElementsByTagName("a")
                    For Each obj In elemCollection 'identificando o obj que possui a strins com os botoes de navegação
                        If Pagina_Pesquisa + 1 = obj.innertext Then
                            obj.click()                 'MOVENDO PARA A PROXIMA PÁGINA
                            Espera_Ate_Que_Abra()
                            GoTo SelecionandoDeposito
                        End If
                        If Pagina_Pesquisa = 5 Or Pagina_Pesquisa = 10 Then
                            If obj.title = "página posterior" Then
                                obj.click()                 'MOVENDO PARA A PROXIMA PÁGINA
                                Espera_Ate_Que_Abra()
                                GoTo SelecionandoDeposito
                            End If
                        End If
                    Next obj

                    If MsgBox("Sistema não conseguiu encontrar o Deposito.  Marque o Deposito Manualmente antes de clique em Sim. Ou clique em Não para cancelar o processo!" & vbCrLf & Err.Number, vbQuestion + vbYesNo) <> vbYes Then Exit Sub
                    'cmd.CommandText = "update Depositos_Judiciais set atualizado = true, Inconsistencia_Data = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                    'cmd.ExecuteNonQuery()

                    GoTo fim
                End If
            End Try

            'If MsgBox("continuar", vbYesNo) <> vbYes Then Exit Sub

            objIndex.Document.Forms(0).elements("btoDetalhar").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra()

            '3ª Tela -- Resultado da Pesquisa e inserção dos dados
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.bancoVO.cdDigitoBanco").innertext = TB.Rows(index)("banco").ToString
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdAgenciaBancaria").innertext = TB.Rows(index)("agencia").ToString
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdContaDepositoJudicial").innertext = TB.Rows(index)("conta").ToString
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdDigitoContaDepositoJudic").innertext = TB.Rows(index)("digito").ToString



            'Inserindo Operacao se for caixa economica
            If TB.Rows(index)("banco").ToString = 104 Then
                Try
                    objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdOperacaoDepositoJudicial").innertext = TB.Rows(index)("operacao").ToString
                Catch ex As Exception

                End Try
            End If

            'Inserindo Tipo de conta "Judicial"
            objIndex.Document.Forms(0).elements("selTipoConta").Item(2).Selected = True
            Espera_Ate_Que_Abra()


            objIndex.Document.Forms(0).elements("btoSalvar").Click() '  salvar
            Thread.Sleep(1000)

            MataMsgbox()
            Espera_Ate_Que_Abra()

            'Verifica se a Tela Limpou
            Try
                If Len(objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdAgenciaBancaria").value) > 0 Then
                    If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
                End If
            Catch ex As Exception

            End Try

            cmd.CommandText = "update Depositos_Judiciais set atualizado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

Fim:
        Next

        MsgBox("Acabou")
    End Sub
End Class