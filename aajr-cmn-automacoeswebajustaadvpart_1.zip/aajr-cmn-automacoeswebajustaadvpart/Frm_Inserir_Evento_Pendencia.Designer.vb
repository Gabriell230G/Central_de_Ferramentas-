﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Inserir_Evento_Pendencia
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Inserir_Evento_Pendencia))
        Me.Grade = New System.Windows.Forms.ListBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.BTConectaGCPJ = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BTProcessaTudo = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.BTProcessarInclusao = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.BTProcessarValidacao = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.BTParar = New System.Windows.Forms.ToolStripButton()
        Me.BTAcompanhamento = New System.Windows.Forms.ToolStripButton()
        Me.Linha = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.ToolStripSeparator5 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripLabel2 = New System.Windows.Forms.ToolStripLabel()
        Me.Tela = New System.Windows.Forms.ToolStripTextBox()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grade
        '
        Me.Grade.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Grade.FormattingEnabled = True
        Me.Grade.Location = New System.Drawing.Point(0, 25)
        Me.Grade.Name = "Grade"
        Me.Grade.Size = New System.Drawing.Size(840, 297)
        Me.Grade.TabIndex = 10
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BTConectaGCPJ, Me.ToolStripSeparator1, Me.BTProcessaTudo, Me.ToolStripSeparator4, Me.BTProcessarInclusao, Me.ToolStripSeparator2, Me.BTProcessarValidacao, Me.ToolStripSeparator3, Me.BTParar, Me.BTAcompanhamento, Me.ToolStripSeparator5, Me.ToolStripLabel1, Me.Linha, Me.ToolStripLabel2, Me.Tela})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(840, 25)
        Me.ToolStrip1.TabIndex = 11
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'BTConectaGCPJ
        '
        Me.BTConectaGCPJ.Image = CType(resources.GetObject("BTConectaGCPJ.Image"), System.Drawing.Image)
        Me.BTConectaGCPJ.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTConectaGCPJ.Name = "BTConectaGCPJ"
        Me.BTConectaGCPJ.Size = New System.Drawing.Size(105, 22)
        Me.BTConectaGCPJ.Text = "Conectar GCPJ"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BTProcessaTudo
        '
        Me.BTProcessaTudo.Enabled = False
        Me.BTProcessaTudo.Image = CType(resources.GetObject("BTProcessaTudo.Image"), System.Drawing.Image)
        Me.BTProcessaTudo.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTProcessaTudo.Name = "BTProcessaTudo"
        Me.BTProcessaTudo.Size = New System.Drawing.Size(108, 22)
        Me.BTProcessaTudo.Text = "Processar Tudo"
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(6, 25)
        '
        'BTProcessarInclusao
        '
        Me.BTProcessarInclusao.Enabled = False
        Me.BTProcessarInclusao.Image = CType(resources.GetObject("BTProcessarInclusao.Image"), System.Drawing.Image)
        Me.BTProcessarInclusao.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTProcessarInclusao.Name = "BTProcessarInclusao"
        Me.BTProcessarInclusao.Size = New System.Drawing.Size(71, 22)
        Me.BTProcessarInclusao.Text = "Inclusão"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'BTProcessarValidacao
        '
        Me.BTProcessarValidacao.Enabled = False
        Me.BTProcessarValidacao.Image = CType(resources.GetObject("BTProcessarValidacao.Image"), System.Drawing.Image)
        Me.BTProcessarValidacao.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTProcessarValidacao.Name = "BTProcessarValidacao"
        Me.BTProcessarValidacao.Size = New System.Drawing.Size(78, 22)
        Me.BTProcessarValidacao.Text = "Validação"
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'BTParar
        '
        Me.BTParar.Image = CType(resources.GetObject("BTParar.Image"), System.Drawing.Image)
        Me.BTParar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTParar.Name = "BTParar"
        Me.BTParar.Size = New System.Drawing.Size(187, 22)
        Me.BTParar.Text = "Preparar Novo Processamento"
        '
        'BTAcompanhamento
        '
        Me.BTAcompanhamento.Image = CType(resources.GetObject("BTAcompanhamento.Image"), System.Drawing.Image)
        Me.BTAcompanhamento.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.BTAcompanhamento.Name = "BTAcompanhamento"
        Me.BTAcompanhamento.Size = New System.Drawing.Size(127, 22)
        Me.BTAcompanhamento.Text = "Acompanhamento"
        '
        'Linha
        '
        Me.Linha.BackColor = System.Drawing.SystemColors.Info
        Me.Linha.Name = "Linha"
        Me.Linha.Size = New System.Drawing.Size(25, 25)
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(36, 22)
        Me.ToolStripLabel1.Text = "Linha"
        '
        'ToolStripSeparator5
        '
        Me.ToolStripSeparator5.Name = "ToolStripSeparator5"
        Me.ToolStripSeparator5.Size = New System.Drawing.Size(6, 25)
        '
        'ToolStripLabel2
        '
        Me.ToolStripLabel2.Name = "ToolStripLabel2"
        Me.ToolStripLabel2.Size = New System.Drawing.Size(29, 22)
        Me.ToolStripLabel2.Text = "Tela"
        '
        'Tela
        '
        Me.Tela.BackColor = System.Drawing.SystemColors.Info
        Me.Tela.Name = "Tela"
        Me.Tela.Size = New System.Drawing.Size(25, 25)
        '
        'Frm_Inserir_Evento_Pendencia
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(840, 322)
        Me.Controls.Add(Me.Grade)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "Frm_Inserir_Evento_Pendencia"
        Me.Text = "Frm_Inserir_Evento_Pendencia"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Grade As System.Windows.Forms.ListBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents BTConectaGCPJ As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BTProcessarInclusao As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BTParar As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BTProcessarValidacao As System.Windows.Forms.ToolStripButton
    Friend WithEvents BTAcompanhamento As System.Windows.Forms.ToolStripButton
    Friend WithEvents BTProcessaTudo As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator4 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents Linha As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents ToolStripSeparator5 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents ToolStripLabel2 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents Tela As System.Windows.Forms.ToolStripTextBox
End Class
