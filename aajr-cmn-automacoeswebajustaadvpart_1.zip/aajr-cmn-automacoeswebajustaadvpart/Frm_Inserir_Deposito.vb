﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Inserir_Deposito
    Dim VarSair As Boolean = False


    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Inserir_Deposito.mdb")
    Dim objIndex As SHDocVw.InternetExplorer


    Private Sub Frm_Inserir_Deposito_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub



    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function


    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        If FecharThread = True Then
            Frm_Principal.BTClickYes.PerformClick()
        End If

        'Abrindo Tabela
        Dim VsQl As String

        If CMBMaquina.SelectedIndex = -1 Then
            VsQl = "select * from DEPOSITOS where Atualizado = false   order by BRADESCO"
        Else
            VsQl = "select * from DEPOSITOS where Atualizado = false and maquina = " & CMBMaquina.Text & "  order by BRADESCO"
        End If

        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        'Abrindo Tela de Pesquisa
        Try
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/finDepContabilizadoAction?metodo=carregar") 'produção
        Catch ex As Exception
            MsgBox("Erro na Abertura da tela de pesquisa. " & vbCrLf & ex.Message, vbInformation)
            Exit Sub
        End Try

        For index = 0 To TB.Rows.Count - 1
forIn:
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1


            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("Bradesco").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()


            Espera_Ate_Que_Abra_Public(objIndex)

            'pesquisando processo


            objIndex.Document.Forms(0).elements("envolvidoVO.processo.cdNumeroProcessoBradesco").innertext = TB.Rows(index)("Bradesco").ToString 'inserindo bradesco
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()


            Espera_Ate_Que_Abra_Public(objIndex)

            Identificar_e_FecharPopUp()

            Espera_Ate_Que_Abra_Public(objIndex)


            'Tela de Cadastro

            'Inserindo Tipo de Deposito
            Try
                objIndex.Document.Forms(0).elements("selTipoDeposito")(2).SELECTED = True
                objIndex.Document.Forms(0).elements("selTipoDeposito").onblur()
            Catch ex As Exception
                objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/finDepContabilizadoAction?metodo=carregar") 'produção
                Grade.Items.Add("REPROCESSANDO")
                MsgBox("Erro ao carregar Processo")
                Exit Sub

            End Try

            Espera_Ate_Que_Abra_Public(objIndex)

            Thread.Sleep(2000)

            'Inserindo finalidade
            Select Case TB.Rows(index)("Finalidade").ToString
                Case "EMBARGOS - DRC"
                    objIndex.Document.Forms(0).elements("selFinalidade")(10).SELECTED = True
                    objIndex.Document.Forms(0).elements("selFinalidade").onblur()
            End Select

            Espera_Ate_Que_Abra_Public(objIndex)



            'inserindo forma de pagamento
            objIndex.Document.Forms(0).elements("selFormaPagamento")(1).SELECTED = True
            objIndex.Document.Forms(0).elements("selFormaPagamento").onblur()

            Espera_Ate_Que_Abra_Public(objIndex)


            'Inserindo Banco
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdBanco").innertext = TB.Rows(index)("banco").ToString 'inserindo bradesco

            'Inserindo Data, Data Contabil e valor
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.dtDepositoJudicialProcesso").innertext = TB.Rows(index)("data").ToString 'inserindo bradesco
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.dtContabilizacaoDepositoJudic").innertext = TB.Rows(index)("DATA_CONTABIL").ToString 'inserindo bradesco
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.vrDepositoJudicialProcesso").innertext = FormatNumber(TB.Rows(index)("valor").ToString, 2) 'inserindo bradesco
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.vrDepositoJudicialProcesso").onblur()

            Espera_Ate_Que_Abra_Public(objIndex)

            'inserindo ID, Tipo de Composição e Valor Composição
            'objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.cdNumeroDocumentoDeposito").innertext = TB.Rows(index)("id").ToString 'inserindo bradesco
            objIndex.Document.Forms(0).elements("selTipoComposicao")(1).SELECTED = True
            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.compsDepJudicVO.vrComposicaoDepositoJudicial").innertext = FormatNumber(TB.Rows(index)("VLR_COMPOSICAO").ToString, 2) 'inserindo bradesco

            objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.dsObservacaoDepositoJudicial").innertext = "VALOR ORIGINAL DO DEPÓSITO – R$ " & FormatNumber(TB.Rows(index)("VLR_ORIGINAL").ToString, 2)

            Espera_Ate_Que_Abra_Public(objIndex)


            'Clicando em Incluir
            objIndex.Document.Forms(0).elements("btoIncluir").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'Clicando em salvar
            objIndex.Document.Forms(0).elements("btoSalvar").Click()

            Espera_Ate_Que_Abra_Public(objIndex)

            'vERIFICANDO se a tela MUDOU
            'Verificando se ainda continua na mesma tela


            Try
                Dim varint As Integer = Len(objIndex.Document.Forms(0).elements("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdBanco").innertext)
                objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/finDepContabilizadoAction?metodo=carregar") 'produção
                Grade.Items.Add("Erro ao cadastrar")
                cmd.CommandText = "update Depositos set ATUALIZADO = true, obs = 'ERRO AO CADASTRAR' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                index += 1
                GoTo forIn


            Catch ex As Exception
                cmd.CommandText = "update Depositos set ATUALIZADO = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            End Try


        Next

        MsgBox("fOI")

    End Sub

    Private Sub Identificar_e_FecharPopUp()
        'Conectando a variável à janela popup
        Thread.Sleep(3000)

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell


        For Each objIndex2 In objShell2.Windows
            If objIndex2.LocationURL = "http://www4.net.bradesco.com.br/gcpj/servlet/finDepositoNovoAlteracaoAction?metodo=abrirPopupDepositosAnteriores" Then
                objIndex2.Visible = True
                objIndex2.Quit()
                Exit For
            End If
        Next objIndex2

    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from Depositos where  ATUALIZADO = false   ORDER BY bradesco"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If

        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE Depositos SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND ATUALIZADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next
        MsgBox("Distribuição Efetuada")
    End Sub
End Class