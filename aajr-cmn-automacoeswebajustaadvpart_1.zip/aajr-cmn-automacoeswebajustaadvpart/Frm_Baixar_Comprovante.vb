﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Imports System.IO

Imports System.Windows.Automation


Public Class Frm_Baixar_Comprovante
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Baixar_Anexo.mdb")
    Dim objIndex As SHDocVw.InternetExplorer


    'ELEMENTOS DE AUTOMACAO
    Private aeDesktop As AutomationElement
    Private frmSelecionar As AutomationElement
    Private frmsSelecionar As AutomationElementCollection
    Private arquivo As AutomationElement
    Private btnAbrir As AutomationElement

    Private arquivoTexto As ValuePattern

    Private btnAbrirClick As InvokePattern
    '------------------------------------------


    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click

        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        Grade.Items.Add("Conexão Efetuada!")
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function
    Private Sub Frm_Baixar_Comprovante_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()

    End Sub

    Private Sub preencheGrade(ByRef Texto As String)
        Grade.Items.Add(Date.Now & " " & Texto)
        Grade.SelectedIndex = Grade.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()
    End Sub

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim elemCollection As Object
        Dim obj As Object

        Dim elemCollection2 As Object
        Dim obj2 As Object

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        Dim Encontrou As Boolean = False
        Dim ContagemAnexos As Integer
        Dim Contagem As Integer = 0
        Dim Pagina_Pesquisa = 0
        Dim Nome_Arquivo As String

        Dim VsQl As String
        VsQl = "select * from PROCESSOS  where verificado = false order by gcpj"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            preencheGrade("Pesquisando processo: " & TB.Rows(index)("gcpj").ToString)


            'ABRINDO TELA DE ANEXOS
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/cadProcsAnexosAction?acao=carregar&cdNumeroProcessoBradesco=" & TB.Rows(index)("gcpj").ToString & "&tituloPagina=Auto_Inicial&permitirSalvar=1")
            Espera_Ate_Que_Abra_Public(objIndex)
            AppActivate("GCPJ - Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")


            Pagina_Pesquisa = 0

IncicioVerificacao:
            'LOCALIZANDO REGISTRO COM A PALAVRA CHAVE
            Pagina_Pesquisa += 1
            elemCollection = objIndex.Document.getElementsByTagName("td")
            Encontrou = False
            ContagemAnexos = -1
            Contagem = 0
            For Each obj In elemCollection
                Contagem += 1

                If Contagem = 24 Or Contagem = 29 Or Contagem = 34 Or Contagem = 39 Or Contagem = 44 Then 'Linhas especificas que contem os nomes dos anexos
                    ContagemAnexos += 1

                    If InStr(UCase(obj.innerhtml), UCase(PalavraChave.Text)) > 0 Then
                        'selecionando registro
                        preencheGrade("Anexo Localizado! Selecionando e Baixando Arquivo...")
                        Encontrou = True
                        Try
                            objIndex.Document.Forms(0).elements("selecionados")(ContagemAnexos).Checked = True
                        Catch ex As Exception
                            objIndex.Document.Forms(0).elements("selecionados").Checked = True
                        End Try

                        Exit For
                    End If
                End If

                If Contagem > 44 Then
                    'Indo para a proxima página se houver
                    elemCollection2 = objIndex.Document.Forms(0).getElementsByTagName("a")
                    For Each obj2 In elemCollection2 'identificando o obj que possui a strins com os botoes de navegação
                        If Pagina_Pesquisa + 1 = Val(obj2.innertext) Then
                            obj2.click()                 'MOVENDO PARA A PROXIMA PÁGINA
                            Espera_Ate_Que_Abra_Public(objIndex)
                            GoTo IncicioVerificacao
                        End If
                        If Pagina_Pesquisa = 5 Or Val(Pagina_Pesquisa) = 10 Then
                            If obj2.title = "página posterior" Then
                                obj2.click()                 'MOVENDO PARA A PROXIMA PÁGINA
                                Espera_Ate_Que_Abra_Public(objIndex)
                                GoTo IncicioVerificacao
                            End If
                        End If
                    Next obj2
                End If
            Next obj

            If Encontrou = False Then
                preencheGrade("Anexo Não Localizado! Indo para o próximo")
                cmd.CommandText = "update processos set verificado = true, OBS = 'ANEXO NÃO ENCONTRADO COM A PLALAVRA: " & PalavraChave.Text & "' WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString
                cmd.ExecuteNonQuery()
                GoTo Proximo
            End If


            'Visualizando o Anexo
            objIndex.Document.Forms(0).elements("btoVisualizar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)




            'localizando anexo aberto
            Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
            Dim objShell2 As Shell32.Shell
            objShell2 = New Shell32.Shell
            Dim TelaLocalizada As Boolean
            Thread.Sleep(5000)
inicio_verificacao:
            For Each objIndex2 In objShell2.Windows
                If InStr(objIndex2.LocationURL, "http://www4.net.bradesco.com.br/gcpj/servlet/cadProcsAnexosAction?acao=VisualizarArquivo&selecionados") Then
                    objIndex2.Visible = True
                    TelaLocalizada = True
                    Exit For
                End If
                'MsgBox(objIndex2.LocationURL)
            Next objIndex2

            Nome_Arquivo = TB.Rows(index)("gcpj").ToString '& "-" '& Replace(Replace(Replace(Now, "/", ""), ":", ""), " ", "")


            objIndex2.ExecWB(SHDocVw.OLECMDID.OLECMDID_SAVEAS, SHDocVw.OLECMDEXECOPT.OLECMDEXECOPT_PROMPTUSER)
            '            objIndex2.ExecWB(4, 2, "", "")
            Thread.Sleep(500)



again:
            Try
                aeDesktop = AutomationElement.RootElement
                frmSelecionar = aeDesktop.FindFirst(TreeScope.Descendants, New PropertyCondition(AutomationElement.NameProperty, "Salvar como"))
                Thread.Sleep(500)
                arquivo = frmSelecionar.FindFirst(TreeScope.Descendants, New PropertyCondition(AutomationElement.ClassNameProperty, "Edit"))
                Thread.Sleep(500)
                arquivoTexto = DirectCast(arquivo.GetCurrentPattern(ValuePattern.Pattern), ValuePattern)
                'Thread.Sleep(500)
                'arquivoTexto.SetValue("teste")
                arquivoTexto.SetValue(Application.StartupPath & "\" & Nome_Arquivo & "-" & UCase(PalavraChave.Text))
                Thread.Sleep(800)
                'SendKeys.Send(" ")
                'Exit Sub
                Thread.Sleep(700)
                btnAbrir = frmSelecionar.FindFirst(TreeScope.Children, New PropertyCondition(AutomationElement.NameProperty, "Salvar"))
                btnAbrirClick = DirectCast(btnAbrir.GetCurrentPattern(InvokePattern.Pattern), InvokePattern)
                Thread.Sleep(700)
                btnAbrirClick.Invoke()
            Catch ex As Exception
                GoTo again
            End Try

            objIndex2.Quit()

            cmd.CommandText = "update processos set verificado = true WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString
            cmd.ExecuteNonQuery()

Proximo:

        Next

        preencheGrade("Processamento Finalizado")

    End Sub


End Class