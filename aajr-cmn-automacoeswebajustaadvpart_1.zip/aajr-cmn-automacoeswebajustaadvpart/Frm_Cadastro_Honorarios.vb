﻿Imports System.Data.OleDb
Imports System.Threading
Imports excel = Microsoft.Office.Interop.Excel


Public Class Frm_Cadastro_Honorarios

    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\" & Environment.UserName & "\BD_Cadastro_Honorarios.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Captura_Fundamento_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Try
            If Conexao.State = ConnectionState.Open Then Conexao.Close()
            Conexao.Open()

        Catch ex As Exception
            MsgBox("Erro ao abrir base de dados. Talves o banco não tenha sido criado para seu código." & vbCrLf & ex.Message, vbCritical)
            End
        End Try

        AlimentarAto()
        CarregarGrade()

    End Sub
    Private Sub AlimentarAto()
        Dim TB As New DataTable()
        Dim Vsql As String
        Vsql = "Select * from INFRA_ATOS order by ato"
        Dim DA As New OleDbDataAdapter(Vsql, Conexao)
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Ato.DataSource = TB
        Ato.DisplayMember = "ato" ' - Campo que será exibido ao user
        Ato.SelectedIndex = -1



    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub

    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
Inicio:
        If FecharThread = True Then
            MsgBox("Execute o procedimento ClickYes")
            Exit Sub
        End If

        'abrindo notas agrupadas
        Dim VsQl As String

        VsQl = "SELECT top 1 TB_NOTAS.NRO_NOTA, TB_NOTAS.VALOR_DOCUMENTO" & _
        " FROM(TB_NOTAS)" & _
        " WHERE (((TB_NOTAS.IMPORTADO)=False))" & _
        " GROUP BY TB_NOTAS.NRO_NOTA, TB_NOTAS.VALOR_DOCUMENTO" & _
        " ORDER BY TB_NOTAS.NRO_NOTA"
        Dim DAAgrup As New OleDbDataAdapter(VsQl, Conexao)
        Dim TBAgrup As New DataTable()
        TBAgrup.Locale = System.Globalization.CultureInfo.InvariantCulture
        DAAgrup.Fill(TBAgrup)

        If TBAgrup.Rows.Count = 0 Then
            MsgBox("Nenhuma nota disponível para cadastro", vbCritical)
            Exit Sub
        End If
        Nota.Text = TBAgrup.Rows(0)("nro_nota").ToString

        DAAgrup.Dispose()
        TBAgrup.Dispose()

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        'For indexAgrup = 0 To TBAgrup.Rows.Count - 1

        'Abrindo Tabela com as notas
        VsQl = "select   * from TB_NOTAS where nro_nota = " & Nota.Text & " and IMPORTADO = false   order BY NRO_NOTA, GCPJ"

        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        If TB.Rows.Count = 0 Then
            MsgBox("Não há registro a ser inserido.")
            Exit Sub
        End If

        Nota.Text = TB.Rows(0)("NRO_NOTA").ToString

        'Abrindo Tela de Pesquisa
        Try
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/finHonorariosNovoAction?metodo=carregarHonorariosEmCadastramento") 'produção
        Catch ex As Exception
            MsgBox("Erro na Abertura da tela de pesquisa. " & vbCrLf & ex.Message, vbInformation)
            Exit Sub
        End Try
        Espera_Ate_Que_Abra_Public(objIndex)


        Dim varMensagem As String = MsgBox("Deseja Criar uma nota nova!" & vbCrLf & "Clique em não para incluir atos numa nota ja existente. (Selecione a nota e clique em alterar)", vbQuestion + vbYesNoCancel)

        If varMensagem = vbYes Then

            'Clicando em Incluir
            objIndex.Document.Forms(0).elements("btoIncluir").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra_Public(objIndex)

            'SELECIONANDO e INSERINDO O CNPJ DO ESCRITÓRIO
            objIndex.Document.Forms(0).elements("cdTipoDocumentoPessoa")(1).SELECTED = True
            objIndex.Document.Forms(0).elements("cdTipoDocumentoPessoa").onchange()
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.pessoaExternaBradescoVO.cdCnpjPessoaExterna").innerText = TB.Rows(0)("cnpj").ToString
            objIndex.Document.Forms(0).elements("despesaHonorariosProcessoVO.pessoaExternaBradescoVO.cdFilialCnpjPessoaExterna").innertext = TB.Rows(0)("filial").ToString
            objIndex.Document.Forms(0).elements("despesaHonorariosProcessoVO.pessoaExternaBradescoVO.cdControleCnpjPessoaExterna").innertext = TB.Rows(0)("digito").ToString

            'Clicando na Lupa para pesquisar o Escritório
            'IDENTIFICANDO GCPJ
            Dim elemCollection As Object
            Dim obj As Object
            Dim contador As Integer
            contador = 0
            elemCollection = objIndex.Document.Forms(0).getElementsByTagName("INPUT")
            For Each obj In elemCollection
                If obj.Type = "button" Then
                    contador = contador + 1
                    If contador = 1 Then
                        obj.onclick()
                        Exit For
                    End If
                End If
            Next obj
            IdentificarEscritorio() 'selecionando o primeiro escritório da PopUp

            'Selecionando tipo de documento
            objIndex.Document.Forms(0).elements("despesaHonorariosProcessoVO.tipoDocumentoHonorarioVO.cdTipoDocumentoHonorarios")(6).SELECTED = True
            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.cdNumeroDocumentoHonorarios").innerText = TB.Rows(0)("nro_nota").ToString
            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.dtDocumentoDespesaHonorarios").innerText = TB.Rows(0)("DATA_DOCUMENTO").ToString
            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.vrDocumentoDespesaHonorarios").innerText = FormatNumber(TB.Rows(0)("VALOR_DOCUMENTO").ToString, 2)

            'selecionando Empresa
            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.empresaBradescoVO.cdEmpresaIncorporada").innerText = 237  'TB.Rows(0)("EMPRESA_GRUPO").ToString
            contador = 0
            elemCollection = objIndex.Document.Forms(0).getElementsByTagName("INPUT")
            For Each obj In elemCollection
                If obj.Type = "button" Then
                    contador = contador + 1
                    If contador = 2 Then
                        obj.onclick()
                        Exit For
                    End If
                End If
            Next obj


        ElseIf varMensagem = vbNo Then
            'clica em alterar nota
            'objIndex.Document.Forms(0).elements("btoAlterar").Click() ' lupa do bt salvar

        ElseIf varMensagem = vbCancel Then
            Exit Sub
        End If


        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            Espera_Ate_Que_Abra_Public(objIndex)

            If Conexao.State = ConnectionState.Open Then Conexao.Close()
            Conexao.Open()

            Grade.Items.Add(Date.Now & " Ato: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  Nota: " & TB.Rows(index)("nro_nota").ToString & "   " & TB.Rows(index)("ATO").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e pesquisando processo 
            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.cdNumeroProcessoBradesco").innerText = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra_Public(objIndex)

            'selecionando a primeira dependencia encontrada
            Try
                objIndex.Document.Forms(0).elements("selDependencia")(1).SELECTED = True
            Catch ex As Exception

            End Try

            'caso o destinatário seja nulo, insere a empresa ligada
            If Len(objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.dependenciaBradescoOnLineVO.cdDestinatario").value) = 0 Then
                objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.dependenciaBradescoOnLineVO.cdDestinatario").value = TB.Rows(index)("EMPRESA_GRUPO").ToString
                MsgBox("Clicar em pesquisar Destinatario")
            End If

            'SELECIONANDO O ATO
            For I = 0 To 100
                Try
                    objIndex.Document.Forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.cdIdentificadorAtoDespesa")(I).SELECTED = True
                    Espera_Ate_Que_Abra_Public(objIndex)
                    If objIndex.Document.Forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.cdIdentificadorAtoDespesa")(I).innertext = TB.Rows(index)("ato").ToString Then
                        Exit For
                    End If
                Catch ex As Exception
                    If MsgBox("Ato não encontrado na listagem. Ato: '" & TB.Rows(index)("ato").ToString & "'" & vbCrLf & "Deseja continuar o cadastro (Selecione o ato antes de clicar em OK)", vbYesNo + vbQuestion) <> vbYes Then Exit Sub
                End Try
            Next


            'AppActivate("GCPJ - Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.dtAtoDespesaHonorarios").innerText = TB.Rows(index)("DATA_ATO").ToString
            objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.vrAtoDespesaHonorarios").innerText = FormatNumber(TB.Rows(index)("VALOR_ATO").ToString, 2)

            Espera_Ate_Que_Abra_Public(objIndex)

            'verificando se O dESTINATARIO foi preenchida
            If Len(objIndex.Document.Forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.dependenciaBradescoOnLineVO.cdDestinatario").value) > 0 Then
                'clicando em incluir
                objIndex.Document.Forms(0).elements("btoIncluir").Click() ' lupa do bt salvar
                IdentificarTelaConfirmacao()
                Thread.Sleep(4000)
            End If

            'If MsgBox("Deseja ir para o proximo?", vbYesNo) <> vbYes Then Exit Sub
            Espera_Ate_Que_Abra_Public(objIndex)


            Try
                If objIndex.Document.forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.cdNumeroProcessoBradesco").value = 0 Then
                    cmd.CommandText = "update TB_NOTAS set importado = true, Obs = 'ATO CADASTRADO', DATA_CADASTRO = Date() where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                Else
                    If Len(objIndex.Document.Forms(0).elements("despesaHonorariosProcessoVO.composicaoDespHonorariosVO.dependenciaBradescoOnLineVO.cdDestinatario").value) = 0 Then
                        cmd.CommandText = "update TB_NOTAS set importado = true, Obs = 'PROCESSO SEM DESTINATÁRIO' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                    Else
                        cmd.CommandText = "update TB_NOTAS set importado = true, Obs = 'ERRO NO CADASTRO' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                    End If
                End If
            Catch ex As Exception
                cmd.CommandText = "update TB_NOTAS set importado = true, Obs = 'ATO CADASTRADO', DATA_CADASTRO = Date() where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            End Try

            If Conexao.State = ConnectionState.Open Then Conexao.Close()
            Conexao.Open()

            cmd.ExecuteNonQuery()
        Next

        If MsgBox("A nota foi cadastrada com sucesso. Favor confirmar o valor e finalizar a nota manualmente." & vbCrLf & vbCrLf & "Deseja ir para a proxima nota?", vbYesNo + vbQuestion) <> vbYes Then
            CarregarGrade()
            Exit Sub
        Else
            CarregarGrade()
            GoTo Inicio
        End If
        'Next

        'ARQUIVANDO NOTAS
        cmd.CommandText = "INSERT INTO TB_NOTAS_Arquivado SELECT TB_NOTAS.* FROM TB_NOTAS;"
        cmd.ExecuteNonQuery()

        'LIMPANDO NOTAS ARQUIVADAS
        cmd.CommandText = "DELETE * FROM TB_NOTAS;"
        cmd.ExecuteNonQuery()


        MsgBox("Processamento concluído com Sucesso!", vbInformation)

    End Sub


    Public Function IdentificarEscritorio() As Boolean
        'Conectando a variável à janela popup
        Thread.Sleep(3000)

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell
        Dim Contador As Integer
        Contador = 1

        For Each objIndex2 In objShell2.Windows
            If TypeName(objIndex2.Document) = "HTMLDocument" Then
                If InStr(1, objIndex2.Document.Title, "(GCPJ)") > 0 Then
                    If Contador = 2 Then
                        objIndex2.Visible = True
                        IdentificarEscritorio = True
                        Exit For
                    End If
                    Contador = Contador + 1
                End If
            End If
        Next objIndex2
        'Call objIndex2.Document.parentWindow.execScript("paginacao('0');", "JavaScript")



        'selecionando o primeiro encontrado
        Dim elemCollection As Object
        elemCollection = objIndex2.Document.Forms(0).getElementsByTagName("a")
        For Each obj In elemCollection
            obj.Click()
            objIndex2.Quit()
            Return False
        Next
        objIndex2.Quit()
        Return True
    End Function

    Public Function IdentificarTelaConfirmacao() As Boolean
        'Conectando a variável à janela popup
        Thread.Sleep(3000)

        Dim objIndex2 As SHDocVw.InternetExplorer = Nothing
        Dim objShell2 As Shell32.Shell
        objShell2 = New Shell32.Shell
        Dim Contador As Integer
        Contador = 1

        For Each objIndex2 In objShell2.Windows
            If TypeName(objIndex2.Document) = "HTMLDocument" Then
                If InStr(1, objIndex2.Document.Title, "(GCPJ)") > 0 Then
                    If Contador = 2 Then
                        objIndex2.Visible = True
                        IdentificarTelaConfirmacao = True
                        Exit For
                    End If
                    Contador = Contador + 1
                End If
            End If
        Next objIndex2

        If objIndex.LocationURL = objIndex2.LocationURL Then Return False

        Try
            objIndex2.Document.Forms(0).elements("btoConfirmar").Click() ' lupa do bt salvar
        Catch ex As Exception

        End Try

        objIndex2.Quit()
        Return True
    End Function

    Private Sub BTPesquisa_Click(sender As System.Object, e As System.EventArgs) Handles BTPesquisa.Click
        Try
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/finHonorariosNovoAction?metodo=carregarHonorariosEmCadastramento") 'produção
        Catch ex As Exception
            MsgBox("Erro na Abertura da tela de pesquisa. " & vbCrLf & ex.Message, vbInformation)
            Exit Sub
        End Try


    End Sub

    Private Sub BTImportar_Click(sender As System.Object, e As System.EventArgs) Handles BTImportar.Click
        Dim VarCaminhoPlanilha As String
        OpenFileDialog1.Title = "Importar Planilha 1"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Excel 2007 / 2010|*.xlsx"

        OpenFileDialog1.ShowDialog()

        If OpenFileDialog1.FileName = "" Then Exit Sub
        VarCaminhoPlanilha = OpenFileDialog1.FileName

        If MsgBox("Atenção, durante este procedimento todas as planilhas em excel serão automaticamente fechadas." & vbCrLf & "Deseja continuar?", vbYesNo + vbInformation) <> vbYes Then Exit Sub

        'VERIFICA SE ALGUM ARQUIVO EM EXCELL ESTÁ ABERTO
        'Verifica se o sistema já está aberto para pode-lo maximizar
        For Each p In Process.GetProcesses
            If UCase(p.ProcessName) = "EXCEL" Then
                For Each p2 In Process.GetProcesses
                    If UCase(p2.ProcessName) = "EXCEL" Then
                        p2.Kill()
                    End If
                Next
            End If
        Next

        Grade.DataSource = Nothing

        If ImportarParaGrade(VarCaminhoPlanilha) = False Then
            MsgBox("Erro na importação da planilha!", vbCritical)
            Exit Sub
        End If


        'MAPA DAS COLUNAS
        'Grade2.Rows(index).Cells(0).Value  NRO_NOTA            A
        'Grade2.Rows(index).Cells(1).Value  GCPJ                B
        'Grade2.Rows(index).Cells(2).Value  VALOR_ATO           C
        'Grade2.Rows(index).Cells(3).Value  ATO                 D
        'Grade2.Rows(index).Cells(4).Value  CNPJ                E
        'Grade2.Rows(index).Cells(5).Value  FILIAL              F
        'Grade2.Rows(index).Cells(6).Value  DIGITO              G
        'Grade2.Rows(index).Cells(7).Value  DATA_DOCUMENTO      H
        'Grade2.Rows(index).Cells(8).Value  VALOR_DOCUMENTO     I
        'Grade2.Rows(index).Cells(9).Value  DATA_ATO            J

        Dim vDataAto As Date
        For index = 0 To Grade2.RowCount - 1

            'Consistencias Coluna A NUMERO DA NOTA
            If Len(Grade2.Rows(index).Cells(0).Value.ToString) > 0 And Not IsNumeric(Grade2.Rows(index).Cells(0).Value.ToString) Then
                MsgBox("A coluna 'A' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'GCPJ
            If Not IsNumeric(Grade2.Rows(index).Cells(1).Value.ToString) Then
                MsgBox("A coluna 'GCPJ' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'valor do ato
            If Not IsNumeric(Grade2.Rows(index).Cells(2).Value.ToString) Then
                MsgBox("A coluna 'VALOR_ATO' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'Ato
            Ato.SelectedIndex = -1
            Ato.Text = Trim(Grade2.Rows(index).Cells(3).Value.ToString)
            If Ato.SelectedIndex = -1 Then
                MsgBox("A coluna 'B' (Ato), possui dados que não estão na listagem da planilha." & vbCrLf & " A Planilha não será importada" & vbCrLf & vbCrLf & "Dado Divergente: '" & Grade2.Rows(index).Cells(3).Value.ToString & "'" & vbCrLf & "GCPJ:  " & Grade2.Rows(index).Cells(1).Value.ToString, vbCritical)
                Exit Sub
            End If

            'Cnpj
            If Not IsNumeric(Grade2.Rows(index).Cells(4).Value.ToString) Then
                MsgBox("A coluna 'CNPJ' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'filial
            If Not IsNumeric(Grade2.Rows(index).Cells(5).Value.ToString) Then
                MsgBox("A coluna 'FILIAL' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'digito
            If Not IsNumeric(Grade2.Rows(index).Cells(6).Value.ToString) Then
                MsgBox("A coluna 'DIGITO' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'DATA DOCUMENTO
            If Not IsDate(Grade2.Rows(index).Cells(7).Value.ToString) Then
                MsgBox("A coluna 'DATA DO DOCUMENTO' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'VALOR DOCUMENTO
            If Len(Grade2.Rows(index).Cells(8).Value.ToString) > 0 And Not IsNumeric(Grade2.Rows(index).Cells(8).Value.ToString) Then
                MsgBox("A coluna 'VALOR DO DOCUMENTO' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

            'DATA DO ATO
            If Not IsDate(Grade2.Rows(index).Cells(9).Value.ToString) Then
                MsgBox("A coluna 'DATA DO ATO' possui dados preenchidos não numéricos. A Planilha não será importada", vbCritical)
                Exit Sub
            End If
            vDataAto = Grade2.Rows(index).Cells(9).Value.ToString
            If vDataAto > Date.Now Then
                MsgBox("A coluna 'DATA DO ATO' possui data futura. A Planilha não será importada", vbCritical)
                Exit Sub
            End If

        Next



        'IMPORTANDO PARA O BANCO
        Dim vSqL As String = ""
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao
        Dim vDATA As Date = Date.Now

        'LIMPANDO TABELA
        cmd.CommandText = "DELETE * FROM Planilha_Importada"
        cmd.ExecuteNonQuery()


        For index = 0 To Grade2.RowCount - 1
            'CAPTURANDO CÓDIGO DA CUSTA
            vSqL = "insert into Planilha_Importada (NRO_NOTA,GCPJ,VALOR_ATO,ATO,CNPJ,FILIAL,DIGITO,DATA_DOCUMENTO,VALOR_DOCUMENTO,DATA_ATO) values " & _
            "(" & SQL_Numero(Grade2.Rows(index).Cells(0).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(1).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(2).Value.ToString()) & _
            "," & SQL_Texto(Grade2.Rows(index).Cells(3).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(4).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(5).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(6).Value.ToString()) & _
            "," & SQL_Data(Grade2.Rows(index).Cells(7).Value.ToString()) & _
            "," & SQL_Numero(Grade2.Rows(index).Cells(8).Value.ToString()) & _
            "," & SQL_Data(Grade2.Rows(index).Cells(9).Value.ToString()) & _
            ")"


            Try
                cmd.CommandText = vSqL
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                'se deu erro na importação, então limpa o que já foi importado

                MsgBox("Erro ao importar esta remessa! Inicie a importação novamente." & vbCrLf & ex.Message, vbCritical)
                Exit Sub
            End Try
        Next


        If MsgBox("Importação Efetuada com sucesso. Deseja dividir as notas?", vbYesNo + vbInformation) <> vbYes Then Exit Sub
        BTDividirNotas.PerformClick()
    End Sub

    Private Sub CarregarGrade()
        Dim VsQl2 As String = "SELECT iif(TB_NOTAS.IMPORTADO,'CADASTRADO','PENDENTE') AS SITUAÇÃO, TB_NOTAS.CNPJ, TB_NOTAS.FILIAL, TB_NOTAS.DIGITO, TB_NOTAS.NRO_NOTA, Count(TB_NOTAS.NRO_NOTA) AS [TOTAL ATOS], FORMAT(Sum(TB_NOTAS.VALOR_ATO),'standard') AS [SOMA DOS ATOS 1], format(TB_NOTAS.VALOR_DOCUMENTO,'standard')AS [SOMA DOS ATOS 2], TB_NOTAS.EMPRESA" & _
                            " FROM(TB_NOTAS)" & _
                            " GROUP BY TB_NOTAS.IMPORTADO, TB_NOTAS.CNPJ, TB_NOTAS.FILIAL, TB_NOTAS.DIGITO, TB_NOTAS.NRO_NOTA, TB_NOTAS.VALOR_DOCUMENTO, TB_NOTAS.EMPRESA" & _
                            " ORDER BY TB_NOTAS.IMPORTADO DESC,  TB_NOTAS.NRO_NOTA"
        Grade2.DataSource = Nothing
        Grade2.Rows.Clear()
        Grade2.Columns.Clear()

        Dim DA2 As New OleDbDataAdapter(VsQl2, Conexao)
        Dim TB2 As New DataTable()
        TB2.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA2.Fill(TB2)
        BindingSource1.DataSource = TB2
        Grade2.DataSource = BindingSource1
        Grade2.Refresh()

        'AutoSize em todas as colunas
        Grade2.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
    End Sub

    Function ImportarParaGrade(ByRef varCaminhoPlanilha2 As String) As Boolean
        'abrindo o Excel e alterando determinadas celulas para evitar o problema de existir algum Número com formatação de Texto
        Try
            Dim app As New excel.Application
            Dim WB As excel.Workbook = app.Workbooks.Open(varCaminhoPlanilha2)
            If WB IsNot Nothing Then
                Dim ws As excel.Worksheet = WB.Worksheets.Item(1)
                For index = 2 To 300
                    Try
                        If IsNumeric(ws.Range("B" & index).Value) Then ws.Range("B" & index).Value = ws.Range("B" & index).Value * 1
                        If IsNumeric(ws.Range("E" & index).Value) Then ws.Range("E" & index).Value = ws.Range("E" & index).Value * 1
                        If IsNumeric(ws.Range("F" & index).Value) Then ws.Range("F" & index).Value = ws.Range("F" & index).Value * 1
                        If IsNumeric(ws.Range("G" & index).Value) Then ws.Range("G" & index).Value = ws.Range("G" & index).Value * 1
                    Catch ex As Exception
                    End Try
                Next
            End If
            WB.Save()
            WB.Close()
        Catch ex As Exception

        End Try



        Dim da As OleDbDataAdapter
        Dim dt As DataTable
        Dim conexao_Excel As String
        Thread.Sleep(1000)
        'Importando Planilha 
        conexao_Excel = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & varCaminhoPlanilha2 & ";Extended Properties='Excel 12.0 Xml;HDR=yes;ReadOnly=False';"

        Try
            da = New OleDbDataAdapter("SELECT * FROM [Plan1$] Where [VALOR_ATO]  Is Not Null ", conexao_Excel)
            dt = New DataTable
            da.Fill(dt)
            BindingSource1.DataSource = dt
        Catch ex As Exception
            MsgBox("Erro ao Importar planilha. O Problema está relacionado ao nome da Pasta de Trabalho ou ao nome das Colunas." & vbCrLf & ex.Message, vbCritical)
            Return False
        End Try


        Grade2.DataSource = Nothing
        Grade2.Rows.Clear()
        Grade2.Columns.Clear()
        Grade2.DataSource = BindingSource1 'dt.DefaultView

        Me.Grade2.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan

        Try
            If UCase(Grade2.Columns(0).HeaderText) <> "NRO_NOTA" Or UCase(Grade2.Columns(9).HeaderText) <> "DATA_ATO" Then 'sem segmento
                'If UCase(Grade2.Columns(2).HeaderText) <> "SEGMENTO" Or UCase(Grade2.Columns(44).HeaderText) <> "DIGITO 10" Then 'com segmento
                MsgBox("A quantidade de colunas ou a ordem das colunas não bate com a planilha original.", vbCritical)
                Return False
            End If
        Catch ex As Exception
            MsgBox("A quantidade de colunas ou a ordem das colunas não bate com a planilha original.", vbCritical)
            Return False
        End Try

        Return True

    End Function

    Private Sub BTDividirNotas_Click(sender As System.Object, e As System.EventArgs) Handles BTDividirNotas.Click

        Dim Vsql As String
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        'identificando feriado ou FDS 
inicio_Verificacao_Feriado:
        Vsql = "SELECT Planilha_Importada.DATA_ATO" & _
            " FROM(Planilha_Importada)" & _
            " WHERE (((Day([DATA_ATO])) In (SELECT DIA FROM [SYS_FERIADOS] WHERE MES = MONTH([Planilha_Importada].[DATA_ATO])))) OR (((Weekday([DATA_ATO]))=7)) OR (((Weekday([DATA_ATO]))=1))"

        Dim DA As New OleDbDataAdapter(Vsql, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        If TB.Rows.Count > 0 Then
            'caso haja registro nesta situação, então soma 1 dia para estes casos
            cmd.CommandText = "UPDATE Planilha_Importada SET Planilha_Importada.DATA_ATO = [Planilha_Importada].[DATA_ATO]+1" & _
                              " WHERE (((Day([DATA_ATO])) In (SELECT DIA FROM [SYS_FERIADOS] WHERE MES = MONTH([Planilha_Importada].[DATA_ATO])))) OR (((Weekday([DATA_ATO]))=7)) OR (((Weekday([DATA_ATO]))=1))"
            cmd.ExecuteNonQuery()
            GoTo inicio_Verificacao_Feriado
        End If

        DA.Dispose()
        TB.Dispose()






        ''identificando sabado e somando 2 dias
        'cmd.CommandText = "UPDATE Planilha_Importada SET Planilha_Importada.DATA_ATO = [Planilha_Importada].[DATA_ATO]+2" & _
        '                    " WHERE  (((Weekday([DATA_ato]))=7))"
        'cmd.ExecuteNonQuery()
        ''identificando domingo e somando 1 dia
        'cmd.CommandText = "UPDATE Planilha_Importada SET Planilha_Importada.DATA_ATO = [Planilha_Importada].[DATA_ATO]+1" & _
        '                    " WHERE  (((Weekday([DATA_ato]))=1))"
        'cmd.ExecuteNonQuery()





        'identificar empresas
        cmd.CommandText = "UPDATE (Planilha_Importada INNER JOIN _00_Dados_Processos ON Planilha_Importada.GCPJ = [_00_Dados_Processos].Bradesco) INNER JOIN GCPJB0J8 ON [_00_Dados_Processos].CodJunAgrup = GCPJB0J8.CAGRUP_BDSCO SET Planilha_Importada.EMPRESA = [GCPJB0J8].[IAGRUP_BDSCO], Planilha_Importada.EMPRESA_GRUPO = [_00_Dados_Processos].[CodJunEmp];"
        cmd.ExecuteNonQuery()

        'acerta empresas nulas
        cmd.CommandText = "UPDATE Planilha_Importada SET Planilha_Importada.EMPRESA = 'BANCO BRADESCO', Planilha_Importada.EMPRESA_GRUPO = 237" & _
                            " WHERE (((Planilha_Importada.EMPRESA) Is Null))"
        cmd.ExecuteNonQuery()

        'acerta valor
        cmd.CommandText = "UPDATE Planilha_Importada SET Planilha_Importada.VALOR_ATO = Format([Planilha_Importada].[VALOR_ATO],'Standard');"
        cmd.ExecuteNonQuery()

        'elimina espaços em branco
        cmd.CommandText = "UPDATE Planilha_Importada SET Planilha_Importada.ATO = Trim([Planilha_Importada].[ATO]), Planilha_Importada.GCPJ = Trim([Planilha_Importada].[GCPJ]), Planilha_Importada.CNPJ = Trim([Planilha_Importada].[CNPJ]), Planilha_Importada.FILIAL = Trim([Planilha_Importada].[FILIAL]), Planilha_Importada.DIGITO = Trim([Planilha_Importada].[DIGITO]);"
        cmd.ExecuteNonQuery()


        Dim ValorTeto As Double
        ValorTeto = "200000"
INICIO:
        'abrindo tabela agrupada por empresa e somando os valores
        VsQl = "SELECT Planilha_Importada.EMPRESA, Sum(Planilha_Importada.VALOR_ATO) AS VALOR, Count(Planilha_Importada.GCPJ) AS QTDE" & _
        " FROM Planilha_Importada" & _
        " GROUP BY Planilha_Importada.EMPRESA"
        Dim DAAgrupado As New OleDbDataAdapter(Vsql, Conexao)
        Dim TBAgrupado As New DataTable()
        TBAgrupado.Locale = System.Globalization.CultureInfo.InvariantCulture
        DAAgrupado.Fill(TBAgrupado)


        'VERIFICANDO SE ALGUMA EMPRESA POSSUI VALOR ACIMA DE 200.000,00
        For index = 0 To TBAgrupado.Rows.Count - 1
            If Val(TBAgrupado.Rows(index)("valor").ToString) >= ValorTeto Then
                If TBAgrupado.Rows(index)("qtde").ToString = 1 Then
                    MsgBox("Ato Unico com valor acima de 200.000,00", vbCritical)
                    Exit Sub
                Else
                    'altera 1 registro
                    cmd.CommandText = "update Planilha_Importada set empresa = " & SQL_Texto(TBAgrupado.Rows(index)("empresa").ToString & "-") & "  where Planilha_Importada.chave_interna in (select top 1 chave_interna from Planilha_Importada where empresa = " & SQL_Texto(TBAgrupado.Rows(index)("empresa").ToString) & " order by valor_ato desc)"
                    cmd.ExecuteNonQuery()

                    GoTo INICIO 'volta no inicio para fazer a contagem novamente
                End If
            End If
        Next


        'terminando o processamento
        Dim Contador As Integer
        Dim NumNota As Double
        Contador = 1
        'formato MM DD SEQ HOR MIN

        For index = 0 To TBAgrupado.Rows.Count - 1
            NumNota = Month(Date.Now).ToString.PadLeft(2, "0") & Microsoft.VisualBasic.Day(Date.Now).ToString.PadLeft(2, "0") & Format(Contador, "00") & Hour(Date.Now).ToString.PadLeft(2, "0") & Minute(Date.Now).ToString.PadLeft(2, "0")
            cmd.CommandText = "update Planilha_Importada set " & _
            " NRO_NOTA = " & NumNota & _
            ", VALOR_DOCUMENTO = " & SQL_Numero(TBAgrupado.Rows(index)("valor").ToString) & _
            ", DATA_DOCUMENTO = date()" & _
            " where empresa = " & SQL_Texto(TBAgrupado.Rows(index)("empresa").ToString)
            cmd.ExecuteNonQuery()
            Contador = Contador + 1
        Next

        'verificando processos inexistentes
        Vsql = "SELECT Planilha_Importada.ATO FROM Planilha_Importada LEFT JOIN INFRA_ATOS ON Planilha_Importada.ATO = INFRA_ATOS.ATO WHERE(((INFRA_ATOS.ATO) Is Null)) GROUP BY Planilha_Importada.ATO;"
        Dim DADup As New OleDbDataAdapter(Vsql, Conexao)
        Dim TBDup As New DataTable()
        TBDup.Locale = System.Globalization.CultureInfo.InvariantCulture
        DADup.Fill(TBDup)
        If TBDup.Rows.Count > 0 Then
            MsgBox("Atenção. O sistema possui processos inexistentes.", vbCritical)
            Exit Sub
        End If

        'limpando notas
        cmd.CommandText = "delete * from TB_NOTAS"
        cmd.ExecuteNonQuery()

        'Acrescentando notas geradas
        cmd.CommandText = "INSERT INTO TB_NOTAS ( NRO_NOTA, GCPJ, VALOR_ATO, ATO, CNPJ, FILIAL, DIGITO, DATA_DOCUMENTO, VALOR_DOCUMENTO, DATA_ATO, EMPRESA_GRUPO, EMPRESA )" & _
" SELECT Planilha_Importada.NRO_NOTA, Planilha_Importada.GCPJ, Planilha_Importada.VALOR_ATO, Planilha_Importada.ATO, Planilha_Importada.CNPJ, Planilha_Importada.FILIAL, Planilha_Importada.DIGITO, Planilha_Importada.DATA_DOCUMENTO, Planilha_Importada.VALOR_DOCUMENTO, Planilha_Importada.DATA_ATO, Planilha_Importada.EMPRESA_GRUPO, Planilha_Importada.EMPRESA" & _
" FROM Planilha_Importada"
        cmd.ExecuteNonQuery()

        CarregarGrade()

        MsgBox("Fim do Processamento!", vbInformation)




    End Sub









End Class