﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Inserir_Reclamante_Reclamada
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Frm_Inserir_Reclamante_Reclamada))
        Me.Grade = New System.Windows.Forms.ListBox()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.btnConectar = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.btnProcessar = New System.Windows.Forms.ToolStripButton()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.cmbTipo = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.CmbArea = New System.Windows.Forms.ToolStripComboBox()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Grade
        '
        Me.Grade.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Grade.FormattingEnabled = True
        Me.Grade.Location = New System.Drawing.Point(0, 25)
        Me.Grade.Name = "Grade"
        Me.Grade.Size = New System.Drawing.Size(697, 309)
        Me.Grade.TabIndex = 3
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btnConectar, Me.ToolStripSeparator1, Me.btnProcessar, Me.ToolStripSeparator2, Me.cmbTipo, Me.ToolStripSeparator3, Me.CmbArea})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(697, 25)
        Me.ToolStrip1.TabIndex = 2
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'btnConectar
        '
        Me.btnConectar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnConectar.Image = CType(resources.GetObject("btnConectar.Image"), System.Drawing.Image)
        Me.btnConectar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnConectar.Name = "btnConectar"
        Me.btnConectar.Size = New System.Drawing.Size(89, 22)
        Me.btnConectar.Text = "Conectar GCPJ"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'btnProcessar
        '
        Me.btnProcessar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.btnProcessar.Enabled = False
        Me.btnProcessar.Image = CType(resources.GetObject("btnProcessar.Image"), System.Drawing.Image)
        Me.btnProcessar.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btnProcessar.Name = "btnProcessar"
        Me.btnProcessar.Size = New System.Drawing.Size(61, 22)
        Me.btnProcessar.Text = "Processar"
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'cmbTipo
        '
        Me.cmbTipo.Items.AddRange(New Object() {"Autor", "Reu"})
        Me.cmbTipo.Name = "cmbTipo"
        Me.cmbTipo.Size = New System.Drawing.Size(121, 25)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(6, 25)
        '
        'CmbArea
        '
        Me.CmbArea.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CmbArea.Items.AddRange(New Object() {"CI", "TR"})
        Me.CmbArea.Name = "CmbArea"
        Me.CmbArea.Size = New System.Drawing.Size(75, 25)
        '
        'Frm_Inserir_Reclamante_Reclamada
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(697, 334)
        Me.Controls.Add(Me.Grade)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "Frm_Inserir_Reclamante_Reclamada"
        Me.Text = "Frm_Inserir_Reclamante_Reclamada"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Grade As System.Windows.Forms.ListBox
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents btnConectar As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents btnProcessar As System.Windows.Forms.ToolStripButton
    Friend WithEvents ToolStripSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents cmbTipo As System.Windows.Forms.ToolStripComboBox
    Friend WithEvents ToolStripSeparator3 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents CmbArea As System.Windows.Forms.ToolStripComboBox
End Class
