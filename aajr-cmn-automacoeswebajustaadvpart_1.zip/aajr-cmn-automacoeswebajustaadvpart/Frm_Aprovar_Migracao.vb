﻿Imports System.Data.OleDb
Imports System.Threading

Public Class Frm_Aprovar_Migracao
    Dim objIndex As SHDocVw.InternetExplorer



    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim x As Integer
        x = 0
        Dim vCont As Integer
        Dim vRotacao As Integer
        vCont = 2
        vRotacao = 0

        Grade.SelectedIndex = Grade.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()


        'Abrindo Tela de Pesquisa
        Try
            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traPendAdvogCienteDistrAction?acao=gridVoltar&mensagem=&paginaChamadora=&paginaCorrente=grid&cdNumeroProcessoBradesco=&cdSequenciaAgendaUsuario=&cdTipoPendenciaUsuario=&selectAll=0&selecionados=0&tableGridPagina=") 'produção
        Catch ex As Exception
            MsgBox("Erro na Abertura da tela de pesquisa. " & vbCrLf & ex.Message, vbInformation)
            Exit Sub
        End Try
        Espera_Ate_Que_Abra_Public(objIndex)

        Call objIndex.Document.parentWindow.execScript("enviarPendencia(6);", "JavaScript")
        Espera_Ate_Que_Abra_Public(objIndex)

        Try
            'TELA DE FILTRO
            objIndex.Document.FORMS(0).ELEMENTS("cdAreaProcesso")(1).SELECTED = True
            objIndex.Document.FORMS(0).ELEMENTS("cdAreaProcesso").ONCHANGE()
            Espera_Ate_Que_Abra_Public(objIndex)
        Catch ex As Exception
            MsgBox("Não foi possivel selecionar a área de processo, não se esqueça de estar habilitado como chefe somente na áera desejada!", vbExclamation)
            Exit Sub
        End Try
        objIndex.Document.FORMS(0).ELEMENTS("btoPesquisar").CLICK()

        'DENTRO DA LISTA
        Espera_Ate_Que_Abra_Public(objIndex)

        Do While x = 0
            '[S5] Limitador de operações: cada volta deste laço salva um lote de ciências no GCPJ.
            '     Ao atingir o limite de lotes a rotina para (ver Mod_LimitadorS5.vb).
            If LimiteS5Atingido(qtdOperacoesS5, LIMITE_LOTES_S5, "lotes") Then Exit Do
            qtdOperacoesS5 += 1


            objIndex.Document.Forms(0).elements("selectAll").checked = True
            objIndex.Document.Forms(0).elements("selectAll").onclick()
            Thread.Sleep(200)

            vRotacao = 0
            Do While vRotacao <= 3
                vCont = 2
                Do While vCont <= 7
                    objIndex.Document.forms(0).acao.value = "paginacao"
                    objIndex.Document.forms(0).tableGridPagina.value = vCont
                    objIndex.Document.forms(0).submit()

                    Thread.Sleep(800)
                    Espera_Ate_Que_Abra_Public(objIndex)

                    If vCont <> 7 Then
                        objIndex.Document.Forms(0).elements("selectAll").checked = True
                        objIndex.Document.Forms(0).elements("selectAll").onclick()
                        Thread.Sleep(200)
                    End If
                    vCont = vCont + 1
                Loop
                vRotacao = vRotacao + 1
            Loop

            objIndex.Document.Forms(0).elements("selectAll").checked = True
            objIndex.Document.Forms(0).elements("selectAll").onclick()
            Thread.Sleep(200)

            'Call objIndex.Document.parentWindow.execScript("javascript: paginacao('1'); return false;", "JavaScript")
            objIndex.Document.forms(0).elements("btoSalvar").click()
            Espera_Ate_Que_Abra_Public(objIndex)
            Grade.Items.Add(Date.Now & " Ciencia em 20 Telas")
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

        Loop

    End Sub


End Class