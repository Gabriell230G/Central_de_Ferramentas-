﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Atualizacao_Evento_Realizado

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function
    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function
    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1
    Private Sub MataMsgbox()
        Dim winHwnd As Long
        Do Until winHwnd <> 0
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
    End Sub

    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Alterar_Evento.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Alteracao_Evento_Load(sender As Object, e As System.EventArgs) Handles Me.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub Espera_Ate_Que_Abra()
        ' Thread.Sleep(5000)
        Do While objIndex.ReadyState = 0 Or objIndex.ReadyState = 1 Or objIndex.ReadyState = 3
            'Espera até que abra
        Loop
        Do While objIndex.Busy = True
            'Espera até que abra
        Loop
    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("www4.net.bradesco.com.br/gcpj")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim VsQl As String
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select  * from TB_Principa where IMPORTADO = false  order by gcpj"

        Else
            VsQl = "select  * from TB_Principa where IMPORTADO = false and maquina = " & CMBMaquina.ComboBox.Text & "   order by gcpj"
        End If

        Dim Encontrou As Boolean = False
        Dim elemCollection As Object = Nothing
        Dim Contagem As Double = 0

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
            qtdOperacoesS5 += 1

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If


            System.Windows.Forms.Application.DoEvents()

            objIndex.Navigate("http://www4.net.bradesco.com.br/gcpj/servlet/traTraPendAtulzResAction?acao=carregar")
            Espera_Ate_Que_Abra()


            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra()

           
            Try
                objIndex.Document.Forms(0).elements("selecionados").Checked = True
                Espera_Ate_Que_Abra()
                objIndex.Document.Forms(0).elements("btodetalhar").Click()
                Espera_Ate_Que_Abra()

                objIndex.Document.Forms(0).elements("dsResumoEventoJudicial").innertext() = "Ciente"


                objIndex.Document.Forms(0).elements("btoSalvar").Click()

                MataMsgbox()
                Espera_Ate_Que_Abra()

                cmd.CommandText = "update TB_Principa set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()



            Catch ex As Exception
                cmd.CommandText = "update TB_Principa set importado = true, obs = 'MAIS DE 1 EVENTO' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()


            End Try

        Next
        MsgBox("Acabou!")
    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from TB_Principa where  importado = false   ORDER BY GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If

        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE TB_Principa SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1

        Next


        MsgBox("Distribuição Efetuada")
    End Sub

    Private Sub ToolStripLabel1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripLabel1.Click

    End Sub
End Class