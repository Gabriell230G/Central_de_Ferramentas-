﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Frm_Migracao
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ConectarGCPJ = New System.Windows.Forms.ToolStripButton()
        Me.MigrarProcessos = New System.Windows.Forms.ToolStripButton()
        Me.CmbAdvogados = New System.Windows.Forms.ToolStripComboBox()
        Me.Grade = New System.Windows.Forms.ListBox()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ConectarGCPJ, Me.MigrarProcessos, Me.CmbAdvogados})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(625, 25)
        Me.ToolStrip1.TabIndex = 0
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ConectarGCPJ
        '
        Me.ConectarGCPJ.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.ConectarGCPJ.Name = "ConectarGCPJ"
        Me.ConectarGCPJ.Size = New System.Drawing.Size(89, 22)
        Me.ConectarGCPJ.Text = "Conectar GCPJ"
        '
        'MigrarProcessos
        '
        Me.MigrarProcessos.Enabled = False
        Me.MigrarProcessos.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.MigrarProcessos.Name = "MigrarProcessos"
        Me.MigrarProcessos.RightToLeftAutoMirrorImage = True
        Me.MigrarProcessos.Size = New System.Drawing.Size(101, 22)
        Me.MigrarProcessos.Text = "Migrar Processos"
        '
        'CmbAdvogados
        '
        Me.CmbAdvogados.Name = "CmbAdvogados"
        Me.CmbAdvogados.Size = New System.Drawing.Size(250, 25)
        '
        'Grade
        '
        Me.Grade.FormattingEnabled = True
        Me.Grade.Location = New System.Drawing.Point(0, 29)
        Me.Grade.Name = "Grade"
        Me.Grade.Size = New System.Drawing.Size(625, 251)
        Me.Grade.TabIndex = 1
        '
        'Frm_Migracao
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(625, 280)
        Me.Controls.Add(Me.Grade)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Name = "Frm_Migracao"
        Me.Text = "frm_Migracao"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents ConectarGCPJ As System.Windows.Forms.ToolStripButton
    Friend WithEvents MigrarProcessos As System.Windows.Forms.ToolStripButton
    Friend WithEvents Grade As System.Windows.Forms.ListBox
    Friend WithEvents CmbAdvogados As System.Windows.Forms.ToolStripComboBox
End Class
