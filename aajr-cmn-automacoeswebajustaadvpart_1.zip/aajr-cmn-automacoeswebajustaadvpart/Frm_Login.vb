﻿
Imports System.Data.OleDb
Imports System.Windows.Forms
Public Class Frm_Login
    Dim AbrirSistema As Boolean = False


    Private Sub Frm_Login_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Login.Text = Environment.UserName   'identifica o usuario logado
        'Senha.Focus()
        SendKeys.Send("{Tab}")
        Senha.Text = ""
        SenhaAtual.Text = ""
    End Sub



    Private Sub Frm_Login_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If AbrirSistema = True Then
            FRM_Principal.Visible = True
        Else
            End
        End If

    End Sub

    Private Sub BTOk_Click(sender As System.Object, e As System.EventArgs) Handles BTOk.Click
        Dim VarSenha As String = vbNull

        'Consistencias
        If Palheta.SelectedTab.Name = "TabPage1" Then
            If Senha.TextLength < 1 Then
                MsgBox("Senha Inválida.", vbInformation)
                Exit Sub
            End If
            VarSenha = Senha.Text

        ElseIf Palheta.SelectedTab.Name = "TabPage2" Then
            If SenhaAtual.TextLength < 1 Or NovaSenha.TextLength < 1 Or NovaSenhaConfirmacao.TextLength < 1 Then
                MsgBox("Favor Preencher todas as senhas.", vbInformation)
                Exit Sub
            End If
            If NovaSenha.Text <> NovaSenhaConfirmacao.Text Then 'by davila
                MsgBox("Confirmação de Senha não Confere.", vbCritical)
                Exit Sub
            End If
            If NovaSenha.Text = "1234" Then 'by davila
                MsgBox("A senha deve ser diferente de 1234", vbCritical)
                Exit Sub
            End If
            VarSenha = SenhaAtual.Text
        End If

        'Abrindo tela de usuarios
        Dim vsql As String
        vsql = ("select  LOGIN, senha from TB_USUARIOS  where LOGIN = '" & Environment.UserName & "'")
        Dim Conexao2 As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Cadastro_Consultoria_Negocios.mdb")
        Conexao2.Open()
        Dim Cmd As New OleDbCommand(vsql, Conexao2)
        Dim DR As OleDbDataReader
        DR = Cmd.ExecuteReader
        DR.Read()

        'Verificando se usuario existe
        If DR.HasRows = False Then
            MsgBox("Usuário não habilitado no Sistema!", vbCritical)
            Exit Sub
        End If

        'validando senha
        If DR.Item("senha") <> VarSenha Then
            MsgBox("Senha não Confere", vbInformation)
            Palheta.Focus()
            Senha.Focus()
            Exit Sub
        End If

        DR.Close()

        'verificando se a senha é 1234
        If Palheta.SelectedIndex = 0 And VarSenha = "1234" Then
            MsgBox("Atenção..  A senha deve ser alterada no primeiro acesso.", vbInformation)
            Palheta.SelectedIndex = 1
            SenhaAtual.Text = 1234
            SenhaAtual.Focus()
            Exit Sub
        End If

        'Trocando Senha
        If Palheta.SelectedTab.Name = "TabPage2" Then
            Cmd.CommandText = ("UPDATE TB_USUARIOS SET Senha = '" & NovaSenha.Text & "'" & _
            " WHERE LOGIN = '" & Environment.UserName & "'")
            Cmd.ExecuteNonQuery()
            MsgBox("Senha Alterada com Sucesso!", vbInformation)
        End If
        AbrirSistema = True
        Me.Close()
    End Sub

    Private Sub BTCancelar_Click(sender As System.Object, e As System.EventArgs) Handles BTCancelar.Click
        Me.Close()
    End Sub



End Class