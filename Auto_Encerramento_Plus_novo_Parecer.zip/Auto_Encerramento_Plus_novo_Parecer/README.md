<div align="center">

<img src="docs/readme/header.svg" alt="Auto Encerramento Parecer: inclui no GCPJ a solicitação de encerramento por liquidação, a partir de uma base no Access" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: C#" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET 4.8" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="base: Access" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o robô lê os processos que já estão carregados no banco Access e, um por um, faz o encerramento (ou o depósito complementar) no GCPJ, deixando anotado na coluna OBS o que aconteceu.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 3 opções de processamento; 5.000 processos por execução (Controle S5); 13 textos fixos de OBS explicados; no máximo 5 envolvidos por processo" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Base no Access BD_DADOS.accdb ➜ 2 Tipo Processamento: ENCERRAMENTO, ACORDOS ou COMPLEMENTAR ➜ 3 Robô com Controle S5 ➜ 4 GCPJ no Internet Explorer ➜ 5 Resultado na coluna OBS e linha marcada como feita" width="100%">
</picture>

### As três opções

Na tela, a opção é escolhida no campo **Tipo Processamento**.

| Opção | Tabela que o robô lê | O que faz no GCPJ | Como marca a linha |
| :--- | :--- | :--- | :---: |
| **ENCERRAMENTO** | `TB_ENCERRAMENTO` | Encerra o processo: motivo, classificação e envolvidos. Quando o motivo é **1 (acordo)** ou **2 (liquidação)**, também lança o depósito, a composição dos valores e o IR isento | `ENCERRADO` + `OBS` |
| **ACORDOS** | `TB_ACORDOS` | O mesmo passo a passo do ENCERRAMENTO, só que lendo a tabela de acordos | `ENCERRADO` + `OBS` |
| **COMPLEMENTAR** | `TB_COMPLEMENTAR` | Lança um depósito avulso complementar: tipo, finalidade, forma de pagamento, valor e composição | `PROCESSADO` + `OBS` |

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `Auto_Encerramento_Plus_novo_Parecer` |
| **Código no inventário** | `C@KM` · Auto Encerramento Parecer |
| **Finalidade (inventário)** | Realizar a inclusão da solicitação de encerramento por liquidação no GCPJ |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em C# Windows Forms, .NET Framework 4.8 |
| **Sistema que altera** | GCPJ, pelo Internet Explorer |
| **Entrada** | Tabelas `TB_ENCERRAMENTO`, `TB_ACORDOS` ou `TB_COMPLEMENTAR` do banco Access |
| **Saída** | Coluna `OBS` + `ENCERRADO` (ou `PROCESSADO`) na mesma tabela |
| **Base local** | `BD_DADOS.accdb`, ao lado do executável (banco com senha) |
| **Onde fica instalado** | `\\mz-vv-fs-140\d4040_1\Publico\BackUp_Sistemas\Compartilhado\Controle_Parecer\Novo_Sistema\Encerramento_Parecer\` |
| **Versão na tela** | 1.1.3 (barra de baixo da janela) |
| **Controle S5** | Até **5.000 processos por execução**, por máquina |

> [!NOTE]
> **Não confunda.** O mesmo código roda em dois aplicativos: `C@KJ` (Auto Encerramento, repositório `Auto_Encerramento_Plus_novo`) e `C@KM` (Auto Encerramento Parecer, repositório `Auto_Encerramento_Plus_novo_Parecer`). Já o repositório `aajr-cmn-aprovadepositos-auto` (Aprova Depósitos, `C@JX`) também tem uma pasta chamada `Auto_Encerramento_Plus`, mas é **outro aplicativo**, com outro código.

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Carregar a base no BD_DADOS.accdb ➜ 2 Escolher o tipo ENCERRAMENTO, ACORDOS ou COMPLEMENTAR ➜ 3 Distribuir máquinas (opcional) ➜ 4 Conectar no GCPJ ➜ 5 Processar (até 5.000 por execução) ➜ 6 Conferir a OBS no Access" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Carregue os processos na tabela certa do `BD_DADOS.accdb` (a que fica ao lado do executável). O robô **não importa planilha**: ele lê direto do banco |
| **2** | No campo **Tipo Processamento**, escolha `ENCERRAMENTO`, `ACORDOS` ou `COMPLEMENTAR` |
| **3** | *(opcional)* Digite a **quantidade** de máquinas no campo *Maquina* e clique em **Distribuir Maquinas**. Depois, em cada máquina, digite o **número dela** (1, 2, 3...) |
| **4** | Clique em **Conectar GCPJ** e faça login no Internet Explorer que abrir. Preencha também *Login* e *Password*: o robô usa esses campos para se reconectar sozinho se o IE der erro |
| **5** | Clique em **Processar** e acompanhe pela grade. Se passar de 5.000, o robô para sozinho e avisa (Controle S5) |
| **6** | Abra o `BD_DADOS.accdb` no Access e confira a coluna **OBS** da tabela do tipo escolhido |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e como montar a base</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com **Internet Explorer** e acesso ao GCPJ
- **Microsoft Access Database Engine** (provedor ACE OLEDB 12.0)
- **Access**, para carregar a base e conferir o resultado

**ENCERRAMENTO e ACORDOS** (`TB_ENCERRAMENTO` / `TB_ACORDOS`). O robô lê as colunas **pela posição**, então a ordem abaixo importa:

| Coluna | Exemplo | Regra |
| :--- | :--- | :--- |
| `GCPJ` | `123456789` | Número do processo no GCPJ |
| `CODIGO_MOTIVO` | `1` | `1` = acordo, `2` = liquidação. Outro código encerra sem depósito e marca todos os envolvidos |
| `CODIGO_CLASSIFICACAO` | `2` | Código da classificação na tela de encerramento |
| `ENCERRADO` | `Não` | `Não` = pendente. O robô marca `Sim` quando termina a linha |
| `OBS` | (vazio) | Onde o robô escreve o resultado |
| `MAQUINA` | `1` | Preenchido pelo *Distribuir Maquinas* |
| `VALOR_TOTAL` | `2300` | Valor base do encerramento e valor do depósito |
| `TIPO_DEPOSITO` | `JUDICIAL` | `JUDICIAL`, `CREDITO EM CONTA`, `TED-DEP JUDICIAL`, `CHEQUE` ou `CHEQUE-DEP JUDICIAL` |
| `CODIGO_BANCO`, `ID` | `1`, 18 caracteres | `ID` é obrigatório com 18 caracteres quando o tipo é `JUDICIAL` |
| `AGENCIA`, `TIPO_CONTA`, `CONTA`, `DIGITO` | `CORRENTE` | Para crédito em conta. `TIPO_CONTA`: `CORRENTE`, `POUPANCA` ou outro |
| `PRINCIPAL`, `CUSTAS`, `HONORARIOS DE SUCUMBENCIA`, `HONORARIOS PERICIAIS`, `IR`, `JUROS` | `2300` | Composição do depósito. Valor `0` não é lançado |
| `QTDE_ENVOLVIDOS` | `1` | Mais de 5 o robô não encerra. Mais de 1, nos casos com depósito, ele encerra os demais como solucionado |
| `NOME`, `CPF`, `FILIAL`, `DIGI` | | Envolvido do processo. No acordo (motivo 1), o robô marca o envolvido pelo `NOME` |
| `FAVORECIDO` | `AUTOR` ou `OUTROS` | Usado no acordo com TED ou crédito em conta e na transferência entre contas |
| `NOME_FAV`, `CPF_FAV`, `FILIAL_FAV`, `DIGI_FAV` | `FILIAL_FAV` = `0` | Dados do favorecido `OUTROS`. `FILIAL_FAV` = `0` quer dizer pessoa física |
| `FORMA_PAGAMENTO` | `TRANSF.ENTRE CONTAS` | Só esse valor muda o caminho do robô |

**COMPLEMENTAR** (`TB_COMPLEMENTAR`). Os textos precisam ser **iguais** aos da lista (mesmas letras e espaços):

| Coluna | Valores aceitos |
| :--- | :--- |
| `GCPJ`, `VALOR`, `BANCO`, `N_ID` | Número do processo, valor do depósito, banco e número do documento (`N_ID` não é usado em `CHEQUE DEP JUDICIAL`) |
| `TIPO_DEPOSITO` | `DEPOSITO CREDITO EM CONTA` ou `GARANTIA DE EXECUCAO` |
| `FINALIDADE` | `LIQUIDACAO - CIVEL`, `ACORDO - CIVEL DIVERSOS`, `COMPL LIQUIDACAO - CIVEL DIVERSOS` ou `EMBARGOS - CIVEL DIVERSOS` |
| `FORMA_PAGAMENTO` | `CHEQUE DEP JUDICIAL`, `TED-DEP JUDICIAL`, `TITULO PUBLICO` ou `TRANSF.ENTRE CONTAS` |
| `TIPO_COMPOSICAO`, `VALOR_COMPOSICAO` | Uma linha por composição, repetindo `GCPJ` e `VALOR`: `PRINCIPAL`, `CUSTAS`, `HONORARIOS SUCUMBENCIA`, `HONORARIOS PERICIAIS`, `IR`, `JUROS` ou um dos tipos de `MULTA` |
| `PROCESSADO`, `OBS`, `MAQUINA` | `PROCESSADO` = `Não` para pendente |

> [!TIP]
> O campo **Maquina** tem dois usos: no *Distribuir Maquinas* ele é a **quantidade** de máquinas; no *Processar* ele é o **número desta máquina**. Cada máquina só trata as linhas com o número dela na coluna `MAQUINA`. Escolha o **Tipo Processamento** antes de distribuir: cada tipo distribui a sua própria tabela.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** para cada processo, o robô escreve na coluna **OBS** o que aconteceu. Então, quando chega uma RO sobre um processo, a resposta quase sempre já está escrita ali, na tabela do tipo que foi usado.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um processo ➜ 2 Abrir o BD_DADOS.accdb na tabela do tipo usado ➜ 3 Ler a coluna OBS ➜ resultado verde (deu certo, nada a fazer), amarelo (alguém precisa olhar) ou vermelho (corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que o processo 123456789 não foi encerrado. Na `TB_ENCERRAMENTO`, a OBS desse processo diz `NRO DO ID JUDICIAL INCORRETO`. Pelo quadro vermelho, isso quer dizer que o `ID` do depósito judicial não tem 18 caracteres. Basta corrigir o `ID`, voltar a linha para pendente e rodar de novo.

#### 🟢 Deu certo: não precisa fazer nada

| O que está escrito na OBS | O que quer dizer |
| :--- | :--- |
| Texto do GCPJ com **Encerramento efetuado com sucesso** | O GCPJ confirmou o encerramento (processo sem depósito) |
| ENCERRADOS APENAS OS DEMAIS ENVOLVIDOS DO PROCESSO, POIS O PRINCIPAL JÁ ESTAVA ENCERRADO COM CUSTOS | O principal já estava encerrado; o robô encerrou os outros envolvidos |
| Mensagem de confirmação do GCPJ (texto livre) | Nos casos com depósito e no COMPLEMENTAR, o robô copia para a OBS a mensagem que o GCPJ mostrou ao salvar. Se o texto for de confirmação, terminou |

#### 🟡 Precisa que alguém olhe

| O que está escrito na OBS | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| PROCESSO JA ENCERRADO | O GCPJ mostrou um alerta logo na pesquisa do processo, e o robô entende que já está encerrado | Conferir no GCPJ. Também aparece se o número do processo estiver errado |
| JÁ EXISTEM ENVOLVIDOS ENCERRADOS PARA O PROCESSO | Algum envolvido já estava encerrado; o robô não mexeu | Conferir e concluir manualmente |
| JÁ EXISTEM ENVOLVIDOS EM ENCERRAMENTO PARA O PROCESSO | Já existe um encerramento em andamento | Concluir manualmente no GCPJ |
| MAIS DE 5 ENVOLVIDOS NO PROCESSO! | Trava de segurança: o robô não encerra processo com mais de 5 envolvidos | Fazer manualmente |
| NÃO É POSSIVEL ENCERRAR PENDENCIA DE VALORES | O GCPJ pediu uma pendência de valores que o robô não trata | Resolver a pendência e rodar de novo |
| NÃO É POSSIVEL ENCERRAR PENDENCIA DE DATA DO FATO GERADOR | Pendência de data do fato gerador. **Aqui o robô para a execução inteira**, não só este processo | Resolver a pendência e clicar em **Processar** de novo |
| DOCUMENTO AUTOR DIVERGENTE NO GCPJ | Acordo com favorecido `AUTOR`. Pode aparecer mesmo sem divergência (ver *Pontos de atenção*) | Conferir no GCPJ se o depósito entrou |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que está escrito na OBS | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| NRO DO ID JUDICIAL INCORRETO | O `ID` do depósito judicial não tem 18 caracteres | Corrigir a coluna `ID` |
| ERRO AO INCLUIR O DEPOSITO | O GCPJ recusou o depósito na hora de incluir | Conferir banco, valor, `ID` e conta |
| CONTA NAO LOCALIZADA | Na transferência entre contas, a conta e o dígito da base não aparecem na lista de contas do favorecido | Conferir `CONTA` e `DIGITO` |
| DADOS NAO LOCALIZADOS NO CNSE | O CPF do favorecido `OUTROS` não foi achado no CNSE | Conferir `CPF_FAV`, `DIGI_FAV` e `NOME_FAV` |
| TIPO FAVORECIDO INVALIDO | A coluna `FAVORECIDO` não é `AUTOR` nem `OUTROS` | Corrigir a coluna |
| Mensagem de erro do GCPJ (texto livre)<br>OBS vazia com a linha marcada como feita | O GCPJ deu erro ao incluir ou salvar (o texto é copiado), ou não mostrou mensagem nenhuma | Ler a mensagem, conferir o processo no GCPJ e corrigir |
| **Só COMPLEMENTAR:** OBS vazia e `PROCESSADO` = Não | O robô achou um problema (processo não abriu, ou tipo de depósito, finalidade ou forma de pagamento com texto diferente da lista), mas anotou em outra tabela (ver *Pontos de atenção*). Na grade aparece *"Processo ... já encerrado"* | Conferir `TIPO_DEPOSITO`, `FINALIDADE`, `FORMA_PAGAMENTO` e o número do processo |

> [!IMPORTANT]
> **Para rodar de novo, a linha precisa voltar a ficar pendente.** No ENCERRAMENTO e no ACORDOS, o robô marca `ENCERRADO` em toda linha que passou por ele (até nas que deram erro) e não mexe nela de novo. Antes, confira no GCPJ em que pé o processo ficou: nos erros de depósito, o robô já tinha clicado em *Encerrar*. Depois, no Access:
> ```sql
> UPDATE TB_ENCERRAMENTO SET ENCERRADO = FALSE, OBS = NULL WHERE GCPJ = 123456789;
> ```
> Para ACORDOS, troque a tabela por `TB_ACORDOS`. No COMPLEMENTAR a coluna é outra: `UPDATE TB_COMPLEMENTAR SET PROCESSADO = FALSE, OBS = NULL WHERE GCPJ = 123456789;`

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| *Selecione um tipo de processamento!* | Nada escolhido em *Tipo Processamento* | Escolher a opção |
| *Informe um número válido* | Campo *Maquina* vazio ou com letra | Digitar o número |
| Janela de erro do .NET ao clicar em **Processar** | GCPJ não conectado, ou o banco (ou a tabela do tipo escolhido) não foi achado | Clicar em **Conectar GCPJ** antes. Conferir se o `BD_DADOS.accdb` está ao lado do executável e tem a tabela |
| O provedor *Microsoft.ACE.OLEDB.12.0* não está registrado | Falta o Access Database Engine | Instalar o Access Database Engine |
| *ATENÇÃO! Campo Login não informado* (ou *Password*) | O botão **Conectar GCPJ Completo** precisa de login e senha | Preencher os dois campos |
| *Caso com pendencia de GFIP... desenvolver...* | Pendência de GFIP, que o robô não trata. A execução para | Tratar o processo manualmente e rodar de novo |
| *Reentrada! ... Verificar qual pendencia está sendo exibida* | O robô tentou mais de 10 vezes liberar as pendências do processo | Ver no GCPJ qual pendência está aberta |
| Janela grande com erro do banco durante o COMPLEMENTAR | Falha ao gravar no Access (por exemplo, a tabela `TB_INCLUSAO` não existe) | Clicar OK e ver *Pontos de atenção* |
| O robô parece travado | Ele fica esperando uma mensagem do GCPJ (*Mensagem da página da web*) ou a janela de login do Windows | Ver se tem janela do GCPJ aberta atrás. Se não tiver, fechar e rodar de novo |
| Aviso **Processamento Limitado - Controle S5** | Chegou a 5.000 processos nesta execução | Normal. Rodar de novo continua de onde parou |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim. O aplicativo `C@KM` agora tem o controle nas três opções.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada processo o robô confere o contador; enquanto não chegou a 5.000, trata o processo e soma 1; ao chegar em 5.000, para, avisa o usuário e escreve na grade" width="100%">
</picture>

Quando o limite é atingido, aparece o aviso **Processamento Limitado - Controle S5** (*"O limite de processamento de 5.000 registros foi atingido. Os itens restantes continuam pendentes e podem ser processados em uma nova execução."*) e a grade mostra *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*. O que sobrou continua pendente para a próxima execução. No COMPLEMENTAR, depois do aviso ainda aparece o *PROCESSAMENTO FINALIZADO COM SUCESSO!* de sempre.

O que conta no limite:

- **ENCERRAMENTO e ACORDOS:** cada processo lido da tabela conta, mesmo os que param numa verificação (já encerrado, mais de 5 envolvidos). Quando o robô reabre o IE e tenta de novo o mesmo processo, ele **não** conta duas vezes.
- **COMPLEMENTAR:** linhas seguidas com o mesmo `GCPJ` e `VALOR` (composições do mesmo depósito) contam como **um** processo.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `LimitadorS5.cs` | constante `LIMITE_OPERACOES`, linha 27 |
| Mensagem do aviso | `LimitadorS5.cs` | método `LimiteAtingido`, linha 36 |
| Texto da grade | `LimitadorS5.cs` | método `MensagemLog`, linha 48 |
| Checagem do ENCERRAMENTO e ACORDOS | `Form1.cs` | `encerramento()`, bloco `[S5]` na linha 1124 |
| Checagem do COMPLEMENTAR | `Form1.cs` | `complementar()`, bloco `[S5]` na linha 1490 |

> [!TIP]
> Para testar sem esperar 5.000 processos: troque `LIMITE_OPERACOES` para `2`, rode com 3 linhas pendentes, tire os prints com o relógio do Windows aparecendo e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra todos os pontos. As evidências oficiais estão em [`docs/Evidencias_S5_AutoEncerramentoParecer.docx`](docs/Evidencias_S5_AutoEncerramentoParecer.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `Auto_Encerramento_Plus\Auto_Encerramento_Plus.csproj`

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `Form1.cs` | `btnConectar_Click` | 20 | Acha um IE com "GCPJ" no título ou abre o GCPJ |
| | `Form1_Load` | 37 | Põe as três opções no *Tipo Processamento* |
| | `btnProcessar_Click` | 53 | ENCERRAMENTO e ACORDOS vão para `encerramento()`; o resto, para `complementar()` |
| | `solicitarEncerramento` | 76 | Depósito, IR isento e composição (motivo 1 ou 2) |
| | `atualizatabela` | 757 | Decide entre `TB_ENCERRAMENTO` e `TB_ACORDOS` |
| | `encerrarDemais` | 770 | Encerra os outros envolvidos (motivo 25, classificação 81) |
| | `atualizaSucumbencia` / `atualizaEvento` | 810 / 825 | Tratam as pendências de sucumbência e de resumo de eventos |
| | `btnDistribuir_Click` | 938 | Chama a distribuição da tabela do tipo escolhido |
| | `ChamaGCPJ` / `cmdGCPJCompleto_Click` | 1018 / 1040 | Abrem o GCPJ e fazem login com *Login* e *Password* (o botão **Conectar GCPJ Completo** fecha o IE antes) |
| | `encerramento` | 1078 | Opções **ENCERRAMENTO** e **ACORDOS** |
| | `complementar` | 1436 | Opção **COMPLEMENTAR** |
| | `retornaDataPagamento` | 1636 | Data do depósito do COMPLEMENTAR |
| | `depositoComplementar`, `tipoPagamento`, `tipoFinalidade`, `tipoDeposito` | 1695 a 1766 | Traduzem o texto da base para o código do GCPJ |
| | `distribuirEncerramento`, `distribuirComplementar`, `distribuirAcordos` | 1811 / 1859 / 1916 | Repartem as linhas pendentes entre as máquinas (rodízio 1, 2, 3...) |
| `Automacao.cs` | `localizarJanela` / `localizarJanelaURL` / `novaJanela` | 60 / 74 / 87 | Acha ou abre o IE |
| | `navegar`, `setaValorNome`, `clicar`, `espera` | 116 a 262 | Comandos básicos de tela |
| | `mataMsgBox` / `lerMsgBox` / `mataPossivelMsgBox` | 302 / 317 / 353 | Leem e fecham os alertas do GCPJ |
| | `elementoAtivo_Capiroto` | 659 | Diz se um botão está **desabilitado** |
| | `localizaValorTabela` / `selecionarTabela` / `clicaContaTabela` | 889 / 921 / 980 | Procuram valores nas tabelas da tela |
| | `acessarSistema` | 1205 | Preenche a janela *Segurança do Windows* |
| `Conexao.cs` | `con` | 12 | Caminho do banco: `BD_DADOS.accdb` ao lado do `.exe` |
| `ClsVersion.cs` | `VersionGIT` | 11 | Versão mostrada na tela (1.1.3) |
| `LimitadorS5.cs` | `LIMITE_OPERACOES` | 27 | Controle S5 |

</details>

<details>
<summary><b>Como cada opção funciona por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>

**ENCERRAMENTO e ACORDOS** (`encerramento()`)

1. Lê da tabela as linhas com `ENCERRADO = FALSE` e `MAQUINA` igual ao número digitado.
2. Abre a tela de encerramento (`traEncerrEncerProce`) e pesquisa o processo. Se o GCPJ mostrar alerta, grava *PROCESSO JA ENCERRADO*.
3. Escolhe o motivo (`CODIGO_MOTIVO`) e a classificação (`CODIGO_CLASSIFICACAO`). Se `QTDE_ENVOLVIDOS` > 5, para ali.
4. Marca os envolvidos: motivo 1 marca a linha com o `NOME`; motivo 2 marca só o primeiro; os outros motivos marcam todos.
5. Se a tabela da tela já mostra `ENCERRADO`, `EM ENCERRAMENTO` ou `BAIXADO`, grava a OBS correspondente (no `BAIXADO`, encerra os demais envolvidos).
6. Clica em *Salvar*. Se o botão *Encerrar* ficar liberado, clica nele. Se não, trata as pendências na ordem em que aparecem: resumo de eventos, sucumbência e CPF são preenchidos; pendência de valores encerra a tentativa daquele processo; data do fato gerador e GFIP param a execução inteira. Depois de 10 voltas sem liberar, também para tudo.
7. **Motivo 1 ou 2:** `solicitarEncerramento` informa o valor base (`VALOR_TOTAL`), o IR isento, a data do depósito (amanhã, pulando fim de semana e os feriados da `SYS_FERIADOS`), a finalidade (26 acordo, 25 liquidação), a forma de pagamento conforme `TIPO_DEPOSITO` ou `FORMA_PAGAMENTO`, e a composição (`PRINCIPAL` a `JUROS`, só os diferentes de zero). Salva e copia a mensagem do GCPJ para a OBS. Se `QTDE_ENVOLVIDOS` > 1, chama `encerrarDemais`.
8. **Outros motivos:** lê a mensagem do GCPJ. Se tiver *Encerramento efetuado com sucesso*, grava na OBS.
9. Nos processos sem depósito, se aparecer uma janela *ERRO!* do IE (ou nenhuma mensagem depois do *Encerrar*), o robô fecha o IE, abre e loga de novo com *Login* e *Password* e recomeça o mesmo processo.

**COMPLEMENTAR** (`complementar()`)

1. Lê a `TB_COMPLEMENTAR` com `PROCESSADO = FALSE` e a `MAQUINA` digitada.
2. Pula as linhas seguidas com o mesmo `GCPJ` e `VALOR` (elas entram como composição do mesmo depósito).
3. Abre a tela de depósito avulso (`finDepositoNovoAlteracaoAction`), pesquisa o processo e fecha a janela de depósitos anteriores.
4. Traduz `TIPO_DEPOSITO`, `FINALIDADE` e `FORMA_PAGAMENTO` para os códigos do GCPJ. Texto que não está na lista faz o robô pular a linha.
5. Preenche banco, data (hoje + 2 dias, pulando fim de semana e feriados), valor e `N_ID` (menos no `CHEQUE DEP JUDICIAL`).
6. Inclui uma composição para cada linha com o mesmo `GCPJ` e `VALOR`.
7. Na finalidade `LIQUIDACAO - CIVEL`, passa pela tela de IR (valor bruto, IR e base do IR, que vira o `VALOR` se estiver 0,00). Nas outras, clica em *Salvar*.
8. Copia a mensagem do GCPJ para a OBS e marca `PROCESSADO` em todas as linhas daquele `GCPJ` e `VALOR`.
9. No fim, mostra *PROCESSAMENTO FINALIZADO COM SUCESSO!*.

</details>

<details>
<summary><b>Banco de dados</b> &nbsp;·&nbsp; tabelas do Access que o código usa</summary>
<br>

| Objeto | Tipo | Conteúdo |
| :--- | :--- | :--- |
| `TB_ENCERRAMENTO` | Tabela | Posições 0 a 30: `GCPJ`, `CODIGO_MOTIVO`, `CODIGO_CLASSIFICACAO`, `ENCERRADO`, `OBS`, `MAQUINA`, `VALOR_TOTAL`, `TIPO_DEPOSITO`, `CODIGO_BANCO`, `ID`, `AGENCIA`, `TIPO_CONTA`, `CONTA`, `DIGITO`, `PRINCIPAL`, `CUSTAS`, `HONORARIOS DE SUCUMBENCIA`, `HONORARIOS PERICIAIS`, `IR`, `JUROS`, `QTDE_ENVOLVIDOS`, `NOME`, `CPF`, `FILIAL`, `DIGI`, `FAVORECIDO`, `NOME_FAV`, `CPF_FAV`, `FILIAL_FAV`, `DIGI_FAV`, `FORMA_PAGAMENTO` |
| `TB_ACORDOS` | Tabela | Mesmas posições da `TB_ENCERRAMENTO` (a cópia do banco tem ainda `FAV_CADASTRADO`, que o código não lê) |
| `TB_COMPLEMENTAR` | Tabela | `GCPJ`, `PRAZO_FATAL`, `TIPO_DEPOSITO`, `FINALIDADE`, `FORMA_PAGAMENTO`, `BANCO`, `VALOR`, `N_ID`, `AGENCIA`, `TIPO_CONTA`, `CONTA`, `DIGITO`, `TIPO_COMPOSICAO`, `VALOR_COMPOSICAO`, `PROCESSADO`, `OBS`, `MAQUINA` |
| `SYS_FERIADOS` | Tabela vinculada | Dia e mês dos feriados, usados na data do depósito |
| `TB_INCLUSAO` | Tabela citada no código | Recebe as falhas do COMPLEMENTAR. Não existe nas cópias do banco que estão no repositório |

As posições foram conferidas na cópia `bin\Debug\BD_DADOS_BKP.accdb`. A cópia `bin\Debug\BD_DADOS.accdb` versionada é mais antiga: não tem a `TB_ACORDOS` nem as colunas `FAVORECIDO` a `FORMA_PAGAMENTO`. O banco que vale é o da pasta de instalação.

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `LimitadorS5.cs` ➜ `LIMITE_OPERACOES` |
| Mudar as opções do *Tipo Processamento* | `Form1.cs` ➜ `Form1_Load`, `btnProcessar_Click` e `btnDistribuir_Click` |
| Mudar a tabela lida pelo ACORDOS | `Form1.cs` ➜ `atualizatabela` e `encerramento` |
| Mudar a data do depósito (ENCERRAMENTO e ACORDOS) | `Form1.cs` ➜ `solicitarEncerramento`, linha 117 (hoje + 1 dia) |
| Mudar a data do depósito (COMPLEMENTAR) | `Form1.cs` ➜ `retornaDataPagamento`, linha 1642 (hoje + 2 dias) |
| Aceitar um novo texto de depósito, finalidade, pagamento ou composição | `Form1.cs` ➜ `tipoDeposito`, `tipoFinalidade`, `tipoPagamento`, `depositoComplementar` |
| Mudar o limite de 5 envolvidos | `Form1.cs` ➜ `encerramento`, linha 1163 |
| Mudar o endereço do GCPJ | `Form1.cs` ➜ procure `intranet85.net.bradesco.com.br/gcpj` |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **COMPLEMENTAR grava as falhas na tabela errada.** Nas linhas 1517, 1531, 1544 e 1557 do `Form1.cs`, quando o processo não abre ou quando `TIPO_DEPOSITO`, `FINALIDADE` ou `FORMA_PAGAMENTO` não estão na lista, o robô faz `UPDATE TB_INCLUSAO SET INCLUIDO = TRUE, OBS = ...` em vez de atualizar a `TB_COMPLEMENTAR`. Resultado: a linha fica com OBS vazia e `PROCESSADO` = Não, volta em toda execução e conta de novo no limite S5; a grade mostra *"Processo ... já encerrado"*, o que não é verdade; e, como a `TB_INCLUSAO` não existe nas cópias do banco do repositório, o `Conexao.executar` (linha 65 do `Conexao.cs`) pode abrir uma janela de erro e deixar o robô parado até alguém clicar OK. Veio do commit de 06/2023. A correção é trocar por `UPDATE TB_COMPLEMENTAR SET PROCESSADO = TRUE, OBS = '...'` com o mesmo `WHERE GCPJ ... and VALOR ...`.
- **Acordo com favorecido AUTOR, por TED ou crédito em conta (linhas 286 a 303).** O `if` que conferia o documento foi comentado e o `else` ficou preso ao `if` da mensagem do GCPJ. Por isso, quando o *Incluir* dá certo (sem mensagem), o robô grava *DOCUMENTO AUTOR DIVERGENTE NO GCPJ* e sai sem lançar a composição nem salvar.
- **Liquidação com TED ou crédito em conta:** o clique em *Incluir* está comentado na linha 463. Vale testar se o depósito entra nesse caminho.
- **Encerramento confirmado por alerta não é gravado.** Nas linhas 1218 a 1222, se o GCPJ mostrar uma mensagem logo depois do *Salvar*, o robô considera sucesso mas não grava nada no banco. A linha continua pendente e, na próxima execução, cai em *PROCESSO JA ENCERRADO*.
- **A grade diz "processado com sucesso!" para quase tudo** (linha 1430), inclusive processos que pararam em erro. Quem diz o resultado é a OBS.
- **Algumas pendências param a execução inteira:** data do fato gerador (linha 1359), GFIP (linha 1320) e mais de 10 voltas nas pendências (linha 1367) usam `return`, não `continue`.
- **Colunas lidas pela posição** (`GetString(27)`, `GetDouble(6)`...). Se alguém mudar a ordem das colunas no Access, o robô lê o campo errado sem avisar.
- **SQL montado por concatenação.** Uma mensagem do GCPJ com aspas simples quebra o `UPDATE` das linhas 744 e 1622, e a OBS não é gravada.
- **O robô pode esperar para sempre** por uma mensagem do GCPJ (`mataMsgBox`, linha 302 do `Automacao.cs`) ou pela janela *Segurança do Windows* (`acessarSistema`, linha 1205).
- **A senha do banco está escrita no código** (`Conexao.cs`, linha 12) e versionada.
- **Código local mais novo que o Git.** O último commit é de 06/2023. A opção ACORDOS, a transferência entre contas, a data do depósito em 1 dia (RO 2611103), a volta para `intranet85` e o Controle S5 estão na pasta, mas não foram commitados.
- As pastas `bin` e `obj` estão versionadas (com cópias do banco); elas são geradas na compilação.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 04/2023 senha no banco Access; 06/2023 opção COMPLEMENTAR; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: corrigir a TB_INCLUSAO" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 12/2022 | I424252 | Opção de depósito do tipo cheque |
| 02/2023 | Pedro Cosmo | Link do GCPJ (`intranet85` para `intranet8`) e versão 1.1.2 com correção de bug |
| 04/2023 | JHONATAS VELIS | Senha na conexão com o Access |
| 06/2023 | Pedro Cosmo | Opção **COMPLEMENTAR** (pagamento complementar), correção no encerramento e fluxo da `LIQUIDACAO - CIVEL` |
| Sem data no Git | Não registrado | Opção **ACORDOS**, transferência entre contas, volta para `intranet85` e data do depósito em 1 dia (comentário da RO 2611103, Gabriel Vasconcellos Gomes) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LimitadorS5.cs`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
