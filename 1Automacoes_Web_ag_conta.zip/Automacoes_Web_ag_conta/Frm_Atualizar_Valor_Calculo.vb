﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices



Public Class Frm_Atualizar_Valor_Calculo


    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Atualizacao_Valor_Calculo.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Atualizar_Valor_Calculo_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click

        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        Grade.Items.Add("Conexão Efetuada!")
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Rotina_Alteracao()
        'Rotina_Cadastro()
    End Sub


    Private Sub preencheGrade(ByVal vTexto As String)
        Grade.Items.Add(Date.Now & " - " & vTexto)
        Grade.SelectedIndex = Grade.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()

    End Sub

    Private Sub Rotina_Alteracao()
        Dim VsQl As String = ""

Inicio:
        VsQl = "select * from TB_Atualizacao_Calculo where IMPORTADO = false order by gcpj"
        
        Dim Encontrou As Boolean = False
        Dim elemCollection As Object = Nothing
        Dim Contagem As Double = 0


        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1


            preencheGrade("PROCESSO: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)

            'Verificando horario após as 22 e aguardando um período de 4 horas
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 21:50:00" Then
                preencheGrade("Horário após as 22:00")
                Dim Vdata As Date = Date.Now
EsperandoRestart:
                If DateDiff(DateInterval.Hour, Vdata, Date.Now) < 6 Then
                    preencheGrade("Aguardando intervalo de 6 horas..")
                    Thread.Sleep(600000)
                    GoTo EsperandoRestart
                Else
                    GoTo INICIO
                End If
            End If

            System.Windows.Forms.Application.DoEvents()

            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/traTraCpmisAtulzValorCalcAction?acao=carregar")
            Espera_Ate_Que_Abra_Public(objIndex)



            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'procura (22 - VALOR DO RISCO - CI)
            If TB.Rows(index)("vlr_risco").ToString <> 0 Then
                Encontrou = False
                Contagem = 0
                elemCollection = objIndex.Document.Forms(0).getElementsByTagName("TR")
                For Each obj In elemCollection
                    If InStr(obj.innertext, "22 - VALOR DO RISCO - CI") > 0 And Contagem > 13 Then
                        objIndex.Document.Forms(0).elements("selecionados")(Contagem - 16).Checked = True
                        Encontrou = True
                        Exit For
                    Else
                        Contagem += 1
                        Encontrou = False
                    End If
                Next

                If Encontrou = False Then 'caso não encontrou então cadastra o valor de Risco
                    preencheGrade("Criando Valor de Risco")

                    objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 22
                    Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
                    Espera_Ate_Que_Abra_Public(objIndex)

                    objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(TB.Rows(index)("DT_CALCULO_RISCO").ToString, DateFormat.ShortDate)
                    objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_RISCO").ToString, 2)
                    objIndex.Document.Forms(0).elements("btoCalcular").Click()
                    Espera_Ate_Que_Abra_Public(objIndex)

                Else 'Penas altes os dados
                    preencheGrade("Alterando Valor de Risco")
                    'Clica em Alterar
                    objIndex.Document.Forms(0).elements("btoAlterar").Click()
                    Espera_Ate_Que_Abra_Public(objIndex)
                    objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(TB.Rows(index)("DT_CALCULO_RISCO").ToString, DateFormat.ShortDate)
                    objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_RISCO").ToString, 2)
                    objIndex.Document.Forms(0).elements("btoCalcular").Click()
                    Espera_Ate_Que_Abra_Public(objIndex)

                End If


                'verifica se realmente o valor selecionado é o valor de risco
                'If objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").value <> 22 Then
                'MsgBox("O Valor selecionado não é o valor de Risco")
                'Exit Sub
                'End If

                objIndex.Document.Forms(0).elements("btoIncluir").Click()
                Espera_Ate_Que_Abra_Public(objIndex)

                'Verifica se a Tela Limpou
                'If Len(objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").value) > 0 Then
                'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
                'End If
            End If


            'Thread.Sleep(3000)
            'Espera_Ate_Que_Abra_Public(objIndex)

            'pocura (21 - VALOR DO PEDIDO - CI)
            'If TB.Rows(index)("vlr_Pedido").ToString <> 0 Then
            '    Encontrou = False
            '    Contagem = 0
            '    elemCollection = objIndex.Document.Forms(0).getElementsByTagName("TR")
            '    For Each obj In elemCollection
            '        If InStr(obj.innertext, "21 - VALOR DO PEDIDO - CI") > 0 And Contagem > 13 Then
            '            objIndex.Document.Forms(0).elements("selecionados")(Contagem - 16).Checked = True
            '            Encontrou = True
            '            Exit For
            '        Else
            '            Contagem += 1
            '            Encontrou = False
            '        End If
            '    Next

            '    If Encontrou = False Then 'caso não encontrou então cadastra o valor de Risco
            '        preencheGrade("Criando Valor de Pedido")
            '        objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 21
            '        Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
            '        Espera_Ate_Que_Abra_Public(objIndex)

            '        objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            '        objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("vlr_Pedido").ToString, 2)
            '        objIndex.Document.Forms(0).elements("btoCalcular").Click()
            '        Espera_Ate_Que_Abra_Public(objIndex)

            '    Else 'Penas altes os dados
            '        preencheGrade("Alterando Valor de Pedido")
            '        'Clica em Alterar
            '        objIndex.Document.Forms(0).elements("btoAlterar").Click()
            '        Espera_Ate_Que_Abra_Public(objIndex)
            '        objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            '        objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("vlr_Pedido").ToString, 2)
            '        objIndex.Document.Forms(0).elements("btoCalcular").Click()
            '        Espera_Ate_Que_Abra_Public(objIndex)

            '    End If

            '    objIndex.Document.Forms(0).elements("btoIncluir").Click()
            '    Espera_Ate_Que_Abra_Public(objIndex)
            'End If


            ''Altera valor da Causa
            'If TB.Rows(index)("vlr_causa").ToString <> 0 Then
            '    Encontrou = False
            '    Contagem = 0
            '    elemCollection = objIndex.Document.Forms(0).getElementsByTagName("TR")
            '    For Each obj In elemCollection
            '        If InStr(obj.innertext, "17 - VALOR DA CAUSA - CI") > 0 And Contagem > 13 Then
            '            Try
            '                objIndex.Document.Forms(0).elements("selecionados")(Contagem - 16).Checked = True
            '            Catch ex As Exception
            '                objIndex.Document.Forms(0).elements("selecionados").Checked = True 'caso tenha somente 1 na lista
            '            End Try

            '            Encontrou = True
            '            Exit For
            '        Else
            '            Contagem += 1
            '            Encontrou = False
            '        End If
            '    Next

            '    If Encontrou = False Then 'caso não encontrou então cadastra o valor de Risco
            '        preencheGrade("Criando Valor da causa")
            '        objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 17
            '        Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
            '        Espera_Ate_Que_Abra_Public(objIndex)

            '        objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            '        objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("vlr_causa").ToString, 2)
            '        objIndex.Document.Forms(0).elements("btoCalcular").Click()
            '        Espera_Ate_Que_Abra_Public(objIndex)

            '    Else 'Penas altes os dados
            '        preencheGrade("Alterando Valor da Causa")
            '        'Clica em Alterar
            '        objIndex.Document.Forms(0).elements("btoAlterar").Click()
            '        Espera_Ate_Que_Abra_Public(objIndex)
            '        objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            '        objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("vlr_causa").ToString, 2)
            '        objIndex.Document.Forms(0).elements("btoCalcular").Click()
            '        Espera_Ate_Que_Abra_Public(objIndex)

            '    End If

            '    objIndex.Document.Forms(0).elements("btoIncluir").Click()
            '    Espera_Ate_Que_Abra_Public(objIndex)
            'End If


            'FINALIZANDO
            preencheGrade("Salvando...")
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoSalvar").Click()
            Thread.Sleep(2000)
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou

            Try
                Dim ValorTeste As String
                ValorTeste = objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext()
                If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            Catch ex As Exception
            End Try

            cmd.CommandText = "update TB_Atualizacao_Calculo set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

            Grade.Items.Clear()

        Next
        MsgBox("Acabou!")

    End Sub

    Private Sub Rotina_Cadastro()
        Dim VsQl As String

        VsQl = "select * from TB_Atualizacao_Calculo where IMPORTADO = false  order by gcpj"


        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1

            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            System.Windows.Forms.Application.DoEvents()

            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/traTraCpmisAtulzValorCalcAction?acao=carregar")
            Espera_Ate_Que_Abra_Public(objIndex)

            'AppActivate("(GCPJ) Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")

            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo e Pesquisando Processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)


            'inserindo Valor Pedido
            objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 21
            Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_PEDIDO").ToString, 2)
            objIndex.Document.Forms(0).elements("btoCalcular").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("btoIncluir").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").value) > 0 Then
            '    If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If


            'inserindo Valor rISCO
            objIndex.Document.Forms(0).elements("cdTipoCalculadoProcesso").innertext = 22
            Call objIndex.Document.parentWindow.execScript("obterTipoCalculo()", "JavaScript")
            Espera_Ate_Que_Abra_Public(objIndex)

            objIndex.Document.Forms(0).elements("dtOriginalValorCalculo").innertext = FormatDateTime(Date.Now, DateFormat.ShortDate)
            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("VLR_Risco").ToString, 2)
            objIndex.Document.Forms(0).elements("btoCalcular").Click()
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.Forms(0).elements("btoIncluir").Click()
            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").value) > 0 Then
            '    If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If


            objIndex.Document.Forms(0).elements("btoSalvar").Click()


            Espera_Ate_Que_Abra_Public(objIndex)

            'Verifica se a Tela Limpou
            'If Len(objIndex.Document.Forms(0).elements("cdTipoAcao").value) > 0 Then
            'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
            'End If

            cmd.CommandText = "update TB_Atualizacao_Calculo set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()
        Next
        MsgBox("Acabou!")

    End Sub

    


End Class