﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices

Public Class Frm_Alterar_Procs_CI


    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb")
    Dim objIndex As SHDocVw.InternetExplorer
    'Dim objIndex2 As SHDocVw.InternetExplorer = Nothing


    Private Sub Frm_Alterar_Procs_CI_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function
    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        If FecharThread = True Then
            MsgBox("Inicie o procedimento ClickYes", vbInformation)
            Exit Sub
        End If

        Dim vsql As String

        vsql = "select  * from Processos_CI where importado = false  ORDER BY gcpj "

        Dim DA As New OleDbDataAdapter(vsql, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        If TB.Rows.Count = 0 Then
            MsgBox("Não encontrado nenhum processo para a importação", vbCritical)
            Exit Sub
        End If

        Grade.Items.Add(Date.Now & "   Abrindo Tela de alteração")
        Grade.SelectedIndex = Grade.Items.Count - 1

        Dim VarGCPJ As String = ""
        Dim VarGCPJ_ANTIGO As String = ""

        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            Espera_Ate_Que_Abra_Public(objIndex)

            'Alimentando Grade de Status
            Grade.Items.Add(Date.Now & " Alterando Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  GCPJ: " & TB.Rows(index)("gcpj").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()


            'PESQUISANDO PROCESSO
            objIndex.Document.Forms(0).elements("nrProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()
            Espera_Ate_Que_Abra_Public(objIndex)



            '1ª tela
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra_Public(objIndex)



            'TELA 2 CLASSIFICAÇÃO
            objIndex.Document.Forms(0).elements("Submit32").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra_Public(objIndex)



            'TELA 3 Autor
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 4 Reu

            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 5 Audiencia
            objIndex.Document.Forms(0).elements("cboAudiencia").focus()
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 6 Documentos
            objIndex.Document.Forms(0).elements("dsDocumentoExcepcional").focus()
            objIndex.Document.Forms(0).elements("btoContinuar").Click() ' Continuar
            Espera_Ate_Que_Abra_Public(objIndex)

            'Tela 7 Anexos
            objIndex.Document.Forms(0).elements("nmDocumento").focus()
            objIndex.Document.Forms(0).elements("Submit32").Click() ' Continuar

            Espera_Ate_Que_Abra_Public(objIndex)


            'Tela 8 Resumo
InserirResumo:
            Try
                Thread.Sleep(1000)
                objIndex.Document.Forms(0).elements("dsResumo").innertext = TB.Rows(index)("RESUMO").ToString
                Espera_Ate_Que_Abra_Public(objIndex)
            Catch ex As Exception
                GoTo InserirResumo
            End Try


            objIndex.Document.Forms(0).elements("button2").Click() ' SALVAR PROCESSO
            Thread.Sleep(1000)

            Espera_Ate_Que_Abra_Public(objIndex)

            'CONSISTENCIA COM gcpj PARA VERIFICAR SE A TELA MUDOU
            VarGCPJ_ANTIGO = VarGCPJ
            'IDENTIFICANDO GCPJ


            'If MsgBox("O Registro foi salvo com sucesso?" & vbCrLf & "GCPJ salvo por último: " & VarGCPJ, vbQuestion + vbYesNo) <> vbYes Then Exit Sub

            cmd.CommandText = "update Processos_CI set importado = true, obs = '' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
            cmd.ExecuteNonQuery()

            'If MsgBox("Deseja ir para o proximo?", vbQuestion + vbYesNo) <> vbYes Then Exit Sub

        Next

        MsgBox("Acabou", vbInformation)
    End Sub

End Class