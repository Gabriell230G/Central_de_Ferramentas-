﻿Module Mod_Variaveis
    Public FecharThread As Boolean = False
    Public IDLogin = Environment.UserName   'identifica o usuario logado
End Module
