﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices


Public Class Frm_Migracao


    Dim objIndex As SHDocVw.InternetExplorer
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Migracao.mdb")



    Private Sub ConectarGCPJ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ConectarGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/")
            objIndex.Visible = True
            Exit Sub
        End If
        ConectarGCPJ.Enabled = False
        MigrarProcessos.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub MigrarProcessos_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MigrarProcessos.Click
        Dim vRegistros As Integer
        Dim vContador As Integer
        Dim vCursor As Integer

        'Abrindo Tabela
        Dim VsQl As String
        VsQl = "select * from tbMigracao where MIGRADO = false order by GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        vRegistros = TB.Rows.Count

        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/disMigracaoMassaAction?acao=carregar")
        objIndex.Visible = True

        'AGUARDANDO CARREGAR
        Espera_Ate_Que_Abra_Public(objIndex)

        For vContador = 0 To vRegistros - 1 Step 1
forIni:

            Grade.Items.Add(Date.Now & " Processo: " & vContador + 1 & " Faltam mais " & TB.Rows.Count - vContador & "  -  " & TB.Rows(vContador)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'SELECIONANDO REGIONAL DE ORIGEM
            For I = 0 To 100
                Try
                    objIndex.Document.Forms(0).elements("selDependencia")(I).SELECTED = True
                    Espera_Ate_Que_Abra_Public(objIndex)
                    If objIndex.Document.Forms(0).elements("selDependencia")(I).innertext = TB.Rows(vContador)("NOM_DEJUR_ORIGEM").ToString Then
                        Exit For
                    End If
                Catch ex As Exception
                    MsgBox("Regional de Origem não encontrado na listagem. Regional: '" & TB.Rows(vContador)("NOM_DEJUR_ORIGEM").ToString & "'", vbCritical)
                    Exit Sub
                End Try
            Next
            objIndex.Document.forms(0).elements("selDependencia").onChange()


            'seleciona Area Civel (## procediemnto não obrigatório)
            'Espera_Ate_Que_Abra_Public(objIndex)
            'objIndex.Document.forms(0).elements("selArea")(3).selected = True
            'objIndex.Document.forms(0).elements("selArea").onchange()

            'Seleciona Classificação Por Processo (## JÁ TRAZ AUTOMARICO POR PROCESSO)
            'Espera_Ate_Que_Abra_Public(objIndex)
            'objIndex.Document.forms(0).elements("selClassificacao")(3).selected = True
            'objIndex.Document.forms(0).elements("selClassificacao").onchange()

            '

            'Inserindo número do Processo
            Espera_Ate_Que_Abra_Public(objIndex)
            objIndex.Document.forms(0).elements("cdNumeroProcessoBradesco").innerText = TB.Rows(vContador)("GCPJ").ToString
            objIndex.Document.forms(0).elements("selSituacao")(0).selected = True
            objIndex.Document.forms(0).elements("selSituacao").onchange()


            'selecionando situação
            objIndex.Document.forms(0).elements("selSituacao")(2).selected = True
            objIndex.Document.forms(0).elements("selSituacao").onChange()


            ''selecionando Regional
            'Espera_Ate_Que_Abra_Public(objIndex)
            'objIndex.Document.forms(0).elements("selDependenciaDestino")(6).selected = True
            'objIndex.Document.forms(0).elements("selDependenciaDestino").onChange()
            'SELECIONANDO REGIONAL DE Destino
            For I = 0 To 100
                Try
                    objIndex.Document.Forms(0).elements("selDependenciaDestino")(I).SELECTED = True
                    Espera_Ate_Que_Abra_Public(objIndex)
                    If objIndex.Document.Forms(0).elements("selDependenciaDestino")(I).innertext = TB.Rows(vContador)("NOM_DEJUR_DESTINO").ToString Then
                        Exit For
                    End If
                Catch ex As Exception
                    MsgBox("Regional de Origem não encontrado na listagem. Regional: '" & TB.Rows(vContador)("NOM_DEJUR_DESTINO").ToString & "'", vbCritical)
                    Exit Sub
                End Try
            Next
            objIndex.Document.forms(0).elements("selDependenciaDestino").onChange()

            'AGUARDANDO CARREGAR

            Espera_Ate_Que_Abra_Public(objIndex)
            vCursor = 0

            Do Until vCursor = 99
                Try
                    objIndex.Document.forms(0).elements("selAdvogadoChefeDestino")(vCursor).selected = True
                    objIndex.Document.forms(0).elements("selAdvogadoChefeDestino").onchange()

                    If objIndex.Document.forms(0).elements("nmAdvogadoChefeInstanciaDestino").value = TB.Rows(vContador)("ADVOGADO").ToString Then
                        'If objIndex.Document.forms(0).elements("nmAdvogadoChefeInstanciaDestino").value = "EDILENE DE LIMA PEREIRA" Then
                        vCursor = 99
                        Exit Do
                    End If
                    vCursor += 1
                Catch ex As Exception

                    MsgBox("Advogado: " & TB.Rows(vContador)("ADVOGADO").ToString & " não encontrado na lista de Advogados Chefe.  PROCESSAMENTO PARADO", vbInformation)
                    Exit Sub
                    'If Conexao.State = ConnectionState.Closed Then Conexao.Open()
                    'Dim Cmd As New OleDbCommand("UPDATE tbMigracao SET MIGRADO = true, OBS = 'ADVOGADO NAO LOCALIZADO' WHERE GCPJ = " & TB.Rows(vContador)("GCPJ"), Conexao)
                    'Cmd.ExecuteNonQuery()
                    'vContador += 1
                    'GoTo forIni

                End Try
            Loop

            'AGUARDANDO CARREGAR
            Espera_Ate_Que_Abra_Public(objIndex)

            'CONSISTENCIA AO SALVAR
            'SELECIONADO POR PROCESSO
            If objIndex.Document.forms(0).elements("selClassificacao").value = 5 Then
                'SALVANDO
                objIndex.Document.forms(0).elements("btoSalvar").click()
            Else
                'VOLTANDO AO MESMO PROCESSO
                'CLICANDO EM LIMPAR
                objIndex.Document.forms(0).elements("btoLimpar").click()
                'AGUARDANDO CARREGAR
                Espera_Ate_Que_Abra_Public(objIndex)
                'ATUALIZANDO GRADE
                Grade.Items.Add("REPROCESSANDO REGISTRO: " & TB.Rows(vContador)("GCPJ").ToString)
                Grade.SelectedIndex = Grade.Items.Count - 1
                System.Windows.Forms.Application.DoEvents()
                'VOLTANDO...
                GoTo forIni
            End If

            'AGUARDANDO(CARREGAR)
            Espera_Ate_Que_Abra_Public(objIndex)

            'aguardando
            Thread.Sleep(1000)

            Espera_Ate_Que_Abra_Public(objIndex)


            If Conexao.State = ConnectionState.Closed Then
                Conexao.Open()
            End If

            Dim Cmd3 As New OleDbCommand("UPDATE tbMigracao SET MIGRADO = true, OBS = 'MIGRADO COM SUCESSO' WHERE GCPJ = " & TB.Rows(vContador)("GCPJ"), Conexao)
            Cmd3.ExecuteNonQuery()

        Next


        MsgBox("Foi", vbExclamation)

    End Sub




End Class
