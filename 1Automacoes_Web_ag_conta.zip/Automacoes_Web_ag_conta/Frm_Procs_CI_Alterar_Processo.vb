﻿Imports System.Data.OleDb
Imports System.Threading

Public Class Frm_Procs_CI_Alterar_Processo
    Dim VarFundamento As String
    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Altera_Procs_CI.mdb")
    Dim objIndex As SHDocVw.InternetExplorer



    Private Sub Frm_Procs_CI_Alterar_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True

        Grade.Items.Add("Conexão Efetuada!")
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        'Abrindo Tabela
        Dim VsQl As String
        VsQl = "select  * from ALTERACAO where ALTERADO = false   order by GCPJ"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")

        Espera_Ate_Que_Abra_Public(objIndex)

        Thread.Sleep(1000)
        Try
            AppActivate("(GCPJ) Gestão Controle de Processos Jurídicos - Windows Internet Explorer")
        Catch ex As Exception

        End Try

        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
forIn:
            Grade.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()



            '"#### Tela de Pesquisa
            objIndex.Document.Forms(0).elements("nrProcessoBradesco").innertext = TB.Rows(index)("GCPJ").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click() ' lupa do bt salvar
            Espera_Ate_Que_Abra_Public(objIndex)

            ''DATA DO FATO GERADOR
            'objIndex.Document.Forms(0).elements("dtFatoGeradorProcessoCivel").innertext = FormatDateTime(TB.Rows(index)("DATA_FATO_GERADOR").ToString, DateFormat.ShortDate) 'dejur
            'Espera_Ate_Que_Abra_Public(objIndex)


            'VALOR DA CAUSA
            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").innertext = FormatNumber(TB.Rows(index)("Vlr_causa").ToString, 2)
            objIndex.Document.Forms(0).elements("vrOriginalCalculoProcesso").onblur()
            Espera_Ate_Que_Abra_Public(objIndex)

            'SALVANDO
            objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
            Espera_Ate_Que_Abra_Public(objIndex)

            Thread.Sleep(1000)

            'Força uma digitação no GCPJ da tela de pesquisa para verificar deu algum erro
            Espera_Ate_Que_Abra_Public(objIndex)
            Try
                objIndex.Document.Forms(0).elements("nrProcessoBradesco").innertext = 0
                cmd.CommandText = "update ALTERACAO set ALTERADO = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                cmd.CommandText = "update ALTERACAO set ALTERADO = true, obs = 'Erro ao Salvar Processo'  where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
                Espera_Ate_Que_Abra_Public(objIndex)
                Thread.Sleep(1000)
                'MsgBox("Erro ao salvar Processo")
                'Exit Sub
            End Try

        Next

    End Sub

End Class