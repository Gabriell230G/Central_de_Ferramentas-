﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Imports ADODB
Imports System.Text
Imports excel = Microsoft.Office.Interop.Excel
Imports System.IO

Public Class Frm_Distribuicao

    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Distribuicao.mdb" & ";Jet OLEDB:Database Password=portal2007")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Distribuicao_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()

        AlimentarDadosNormais()
        AlimentarDadosDivergentes()
        Me.WindowState = FormWindowState.Maximized

    End Sub

    Private Sub AlimentarDadosNormais()
        Dim VsQl2 As String = " select GCPJ, COD_INTERNO, NOME_INTERNO, COD_ESCRITORIO, NOME_ESCRITORIO, LOGIN" & _
            " from tb_distribuicao " & _
            " where importado = false and (obs is null or obs = '') and login = " & SQL_Texto(IDLogin) & _
            " order by GCPJ"

        GradeProcessos.DataSource = Nothing
        GradeProcessos.Rows.Clear()
        GradeProcessos.Columns.Clear()

        Dim DA2 As New OleDbDataAdapter(VsQl2, Conexao)
        Dim TB2 As New DataTable()
        TB2.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA2.Fill(TB2)
        BindingSource1.DataSource = TB2
        GradeProcessos.DataSource = BindingSource1
        GradeProcessos.Refresh()

        'AutoSize em todas as colunas
        GradeProcessos.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
        DA2.Dispose()
        TB2.Dispose()
    End Sub
    Private Sub AlimentarDadosDivergentes()
        Dim VsQl2 As String = " select OBS AS INCONSISTÊNCIA, GCPJ, COD_INTERNO, NOME_INTERNO, COD_ESCRITORIO, NOME_ESCRITORIO, LOGIN" & _
    " from tb_distribuicao " & _
    " where importado = false and (obs  is not null and obs <> '') and login = " & SQL_Texto(IDLogin)

        GradeDivergente.DataSource = Nothing
        GradeDivergente.Rows.Clear()
        GradeDivergente.Columns.Clear()

        Dim DA2 As New OleDbDataAdapter(VsQl2, Conexao)
        Dim TB2 As New DataTable()
        TB2.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA2.Fill(TB2)
        GradeDivergente.DataSource = TB2
        GradeDivergente.Refresh()

        If TB2.Rows.Count > 0 Then
            GradeDivergente.Visible = True
        Else
            GradeDivergente.Visible = False
        End If

        'AutoSize em todas as colunas
        GradeDivergente.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells)
        DA2.Dispose()
        TB2.Dispose()



    End Sub


    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        MsgBox("Conexão Efetuada!", vbInformation)
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim GCPJAnterior As Double = 0

        If FecharThread = True Then
            MsgBox("Inicie o Procedimento ClickYes")
            Exit Sub
        End If


        If GradeDivergente.RowCount > 0 Then
            MsgBox("Foram encontradas inconsistências na última importação. O sistema só permite o processamento se nenhuma inconsistência for encontrada!", vbInformation)
            Exit Sub
        End If

        'Abrindo Tabela
        Dim DA As New OleDbDataAdapter("select * from TB_Distribuicao where importado = false and login = " & SQL_Texto(IDLogin) & " order by gcpj ", Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)

        If TB.Rows.Count = 0 Then
            MsgBox("Não existe Processo a ser distribuído.", vbInformation)
            Exit Sub
        End If


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/disDistribuicaoAction?acao=carregar")
        Espera_Ate_Que_Abra_Public(objIndex)

        'selecionando area de consulta
        Try
            For I = 1 To 100
                If objIndex.Document.Forms(0).elements("selAreaConsulta")(I).INNERTEXT = "CIVEL" Then
                    objIndex.Document.Forms(0).elements("selAreaConsulta")(I).SELECTED = True
                    objIndex.Document.Forms(0).elements("selAreaConsulta").onchange()
                    Exit For
                End If
            Next
        Catch ex As Exception
            MsgBox("Área CIVEL não está disponível no GCPJ", vbCritical)
            Exit Sub
        End Try


        objIndex.Document.Forms(0).elements("btoPesquisar").Click()
        AppActivate("GCPJ - Gestão e Controle de Processos Jurídicos - Windows Internet Explorer")
        Espera_Ate_Que_Abra_Public(objIndex)


        For index = 0 To TB.Rows.Count - 1

            'Verificando horario após as 22 e aguardando um período de 4 horas
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                GradeAndamento.Items.Add("Horário após as 22:00")
                GradeAndamento.SelectedIndex = GradeAndamento.Items.Count - 1
                Dim Vdata As Date = Date.Now
EsperandoRestart:
                If DateDiff(DateInterval.Hour, Vdata, Date.Now) < 4 Then
                    GradeAndamento.Items.Add(Date.Now & "  Aguardando intervalo de 4 horas..")
                    GradeAndamento.SelectedIndex = GradeAndamento.Items.Count - 1
                    Thread.Sleep(600000)
                    GoTo EsperandoRestart
                End If
            End If

            'Verificando se o GCPJ é duplicado
            If GCPJAnterior = TB.Rows(index)("gcpj").ToString Then
                GradeAndamento.Items.Add("GCPJ Duplicado na Planilha")
                cmd.CommandText = "update TB_Distribuicao set importado = true, OBS = 'GCPJ Duplicado na Planilha' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
                GoTo fim
            End If

            GCPJAnterior = TB.Rows(index)("gcpj").ToString

            GradeAndamento.Items.Add(Date.Now & " Processo: " & index + 1 & " Faltam mais " & TB.Rows.Count - index & "  -  " & TB.Rows(index)("GCPJ").ToString)
            GradeAndamento.SelectedIndex = GradeAndamento.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Adcionando numero do processo
            objIndex.Document.Forms(0).elements("cdNumeroProcessoBradesco").innertext = TB.Rows(index)("gcpj").ToString
            objIndex.Document.Forms(0).elements("btoPesquisar").Click()

            'MataPossivelMsgbox()

            Espera_Ate_Que_Abra_Public(objIndex)


            objIndex.Document.Forms(0).elements("cdAdvogadoInternoBradesco").innertext = TB.Rows(index)("cod_interno").ToString
            objIndex.Document.Forms(0).elements("cdPessoaExternaBradesco").innertext = "" & TB.Rows(index)("COD_ESCRITORIO").ToString


            objIndex.Document.Forms(0).elements("selectAll").checked = True
            objIndex.Document.Forms(0).elements("selectAll").onclick()

            objIndex.Document.Forms(0).elements("btoSalvar").Click()

            'Thread.Sleep(5000)
            'SendKeys.Send("{Enter}")

            'MataMsgbox()

            Espera_Ate_Que_Abra_Public(objIndex)



            'Verifica se a Tela Limpou
            If Len(objIndex.Document.Forms(0).elements("cdAdvogadoInternoBradesco").value) > 0 Then
                'If MsgBox("A Tela não limpou. Deseja Continuar?", vbYesNo) <> vbYes Then Exit Sub
                GradeAndamento.Items.Add("A TELA NÃO LIMPOU")
                cmd.CommandText = "update TB_Distribuicao set importado = true, OBS = 'A TELA NÃO LIMPOU' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            Else
                cmd.CommandText = "update TB_Distribuicao set importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            End If

            AlimentarDadosNormais()
fim:
        Next
        GradeAndamento.Items.Add(Date.Now & " - Processo Finalizado!")
        GradeAndamento.SelectedIndex = GradeAndamento.Items.Count - 1
        DA.Dispose()
        TB.Dispose()
    End Sub

    Private Sub BTImportar_Click(sender As System.Object, e As System.EventArgs) Handles BTImportar.Click
        GradeAndamento.Items.Clear()
        Dim VarCaminhoPlanilha As String
        OpenFileDialog1.Title = "Importar Planilha 1"
        OpenFileDialog1.FileName = ""
        OpenFileDialog1.Filter = "Excel 2007 / 2010|*.xlsx"

        OpenFileDialog1.ShowDialog()

        If OpenFileDialog1.FileName = "" Then Exit Sub

        'MOVENDO ARQUIVO PARA PASTA DE PLANILHAS IMPORTADAS nos meus documentos
        Try
            MkDir("C:\Users\" & IDLogin & "\Documents\Planilhas_Distribuicao")
        Catch ex As Exception
        End Try

        VarCaminhoPlanilha = "C:\Users\" & IDLogin & "\Documents\Planilhas_Distribuicao\" & Year(Date.Now) & "_" & Month(Date.Now).ToString.PadLeft(2, "0") & "_" & Microsoft.VisualBasic.Day(Date.Now).ToString.PadLeft(2, "0") & "_" & Hour(Date.Now).ToString.PadLeft(2, "0") & Minute(Date.Now).ToString.PadLeft(2, "0") & Second(Date.Now).ToString.PadLeft(2, "0") & ".xlsx"

        Try
            File.Copy(OpenFileDialog1.FileName, VarCaminhoPlanilha)
        Catch ex As Exception
            MsgBox("Erro ao mover planilha para meus Documentos. Inicie o processo novamente", vbCritical)
            Exit Sub
        End Try

        If MsgBox("Atenção, durante este procedimento todas as planilhas em excel serão automaticamente fechadas." & vbCrLf & "Deseja continuar?", vbYesNo + vbInformation) <> vbYes Then Exit Sub


        GradeAndamento.Items.Add("Importando Planilha em Excel.    Aguarde!")
        GradeAndamento.SelectedIndex = GradeAndamento.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()

        'limpando tabela
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao
        cmd.CommandText = "delete * from tb_distribuicao where login = " & SQL_Texto(IDLogin)
        cmd.ExecuteNonQuery()


        'VERIFICA SE ALGUM ARQUIVO EM EXCELL ESTÁ ABERTO
        'Verifica se o sistema já está aberto para pode-lo maximizar
        For Each p In Process.GetProcesses
            If UCase(p.ProcessName) = "EXCEL" Then
                For Each p2 In Process.GetProcesses
                    If UCase(p2.ProcessName) = "EXCEL" Then
                        p2.Kill()
                    End If
                Next
            End If
        Next

        GradeProcessos.DataSource = Nothing
        GradeDivergente.DataSource = Nothing

        If ImportarParaGrade(VarCaminhoPlanilha) = False Then
            MsgBox("Erro na importação da planilha!", vbCritical)
            GradeAndamento.Items.Clear()
            Exit Sub
        End If

        If GradeProcessos.RowCount = 0 Then
            MsgBox("Planilha Vazia!", vbCritical)
            GradeAndamento.Items.Clear()
            Exit Sub
        End If

        'MAPA DAS COLUNAS
        'GradeProcessos.Rows(index).Cells(0).Value  gcpj                A
        'GradeProcessos.Rows(index).Cells(1).Value  cod adv             B
        'GradeProcessos.Rows(index).Cells(2).Value  nome adv            C
        'GradeProcessos.Rows(index).Cells(3).Value  cod escritorio      D
        'GradeProcessos.Rows(index).Cells(4).Value  nome escritorio     E


        'consistencias básicas
        For index = 0 To GradeProcessos.RowCount - 1
            If Not IsNumeric(GradeProcessos.Rows(index).Cells(0).Value.ToString) Then
                MsgBox("Atenção. A coluna A (GCPJ) possui registros não numéricos. Favor fazer o acerto na planilha e importar novamente!", vbCritical)
                GradeAndamento.Items.Clear()
                Exit Sub
            End If

            If Not IsNumeric(GradeProcessos.Rows(index).Cells(3).Value.ToString) Then
                MsgBox("Atenção. A coluna D (Código Contratado) possui registros não numéricos. Favor fazer o acerto na planilha e importar novamente!", vbCritical)
                GradeAndamento.Items.Clear()
                Exit Sub
            End If

            If Len(GradeProcessos.Rows(index).Cells(1).Value.ToString) = 0 Then
                MsgBox("Atenção. A coluna B (Código Advogado) possui registros em branco. Favor fazer o acerto na planilha e importar novamente!", vbCritical)
                GradeAndamento.Items.Clear()
                Exit Sub
            End If

        Next

        'IMPORTANDO PARA O BANCO
        Dim vSqL As String = ""
        Dim vDATA As Date = Date.Now


        For index = 0 To GradeProcessos.RowCount - 1
            'acrescenta como Importado = True  pois somente após as inconsistencias o importado ficará false
            vSqL = "insert into tb_distribuicao (GCPJ, COD_INTERNO, NOME_INTERNO, COD_ESCRITORIO, NOME_ESCRITORIO, login, importado) values " & _
            "(" & SQL_Numero(GradeProcessos.Rows(index).Cells(0).Value.ToString()) & _
            "," & SQL_Texto(GradeProcessos.Rows(index).Cells(1).Value.ToString()) & _
            "," & SQL_Texto(GradeProcessos.Rows(index).Cells(2).Value.ToString()) & _
            "," & SQL_Numero(GradeProcessos.Rows(index).Cells(3).Value.ToString()) & _
            "," & SQL_Texto(GradeProcessos.Rows(index).Cells(4).Value.ToString()) & _
            "," & SQL_Texto(IDLogin) & _
            ",true" & _
            ")"


            Try
                cmd.CommandText = vSqL
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                'se deu erro na importação, então limpa o que já foi importado
                MsgBox(vSqL)
                MsgBox("Erro ao importar esta planilha! Inicie a importação novamente." & vbCrLf & ex.Message, vbCritical)
                GradeAndamento.Items.Clear()
                Exit Sub
            End Try
        Next

        'consistencias Específicas
        GradeAndamento.Items.Add("Identificando eventuais inconsistências.   Aguarde!")
        GradeAndamento.SelectedIndex = GradeAndamento.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()



        ''Verificando se o GCPJ Existe
        'cmd.CommandText = "UPDATE TB_Distribuicao LEFT JOIN _00_Dados_Processos ON TB_Distribuicao.GCPJ = [_00_Dados_Processos].Bradesco SET TB_Distribuicao.OBS = 'GCPJ INEXISTENTE'" & _
        '                " WHERE ((([_00_Dados_Processos].Bradesco) Is Null))" & _
        '                " AND login = " & SQL_Texto(IDLogin)
        'cmd.ExecuteNonQuery()

        'vERIFICARRO ERRO DE CADASTRO PARA PROCESSOS SEM ENVOLVIDO
        'SE O PROCESSO ESTIVER SEM ENVOLVIDO, A TELA DE DISTRIBUIÇÃO DÁ ERRO
        cmd.CommandText = "UPDATE TB_Distribuicao INNER JOIN _00_Dados_Processos ON TB_Distribuicao.GCPJ = [_00_Dados_Processos].Bradesco SET TB_Distribuicao.OBS = 'PROCESSO SEM ENVOLVIDO' " & _
                        " WHERE ((([_00_Dados_Processos].Envolvido) Is Null Or ([_00_Dados_Processos].Envolvido)=''))" & _
                        " AND login = " & SQL_Texto(IDLogin)
        cmd.ExecuteNonQuery()

        'Verificando se o aDV iNTERNO Existe
        cmd.CommandText = "UPDATE TB_Distribuicao LEFT JOIN GCPJB004 ON TB_Distribuicao.COD_INTERNO = GCPJB004.CADVOG_INTERN_BDSCO SET TB_Distribuicao.OBS = 'ADV INTERNO NÃO EXISTE OU ESTÁ DESABILITADO NO GCPJ'" & _
                        " WHERE (((GCPJB004.CADVOG_INTERN_BDSCO) Is Null)) OR (((GCPJB004.DDSATV_ADVOG_BDSCO) Is Not Null))" & _
                        " AND login = " & SQL_Texto(IDLogin)
        cmd.ExecuteNonQuery()
  
        'Verificando se o aDV cONTATADO ESTÁ HABILITADO NA ÁREA ci
        cmd.CommandText = "UPDATE TB_Distribuicao SET TB_Distribuicao.OBS = 'Escritório não habilitado na área CI'" & _
                            " WHERE (((TB_Distribuicao.COD_ESCRITORIO) Not In (select CPSSOA_EXTER_BDSCO from GCPJB0A1 where CAREA_PROCS_JUDIC = 3 and CSUBDV_AREA_PROCS = 3)))" & _
                            " AND login = " & SQL_Texto(IDLogin)
        cmd.ExecuteNonQuery()

        'Verificando se o aDV cONTATADO ESTÁ HABILITADO PARA O 4429 OU 4785 Existe
        cmd.CommandText = "UPDATE TB_Distribuicao SET TB_Distribuicao.OBS = 'Escritório não habilitado para o 4785 OU 4429'" & _
                            " WHERE (((TB_Distribuicao.COD_ESCRITORIO) Not In (select CPSSOA_EXTER_BDSCO from gcpjb098 where cdepdc = 4785 or cdepdc = 4429)))" & _
                            " AND login = " & SQL_Texto(IDLogin)
        cmd.ExecuteNonQuery()


        'deixando todos os Registros pronto para o uso
        cmd.CommandText = "update tb_distribuicao set importado = false where login = " & SQL_Texto(IDLogin)
        cmd.ExecuteNonQuery()

        AlimentarDadosNormais()
        AlimentarDadosDivergentes()

        GradeAndamento.Items.Clear()
        GradeAndamento.Items.Add("Importação Efetuada com sucesso!")
        GradeAndamento.SelectedIndex = GradeAndamento.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()


    End Sub

    Function ImportarParaGrade(ByRef varCaminhoPlanilha2 As String) As Boolean
        'abrindo o Excel e alterando determinadas celulas para evitar o problema de existir algum Número com formatação de Texto
        Try
            Dim app As New excel.Application
            Dim WB As excel.Workbook = app.Workbooks.Open(varCaminhoPlanilha2)
            If WB IsNot Nothing Then
                Dim ws As excel.Worksheet = WB.Worksheets.Item(1)
                For index = 2 To 5000
                    If Len(ws.Range("A" & index).Value) = 0 Then Exit For
                    Try
                        If IsNumeric(ws.Range("A" & index).Value) Then ws.Range("A" & index).Value = ws.Range("A" & index).Value * 1
                        If IsNumeric(ws.Range("D" & index).Value) Then ws.Range("D" & index).Value = ws.Range("D" & index).Value * 1
                    Catch ex As Exception
                    End Try
                Next
                'ALTERANDO TITULOS DA COLUNA
                ws.Range("A1").Value = "GCPJ"
                ws.Range("B1").Value = "COD_ADV_BANCO"
                ws.Range("C1").Value = "NOME_ADV_BANCO"
                ws.Range("D1").Value = "COD_ADV_CONTRATADO"
                ws.Range("E1").Value = "NOME_ADV_CONTRATADO"
                ws.Name = "Plan_Distribuicao"

            End If
            WB.Save()
            WB.Close()
        Catch ex As Exception
            MsgBox(ex.Message, vbInformation)
            Return False
        End Try



        Dim da As OleDbDataAdapter
        Dim dt As DataTable
        Dim conexao_Excel As String
        Thread.Sleep(1000)
        'Importando Planilha 
        conexao_Excel = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & varCaminhoPlanilha2 & ";Extended Properties='Excel 12.0 Xml;HDR=yes;ReadOnly=False';"

        Try
            da = New OleDbDataAdapter("SELECT GCPJ, COD_ADV_BANCO, NOME_ADV_BANCO, COD_ADV_CONTRATADO, NOME_ADV_CONTRATADO  FROM [Plan_Distribuicao$] Where [GCPJ]  Is Not Null ", conexao_Excel)
            dt = New DataTable
            da.Fill(dt)
        Catch ex As Exception
            MsgBox("Erro ao Importar planilha. O Problema está relacionado ao nome da Pasta de Trabalho ou ao nome das Colunas." & vbCrLf & ex.Message, vbCritical)
            Return False
        End Try


        GradeProcessos.DataSource = Nothing
        GradeProcessos.Rows.Clear()
        GradeProcessos.Columns.Clear()
        GradeProcessos.DataSource = dt 'dt.DefaultView

        Me.GradeProcessos.AlternatingRowsDefaultCellStyle.BackColor = Color.LightCyan

        da.Dispose()
        dt.Dispose()

        Return True

    End Function




    Private Sub BTHelp_Click(sender As System.Object, e As System.EventArgs) Handles BTHelp.Click
        MsgBox("A planilha deve seguir o seguinte Layout:" & vbCrLf & vbCrLf & _
            "Coluna A: GCPJ (Somente números)" & vbCrLf & _
            "Coluna B: Cód. Adv. Interno (Código funcional com a Letra)" & vbCrLf & _
            "Coluna C: Nome Adv. Interno " & vbCrLf & _
            "Coluna D: Cód. Adv. Contratado (Somente números)" & vbCrLf & _
            "Coluna E: Nome Adv. Contratado" & vbCrLf & vbCrLf & _
            "Planilhas fora deste layout serão recusadas pelo sistema!", vbInformation)
    End Sub

    Private Sub BTRelatorio_Click(sender As System.Object, e As System.EventArgs) Handles BTRelatorio.Click

        MsgBox("Atenção.. Será exportado para o excel apenas o último processamento!", vbCritical)
        
        Dim VsQl As String = " select GCPJ, COD_INTERNO, NOME_INTERNO, COD_ESCRITORIO, NOME_ESCRITORIO, OBS, LOGIN" & _
            " from tb_distribuicao " & _
            " where importado = true and login = " & SQL_Texto(IDLogin) & _
            " order by GCPJ"

        ExportExcel(VsQl)

    End Sub

    Public Sub ExportExcel(ByVal VarSQL As String)


        Dim stcon As String = Conexao.ConnectionString
        Dim stsql As String = VarSQL
        Dim cnt As New ADODB.Connection
        Dim rst As New ADODB.Recordset
        Dim fld As ADODB.Field



        'Abre a conexão com o banco de dados
        cnt.Open(stcon)
        'Abre o recordset
        With rst
            .CursorLocation = CursorLocationEnum.adUseClient
            .Open(stsql, cnt, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly, ADODB.CommandTypeEnum.adCmdText)
            .ActiveConnection = Nothing
        End With
        'Fecha a conexão com o banco de dados
        cnt.Close()
        'Define variáveis para o Excel: Application(Excel),WorkBook(pasta de trabalho),WorkSheet(Planilha)
        'Range(intervalo de células)
        Dim xlapp As New excel.Application
        Dim xlwbook As excel.Workbook = xlapp.Workbooks.Add(excel.XlWBATemplate.xlWBATWorksheet)
        Dim xlwsheet As excel.Worksheet = CType(xlwbook.Worksheets(1), excel.Worksheet)
        Dim xlrange As excel.Range = xlwsheet.Range("A1")
        'define modo de cálculo : xlCalculationAutomatic , xlCalculationManual, xlCalculationSemiautomatic
        Dim xlcalc As excel.XlCalculation
        'Desabilita temporariamente o calculo automatico passando para manual
        With xlapp
            xlcalc = .Calculation
            .Calculation = excel.XlCalculation.xlCalculationManual
        End With
        Dim contadorCampos As Integer = Nothing

        'Escreve os nomes dos campos na planilha
        For Each fld In rst.Fields
            xlrange.Offset(0, contadorCampos).Value = fld.Name
            contadorCampos = contadorCampos + 1
        Next

        'Copia o recordset para a planilha
        xlrange.Offset(1, 0).CopyFromRecordset(rst)
        'Fecha o recordset.
        rst.Close()
        With xlapp
            .Visible = True
            .UserControl = True
            'Restaura o calculo
            .Calculation = xlcalc
        End With
        'libera os objetos
        fld = Nothing
        rst = Nothing
        cnt = Nothing
        xlrange = Nothing
        xlwsheet = Nothing
        xlwbook = Nothing
        xlapp = Nothing

    End Sub




End Class