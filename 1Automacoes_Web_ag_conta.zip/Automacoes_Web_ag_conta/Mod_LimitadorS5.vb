﻿'==============================================================================
'  CONTROLE S5 - LIMITADOR DE OPERAÇÕES
'  Normativo 05.1073 - Sistemas/Aplicativos Mantidos em Ambiente Departamental
'  Aplicativo: Controle_Depositos_BB_CaixaEconomica (C@XB)
'------------------------------------------------------------------------------
'  O QUE FAZ
'    Limita quantos depósitos o robô pode atualizar no GCPJ em UMA execução
'    (botão "Processar" da tela Frm_Altera_Ag_Conta).
'    Quando o limite é atingido:
'      1. o laço da automação para (Exit For);
'      2. o usuário recebe o aviso "Processamento Limitado - Controle S5";
'      3. os depósitos que sobraram continuam com ATUALIZADO = False na base
'         Controle_Depositos.accdb e podem ser processados numa nova execução.
'
'  COMO MUDAR O LIMITE
'    Altere SOMENTE a constante abaixo. Não precisa mexer em mais nenhum lugar.
'
'  ONDE ELE É USADO
'    Ctrl+Shift+F no Visual Studio e pesquise por "[S5]". A rotina tem:
'      - 1 linha de declaração do contador (início da Sub);
'      - 1 bloco de 3 linhas no começo do laço que mexe no GCPJ.
'==============================================================================
Module Mod_LimitadorS5

    ''' <summary>Máximo de depósitos atualizados no GCPJ por execução.</summary>
    Public Const LIMITE_OPERACOES_S5 As Integer = 5000

    ''' <summary>
    ''' Retorna True quando a execução já chegou no limite do Controle S5
    ''' e, nesse caso, avisa o usuário. Uso dentro do laço:
    '''     If LimiteS5Atingido(qtdOperacoesS5) Then Exit For
    '''     qtdOperacoesS5 += 1
    ''' </summary>
    ''' <param name="qtdOperacoes">Quantos depósitos já foram processados nesta execução.</param>
    ''' <param name="limite">Limite a aplicar (padrão: LIMITE_OPERACOES_S5).</param>
    ''' <param name="unidade">Texto usado no aviso (padrão: "depósitos").</param>
    Public Function LimiteS5Atingido(ByVal qtdOperacoes As Integer, _
                                     Optional ByVal limite As Integer = LIMITE_OPERACOES_S5, _
                                     Optional ByVal unidade As String = "depósitos") As Boolean
        If qtdOperacoes < limite Then Return False

        MsgBox("O limite de processamento de " & Format(limite, "#,##0") & " " & unidade & " foi atingido." & vbCrLf & vbCrLf & _
               "Os depósitos restantes continuam pendentes e podem ser processados em uma nova execução.", _
               vbExclamation, "Processamento Limitado - Controle S5")
        Return True
    End Function

End Module
