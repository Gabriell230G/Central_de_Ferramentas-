﻿Imports System.Data.OleDb
Imports System.Threading
Imports System.Runtime.InteropServices
Public Class Frm_Cadastro_Envolvido
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function
    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function
    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1

    Dim Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD_Cadastro_Processos_CI.mdb")
    Dim objIndex As SHDocVw.InternetExplorer

    Private Sub Frm_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub
    Private Sub BTConectaGCPJ_Click(sender As System.Object, e As System.EventArgs) Handles BTConectaGCPJ.Click
        If VerificaGCPJ() = False Then
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/")
            objIndex.Visible = True
            Exit Sub
        End If
        BTConectaGCPJ.Enabled = False
        BTProcessar.Enabled = True
        Grade.Items.Add("Conexao Efetuada")
    End Sub
    Private Function VerificaGCPJ() As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        Dim objShell As New Shell32.Shell
        For Each obj In objShell.Windows
            If TypeName(obj.Document) = "HTMLDocumentClass" Then
                If InStr(1, obj.Document.Title, "GCPJ") > 0 Then
                    objIndex = obj
                    objIndex.Visible = True
                    Return True
                    Exit For
                End If
            End If
        Next obj
        Return False
    End Function

    Private Sub Frm_Cadastro_Envolvido_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
    End Sub

    Private Sub BTProcessar_Click(sender As System.Object, e As System.EventArgs) Handles BTProcessar.Click
        Dim VsQl As String
        If CMBMaquina.ComboBox.SelectedIndex = -1 Then
            VsQl = "select  * from CADASTRO_ENVOLVIDO where importado = false  ORDER BY envolvido "
        Else
            VsQl = "select * from CADASTRO_ENVOLVIDO where importado = false and maquina = " & CMBMaquina.ComboBox.Text & "  ORDER BY envolvido "
        End If


        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        If TB.Rows.Count = 0 Then
            MsgBox("Não encontrado nenhum envolvido para cadastro", vbCritical)
            Exit Sub
        End If


        Grade.Items.Add(Date.Now & "   Abrindo Tela de Cadastro")
        Grade.SelectedIndex = Grade.Items.Count - 1

        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=filtroIncluir&paginaCorrente=pessoaExternaBradescoFiltrar&cdPessoaExternaBradesco=&cdCpfPessoaExterna=&cdControleCpfPessoaExterna=&cdCnpjPessoaExterna=&cdFilialCnpjPessoaExterna=&cdControleCnpjPessoaExterna=&nmPessoaExternaProcesso=")

        Espera_Ate_Que_Abra_Public(objIndex)


        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao

        For index = 0 To TB.Rows.Count - 1
            If Date.Now >= FormatDateTime(Date.Now, DateFormat.ShortDate) & " 22:00:00" Then
                MsgBox("Horário após as 22:00")
                Exit Sub
            End If

            'Alimentando Grade de Status
            Grade.Items.Add(Date.Now & " Inserindo Reclamante: " & index + 1 & " Faltam mais " & TB.Rows.Count - index)
            Grade.SelectedIndex = Grade.Items.Count - 1
            System.Windows.Forms.Application.DoEvents()

            'Inserindo Pessoa Fisica com CPF
            If TB.Rows(index)("tipo").ToString = "PESSOA FISICA" Then
                objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(5).Selected = True
                Call objIndex.Document.parentWindow.execScript("tratarTipoPessoa();", "JavaScript")
                'inserindo nome
                objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("envolvido").ToString
                objIndex.Document.Forms(0).elements("cdCpfPessoaExterna").innertext = TB.Rows(index)("cpf").ToString
                objIndex.Document.Forms(0).elements("cdControleCpfPessoaExterna").innertext = TB.Rows(index)("digito").ToString
            End If

            'Inserindo Pessoa Juridica com CPF
            If TB.Rows(index)("tipo").ToString = "PESSOA JURIDICA" Then
                objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(6).Selected = True
                Call objIndex.Document.parentWindow.execScript("tratarTipoPessoa();", "JavaScript")
                'inserindo nome
                objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("envolvido").ToString
                objIndex.Document.Forms(0).elements("cdCnpjPessoaExterna").innertext = TB.Rows(index)("cpf").ToString
                objIndex.Document.Forms(0).elements("cdFilialCnpjPessoaExterna").innertext = TB.Rows(index)("filial").ToString
                objIndex.Document.Forms(0).elements("cdControleCnpjPessoaExterna").innertext = TB.Rows(index)("digito").ToString

            End If

            'Inserindo Pessoa Fisica Sem CPF
            If TB.Rows(index)("tipo").ToString = "PESSOA FISICA SEM CPF" Then
                objIndex.Document.Forms(0).elements("cdTipoPessoaExterna").Item(5).Selected = True
                Call objIndex.Document.parentWindow.execScript("tratarTipoPessoa();", "JavaScript")
                objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").innertext = TB.Rows(index)("envolvido").ToString
            End If




            'Clicando no botão Salvar
            objIndex.Document.Forms(0).elements("btoSalvar").Click() ' Salvar


            Espera_Ate_Que_Abra_Public(objIndex)

            If Len(objIndex.Document.Forms(0).elements("nmPessoaExternaProcesso").Value) > 0 Then
                cmd.CommandText = "update CADASTRO_ENVOLVIDO set  importado = true, obs = 'Erro ao Cadastrar' where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            Else
                cmd.CommandText = "update CADASTRO_ENVOLVIDO set  importado = true where chave_interna = " & TB.Rows(index)("chave_interna").ToString
                cmd.ExecuteNonQuery()
            End If

            Thread.Sleep(1000)

            'X = MsgBox("O Registro foi salvo com sucesso?" & vbCrLf & "GCPJ salvo por último: " & VarGCPJ, vbQuestion + vbYesNo)
            'If X <> vbYes Then Exit Sub



            'X = MsgBox("Deseja ir para o proximo?", vbQuestion + vbYesNo)
            'If X <> vbYes Then Exit Sub

        Next

        MsgBox("Fim")
    End Sub

    Private Sub BTDistribuir_Click(sender As System.Object, e As System.EventArgs) Handles BTDistribuir.Click
        Dim VsQl As String
        VsQl = "select   * from CADASTRO_ENVOLVIDO where  importado = false   ORDER BY envolvido"
        Dim DA As New OleDbDataAdapter(VsQl, Conexao)
        Dim TB As New DataTable()
        TB.Locale = System.Globalization.CultureInfo.InvariantCulture
        DA.Fill(TB)
        Dim Maquina As String
        If TB.Rows.Count = 0 Then
            MsgBox("Nenhum Processo Encontrado", vbCritical)
            Exit Sub
        End If


        Dim totalMaquina As Double
        totalMaquina = InputBox("Informe a Quantidade de Máquina")
        Maquina = 1

        If Conexao.State = ConnectionState.Open Then Conexao.Close()
        Conexao.Open()
        Dim cmd As New OleDbCommand
        cmd.Connection = Conexao


        For index = 0 To TB.Rows.Count - 1
            cmd.CommandText = "UPDATE CADASTRO_ENVOLVIDO SET MAQUINA = " & Maquina & " WHERE CHAVE_INTERNA = " & TB.Rows(index)("CHAVE_INTERNA").ToString & " AND IMPORTADO = FALSE"
            cmd.ExecuteNonQuery()

            Maquina += 1
            If Maquina > totalMaquina Then Maquina = 1
        Next



        MsgBox("Distribuição Efetuada")
    End Sub

    Private Sub BTAlteraEnvolvido_Click(sender As System.Object, e As System.EventArgs) Handles BTAlteraEnvolvido.Click


        Dim Encontrou As Boolean = False
        Dim elemCollection As Object = Nothing
        Dim Contagem As Double = 0

        Dim vcontador As Integer = 0
        Dim vTb As New DataSet
        Dim vComando As New OleDbCommand
        Dim vCmd As New OleDbDataAdapter("SELECT * FROM TAB_ALTERA_ENVOLVIDO WHERE Alterado = FALSE order by GCPJ", Conexao)
        vCmd.Fill(vTb)





        Do While vcontador < vTb.Tables(0).Rows.Count
Inicio:
            'Try

            'TELA DE ALTERACAO ATIVOS
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcAlteracaoAction?acao=carregar&sessao=limpar&estimulo=alteracaoAtivos")
            Espera_Ate_Que_Abra_Public(objIndex)
            'PESQUISANDO
            Grade.Items.Add("Atualizando " & vTb.Tables(0).Rows(vcontador)("GCPJ").ToString & "  -  Faltam: " & vTb.Tables(0).Rows.Count - vcontador & "  -  " & vTb.Tables(0).Rows(vcontador)("envolvido").ToString & "  " & vTb.Tables(0).Rows(vcontador)("cpf").ToString & "/" & vTb.Tables(0).Rows(vcontador)("filial").ToString & "-" & vTb.Tables(0).Rows(vcontador)("digito").ToString)
            Grade.SelectedIndex = Grade.Items.Count - 1


            objIndex.Document.forms(0).elements("nrProcessoBradesco").innertext = vTb.Tables(0).Rows(vcontador)("GCPJ").ToString
            objIndex.Document.forms(0).elements("btoPesquisar").click()

            Espera_Ate_Que_Abra_Public(objIndex)
            'PRIMEIRO CONTINUAR
            objIndex.Document.forms(0).elements("btoContinuar").click()
            'SE DER ALGUM ERRO DE CONSISTENCIAS

            Espera_Ate_Que_Abra_Public(objIndex)

            'SEGUNDO CONTINUAR
            objIndex.Document.FORMS(0).ELEMENTS("Submit32").CLICK()
            'SE DER ALGUM ERRO DE CONSISTENCIAS
            Espera_Ate_Que_Abra_Public(objIndex)

            'INDO PARA A TELA REU
            objIndex.Document.FORMS(0).ELEMENTS("btoContinuar").CLICK()

            Espera_Ate_Que_Abra_Public(objIndex)


            'Deletando envolvido atual
            Try
                Thread.Sleep(2000)

                objIndex.Document.Forms(0).elements("selecionados").Checked = True
                objIndex.Document.Forms(0).elements("btoExcluir").Click()
                Espera_Ate_Que_Abra_Public(objIndex)

            Catch ex As Exception
                If MsgBox("Erro ao deletar Envonvido. delete manualmente", vbYesNo) <> vbYes Then Exit Sub
            End Try

            'inserindo Envolvido
            'verifica se é pessoa Fisica
            If Len(vTb.Tables(0).Rows(vcontador)("cpf").ToString) > 0 And (Len(vTb.Tables(0).Rows(vcontador)("filial").ToString) = 0 Or vTb.Tables(0).Rows(vcontador)("filial").ToString = 0) Then
                objIndex.Document.Forms(0).elements("tiporeu").Item(5).Selected = True
                Call objIndex.Document.parentWindow.execScript("alteraDivTipo(3,5,true);", "JavaScript")
                objIndex.Document.Forms(0).elements("dsnome").innertext = vTb.Tables(0).Rows(vcontador)("envolvido").ToString
                objIndex.Document.Forms(0).elements("cdCodigo").innertext = vTb.Tables(0).Rows(vcontador)("cpf").ToString
                objIndex.Document.Forms(0).elements("cdControle").innertext = vTb.Tables(0).Rows(vcontador)("digito").ToString
            End If

            'verifica se é pessoa Jurídica
            If Len(vTb.Tables(0).Rows(vcontador)("cpf").ToString) > 0 And Len(vTb.Tables(0).Rows(vcontador)("filial").ToString) > 0 And vTb.Tables(0).Rows(vcontador)("filial").ToString <> 0 Then
                objIndex.Document.Forms(0).elements("tiporeu").Item(6).Selected = True
                Call objIndex.Document.parentWindow.execScript("alteraDivTipo(4,5,true);", "JavaScript")
                objIndex.Document.Forms(0).elements("cdCodigo").innertext = vTb.Tables(0).Rows(vcontador)("cpf").ToString
                objIndex.Document.Forms(0).elements("cdFilial").innertext = vTb.Tables(0).Rows(vcontador)("filial").ToString
                objIndex.Document.Forms(0).elements("cdControle").innertext = vTb.Tables(0).Rows(vcontador)("digito").ToString
            End If

            objIndex.Document.Forms(0).elements("btoIncluir").Click() ' Clica em Incluir Autor
            Espera_Ate_Que_Abra_Public(objIndex)


            'verificando se o envolvido foi selecionado
            Try
                objIndex.Document.Forms(0).elements("selecionados").Checked = True
            Catch ex As Exception
                If MsgBox("Nenhum Envolvido selecionado. Selecione manulmente", vbYesNo) <> vbYes Then Exit Sub
            End Try



            'SALVANDO
            objIndex.Document.FORMS(0).ELEMENTS("btoSalvar").CLICK()
            Espera_Ate_Que_Abra_Public(objIndex)

            '############
            'Deletando Dependencia Antiga


proximo:
            Try
                vComando.CommandText = "UPDATE TAB_ALTERA_ENVOLVIDO SET Alterado = TRUE WHERE gcpj = " & vTb.Tables(0).Rows(vcontador)("gcpj").ToString
                vComando.Connection = Conexao
                vComando.ExecuteNonQuery()
            Catch ex As Exception
                MsgBox("Erro ao salvar")
                Exit Sub
            End Try

            vcontador += 1

        Loop

        MsgBox("Processamento realizado com sucesso!", vbExclamation)




    End Sub
End Class