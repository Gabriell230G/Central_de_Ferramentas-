<div align="center">

<img src="docs/readme/header.svg" alt="Controle de Depósitos: preenche no GCPJ o banco, a agência e a conta dos depósitos judiciais do Banco do Brasil e da Caixa" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: VB.NET" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET Framework" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="base: Access" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o robô pega na base Access os depósitos judiciais que ainda estão sem conta no GCPJ, acha cada um deles na tela do GCPJ pela data e pelo valor, preenche banco, agência, conta e dígito (e a operação, quando é Caixa) e marca o depósito como **ATUALIZADO** na base.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 2 bancos atendidos (Banco do Brasil e Caixa); 5.000 depósitos por execução (Controle S5); 22h horário limite do robô; 12 máquinas para dividir a fila" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Base Access com os depósitos pendentes ➜ 2 Pesquisa no GCPJ pelo processo e pela data ➜ 3 Robô com Controle S5 acha o depósito pela data e pelo valor ➜ 4 Preenche a conta judicial ➜ 5 Salva no GCPJ e marca ATUALIZADO na base" width="100%">
</picture>

### Os botões da tela

| Botão | O que faz |
| :--- | :--- |
| **Conectar GCPJ** | Procura uma janela do Internet Explorer com o GCPJ aberto. Se não acha, abre o GCPJ para você fazer login (aí é só clicar de novo). Quando acha, libera o **Processar** |
| **Máquina** | Lista de 1 a 12. Escolha o número desta máquina para tratar só a parte dela da fila. Em branco, trata a fila inteira |
| **Distribuir Máquinas** | Pergunta quantas máquinas vão rodar e divide os depósitos pendentes entre elas (coluna `MAQUINA`). Mexe **só na base Access**, não no GCPJ |
| **Processar** | Começa o trabalho no GCPJ, depósito por depósito, até 5.000 por execução (Controle S5) |

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `dev-auto-automacoeswebagconta` (Bitbucket, projeto COLDA) |
| **Código no inventário** | `C@XB` · Controle_Depositos_BB_CaixaEconomica |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em VB.NET Windows Forms |
| **Sistema que altera** | GCPJ (conta do depósito judicial) |
| **Entrada** | Tabela `_Depositos_Pendentes` da base `Controle_Depositos.accdb` |
| **Saída** | Conta gravada no GCPJ + coluna `ATUALIZADO` = Sim na base |
| **Base local** | `Controle_Depositos.accdb`, ao lado do executável |
| **Executável** | **Controle_Depositos.exe**. O projeto se chama `Automacoes_Web`, mas abre direto na tela `Frm_Altera_Ag_Conta` |
| **Acesso** | Não tem login próprio: usa o login do GCPJ no Internet Explorer |
| **Controle S5** | Até **5.000 depósitos por execução** |

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Base preparada com os depósitos pendentes ➜ 2 Dividir a fila entre as máquinas (opcional) ➜ 3 Conectar no GCPJ ➜ 4 Escolher a máquina ➜ 5 O robô trabalha (depósito por depósito, até 5.000 por execução) ➜ 6 Conferir o resultado" width="100%">
</picture>

| Parada | O que fazer |
| :---: | :--- |
| **1** | Confira se a base `Controle_Depositos.accdb` (ao lado do executável) tem os depósitos pendentes, com `ATUALIZADO` = Não |
| **2** | *Opcional:* se mais de uma máquina vai rodar, clique em **Distribuir Máquinas** **em uma só máquina** e informe quantas são |
| **3** | Clique em **Conectar GCPJ**. Se abrir o Internet Explorer, faça login e clique de novo, até aparecer *Conexão Efetuada!* |
| **4** | Escolha o número da **Máquina** (ou deixe em branco para tratar todos) |
| **5** | Clique em **Processar** e espere. A grade mostra cada depósito. Se chegar a 5.000, ele para sozinho e avisa (Controle S5) |
| **6** | Ao ver *Acabou*, confira na base quais ficaram com `ATUALIZADO` = Sim |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter</summary>
<br>

- Windows com **Internet Explorer** e acesso ao GCPJ
- **Microsoft Access Database Engine** (o provedor `Microsoft.ACE.OLEDB.12.0`)
- A base **`Controle_Depositos.accdb`** na **mesma pasta** do `Controle_Depositos.exe`. A tela abre a base assim que é aberta
- Rodar **antes das 22h**: depois disso o robô para sozinho

| Coluna da base usada pelo robô | Para que serve |
| :--- | :--- |
| `BRADESCO` | Número do processo no GCPJ (usado na pesquisa) |
| `DATA_DEPOSITO` / `VLR_DEPOSITO` | Data e valor do depósito: é assim que o robô acha a linha certa |
| `BANCO` / `AGENCIA` / `CONTA` / `DIGITO_CONTA` | O que vai ser gravado no GCPJ |
| `OPERACAO` | Só para Caixa (banco `104`) |
| `ATUALIZADO` | Não = pendente; Sim = já gravado no GCPJ |
| `MAQUINA` | Número da máquina que vai tratar o depósito |
| `CHAVE_INTERNA` | Chave da linha, usada para marcar `ATUALIZADO` |

> [!TIP]
> Os depósitos chegam na base por fora do sistema (o código não importa planilha). Rodar de novo é seguro: o robô só pega o que está com `ATUALIZADO` = Não.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** depósito gravado no GCPJ fica com `ATUALIZADO` = Sim na base. Se está Não, o robô ainda não terminou ele. Então, quando chega uma RO sobre um depósito, primeiro olhe a base e depois confira a conta no GCPJ.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um depósito ➜ 2 Olhar na base se ATUALIZADO é Sim ou Não ➜ 3 Conferir no GCPJ se a conta está gravada ➜ resultado verde (deu certo, nada a fazer), amarelo (alguém precisa olhar) ou vermelho (corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que o depósito do GCPJ 123456 continua sem conta. Na base, a linha dele está com `ATUALIZADO` = Não. Pelo quadro amarelo, ele foi pulado (o robô não achou o depósito ou a execução parou antes). Basta conferir data e valor na base e rodar de novo.

#### 🟢 Deu certo: não precisa fazer nada

| O que aparece | O que quer dizer |
| :--- | :--- |
| `ATUALIZADO` = Sim na base e a conta aparece no GCPJ | O robô preencheu e salvou o depósito |
| `Acabou`<br><sub>aviso final</sub> | A execução chegou ao fim da fila |
| `Distribuição Efetuada`<br><sub>aviso</sub> | A fila foi dividida entre as máquinas (só na base) |

#### 🟡 Precisa que alguém olhe

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| *Sistema não conseguiu encontrar o Deposito. Marque o Deposito Manualmente antes de clique em Sim...* | O GCPJ trouxe mais de um depósito e nenhum tinha a mesma data e o mesmo valor da base | **Sim** pula esse depósito (ele continua Não na base) e segue para o próximo. **Não** para a execução. Tratar o pulado na mão |
| *A Tela não limpou. Deseja Continuar?* | Depois de salvar, os campos do GCPJ não ficaram vazios. Pode ser que não salvou | Conferir o depósito no GCPJ antes de responder. **Sim** marca como ATUALIZADO mesmo assim |
| Aviso **Processamento Limitado - Controle S5** | A execução chegou a 5.000 depósitos | Normal. Rodar de novo continua com o que sobrou |
| `ATUALIZADO` = Sim na base, mas a conta **não** está no GCPJ | O robô fecha o aviso do GCPJ **sem ler o texto**. O aviso pode ter sido de erro | Corrigir na mão no GCPJ |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| *Horário após as 22:00* | Passou das 22h e o robô parou (sem o aviso *Acabou*) | Rodar no dia seguinte, antes das 22h |
| *Nenhum Processo Encontrado* | Não há depósito com `ATUALIZADO` = Não (ao clicar em Distribuir Máquinas) | Conferir se a base foi carregada |
| Depósito continua Não e o robô passou direto | Data ou valor na base diferentes do GCPJ | Corrigir a linha na base e rodar de novo |

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| Botão **Processar** cinza | Ainda não conectou no GCPJ | Clicar em **Conectar GCPJ** até aparecer *Conexão Efetuada!* |
| Erro do Windows logo ao abrir | A tela não achou a base: falta o `Controle_Depositos.accdb` ao lado do executável ou o Access Database Engine | Conferir a pasta e instalar o Access Database Engine |
| Erro ao clicar em **Distribuir Máquinas** | Clicou em Cancelar ou deixou a quantidade em branco | Clicar de novo e digitar um número |
| O robô "travou" e não termina | Esperando um aviso do GCPJ que não veio (GCPJ fora do ar ou sessão expirada) | Fechar pelo Gerenciador de Tarefas, logar de novo no GCPJ e rodar de novo |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim. O `C@XB` agora tem o controle na rotina **Processar**, que é a única que mexe no GCPJ. O contador soma **cada depósito que o robô começa a tratar**, inclusive os que acabam pulados. É o jeito mais seguro: nunca passa de 5.000 tentativas no GCPJ por execução.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada depósito o robô confere o contador; enquanto não chegou a 5.000, preenche a conta no GCPJ e soma 1; ao chegar em 5.000, para e avisa o usuário" width="100%">
</picture>

Quando o limite é atingido, aparece o aviso **Processamento Limitado - Controle S5** (*"O limite de processamento de 5.000 depósitos foi atingido. Os depósitos restantes continuam pendentes e podem ser processados em uma nova execução."*). Em seguida vem o aviso de sempre (*Acabou*). O que sobrou continua com `ATUALIZADO` = Não para a próxima execução.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `Mod_LimitadorS5.vb` | constante `LIMITE_OPERACOES_S5`, linha 26 |
| Mensagem do aviso | `Mod_LimitadorS5.vb` | função `LimiteS5Atingido`, linha 37 |
| Checagem do Processar | `Frm_Altera_Ag_Conta.vb` | `BTProcessar_Click`: contador na linha 127, bloco `[S5]` na linha 154 |

> [!TIP]
> Para testar sem esperar 5.000 depósitos: troque `LIMITE_OPERACOES_S5` para `2`, deixe pelo menos 3 depósitos pendentes, rode, tire os prints com o relógio do Windows aparecendo (código, aviso e base) e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra todos os pontos. As evidências oficiais estão em [`docs/Evidencias_S5_ControleDepositos.docx`](docs/Evidencias_S5_ControleDepositos.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `Automacoes_Web.vbproj` (solução `Automacoes_Web.sln`). A tela inicial é a `Frm_Altera_Ag_Conta` (definida em `My Project\Application.myapp`).

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `Frm_Altera_Ag_Conta.vb` | `Conexao` | 49 | Caminho da base: `Controle_Depositos.accdb` ao lado do `.exe` |
| | `Frm_Altera_Ag_Conta_Load` | 53 | Abre a base quando a tela abre |
| | `Espera_Ate_Que_Abra` | 57 | Espera a página do GCPJ terminar de carregar |
| | `BTConectaGCPJ_Click` | 67 | Acha ou abre o IE do GCPJ e libera o **Processar** |
| | `VerificaGCPJ` | 79 | Procura uma janela do IE com "GCPJ" no nome |
| | `BTDistribuir_Click` | 91 | Divide os pendentes entre as máquinas (só na base) |
| | `BTProcessar_Click` | 126 | Rotina **Processar** (a que tem o Controle S5) |
| | `MataMsgbox` | 37 | Espera o aviso *Mensagem da página da web* e clica em OK |
| `Mod_LimitadorS5.vb` | `LIMITE_OPERACOES_S5` / `LimiteS5Atingido` | 26 / 37 | Controle S5 |

As outras telas da pasta (`Frm_Inclusao_Evento`, `Frm_Distribuicao` e as demais) são herança do Automações Web. Elas são compiladas junto, mas **não abrem** neste executável, porque a tela inicial é a `Frm_Altera_Ag_Conta` e ela não chama nenhuma outra.

</details>

<details>
<summary><b>Como o Processar funciona por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>

1. Lê na base os depósitos com `ATUALIZADO` = Não (só os da máquina escolhida, se houver), em ordem de processo e data.
2. Bloco `[S5]`: se já tratou 5.000 depósitos nesta execução, para.
3. Abre a tela `finDepFaltaConta` do GCPJ. Se já passou das 22h, avisa e para.
4. Escreve na grade: número do depósito na fila, quantos faltam, GCPJ, data e valor.
5. Pesquisa pelo processo (`cdNumeroProcessoBradesco`) com a data do depósito como início e fim do período.
6. Marca o depósito. Se vier mais de um, procura a linha com a **mesma data e o mesmo valor**, passando as páginas se precisar. Se não achar, pergunta ao usuário (ver *Recebi uma RO*).
7. Clica em **Detalhar** e preenche banco, agência, conta e dígito. Se o banco é **104 (Caixa)**, preenche também a operação.
8. Escolhe o tipo de conta **Judicial**, clica em **Salvar** e fecha o aviso do GCPJ.
9. Confere se a tela limpou e marca `ATUALIZADO` = Sim na base.
10. No fim da fila, mostra *Acabou*.

</details>

<details>
<summary><b>Banco de dados</b> &nbsp;·&nbsp; o que tem no Access</summary>
<br>

| Objeto | Usado pelo código? | Conteúdo |
| :--- | :---: | :--- |
| `_Depositos_Pendentes` | Sim | A fila do robô (colunas na seção *Antes da primeira vez*) |
| `_Depositos_Pendentes_Temp` | Não | Tabela de apoio com os dados dos depósitos (processo, regional, envolvidos, advogados) |

O sistema **não grava log**. O histórico fica só na coluna `ATUALIZADO` e na grade da tela, que some quando a tela fecha.

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `Mod_LimitadorS5.vb` ➜ `LIMITE_OPERACOES_S5` |
| Mudar o horário limite (22h) | `Frm_Altera_Ag_Conta.vb` ➜ linha 164 |
| Mudar o banco que pede operação (Caixa) | `Frm_Altera_Ag_Conta.vb` ➜ `If ... ("banco") = 104` (linha 276) |
| Mudar o tipo de conta (Judicial) | `Frm_Altera_Ag_Conta.vb` ➜ `selTipoConta` (linha 285) |
| Mudar o endereço do GCPJ | `Frm_Altera_Ag_Conta.vb` ➜ procure `intranet85.net.bradesco.com.br/gcpj` |
| Mudar a quantidade de máquinas na lista | `Frm_Altera_Ag_Conta.Designer.vb` ➜ itens do `CMBMaquina` (linha 85) |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **Dados reais no repositório.** `bin\Debug` tem as bases `Controle_Depositos.accdb` e `Controle_Depositos_RO_12185.accdb` e planilhas (pasta `Inserir Ag. Conta`, `Redistribuicao`, `Honorários`) com dados de processos e pessoas. Tudo isso está versionado no Git. O ideal é tirar do repositório e guardar só na pasta de rede.
- **`sslVerify = false`** no `.git\config`: o Git não confere o certificado do Bitbucket.
- **"Sim" pula o depósito.** Na pergunta *Sistema não conseguiu encontrar o Deposito*, o texto pede para marcar na mão e clicar em Sim, mas o código vai direto para o próximo (linha 256) sem salvar nada. O depósito continua Não na base.
- **ATUALIZADO não confirma o salvamento.** O `MataMsgbox` (linha 37) clica em OK no primeiro aviso *Mensagem da página da web*, sem ler o texto, e espera para sempre se o aviso não vier.
- **Distribuir Máquinas** dá erro se a quantidade ficar em branco (linha 105).
- **Parada das 22h** sai sem o aviso *Acabou* e sem nenhum registro.
- **SQL montado por concatenação** (linhas 114, 140 e 303).
- **Depende do layout do GCPJ:** os campos são achados pelo nome (`cdNumeroProcessoBradesco`, `itemSelecionado`, `btoSalvar`...). Se o GCPJ mudar a tela, o robô quebra.
- **Projeto inteiro do Automações Web junto:** além desta tela, a pasta tem todas as outras (e o subprojeto `ClickYes_Web`). Cuidado ao mexer: o `.vbproj` compila todas.
- As pastas `bin`, `obj` e `.vs` estão versionadas, inclusive o arquivo de trava `Controle_Depositos.laccdb`.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 01/2024 primeiro commit do código no Bitbucket; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: tirar os dados reais do repositório" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 01/2024 | Thiago Pedro Carvalho de Oliveira | Primeiro commit no Bitbucket (*Inserindo automação para controle de versionamento e backup*) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`Mod_LimitadorS5.vb`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
