﻿Imports System.Runtime.InteropServices
Imports System.Threading
Public Class Form1
    Public objIndex As SHDocVw.InternetExplorer
    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowByCaption( _
                ByVal zero As IntPtr, _
                ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function

    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1

    Private Sub Espera_Ate_Que_Abra()
        Thread.Sleep(500)
        Do While objIndex.ReadyState = 0 Or objIndex.ReadyState = 1 Or objIndex.ReadyState = 3
            'Espera até que abra
        Loop
        Do While objIndex.Busy = True
            'Espera até que abra
        Loop
    End Sub

    Private Function MataPossivelMsgbox() As Boolean
        Thread.Sleep(1000)
        Dim winHwnd As Long
        Do Until winHwnd <> 0
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
            'If (objIndex.ReadyState <> 0 And objIndex.ReadyState <> 1 And objIndex.ReadyState <> 3) Then Exit Sub
            If objIndex.Busy = False Then
                Thread.Sleep(1000)
                Return False
            End If
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
        Return True
    End Function

    Private Sub btnConectar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConectar.Click
        If VerificaGCPJ("GCPJ") = False Then
            preencheGrade("Abrindo nova instância do GCPJ...")
            preencheGrade("Por favor, insira seu login e senha!")
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj")
            Espera_Ate_Que_Abra()
            objIndex.Visible = True
            Exit Sub
        Else
            preencheGrade("GCPJ Localizado! Prossiga com o processamento!")
            objIndex.Visible = True
        End If
    End Sub

    Private Function VerificaGCPJ(ByVal nomeJanela As String) As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        For Each ie As SHDocVw.InternetExplorer In New SHDocVw.ShellWindows
            If InStr(ie.LocationName.ToString, nomeJanela) Then
                objIndex = ie
                Return True
            End If
        Next
        Return False
    End Function
    Private Sub preencheGrade(ByRef Texto As String)
        Grade.Items.Add(Format(Date.Now, "hh:mm:ss") & " - " & Texto)
        Grade.SelectedIndex = Grade.Items.Count - 1
        System.Windows.Forms.Application.DoEvents()
    End Sub

    Private Sub limpaGrade()
        Grade.Items.Clear()
        System.Windows.Forms.Application.DoEvents()
    End Sub

    Private Sub MataMsgbox()
        Dim winHwnd As Long
        Do Until winHwnd <> 0
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
    End Sub

    Private Sub btnProcessar_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnProcessar.Click
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de registros processados nesta execução
        Dim vContadorRegistro As Integer = 0
        If txtLinha.Text = "" Then
            txtLinha.Text = 0
        End If
        If txtPagina.Text = "" Then
            txtPagina.Text = 0
        End If
        'tratamento resumo
        If txtResumo.Text = "" Or Len(txtResumo.Text) = 0 Then
            MsgBox("ATENÇÃO! Preencha o resumo!", vbExclamation)
            Exit Sub
        End If
        Dim vFim As Boolean = False
        Dim vSelecao As Object
        Dim vLinha As Object
        Dim vCelulas As Object
        Dim vContador As Integer
        Dim vAtualiza As Boolean = False

        preencheGrade("Iniciando o processamento da atualização de eventos, desde que sejam CONSIDERAÇÕES SOBRE O PROCESSO")
        'navegando
        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/traTraPendAdvogAtulzResAction?acao=carregar")
        Espera_Ate_Que_Abra()

        Do Until vFim = True
            '[S5] Limitador de operações: para o processamento ao atingir o limite (ver Mod_LimitadorS5.vb)
            If LimiteS5Atingido(qtdOperacoesS5) Then
                preencheGrade("Controle S5: limite de " & Format(LIMITE_OPERACOES_S5, "#,##0") & " registros atingido. Processamento interrompido.")
                Exit Do
            End If
            qtdOperacoesS5 += 1

            'ATUALIZAR TELA?
            If vAtualiza = True Then
                objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/traTraPendAdvogAtulzResAction?acao=carregar")
                Espera_Ate_Que_Abra()
            End If
            'MOVENDO AS FOLHAS
            For i = 1 To CInt(txtPagina.Text)
                Call objIndex.Document.parentWindow.execScript("paginacao('7')", "JavaScript")
                Espera_Ate_Que_Abra()
            Next

            Try
                objIndex.Document.forms(0).elements("selecionados")(0 + txtLinha.Text).checked = True
                vSelecao = objIndex.Document.forms(0).elements("selecionados")(0 + txtLinha.Text)
                'celula
                vLinha = objIndex.Document.forms(0).elements("selecionados")(0 + txtLinha.Text).parentElement
                'linha
                vLinha = vLinha.parentElement
                vCelulas = vLinha.Cells
                vContador = 0
                For Each vcelula In vCelulas
                    vContador += 1
                    If vContador = 4 Then
                        vContadorRegistro += 1
                        'MsgBox(vcelula.innertext)
                        If Trim(vcelula.innertext) = "RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO" Then
                            'DEVO ATUALIZAR
                            objIndex.Document.forms(0).elements("btoExecutar").click()
                            Espera_Ate_Que_Abra()
                            preencheGrade("Baixando pendência do processo bradesco: " & objIndex.Document.forms(0).elements("cdNumeroProcessoBradesco").value)
                            objIndex.Document.forms(0).elements("dsResumoEventoJudicial").value = txtResumo.Text
                            'SALVANDO
                            objIndex.Document.FORMS(0).elements("btoSalvar").click()
                            vAtualiza = False
                            MataMsgbox()
                            Espera_Ate_Que_Abra()
                            GoTo proximo
                        Else
                            'SE NAO FOR CONSIDERACOES...
                            preencheGrade("Evento não é RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO, ignorando...")
                            vAtualiza = True
                            txtLinha.Text += 1
                            If txtLinha.Text >= 10 Then
                                txtPagina.Text += 1
                                txtLinha.Text = 0
                            End If
                            Application.DoEvents()
                            GoTo proximo
                        End If
                    End If
                Next
            Catch ex As Exception
                'DEU ERRO, VOU VER O ULTIMO CASO
                If txtPagina.Text = 0 And txtLinha.Text = 0 Then
                    'ESTOU APENAS COM UM REGISTRO, SEM NENHUMA EXCEÇÃO.
                    objIndex.Document.forms(0).elements("selecionados").checked = True
                    vSelecao = objIndex.Document.forms(0).elements("selecionados")
                    'celula
                    vLinha = objIndex.Document.forms(0).elements("selecionados").parentElement
                    'linha
                    vLinha = vLinha.parentElement
                    vCelulas = vLinha.Cells
                    vContador = 0
                    For Each vcelula In vCelulas
                        vContador += 1
                        If vContador = 4 Then
                            vContadorRegistro += 1
                            If Trim(vcelula.innertext) = "RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO" Then
                                'DEVO ATUALIZAR
                                objIndex.Document.forms(0).elements("btoExecutar").click()
                                Espera_Ate_Que_Abra()
                                preencheGrade("Baixando pendência do processo bradesco: " & objIndex.Document.forms(0).elements("cdNumeroProcessoBradesco").value)
                                objIndex.Document.forms(0).elements("dsResumoEventoJudicial").value = txtResumo.Text
                                'SALVANDO
                                objIndex.Document.FORMS(0).elements("btoSalvar").click()
                                MataMsgbox()
                                Espera_Ate_Que_Abra()
                                vFim = True
                            Else
                                'SE NAO FOR CONSIDERACOES...
                                preencheGrade("Evento não é RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO, ignorando...")
                                'FIM DO PROCESSAMENTO!
                                vFim = True
                            End If
                        End If
                    Next
                Else
                    'ACABARAM OS REGISTROS E FICARAM APENAS OS CASOS QUE NAO SÃO CONSIDERAÇÕES.
                    vFim = True
                End If
            End Try
proximo:
            preencheGrade("Foram percorridos " & vContadorRegistro & " até o momento")
        Loop
        preencheGrade("Processamento realizado com sucesso!")
    End Sub
End Class
