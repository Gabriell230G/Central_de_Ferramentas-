# Atualizador de Eventos (aajr-cmn-atualizaeventos-auto)

Robô que baixa, no GCPJ, as pendências do tipo **"RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO"**, preenchendo um resumo padrão e salvando o evento.

| Item | Valor |
|---|---|
| Código no inventário | **C@KG** (ATUALIZAÇÃO EVENTOS) |
| Área | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| Linguagem | VB.NET (Windows Forms) |
| Framework | .NET Framework 4.8 |
| Sistema alvo | GCPJ (Internet Explorer, via SHDocVw) |
| Base local | não usa |
| Controle S5 | Implementado (limite de **5.000** registros por execução) |

---

## Sumário

1. [O que o sistema faz](#1-o-que-o-sistema-faz)
2. [Como rodar](#2-como-rodar)
3. [Estrutura do projeto](#3-estrutura-do-projeto)
4. [Controle S5: Limitador de Operações](#4-controle-s5-limitador-de-operações)
5. [Guia rápido: quero mudar X, onde vou?](#5-guia-rápido-quero-mudar-x-onde-vou)
6. [Pontos de atenção](#6-pontos-de-atenção)
7. [Histórico](#7-histórico)

---

## 1. O que o sistema faz

```
Conectar ➜ informar o Resumo Evento ➜ Processar
   ➜ o robô abre a lista de pendências (Atualização de Resumo)
   ➜ olha a 4ª coluna de cada linha
        é "RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO"?
           ➜ SIM: executa, preenche o resumo e salva
           ➜ NÃO: pula para a próxima linha (e avança a página a cada 10)
   ➜ termina quando acabam as linhas OU quando atinge o limite do Controle S5
```

| Campo / Botão | Para que serve |
|---|---|
| **Conectar** | Procura o GCPJ aberto ou abre um novo (faça o login) |
| **Pagina / Linha** | Ponto de partida na lista. O próprio robô vai atualizando enquanto pula linhas |
| **Resumo Evento** | Texto gravado no evento (padrão: *"Aguardando informação do escritório contratado."*) |
| **Processar** | Inicia a automação |

## 2. Como rodar

1. Abra `atualizaEventos.sln` no Visual Studio.
2. Rode, clique em **Conectar** e faça login no GCPJ no Internet Explorer que abrir.
3. Confira o **Resumo Evento** e clique em **Processar**.

## 3. Estrutura do projeto

| Arquivo | Para que serve |
|---|---|
| `Form1.vb` | Tela e **toda a automação** (`btnProcessar_Click`) |
| `Form1.Designer.vb` | Layout da tela |
| `Mod_LimitadorS5.vb` | **Controle S5**: limite de operações por execução |

## 4. Controle S5: Limitador de Operações

Exigência do normativo **05.1073** para aplicativos com C10 = Sim (automação que atualiza dados em sistema estruturado).

### Como funciona

```
Clique em Processar ➜ contador = 0
   A cada volta do laço (1 pendência analisada):
      contador já chegou no limite?  ➜ SIM: avisa o usuário e para
                                      ➜ NÃO: soma 1 e trata a pendência
```

Ao atingir o limite aparece a mensagem **"Processamento Limitado - Controle S5"** e a grade registra *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*. As pendências que sobraram continuam na fila do GCPJ.

### Onde mexer

| O que | Arquivo | Onde |
|---|---|---|
| **Valor do limite** | `Mod_LimitadorS5.vb` | constante `LIMITE_OPERACOES_S5` (linha 22) |
| Mensagem exibida ao usuário | `Mod_LimitadorS5.vb` | função `LimiteS5Atingido` |
| Ponto de checagem no laço | `Form1.vb` | `btnProcessar_Click`, bloco `[S5]` na linha 128 (logo no início do `Do Until vFim`) |

> Dica: **Ctrl+Shift+F** e pesquise `[S5]`.

### Documento de evidências

O Word com as evidências do Controle S5 (trechos do código alterado, resultado dos testes e espaço para os prints do ambiente) fica em [`docs/Evidencias_S5_AtualizaEventos.docx`](docs/Evidencias_S5_AtualizaEventos.docx).

### Como testar e gerar a evidência

1. Em `Mod_LimitadorS5.vb`, troque temporariamente `LIMITE_OPERACOES_S5 = 5000` para `2`.
2. Rode o **Processar** com pelo menos 3 pendências na fila.
3. Confira o aviso **Processamento Limitado - Controle S5** depois de 2 pendências.
4. Tire os prints com o **relógio do Windows aparecendo**: código e mensagem.
5. **Volte o valor para 5000** antes de gerar a versão final.

## 5. Guia rápido: quero mudar X, onde vou?

| Quero... | Vá em |
|---|---|
| Mudar o limite do Controle S5 | `Mod_LimitadorS5.vb` ➜ `LIMITE_OPERACOES_S5` |
| Mudar o tipo de pendência tratada | `Form1.vb` ➜ texto `"RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO"` (aparece 2 vezes) |
| Mudar o resumo padrão | `Form1.Designer.vb` ➜ `txtResumo.Text` |
| Mudar a tela do GCPJ | `Form1.vb` ➜ URL `traTraPendAdvogAtulzResAction` |

## 6. Pontos de atenção

- O robô identifica a coluna pela **posição** (4ª célula). Se o GCPJ mudar o layout da tabela, a regra quebra.
- Quando a lista tem uma única linha, o código entra no `Catch` e trata esse caso separado. Isso é esperado.

## 7. Histórico

| Data | Autor | Alteração |
|---|---|---|
| 01/2026 | Daniela Chirinian | Primeiro commit (migração para o GitHub) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`Mod_LimitadorS5.vb`) e novo README |

---

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
