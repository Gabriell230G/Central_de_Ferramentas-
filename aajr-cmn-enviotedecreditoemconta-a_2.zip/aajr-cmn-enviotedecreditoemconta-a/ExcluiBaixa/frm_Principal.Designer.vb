﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_Principal
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_Principal))
        Me.lbl_IDusuario = New System.Windows.Forms.Label()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lbl_usuario = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Grade = New System.Windows.Forms.ListBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.cb_Area = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btn_EnviarTED = New System.Windows.Forms.Button()
        Me.txt_DataDep = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_GCPJ = New System.Windows.Forms.Button()
        Me.btn_CadUsuario = New System.Windows.Forms.ToolStripDropDownButton()
        Me.NovoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditarNomeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AlterarSenhaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me.btn_Sair = New System.Windows.Forms.ToolStripButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.StatusStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_IDusuario
        '
        Me.lbl_IDusuario.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.lbl_IDusuario.AutoSize = True
        Me.lbl_IDusuario.Location = New System.Drawing.Point(929, 25)
        Me.lbl_IDusuario.Name = "lbl_IDusuario"
        Me.lbl_IDusuario.Size = New System.Drawing.Size(23, 19)
        Me.lbl_IDusuario.TabIndex = 2
        Me.lbl_IDusuario.Text = "ID"
        Me.lbl_IDusuario.Visible = False
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lbl_usuario, Me.ToolStripStatusLabel1})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 439)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(956, 26)
        Me.StatusStrip1.TabIndex = 11
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lbl_usuario
        '
        Me.lbl_usuario.BackColor = System.Drawing.Color.Transparent
        Me.lbl_usuario.BorderStyle = System.Windows.Forms.Border3DStyle.SunkenOuter
        Me.lbl_usuario.Name = "lbl_usuario"
        Me.lbl_usuario.Size = New System.Drawing.Size(775, 20)
        Me.lbl_usuario.Spring = True
        Me.lbl_usuario.Text = "Usuário Logado: "
        Me.lbl_usuario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(166, 20)
        Me.ToolStripStatusLabel1.Text = "BANCO BRADESCO S/A"
        '
        'Grade
        '
        Me.Grade.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Grade.FormattingEnabled = True
        Me.Grade.ItemHeight = 17
        Me.Grade.Location = New System.Drawing.Point(14, 82)
        Me.Grade.Name = "Grade"
        Me.Grade.Size = New System.Drawing.Size(904, 293)
        Me.Grade.TabIndex = 3
        '
        'GroupBox2
        '
        Me.GroupBox2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GroupBox2.Controls.Add(Me.Button1)
        Me.GroupBox2.Controls.Add(Me.cb_Area)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.btn_EnviarTED)
        Me.GroupBox2.Controls.Add(Me.txt_DataDep)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Controls.Add(Me.Grade)
        Me.GroupBox2.Controls.Add(Me.btn_GCPJ)
        Me.GroupBox2.Font = New System.Drawing.Font("Bradesco Sans", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Maroon
        Me.GroupBox2.Location = New System.Drawing.Point(12, 33)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(932, 396)
        Me.GroupBox2.TabIndex = 12
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "GCPJ / Financeiro Contábil / Lançamentos / Depósito Judicial / Aguardando Envio d" &
    "a TED"
        '
        'cb_Area
        '
        Me.cb_Area.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cb_Area.FormattingEnabled = True
        Me.cb_Area.Items.AddRange(New Object() {"CI", "TR"})
        Me.cb_Area.Location = New System.Drawing.Point(306, 37)
        Me.cb_Area.Name = "cb_Area"
        Me.cb_Area.Size = New System.Drawing.Size(81, 25)
        Me.cb_Area.TabIndex = 8
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bradesco Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(264, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(45, 19)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Área:"
        '
        'btn_EnviarTED
        '
        Me.btn_EnviarTED.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_EnviarTED.Enabled = False
        Me.btn_EnviarTED.Font = New System.Drawing.Font("Bradesco Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_EnviarTED.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_EnviarTED.Location = New System.Drawing.Point(588, 32)
        Me.btn_EnviarTED.Name = "btn_EnviarTED"
        Me.btn_EnviarTED.Size = New System.Drawing.Size(147, 30)
        Me.btn_EnviarTED.TabIndex = 6
        Me.btn_EnviarTED.Text = "Enviar TED"
        Me.btn_EnviarTED.UseVisualStyleBackColor = True
        '
        'txt_DataDep
        '
        Me.txt_DataDep.BackColor = System.Drawing.SystemColors.ControlLight
        Me.txt_DataDep.Location = New System.Drawing.Point(105, 38)
        Me.txt_DataDep.Name = "txt_DataDep"
        Me.txt_DataDep.Size = New System.Drawing.Size(126, 24)
        Me.txt_DataDep.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bradesco Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(13, 42)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(110, 19)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Data Depósito:"
        '
        'btn_GCPJ
        '
        Me.btn_GCPJ.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btn_GCPJ.Font = New System.Drawing.Font("Bradesco Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_GCPJ.ForeColor = System.Drawing.SystemColors.ControlText
        Me.btn_GCPJ.Location = New System.Drawing.Point(431, 32)
        Me.btn_GCPJ.Name = "btn_GCPJ"
        Me.btn_GCPJ.Size = New System.Drawing.Size(147, 30)
        Me.btn_GCPJ.TabIndex = 1
        Me.btn_GCPJ.Text = "Conectar GCPJ"
        Me.btn_GCPJ.UseVisualStyleBackColor = True
        '
        'btn_CadUsuario
        '
        Me.btn_CadUsuario.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NovoToolStripMenuItem, Me.EditarNomeToolStripMenuItem, Me.AlterarSenhaToolStripMenuItem})
        Me.btn_CadUsuario.Image = CType(resources.GetObject("btn_CadUsuario.Image"), System.Drawing.Image)
        Me.btn_CadUsuario.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_CadUsuario.Name = "btn_CadUsuario"
        Me.btn_CadUsuario.Size = New System.Drawing.Size(162, 24)
        Me.btn_CadUsuario.Text = "Cadastro Usuários"
        '
        'NovoToolStripMenuItem
        '
        Me.NovoToolStripMenuItem.Name = "NovoToolStripMenuItem"
        Me.NovoToolStripMenuItem.Size = New System.Drawing.Size(181, 26)
        Me.NovoToolStripMenuItem.Text = "Novo"
        '
        'EditarNomeToolStripMenuItem
        '
        Me.EditarNomeToolStripMenuItem.Name = "EditarNomeToolStripMenuItem"
        Me.EditarNomeToolStripMenuItem.Size = New System.Drawing.Size(181, 26)
        Me.EditarNomeToolStripMenuItem.Text = "Editar Nome"
        '
        'AlterarSenhaToolStripMenuItem
        '
        Me.AlterarSenhaToolStripMenuItem.Name = "AlterarSenhaToolStripMenuItem"
        Me.AlterarSenhaToolStripMenuItem.Size = New System.Drawing.Size(181, 26)
        Me.AlterarSenhaToolStripMenuItem.Text = "Alterar Senha"
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(20, 20)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.btn_CadUsuario, Me.ToolStripLabel1, Me.btn_Sair})
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System
        Me.ToolStrip1.Size = New System.Drawing.Size(956, 27)
        Me.ToolStrip1.TabIndex = 3
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripLabel1
        '
        Me.ToolStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.ToolStripLabel1.BackColor = System.Drawing.Color.Transparent
        Me.ToolStripLabel1.Name = "ToolStripLabel1"
        Me.ToolStripLabel1.Size = New System.Drawing.Size(13, 24)
        Me.ToolStripLabel1.Text = " "
        '
        'btn_Sair
        '
        Me.btn_Sair.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right
        Me.btn_Sair.Image = CType(resources.GetObject("btn_Sair.Image"), System.Drawing.Image)
        Me.btn_Sair.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.btn_Sair.Name = "btn_Sair"
        Me.btn_Sair.Size = New System.Drawing.Size(58, 24)
        Me.btn_Sair.Text = "Sair"
        '
        'Button1
        '
        Me.Button1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button1.Enabled = False
        Me.Button1.Font = New System.Drawing.Font("Bradesco Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(744, 32)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(147, 30)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "Enviar CRED"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frm_Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(956, 465)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.lbl_IDusuario)
        Me.Controls.Add(Me.ToolStrip1)
        Me.Font = New System.Drawing.Font("Bradesco Sans", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(575, 260)
        Me.Name = "frm_Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Sistema de Envio TED"
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl_IDusuario As Windows.Forms.Label
    Friend WithEvents StatusStrip1 As Windows.Forms.StatusStrip
    Friend WithEvents lbl_usuario As Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel1 As Windows.Forms.ToolStripStatusLabel
    Private WithEvents Grade As Windows.Forms.ListBox
    Friend WithEvents GroupBox2 As Windows.Forms.GroupBox
    Friend WithEvents btn_EnviarTED As Windows.Forms.Button
    Friend WithEvents txt_DataDep As Windows.Forms.TextBox
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents btn_GCPJ As Windows.Forms.Button
    Friend WithEvents btn_CadUsuario As Windows.Forms.ToolStripDropDownButton
    Friend WithEvents NovoToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditarNomeToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents AlterarSenhaToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStrip1 As Windows.Forms.ToolStrip
    Friend WithEvents ToolStripLabel1 As Windows.Forms.ToolStripLabel
    Friend WithEvents btn_Sair As Windows.Forms.ToolStripButton
    Friend WithEvents cb_Area As Windows.Forms.ComboBox
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents Button1 As Windows.Forms.Button
End Class
