﻿Imports System.Windows.Forms

Public Class frm_CadUsuario
    Private Sub frm_CadUsuario_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim conn As New cls_Conexao
        conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'ACESSOU CADASTRO USUÁRIO - " & UCase(Me.Text) & "' , '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
        conn.ExecutaQuery()

        conn.StrSQL = "SELECT Tb_Usuario.ID_Usuario as Matricula, Tb_Usuario.Nome FROM Tb_Usuario ORDER BY Tb_Usuario.Nome;"
        grid_usuarios.DataSource = conn.GeraTBL
        grid_usuarios.Columns(0).Width = 90
    End Sub

    Private Sub btn_Cancelar_Click(sender As Object, e As EventArgs) Handles btn_Cancelar.Click
        Me.Close()
    End Sub

    Private Sub btn_Salvar_Click(sender As Object, e As EventArgs) Handles btn_Salvar.Click
        Dim conn As New cls_Conexao

        If Trim(txt_Matricula.Text) = "" Then
            MsgBox("Informe a matrícula.", vbExclamation, "Sistema de Envio TED")
            txt_Matricula.Focus()
            Exit Sub
        End If
        If Trim(txt_Nome.Text) = "" Then
            MsgBox("Informe o nome.", vbExclamation, "Sistema de Envio TED")
            txt_Nome.Focus()
            Exit Sub
        End If

        If txt_Matricula.Enabled = False Then
            conn.StrSQL = "UPDATE Tb_Usuario SET Tb_Usuario.Nome = '" & Trim(Me.txt_Nome.Text) & "' WHERE ((Tb_Usuario.ID_Usuario)='" & txt_Matricula.Text & "')"
            conn.ExecutaQuery()
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'ATUALIZOU NOME DO USUÁRIO' , '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            frm_Principal.lbl_usuario.Text = "Usuário Logado: " & Trim(Me.txt_Nome.Text)
            MsgBox("Operação realizada com sucesso!", vbInformation, "Sistema de Envio TED")
            Me.Close()

        Else
            conn.StrSQL = "INSERT INTO Tb_Usuario ( ID_Usuario, Nome, Senha ) VALUES ('" & Trim(txt_Matricula.Text) & "', '" & Trim(Me.txt_Nome.Text) & "' , '1234');"
            conn.ExecutaQuery()
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'INSERIU USUÁRIO " & Trim(txt_Matricula.Text) & "' , '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            MsgBox("Usuário cadastrado com sucesso! Senha inicial: 1234", vbInformation, "Sistema de Envio TED")
            txt_Matricula.Text = ""
            txt_Nome.Text = ""
        End If

        conn.StrSQL = "SELECT Tb_Usuario.ID_Usuario as Matricula, Tb_Usuario.Nome FROM Tb_Usuario;"
        grid_usuarios.DataSource = conn.GeraTBL
        grid_usuarios.Columns(0).Width = 90
    End Sub


    Private Sub txt_Matricula_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txt_Matricula.KeyPress
        If Not Char.IsNumber(e.KeyChar) Then
            e.Handled = True
        End If
    End Sub
End Class