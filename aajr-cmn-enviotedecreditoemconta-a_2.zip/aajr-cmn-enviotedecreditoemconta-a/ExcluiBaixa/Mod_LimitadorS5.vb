﻿'==============================================================================
'  CONTROLE S5 - LIMITADOR DE OPERAÇÕES
'  Normativo 05.1073 - Sistemas/Aplicativos Mantidos em Ambiente Departamental
'------------------------------------------------------------------------------
'  O QUE FAZ
'    Limita quantos registros o robô pode processar no GCPJ em UMA execução.
'    Quando o limite é atingido:
'      1. o laço da automação para (Exit Do);
'      2. o usuário recebe o aviso "Processamento Limitado - Controle S5";
'      3. os depósitos que sobraram continuam em "Aguardando Envio" no GCPJ para a próxima execução.
'
'  COMO MUDAR O LIMITE
'    Altere SOMENTE a constante LIMITE_OPERACOES_S5 abaixo.
'
'  ONDE ELE É USADO
'    Ctrl+Shift+F no Visual Studio e pesquise por "[S5]".
'      - frm_Principal.vb > btn_EnviarTED_Click (envio de TED)
'      - frm_Principal.vb > Button1_Click (envio de Crédito em Conta)
'==============================================================================
Module Mod_LimitadorS5

    ''' <summary>Máximo de registros processados no GCPJ por execução.</summary>
    Public Const LIMITE_OPERACOES_S5 As Integer = 5000

    ''' <summary>
    ''' Retorna True quando a execução já chegou no limite do Controle S5
    ''' e, nesse caso, avisa o usuário. Uso dentro do laço:
    '''     If LimiteS5Atingido(qtdOperacoesS5) Then Exit Do
    '''     qtdOperacoesS5 += 1
    ''' </summary>
    ''' <param name="qtdOperacoes">Quantos registros já foram processados nesta execução.</param>
    Public Function LimiteS5Atingido(ByVal qtdOperacoes As Integer) As Boolean
        If qtdOperacoes < LIMITE_OPERACOES_S5 Then Return False

        MsgBox("O limite de processamento de " & Format(LIMITE_OPERACOES_S5, "#,##0") & " registros foi atingido." & vbCrLf & vbCrLf & _
               "Os itens restantes continuam pendentes no GCPJ e podem ser processados em uma nova execução.", _
               vbExclamation, "Processamento Limitado - Controle S5")
        Return True
    End Function

End Module
