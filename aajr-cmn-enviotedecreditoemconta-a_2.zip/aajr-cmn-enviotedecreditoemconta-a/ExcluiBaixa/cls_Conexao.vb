﻿Imports System.Data.OleDb
Imports System.Windows.Forms

Public Class cls_Conexao
    Private Conexao As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\BD\BD_DADOS.accdb")
    Private command As OleDbCommand
    Private vStrSQL As String

    Private Sub Open()
        If Me.Conexao.State = ConnectionState.Closed Then
            Me.Conexao.Open()
        End If
    End Sub
    Private Sub Close()
        If Not Me.Conexao Is Nothing Then
            If Me.Conexao.State = ConnectionState.Open Then
                Me.Conexao.Close()
            End If
        End If
    End Sub

    Public Property StrSQL() As String
        Set(ByVal value As String)
            Me.vStrSQL = value
        End Set
        Get
            Return Me.vStrSQL
        End Get
    End Property

    Public Function ExecutaQuery() As Boolean
        Try
            Me.Open()
            Me.command = New OleDbCommand(Me.vStrSQL, Me.Conexao)
            Me.command.CommandTimeout = 0
            Me.command.ExecuteNonQuery()

            ExecutaQuery = True
        Catch ex As Exception
            ExecutaQuery = False
        End Try
        Me.Close()
        Return ExecutaQuery
    End Function
    Function GeraTBL() As Data.DataTable
        Try
            Me.Open()
            GeraTBL = New Data.DataTable

            Dim adapter As New OleDbDataAdapter(Me.vStrSQL, Me.Conexao)
            adapter.Fill(GeraTBL)

            Me.Close()
            Return GeraTBL
        Catch ex As Exception
            Me.Close()
            Return Nothing
        End Try
    End Function

    Function SQL_Data(ByVal XData As String)
        If Not IsDate(XData) Then
            Return "NULL"
        Else
            Dim VarData As Date
            VarData = XData
            Return "#" & Format(VarData, "MM/dd/yyyy") & "#"
        End If
    End Function

    Function SQL_Numero(ByVal XNumero As String)
        If Not IsNumeric(XNumero) Then
            Return "NULL"
        Else
            Return XNumero
        End If
    End Function
    Function SQL_Hora(ByVal XHora As String)
        If Not IsDate(XHora) Then
            Return "NULL"
        Else
            Dim VarHora As Date
            VarHora = XHora
            Return "#" & Format(VarHora, "HH:mm") & "#"
        End If
    End Function

    Function SQL_Texto(ByVal XTexto As String, Optional ByVal XTamanho As Integer = 0)
        If XTamanho = 0 Then
            Return "'" & Replace(Trim(XTexto), "'", "") & "'"
        Else
            Return "'" & Replace(Trim(Mid(XTexto, 1, XTamanho)), "'", "") & "'"
        End If
    End Function

    Function SQL_Valor(ByVal XNumero As String)
        If Not IsNumeric(XNumero) Then
            Return "NULL"
        Else
            XNumero = Replace(XNumero, ".", "")
            Return Replace(XNumero, ",", ".")
        End If
    End Function

End Class
