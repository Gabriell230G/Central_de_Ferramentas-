Imports System.Data.OleDb


Public Class frm_Login
    Public IDLogon As String = Environment.UserName

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        If Trim(TxtUsuario.Text).Length = 0 Then
            MsgBox("Favor informar usu�rio.", vbExclamation)
            TxtSenha.Focus()
            Exit Sub
        End If

        If Trim(TxtSenha.Text).Length = 0 Then
            MsgBox("Favor informar a senha.", vbExclamation)
            TxtSenha.Focus()
            Exit Sub
        End If

        Dim conn As New cls_Conexao
        Dim tbl As DataTable

        conn.StrSQL = "SELECT Tb_Usuario.ID_Usuario, Tb_Usuario.Nome, Tb_Usuario.Senha FROM Tb_Usuario WHERE (((Tb_Usuario.ID_Usuario)='" & Trim(TxtUsuario.Text) & "'));"
        tbl = conn.GeraTBL
        If tbl.Rows.Count = 0 Then
            MsgBox("Usu�rio n�o cadastrado.", vbCritical)
            Exit Sub
        End If

        'validando senha
        If tbl.Rows(0)("SENHA").ToString <> Trim(TxtSenha.Text) Then
            MsgBox("Senha n�o confere.", vbExclamation)
            TxtSenha.Focus()
            Exit Sub
        End If

        conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & Trim(TxtUsuario.Text) & "', 'ACESSOU SISTEMA', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
        conn.ExecutaQuery()

        frm_Principal.lbl_usuario.Text = "Usu�rio Logado: " & tbl.Rows(0)("Nome").ToString
        frm_Principal.lbl_IDusuario.Text = tbl.Rows(0)("ID_Usuario").ToString
        frm_Principal.Show()
        Me.Close()
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        Me.Close()
    End Sub

    Private Sub LoginForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        IDLogon = Environment.UserName

        Select Case UCase(Mid(IDLogon, 1, 1))
            Case "A"
                IDLogon = "1" & Mid(IDLogon, 2, IDLogon.Length)
            Case "B"
                IDLogon = "2" & Mid(IDLogon, 2, IDLogon.Length)
            Case "C"
                IDLogon = "3" & Mid(IDLogon, 2, IDLogon.Length)
            Case "D"
                IDLogon = "4" & Mid(IDLogon, 2, IDLogon.Length)
            Case "E"
                IDLogon = "5" & Mid(IDLogon, 2, IDLogon.Length)
            Case "F"
                IDLogon = "6" & Mid(IDLogon, 2, IDLogon.Length)
            Case "G"
                IDLogon = "7" & Mid(IDLogon, 2, IDLogon.Length)
            Case "H"
                IDLogon = "8" & Mid(IDLogon, 2, IDLogon.Length)
            Case "I"
                IDLogon = "9" & Mid(IDLogon, 2, IDLogon.Length)
        End Select

        TxtUsuario.Text = IDLogon
        TxtSenha.Focus()
    End Sub
    Private Sub frm_Login_Activated(sender As Object, e As EventArgs) Handles Me.Activated
        TxtSenha.Focus()
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel_AltSenha.LinkClicked
        Dim frm As New frm_AltSenha
        frm.txt_Usuario.Text = IDLogon
        frm.ShowDialog()
    End Sub


End Class
