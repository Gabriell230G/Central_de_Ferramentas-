﻿Public Class frm_AltSenha
    Private Sub btn_Cancelar_Click(sender As Object, e As EventArgs) Handles btn_Cancelar.Click
        Me.Close()
    End Sub

    Private Sub btn_Alterar_Click(sender As Object, e As EventArgs) Handles btn_Alterar.Click
        If Trim(txt_Usuario.Text).Length = 0 Or Trim(txt_SenhaAtual.Text).Length = 0 Or Trim(txt_NovaSenha.Text).Length = 0 Or Trim(txt_NovaSenhaConfirmacao.Text).Length = 0 Then
            MsgBox("Preencha todos os campos.", vbExclamation)
            Exit Sub
        End If
        If txt_NovaSenha.Text <> txt_NovaSenhaConfirmacao.Text Then
            MsgBox("Confirmação de Senha não Confere.", vbCritical)
            Exit Sub
        End If

        Dim conn As New cls_Conexao
        Dim tbl As DataTable

        conn.StrSQL = "SELECT Tb_Usuario.ID_Usuario, Tb_Usuario.Nome, Tb_Usuario.Senha FROM Tb_Usuario WHERE (((Tb_Usuario.ID_Usuario)='" & Trim(txt_Usuario.Text) & "'));"
        tbl = conn.GeraTBL
        If tbl.Rows.Count = 0 Then
            MsgBox("Usuário não cadastrado.", vbCritical)
            Exit Sub
        End If

        'validando senha
        If tbl.Rows(0)("SENHA").ToString <> Trim(txt_SenhaAtual.Text) Then
            MsgBox("Senha não confere.", vbExclamation)
            txt_SenhaAtual.Focus()
            Exit Sub
        End If

        conn.StrSQL = "UPDATE Tb_Usuario SET Tb_Usuario.Senha = '" & Trim(txt_NovaSenha.Text) & "' WHERE (((Tb_Usuario.ID_Usuario)='" & Trim(txt_Usuario.Text) & "'));"
        If conn.ExecutaQuery Then
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora ) VALUES ('" & Trim(txt_Usuario.Text) & "', 'ALTEROU SENHA', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()
            MsgBox("Senha alterada com sucesso!", vbInformation)
            Me.Close()
        End If

    End Sub

End Class