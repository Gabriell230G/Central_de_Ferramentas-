﻿Imports System.Threading
Imports System.Runtime.InteropServices

Public Class frm_Principal
    Public objIndex As SHDocVw.InternetExplorer
    Public popup As SHDocVw.InternetExplorer

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Shared Function SendMessage(ByVal hWnd As IntPtr, ByVal Msg As UInteger, ByVal wParam As IntPtr, ByVal lParam As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll", EntryPoint:="FindWindow", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Shared Function FindWindowByCaption(
                ByVal zero As IntPtr,
                ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)>
    Private Shared Function FindWindowEx(ByVal parentHandle As IntPtr, ByVal childAfter As IntPtr, ByVal lclassName As String, ByVal windowTitle As String) As IntPtr
    End Function

    Public Const WM_CLOSE = &H10
    Private Const BM_CLICK As Integer = &HF5
    Private Const WM_ACTIVATE As Integer = &H6
    Private Const WA_ACTIVE As Integer = 1


    Private Sub frm_Principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txt_DataDep.Text = DateTime.Now.ToShortDateString()
        preencheGrade("Bem vindo Sistema de Envio TED")
        preencheGrade("Conecte ao GCPJ para iniciar o processamento")
    End Sub

    Private Sub AlterarSenhaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AlterarSenhaToolStripMenuItem.Click
        Dim frm As New frm_AltSenha
        frm.txt_Usuario.Text = lbl_IDusuario.Text
        frm.ShowDialog()
    End Sub

    Private Sub NovoToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NovoToolStripMenuItem.Click
        Dim frm As New frm_CadUsuario
        frm.Text = "Novo Usuário"
        frm.lbl_IDusuario.Text = lbl_IDusuario.Text
        frm.ShowDialog()
    End Sub

    Private Sub EditarNomeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EditarNomeToolStripMenuItem.Click
        Dim frm As New frm_CadUsuario
        frm.Text = "Alterar Nome"
        frm.lbl_IDusuario.Text = lbl_IDusuario.Text
        frm.txt_Matricula.Text = lbl_IDusuario.Text
        frm.txt_Nome.Text = Replace(lbl_usuario.Text, "Usuário Logado: ", "")
        frm.txt_Matricula.Enabled = False
        frm.ShowDialog()
    End Sub

    Private Sub btn_Sair_Click(sender As Object, e As EventArgs) Handles btn_Sair.Click
        Me.Close()
    End Sub

    Private Sub btn_GCPJ_Click(sender As Object, e As EventArgs) Handles btn_GCPJ.Click
        If VerificaGCPJ("GCPJ", 0) = False Then
            preencheGrade("GCPJ não localizado, abrindo nova janela.")
            objIndex = New SHDocVw.InternetExplorer
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj")
        End If
        btn_EnviarTED.Enabled = True
        Button1.Enabled = True
        preencheGrade("GCPJ localizado, prossiga com o procedimento")
    End Sub

    Sub preencheGrade(texto As String)
        Grade.Items.Add(DateTime.Now.ToShortDateString() + " - " + DateTime.Now.ToShortTimeString() + " " + texto)
        Grade.SelectedIndex = Grade.Items.Count - 1
    End Sub

    Private Sub btn_EnviarTED_Click(sender As Object, e As EventArgs) Handles btn_EnviarTED.Click
        Dim conn As New cls_Conexao
        Dim cont As Integer
        Dim objTable As Object
        Dim item_inicial As Integer
        Dim cont_gcpj As Integer = 0
        Dim gcpj As String = ""
        Dim valor As String = ""
        Dim pagina As Integer = 1
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de envios feitos nesta execução

        If Trim(txt_DataDep.Text) = "" Then
            preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!")
            txt_DataDep.Focus()
            Exit Sub
        End If

        If Not IsDate(txt_DataDep.Text) Then
            preencheGrade("ATENÇÃO! Informe uma data válida no campo data do depósito.")
            txt_DataDep.Focus()
            Exit Sub
        End If

        If Trim(cb_Area.Text) = "" Then
            preencheGrade("ATENÇÃO! Obrigatório o preenchimento da Área!")
            cb_Area.Focus()
            Exit Sub
        End If

        conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'ACESSOU ROTINA ENVIAR TED', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
        conn.ExecutaQuery()

        If VerificaGCPJ("GCPJ", 0) = False Then
            preencheGrade("GCPJ não localizado. Clique em Conectar GCPJ para continuar.")
            Exit Sub
        End If

        item_inicial = 2
        cont = 50
        objIndex.Visible = True

        Try
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/finDepAguardEnvTedAction?metodo=carregar&origem=")
            Espera_Ate_Que_Abra()
inicio:
            Do While cont > 3

                objTable = objIndex.Document.getElementsByTagName("table")
                cont = objTable(3).Rows.Length
                If cont = 3 Then
                    Exit Do
                End If

                If item_inicial > cont - 2 Then
                    gcpj = objTable(3).Rows(2).all.Item(2).innertext
                    pagina = pagina + 1
                    Try
                        objIndex.Document.parentWindow.execScript("document.forms[0].elements['paginaDeposito'].value=" & pagina & ";paginarFinanceiro('paginarGridFiltro')", "JavaScript")
                        Espera_Ate_Que_Abra()
                        objTable = objIndex.Document.getElementsByTagName("table")
                        If gcpj = objTable(3).Rows(2).all.Item(2).innertext Then
                            Exit Do
                        End If
                    Catch ex As Exception
                        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/finDepAguardEnvTedAction?metodo=carregar&origem=")
                        Exit Do
                    End Try
                    item_inicial = 2
                End If
                cont_gcpj = cont_gcpj + 1

                'Verifica se é o mesmo GCPJ que já tratou - se for está com erro então vai para o próximo
                If gcpj = Trim(objTable(3).Rows(item_inicial).all.Item(2).innertext) And valor = Trim(objTable(3).Rows(item_inicial).all.Item(10).innertext) Then
                    item_inicial = item_inicial + 1
                    GoTo inicio
                End If
                gcpj = Trim(objTable(3).Rows(item_inicial).all.Item(2).innertext)
                valor = Trim(objTable(3).Rows(item_inicial).all.Item(10).innertext)

                'Verifica se é CI ou TR - se não for vai para o próximo
                If Trim(objTable(3).Rows(item_inicial).all.Item(6).innertext) <> cb_Area.Text Then
                    item_inicial = item_inicial + 1
                    preencheGrade("GCPJ " & gcpj & " - TED não enviada pois Área é diferente da Área escolhida.")
                    GoTo inicio
                End If

                'Verifica se é a data Depósito informada - se não for vai para o próximo
                If Trim(txt_DataDep.Text) <> Trim(objTable(3).Rows(item_inicial).all.Item(9).innertext) Then
                    item_inicial = item_inicial + 1
                    preencheGrade("GCPJ " & gcpj & " - TED não enviada pois a Data do depósito é diferente da data escolhida.")
                    GoTo inicio
                End If

                '[S5] Limitador de operações: antes de enviar o próximo depósito, confere se o limite
                '     da execução já foi atingido (ver Mod_LimitadorS5.vb)
                If LimiteS5Atingido(qtdOperacoesS5) Then
                    preencheGrade("Controle S5: limite de " & Format(LIMITE_OPERACOES_S5, "#,##0") & " envios atingido. Processamento interrompido.")
                    conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'CONTROLE S5 - LIMITE DE OPERACOES ATINGIDO NA ROTINA ENVIAR TED', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
                    conn.ExecutaQuery()
                    Exit Do
                End If
                qtdOperacoesS5 += 1

                objTable(3).Rows(item_inicial).all.Item(1).Click

                objIndex.Document.all.Item("btoEnviarTed").Click
                If Not MataMsgbox() Then
                    item_inicial = item_inicial + 1
                    GoTo inicio
                End If
                preencheGrade("GCPJ " & gcpj & " - TED enviada com sucesso!")
                Espera_Ate_Que_Abra()

            Loop

        Catch ex As Exception
            If cont_gcpj > 0 Then
                item_inicial = item_inicial + 1
            End If
            GoTo inicio
        End Try

        If cont_gcpj = 0 Then
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'EXECUTOU ROTINA ENVIAR TED - NENHUM REGISTRO LOCALIZADO PARA ENVIAR', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            MsgBox("Nenhum registro localizado para enviar.", vbInformation, "Sistema de Envio TED")
        ElseIf item_inicial > 2 Then
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'EXECUTOU ROTINA ENVIAR TED COM SUCESSO - ALGUNS ITENS NÃO PUDERAM SER ENVIADOS', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            MsgBox("Operação realizada com sucesso!" & vbNewLine & vbNewLine &
                   "Alguns registros não puderam ser enviados. Verifique!", vbInformation, "Sistema de Envio TED")
        Else
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'EXECUTOU ROTINA ENVIAR TED COM SUCESSO', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            MsgBox("Operação realizada com sucesso!", vbInformation, "Sistema de Envio TED")
        End If
        preencheGrade("Processo finalizado!")
    End Sub


    Private Function VerificaGCPJ(ByVal nomeJanela As String, ByVal tipo As Integer) As Boolean
        'ROTINA QUE DEVERA FICAR EM SEU CODIGO QUE VERIFICA SE O GCPJ ESTÁ ATIVO, E INSERE NO OBJETO objIndex O SISTEMA
        For Each ie As SHDocVw.InternetExplorer In New SHDocVw.ShellWindows
            If InStr(ie.LocationName.ToString, nomeJanela) Then
                If tipo = 0 Then
                    objIndex = ie
                Else
                    popup = ie
                End If
                ' preencheGrade("Janela encontrada: " & ie.LocationName.ToString)
                Return True
            End If
        Next

        Return False
    End Function

    Private Sub Espera_Ate_Que_Abra()
        Try
            ' Thread.Sleep(5000)
            Do While objIndex.ReadyState = 0 Or objIndex.ReadyState = 1 Or objIndex.ReadyState = 3
                'Espera até que abra
            Loop
            Do While objIndex.Busy = True
                'Espera até que abra
            Loop
        Catch ex As Exception

        End Try

    End Sub

    Private Function MataMsgbox() As Boolean
        Dim winHwnd As Long
        Dim cont As Integer = 1

        Do Until winHwnd <> 0
            Thread.Sleep(100)
            winHwnd = FindWindowByCaption(vbNullString, "Mensagem da página da web")

            cont = cont + 1
            If cont = 500 Or (cont = 50 And objIndex.ReadyState <> 0 And objIndex.ReadyState <> 1 And objIndex.ReadyState <> 3 And objIndex.Busy = False) Then
                Return False
            End If
        Loop

        Thread.Sleep(1000)
        Dim btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK")
        SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, 0)
        SendMessage(btn, BM_CLICK, 0, 0)
        Return True
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim conn As New cls_Conexao
        Dim cont As Integer
        Dim objTable As Object
        Dim item_inicial As Integer
        Dim cont_gcpj As Integer = 0
        Dim gcpj As String = ""
        Dim valor As String = ""
        Dim pagina As Integer = 1
        Dim qtdOperacoesS5 As Integer = 0 '[S5] contador de envios feitos nesta execução

        If Trim(txt_DataDep.Text) = "" Then
            preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!")
            txt_DataDep.Focus()
            Exit Sub
        End If

        If Not IsDate(txt_DataDep.Text) Then
            preencheGrade("ATENÇÃO! Informe uma data válida no campo data do depósito.")
            txt_DataDep.Focus()
            Exit Sub
        End If

        If Trim(cb_Area.Text) = "" Then
            preencheGrade("ATENÇÃO! Obrigatório o preenchimento da Área!")
            cb_Area.Focus()
            Exit Sub
        End If

        conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'ACESSOU ROTINA ENVIAR TED', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
        conn.ExecutaQuery()

        If VerificaGCPJ("GCPJ", 0) = False Then
            preencheGrade("GCPJ não localizado. Clique em Conectar GCPJ para continuar.")
            Exit Sub
        End If

        item_inicial = 2
        cont = 50
        objIndex.Visible = True

        Try
            objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/finDepAguardEnvCredBradAction?metodo=carregar")
            Espera_Ate_Que_Abra()
inicio:
            Do While cont > 3

                objTable = objIndex.Document.getElementsByTagName("table")
                cont = objTable(3).Rows.Length
                If cont = 3 Then
                    Exit Do
                End If

                If item_inicial > cont - 2 Then
                    gcpj = objTable(3).Rows(2).all.Item(2).innertext
                    pagina = pagina + 1
                    Try
                        objIndex.Document.parentWindow.execScript("document.forms[0].elements['paginaDeposito'].value=" & pagina & ";paginarFinanceiro('paginarGridFiltro')", "JavaScript")
                        Espera_Ate_Que_Abra()
                        objTable = objIndex.Document.getElementsByTagName("table")
                        If gcpj = objTable(3).Rows(2).all.Item(2).innertext Then
                            Exit Do
                        End If
                    Catch ex As Exception
                        objIndex.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/finDepAguardEnvCredBradAction?metodo=carregar")
                        Exit Do
                    End Try
                    item_inicial = 2
                End If
                cont_gcpj = cont_gcpj + 1

                'Verifica se é o mesmo GCPJ que já tratou - se for está com erro então vai para o próximo
                If gcpj = Trim(objTable(3).Rows(item_inicial).all.Item(2).innertext) And valor = Trim(objTable(3).Rows(item_inicial).all.Item(10).innertext) Then
                    item_inicial = item_inicial + 1
                    GoTo inicio
                End If
                gcpj = Trim(objTable(3).Rows(item_inicial).all.Item(2).innertext)
                valor = Trim(objTable(3).Rows(item_inicial).all.Item(10).innertext)

                'Verifica se é CI ou TR - se não for vai para o próximo
                If Trim(objTable(3).Rows(item_inicial).all.Item(6).innertext) <> cb_Area.Text Then
                    item_inicial = item_inicial + 1
                    preencheGrade("GCPJ " & gcpj & " - CRED CONTA não enviada pois Área é diferente da Área escolhida.")
                    GoTo inicio
                End If

                'Verifica se é a data Depósito informada - se não for vai para o próximo
                If Trim(txt_DataDep.Text) <> Trim(objTable(3).Rows(item_inicial).all.Item(9).innertext) Then
                    item_inicial = item_inicial + 1
                    preencheGrade("GCPJ " & gcpj & " - CRED CONTA não enviada pois a Data do depósito é diferente da data escolhida.")
                    GoTo inicio
                End If

                '[S5] Limitador de operações: antes de enviar o próximo depósito, confere se o limite
                '     da execução já foi atingido (ver Mod_LimitadorS5.vb)
                If LimiteS5Atingido(qtdOperacoesS5) Then
                    preencheGrade("Controle S5: limite de " & Format(LIMITE_OPERACOES_S5, "#,##0") & " envios atingido. Processamento interrompido.")
                    conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'CONTROLE S5 - LIMITE DE OPERACOES ATINGIDO NA ROTINA ENVIAR CRED CONTA', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
                    conn.ExecutaQuery()
                    Exit Do
                End If
                qtdOperacoesS5 += 1

                objTable(3).Rows(item_inicial).all.Item(1).Click

                objIndex.Document.all.Item("btoEnviarCreditoConta").Click
                If Not MataMsgbox() Then
                    item_inicial = item_inicial + 1
                    GoTo inicio
                End If
                preencheGrade("GCPJ " & gcpj & " - CRED CONTA enviada com sucesso!")
                Espera_Ate_Que_Abra()

            Loop

        Catch ex As Exception
            If cont_gcpj > 0 Then
                item_inicial = item_inicial + 1
            End If
            GoTo inicio
        End Try

        If cont_gcpj = 0 Then
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'EXECUTOU ROTINA ENVIAR CRED CONTA - NENHUM REGISTRO LOCALIZADO PARA ENVIAR', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            MsgBox("Nenhum registro localizado para enviar.", vbInformation, "Sistema de Envio CRED CONTA")
        ElseIf item_inicial > 2 Then
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'EXECUTOU ROTINA ENVIAR CRED CONTA COM SUCESSO - ALGUNS ITENS NÃO PUDERAM SER ENVIADOS', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            MsgBox("Operação realizada com sucesso!" & vbNewLine & vbNewLine &
                   "Alguns registros não puderam ser enviados. Verifique!", vbInformation, "Sistema de Envio CRED CONTA")
        Else
            conn.StrSQL = "INSERT INTO Tb_Log ( ID_Usuario, Log, DataHora) VALUES ('" & lbl_IDusuario.Text & "', 'EXECUTOU ROTINA ENVIAR CRED CONTA COM SUCESSO', '" & Format(DateTime.Now, "yyyy-MM-dd HH:mm:ss") & "');"
            conn.ExecutaQuery()

            MsgBox("Operação realizada com sucesso!", vbInformation, "Sistema de Envio TED")
        End If
        preencheGrade("Processo finalizado!")

    End Sub
End Class