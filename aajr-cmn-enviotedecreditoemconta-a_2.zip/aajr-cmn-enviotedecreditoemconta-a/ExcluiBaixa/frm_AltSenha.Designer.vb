﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_AltSenha
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_AltSenha))
        Me.txt_NovaSenhaConfirmacao = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_NovaSenha = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_SenhaAtual = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_Usuario = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btn_Cancelar = New System.Windows.Forms.Button()
        Me.btn_Alterar = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txt_NovaSenhaConfirmacao
        '
        Me.txt_NovaSenhaConfirmacao.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.txt_NovaSenhaConfirmacao.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_NovaSenhaConfirmacao.Location = New System.Drawing.Point(100, 109)
        Me.txt_NovaSenhaConfirmacao.Name = "txt_NovaSenhaConfirmacao"
        Me.txt_NovaSenhaConfirmacao.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_NovaSenhaConfirmacao.Size = New System.Drawing.Size(110, 23)
        Me.txt_NovaSenhaConfirmacao.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(22, 113)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(75, 15)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Confirmação:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_NovaSenha
        '
        Me.txt_NovaSenha.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.txt_NovaSenha.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_NovaSenha.Location = New System.Drawing.Point(100, 78)
        Me.txt_NovaSenha.Name = "txt_NovaSenha"
        Me.txt_NovaSenha.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_NovaSenha.Size = New System.Drawing.Size(110, 23)
        Me.txt_NovaSenha.TabIndex = 14
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(22, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 15)
        Me.Label2.TabIndex = 17
        Me.Label2.Text = "Nova Senha:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_SenhaAtual
        '
        Me.txt_SenhaAtual.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.txt_SenhaAtual.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_SenhaAtual.Location = New System.Drawing.Point(100, 46)
        Me.txt_SenhaAtual.Name = "txt_SenhaAtual"
        Me.txt_SenhaAtual.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt_SenhaAtual.Size = New System.Drawing.Size(110, 23)
        Me.txt_SenhaAtual.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(22, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 15)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "Senha Atual:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_Usuario
        '
        Me.txt_Usuario.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.txt_Usuario.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Usuario.Location = New System.Drawing.Point(100, 15)
        Me.txt_Usuario.Name = "txt_Usuario"
        Me.txt_Usuario.Size = New System.Drawing.Size(110, 23)
        Me.txt_Usuario.TabIndex = 19
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(22, 19)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 15)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Usuário:"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btn_Cancelar
        '
        Me.btn_Cancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_Cancelar.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Cancelar.Image = CType(resources.GetObject("btn_Cancelar.Image"), System.Drawing.Image)
        Me.btn_Cancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Cancelar.Location = New System.Drawing.Point(119, 149)
        Me.btn_Cancelar.Name = "btn_Cancelar"
        Me.btn_Cancelar.Size = New System.Drawing.Size(97, 42)
        Me.btn_Cancelar.TabIndex = 22
        Me.btn_Cancelar.Text = "&Cancelar"
        Me.btn_Cancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btn_Alterar
        '
        Me.btn_Alterar.Font = New System.Drawing.Font("Bradesco Sans", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Alterar.Image = CType(resources.GetObject("btn_Alterar.Image"), System.Drawing.Image)
        Me.btn_Alterar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Alterar.Location = New System.Drawing.Point(16, 149)
        Me.btn_Alterar.Name = "btn_Alterar"
        Me.btn_Alterar.Size = New System.Drawing.Size(97, 42)
        Me.btn_Alterar.TabIndex = 21
        Me.btn_Alterar.Text = "Alterar"
        Me.btn_Alterar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frm_AltSenha
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(233, 206)
        Me.Controls.Add(Me.btn_Cancelar)
        Me.Controls.Add(Me.btn_Alterar)
        Me.Controls.Add(Me.txt_Usuario)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_NovaSenhaConfirmacao)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txt_NovaSenha)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt_SenhaAtual)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Bradesco Sans Condensed", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frm_AltSenha"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Alterar Senha"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_NovaSenhaConfirmacao As Windows.Forms.TextBox
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents txt_NovaSenha As Windows.Forms.TextBox
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents txt_SenhaAtual As Windows.Forms.TextBox
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents txt_Usuario As Windows.Forms.TextBox
    Friend WithEvents Label4 As Windows.Forms.Label
    Friend WithEvents btn_Cancelar As Windows.Forms.Button
    Friend WithEvents btn_Alterar As Windows.Forms.Button
End Class
