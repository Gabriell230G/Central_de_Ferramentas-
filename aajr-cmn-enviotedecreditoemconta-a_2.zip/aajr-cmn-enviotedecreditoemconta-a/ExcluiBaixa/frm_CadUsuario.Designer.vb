﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_CadUsuario
    Inherits System.Windows.Forms.Form

    'Descartar substituições de formulário para limpar a lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Exigido pelo Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'OBSERVAÇÃO: o procedimento a seguir é exigido pelo Windows Form Designer
    'Pode ser modificado usando o Windows Form Designer.  
    'Não o modifique usando o editor de códigos.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_CadUsuario))
        Me.txt_Matricula = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt_Nome = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btn_Cancelar = New System.Windows.Forms.Button()
        Me.btn_Salvar = New System.Windows.Forms.Button()
        Me.lbl_IDusuario = New System.Windows.Forms.Label()
        Me.grid_usuarios = New System.Windows.Forms.DataGridView()
        CType(Me.grid_usuarios, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txt_Matricula
        '
        Me.txt_Matricula.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.txt_Matricula.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Matricula.Location = New System.Drawing.Point(175, 21)
        Me.txt_Matricula.Name = "txt_Matricula"
        Me.txt_Matricula.Size = New System.Drawing.Size(195, 23)
        Me.txt_Matricula.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(12, 25)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(157, 15)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Matrícula (somente números):"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_Nome
        '
        Me.txt_Nome.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.txt_Nome.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_Nome.Location = New System.Drawing.Point(57, 54)
        Me.txt_Nome.Name = "txt_Nome"
        Me.txt_Nome.Size = New System.Drawing.Size(313, 23)
        Me.txt_Nome.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 15)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Nome:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'btn_Cancelar
        '
        Me.btn_Cancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_Cancelar.Font = New System.Drawing.Font("Bradesco Sans Condensed", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Cancelar.Image = CType(resources.GetObject("btn_Cancelar.Image"), System.Drawing.Image)
        Me.btn_Cancelar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Cancelar.Location = New System.Drawing.Point(198, 96)
        Me.btn_Cancelar.Name = "btn_Cancelar"
        Me.btn_Cancelar.Size = New System.Drawing.Size(97, 42)
        Me.btn_Cancelar.TabIndex = 6
        Me.btn_Cancelar.Text = "Cancelar"
        Me.btn_Cancelar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btn_Salvar
        '
        Me.btn_Salvar.Font = New System.Drawing.Font("Bradesco Sans", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Salvar.Image = CType(resources.GetObject("btn_Salvar.Image"), System.Drawing.Image)
        Me.btn_Salvar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_Salvar.Location = New System.Drawing.Point(95, 96)
        Me.btn_Salvar.Name = "btn_Salvar"
        Me.btn_Salvar.Size = New System.Drawing.Size(97, 42)
        Me.btn_Salvar.TabIndex = 5
        Me.btn_Salvar.Text = "Salvar "
        Me.btn_Salvar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lbl_IDusuario
        '
        Me.lbl_IDusuario.AutoSize = True
        Me.lbl_IDusuario.Location = New System.Drawing.Point(334, 111)
        Me.lbl_IDusuario.Name = "lbl_IDusuario"
        Me.lbl_IDusuario.Size = New System.Drawing.Size(18, 13)
        Me.lbl_IDusuario.TabIndex = 8
        Me.lbl_IDusuario.Text = "ID"
        Me.lbl_IDusuario.Visible = False
        '
        'grid_usuarios
        '
        Me.grid_usuarios.AllowUserToAddRows = False
        Me.grid_usuarios.AllowUserToDeleteRows = False
        Me.grid_usuarios.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.grid_usuarios.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.grid_usuarios.BackgroundColor = System.Drawing.Color.WhiteSmoke
        Me.grid_usuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grid_usuarios.Location = New System.Drawing.Point(15, 164)
        Me.grid_usuarios.Name = "grid_usuarios"
        Me.grid_usuarios.ReadOnly = True
        Me.grid_usuarios.RowHeadersWidth = 25
        Me.grid_usuarios.Size = New System.Drawing.Size(354, 240)
        Me.grid_usuarios.TabIndex = 7
        '
        'frm_CadUsuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(387, 416)
        Me.Controls.Add(Me.grid_usuarios)
        Me.Controls.Add(Me.lbl_IDusuario)
        Me.Controls.Add(Me.btn_Cancelar)
        Me.Controls.Add(Me.btn_Salvar)
        Me.Controls.Add(Me.txt_Matricula)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt_Nome)
        Me.Controls.Add(Me.Label1)
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.Name = "frm_CadUsuario"
        Me.Text = "Envio TED - Cadastro de Usuários"
        CType(Me.grid_usuarios, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt_Matricula As Windows.Forms.TextBox
    Friend WithEvents Label4 As Windows.Forms.Label
    Friend WithEvents txt_Nome As Windows.Forms.TextBox
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents btn_Cancelar As Windows.Forms.Button
    Friend WithEvents btn_Salvar As Windows.Forms.Button
    Friend WithEvents lbl_IDusuario As Windows.Forms.Label
    Friend WithEvents grid_usuarios As Windows.Forms.DataGridView
End Class
