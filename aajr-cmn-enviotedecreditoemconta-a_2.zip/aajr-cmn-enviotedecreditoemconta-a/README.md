# Sistema de Envio TED e Crédito em Conta (aajr-cmn-enviotedecreditoemconta-a)

Robô que envia, no GCPJ, os depósitos judiciais que estão **aguardando envio** por **TED** ou por **Crédito em Conta Bradesco**, filtrando por área (CI / TR) e data do depósito.

| Item | Valor |
|---|---|
| Código no inventário | **C@ZB** (Envio ted e crédito em conta) |
| Área | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| Linguagem | VB.NET (Windows Forms) |
| Framework | .NET Framework 4.8 |
| Sistema alvo | GCPJ (Internet Explorer, via SHDocVw) |
| Base local | `BD\BD_DADOS.accdb` (usuários e log) |
| Acesso | login próprio (`Tb_Usuario`) |
| Log | tabela `Tb_Log` |
| Controle S5 | Implementado (limite de **5.000** envios por execução) |

> A pasta do projeto se chama `ExcluiBaixa` por herança. O executável gerado é o **EnvioTED**.

---

## Sumário

1. [O que o sistema faz](#1-o-que-o-sistema-faz)
2. [Como rodar](#2-como-rodar)
3. [Estrutura do projeto](#3-estrutura-do-projeto)
4. [Controle S5: Limitador de Operações](#4-controle-s5-limitador-de-operações)
5. [Guia rápido: quero mudar X, onde vou?](#5-guia-rápido-quero-mudar-x-onde-vou)
6. [Pontos de atenção](#6-pontos-de-atenção)
7. [Histórico](#7-histórico)

---

## 1. O que o sistema faz

```
Login ➜ Conectar GCPJ ➜ informar Data Depósito e Área ➜ Enviar TED (ou Enviar CRED)
   ➜ o robô percorre a lista "Aguardando Envio" página por página
   ➜ para cada linha: é da área escolhida? é da data escolhida?
        ➜ SIM: seleciona e envia
        ➜ NÃO: pula para a próxima
   ➜ termina quando acabam as páginas OU quando atinge o limite do Controle S5
   ➜ grava o resultado no Tb_Log
```

| Botão | O que faz | Tela do GCPJ |
|---|---|---|
| **Conectar GCPJ** | Procura o GCPJ aberto ou abre um novo | - |
| **Enviar TED** | Envia os depósitos por TED | Financeiro Contábil ➜ Lançamentos ➜ Depósito Judicial ➜ Aguardando Envio da TED |
| **Enviar CRED** | Envia os depósitos por Crédito em Conta | Financeiro Contábil ➜ Lançamentos ➜ Depósito Judicial ➜ Aguardando Envio Crédito Bradesco |
| **Cadastro Usuários** | Novo usuário, editar nome, alterar senha | - |

## 2. Como rodar

1. Abra `EnvioTED.sln` no Visual Studio.
2. Instale o **Microsoft Access Database Engine** (ACE OLEDB 12.0).
3. Garanta a pasta `BD\BD_DADOS.accdb` ao lado do executável.
4. Faça login, clique em **Conectar GCPJ**, preencha **Data Depósito** e **Área** e escolha o envio.

## 3. Estrutura do projeto

| Arquivo | Para que serve |
|---|---|
| `frm_Login.vb` | Tela de login (valida na `Tb_Usuario` e grava *ACESSOU SISTEMA* no log) |
| `frm_Principal.vb` | Tela principal e as **duas rotinas de envio** |
| `frm_CadUsuario.vb` / `frm_AltSenha.vb` | Cadastro de usuário e troca de senha |
| `cls_Conexao.vb` | Conexão com o Access |
| `Mod_LimitadorS5.vb` | **Controle S5**: limite de operações por execução |

## 4. Controle S5: Limitador de Operações

Exigência do normativo **05.1073** para aplicativos com C10 = Sim.

### Como funciona

```
Clique em Enviar ➜ contador = 0
   Antes de enviar cada depósito:
      contador já chegou no limite?  ➜ SIM: avisa, grava no Tb_Log e para
                                      ➜ NÃO: envia e soma 1
```

O contador só soma **envios de verdade**. Linhas puladas (área ou data diferente) não contam.

Ao atingir o limite:

- aparece a mensagem **"Processamento Limitado - Controle S5"**;
- a grade mostra *"Controle S5: limite de 5.000 envios atingido. Processamento interrompido."*;
- o `Tb_Log` recebe *"CONTROLE S5 - LIMITE DE OPERACOES ATINGIDO NA ROTINA ENVIAR TED"* (ou *ENVIAR CRED CONTA*);
- os depósitos que sobraram continuam em "Aguardando Envio" no GCPJ.

### Onde mexer

| O que | Arquivo | Onde |
|---|---|---|
| **Valor do limite** | `Mod_LimitadorS5.vb` | constante `LIMITE_OPERACOES_S5` (linha 23) |
| Mensagem exibida ao usuário | `Mod_LimitadorS5.vb` | função `LimiteS5Atingido` |
| Envio TED | `frm_Principal.vb` | `btn_EnviarTED_Click`, bloco `[S5]` na linha 170 |
| Envio Crédito em Conta | `frm_Principal.vb` | `Button1_Click`, bloco `[S5]` na linha 366 |

> Dica: **Ctrl+Shift+F** e pesquise `[S5]`.

### Documento de evidências

O Word com as evidências do Controle S5 (trechos do código alterado, resultado dos testes e espaço para os prints do ambiente) fica em [`docs/Evidencias_S5_EnvioTED.docx`](docs/Evidencias_S5_EnvioTED.docx).

### Como testar e gerar a evidência

1. Em `Mod_LimitadorS5.vb`, troque temporariamente `LIMITE_OPERACOES_S5 = 5000` para `2`.
2. Rode o envio com pelo menos 3 depósitos da área e data escolhidas.
3. Confira: 2 envios, o aviso **Processamento Limitado - Controle S5** e a linha no `Tb_Log`.
4. Tire os prints com o **relógio do Windows aparecendo**: código, mensagem e `Tb_Log`.
5. **Volte o valor para 5000** antes de gerar a versão final.

## 5. Guia rápido: quero mudar X, onde vou?

| Quero... | Vá em |
|---|---|
| Mudar o limite do Controle S5 | `Mod_LimitadorS5.vb` ➜ `LIMITE_OPERACOES_S5` |
| Mudar as áreas disponíveis (CI / TR) | `frm_Principal.Designer.vb` ➜ itens do `cb_Area` |
| Mudar as colunas lidas na tabela do GCPJ | `frm_Principal.vb` ➜ `objTable(3).Rows(item_inicial).all.Item(n)` (2 = GCPJ, 6 = área, 9 = data, 10 = valor) |
| Mudar o que vai para o log | `frm_Principal.vb` ➜ `INSERT INTO Tb_Log` |

## 6. Pontos de atenção

- As duas rotinas são quase cópias uma da outra. Mudou uma, confira a outra.
- O laço usa `GoTo inicio` para pular linhas e para tentar de novo após erro. O bloco `[S5]` fica **logo antes do envio**, então pulos e novas tentativas não somam no contador.
- A senha do usuário fica na `Tb_Usuario` do Access.

## 7. Histórico

| Data | Autor | Alteração |
|---|---|---|
| 12/2025 | Daniela Chirinian | Primeiro commit (migração para o GitHub) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`Mod_LimitadorS5.vb`) e novo README |

---

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
