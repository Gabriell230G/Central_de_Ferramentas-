﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.OleDb;
using System.Windows.Forms;


namespace EnviaDepositoGCPJ
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (Automacao.localizarJanela("GCPJ") == false)
            {
                Automacao.novaJanela("https://intranet85.net.bradesco.com.br/gcpj");
                preencheGrade("GCPJ não localizado, abrindo nova instância, favor fazer login e tentar novamente");
                btnEnvia.Enabled = false;
                return;
            }

            preencheGrade("GCPJ localizado, prossiga com a automação");
            btnEnvia.Enabled = true;
        }

        private void preencheGrade(String texto)
        {
            Grade.Items.Add(DateTime.Now.ToShortDateString() + " - " + DateTime.Now.ToShortTimeString() + " " + texto);
            Grade.SelectedIndex = Grade.Items.Count - 1;
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            preencheGrade("Bem vindo ao envia depósito, por favor conecte ao GCPJ");
        }

        private void btnEnvia_Click(object sender, EventArgs e)
        {
            int contador = 0;
            preencheGrade("Navegando para a tela de envio de depósitos");
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/finDepAEnviarAction?metodo=carregar&origem=financeiro");
            Automacao.espera();

            while (Automacao.selecionarRadio(0, "itemSelecionado"))
            {
                // [S5] Limitador de operações: "contador" já soma os depósitos enviados; para ao atingir o limite (ver LimitadorS5.cs)
                if (LimitadorS5.LimiteAtingido(contador))
                {
                    preencheGrade(LimitadorS5.MensagemLog());
                    break;
                }

                Automacao.espera();
                Automacao.clicar("btoEnviar");
                Automacao.mataMsgBox();
                contador++;
                preencheGrade("Foram aprovados: " + contador.ToString() + " até o momento");
            }

            preencheGrade("Processamento realizado com sucesso!");
            
        }
    }
}
