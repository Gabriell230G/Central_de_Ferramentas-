# Envia Depósitos GCPJ (aajr-cmn-enviadepositogcpj-auto)

Robô que envia, no GCPJ, todos os depósitos que estão na tela **"Depósitos a Enviar"** do Financeiro.

| Item | Valor |
|---|---|
| Código no inventário | **C@KR** (Automação envia depósito no GCPJ) |
| Área | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| Linguagem | C# (Windows Forms) |
| Framework | .NET Framework 4.6.1 |
| Sistema alvo | GCPJ (Internet Explorer, via SHDocVw / mshtml) |
| Base local | não usa |
| Controle S5 | Implementado (limite de **5.000** envios por execução) |

---

## Sumário

1. [O que o sistema faz](#1-o-que-o-sistema-faz)
2. [Como rodar](#2-como-rodar)
3. [Estrutura do projeto](#3-estrutura-do-projeto)
4. [Controle S5: Limitador de Operações](#4-controle-s5-limitador-de-operações)
5. [Guia rápido: quero mudar X, onde vou?](#5-guia-rápido-quero-mudar-x-onde-vou)
6. [Histórico](#6-histórico)

---

## 1. O que o sistema faz

```
Conectar GCPJ ➜ Enviar Depósitos
   ➜ abre "Depósitos a Enviar"
   ➜ enquanto existir um item na lista: seleciona o primeiro ➜ clica em Enviar ➜ confirma
   ➜ termina quando a lista fica vazia OU quando atinge o limite do Controle S5
```

| Botão | O que faz |
|---|---|
| **Conectar GCPJ** | Procura o GCPJ aberto. Se não achar, abre um novo e pede para logar e clicar de novo |
| **Enviar Depósitos** | Envia os depósitos um a um e mostra quantos já foram |

## 2. Como rodar

1. Abra `EnviaDepositoGCPJ.sln` no Visual Studio.
2. Rode, clique em **Conectar GCPJ** e faça login no Internet Explorer.
3. Clique de novo em **Conectar GCPJ** (o botão **Enviar Depósitos** só libera quando o GCPJ é encontrado) e depois em **Enviar Depósitos**.

## 3. Estrutura do projeto

| Arquivo | Para que serve |
|---|---|
| `Form1.cs` | Tela e a rotina de envio (`btnEnvia_Click`) |
| `Form1.Designer.cs` | Layout da tela |
| `Automacao.cs` | Funções que controlam o Internet Explorer |
| `LimitadorS5.cs` | **Controle S5**: limite de operações por execução |

## 4. Controle S5: Limitador de Operações

Exigência do normativo **05.1073** para aplicativos com C10 = Sim.

### Como funciona

A rotina já tinha uma variável `contador` que soma os depósitos enviados. O Controle S5 usa esse mesmo contador:

```
Enviar Depósitos ➜ contador = 0
   Antes de enviar cada depósito:
      contador já chegou no limite?  ➜ SIM: avisa o usuário e para
                                      ➜ NÃO: envia e soma 1
```

Ao atingir o limite aparece a mensagem **"Processamento Limitado - Controle S5"** e a grade registra *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*. Os depósitos que sobraram continuam na tela "Depósitos a Enviar".

### Onde mexer

| O que | Arquivo | Onde |
|---|---|---|
| **Valor do limite** | `LimitadorS5.cs` | constante `LIMITE_OPERACOES` (linha 26) |
| Mensagem exibida ao usuário | `LimitadorS5.cs` | método `LimiteAtingido` |
| Ponto de checagem no laço | `Form1.cs` | `btnEnvia_Click`, bloco `[S5]` na linha 61 |

### Documento de evidências

O Word com as evidências do Controle S5 (trechos do código alterado, resultado dos testes e espaço para os prints do ambiente) fica em [`docs/Evidencias_S5_EnviaDepositoGCPJ.docx`](docs/Evidencias_S5_EnviaDepositoGCPJ.docx).

### Como testar e gerar a evidência

1. Em `LimitadorS5.cs`, troque temporariamente `LIMITE_OPERACOES = 5000` para `2`.
2. Rode com pelo menos 3 depósitos na fila.
3. Confira: 2 depósitos enviados e o aviso **Processamento Limitado - Controle S5**.
4. Tire os prints com o **relógio do Windows aparecendo**: código e mensagem.
5. **Volte o valor para 5000** antes de gerar a versão final.

## 5. Guia rápido: quero mudar X, onde vou?

| Quero... | Vá em |
|---|---|
| Mudar o limite do Controle S5 | `LimitadorS5.cs` ➜ `LIMITE_OPERACOES` |
| Mudar a tela do GCPJ | `Form1.cs` ➜ URL `finDepAEnviarAction` |
| Mudar o botão clicado no GCPJ | `Form1.cs` ➜ `Automacao.clicar("btoEnviar")` |

## 6. Histórico

| Data | Autor | Alteração |
|---|---|---|
| 01/2026 | Daniela Chirinian | Primeiro commit (migração para o GitHub) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LimitadorS5.cs`) e novo README |

---

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
