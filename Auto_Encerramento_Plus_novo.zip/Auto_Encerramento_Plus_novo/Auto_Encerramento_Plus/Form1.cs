﻿using System;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Threading;
using System.Diagnostics;
using System.Drawing.Drawing2D;
using static Auto_Encerramento_Plus.ClsVersion;
using System.Data;
using System.Collections.Generic;

namespace Auto_Encerramento_Plus
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, EventArgs e)
        {
            preencheGrade("Localizando GCPJ....");
            if (Automacao.localizarJanela("GCPJ") == false)
            {
                preencheGrade("GCPJ não localizado, abrindo nova janela.");
                Automacao.novaJanela("https://intranet85.net.bradesco.com.br/gcpj/");
            }
            preencheGrade("GCPJ localizado, prossiga com o procedimento");
        }

        private void preencheGrade(String texto)
        {
            Grade.Items.Add(DateTime.Now.ToShortDateString() + " - " + DateTime.Now.ToShortTimeString() + " " + texto);
            Grade.SelectedIndex = Grade.Items.Count - 1;
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            preencheGrade("Bem vindo ao auto encerramento plus");
            preencheGrade("Carregue a base de dados com os processos que deseja encerrar e");
            preencheGrade("Conecte ao GCPJ para iniciar o processamento");
            txtPassword.TextBox.PasswordChar = '*';
            toolStripStatusLabel1.Text = "BANCO BRADESCO S / A - DEPARTAMENTO JURÍDICO - MATRIZ - VERSION GOGS " + VersionGIT + "";

            CBSelecionaProcessamento.Items.Add("ENCERRAMENTO");
            CBSelecionaProcessamento.Items.Add("COMPLEMENTAR");
            CBSelecionaProcessamento.Items.Add("ACORDOS");

        }

        string vMSGSalvar;
        string vMSGSalvar2;
        private void btnProcessar_Click(object sender, EventArgs e)
        {
            if (CBSelecionaProcessamento.Text == "")
            {
                MessageBox.Show("Selecione um tipo de processamento!");
                return;
            }

            if (CBSelecionaProcessamento.Text == "ENCERRAMENTO" || CBSelecionaProcessamento.Text == "ACORDOS")
            {
                encerramento();
            }
            else
            {
                complementar();
            }
        }

        public void clicarEncerrar()
        {
            vMSGSalvar = Automacao.lerMsgBox();
        }

        private void solicitarEncerramento(double gcpj)
        {
            //carregando os dados...
            string tipoprocessamento;
            tipoprocessamento = atualizatabela(CBSelecionaProcessamento.Text);
            OleDbDataReader dr2;
            if(CBSelecionaProcessamento.Text == "ENCERRAMENTO")
            {
                dr2 = Conexao.consultar("SELECT * FROM TB_ENCERRAMENTO WHERE GCPJ = " + gcpj);
            }
            else
            {
                dr2 = Conexao.consultar("SELECT * FROM TB_ACORDOS WHERE GCPJ = " + gcpj);
            }
            
            dr2.Read();

            //valor base para o encerramento....
            Automacao.setaValorNome("valoresEncerramentoVO.vlBaseEncerramento", dr2.GetDouble(6).ToString("N"));
            Automacao.clicar("btoSalvar");
            Automacao.espera();

            //localizar a popup do IR para fechar.
            Thread.Sleep(500);
            Automacao.fecharPopUp("traEncerrRecolIR?metodo");

            //ir isento
            Automacao.selecionaCombo("cdMotivoRecolhimento", "17", "value");
            Automacao.clicar("btoSalvar");
            Automacao.mataPossivelMsgBox();

            //resumo do encerramento
            Thread.Sleep(500);
            Automacao.espera();
            Automacao.clicar("btoContinuar");
            Automacao.espera();

            //data deposito hoje mais um dia útil
            DateTime dt = new DateTime();
            String validaferiado = "";
            dt = DateTime.Now;
            dt = dt.AddDays(1);//Correção de 48 horas para 24 horas - Atendendo a RO 2611103 - Analista: Gabriel Vasconcellos Gomes
            checagem:
            if (dt.DayOfWeek == DayOfWeek.Saturday)
            {
                dt = dt.AddDays(2);
            }

            if (dt.DayOfWeek == DayOfWeek.Sunday)
            {
                dt = dt.AddDays(1);
            }
                     
            //verificando feriados....
            preencheGrade("Verificando feriados");
            OleDbDataReader drFeriado;
            int dia = dt.Day;
            int mes = dt.Month;
            int dia2 = 0;
            int mes2 = 0;
            if (validaferiado == "" || validaferiado == "dt2")
            {
                DateTime dt2 = dt;
                dt2 = dt2.AddDays(-1);
                dia2 = dt2.Day;
                mes2 = dt2.Month;

            }

            drFeriado = Conexao.consultar("SELECT * FROM SYS_FERIADOS");
            while (drFeriado.Read())
            {
                if (drFeriado.GetInt32(0) == dia2 && drFeriado.GetInt32(1) == mes2)
                {
                    dt = dt.AddDays(1);
                    drFeriado.Close();
                    validaferiado = "dt2";
                    goto checagem;
                }
                if (drFeriado.GetInt32(0) == dia && drFeriado.GetInt32(1) == mes)
                {
                    //dia e mes é feriado
                    dt = dt.AddDays(1);
                    drFeriado.Close();
                    validaferiado = "dt";
                    //iniciando a consistencia novamente
                    goto checagem;
                }
            }
            drFeriado.Close();

            //PREENCHENDO A DATA [
            Automacao.setaValorNome("depositoEnvolvidoVO.dtDeposito", dt.ToShortDateString());

            Automacao.espera();

            //preenchendo o tipo de deposito....
            //SE TIVER ID PREENCHIDO, VAMOS SEGUIR COMO JUDICIAL
            if (dr2.GetString(7).Trim() == "JUDICIAL")
            {
                //deposito judicial
                Automacao.selecionaCombo("selDeposito", "4", "value");
            }
            else if (dr2.GetString(7).Trim() == "CREDITO EM CONTA")
            {
                //credito em conta
                Automacao.selecionaCombo("selDeposito", "2", "value");
            }
            //alteração incluida RO 42887 para inclusao de deposito do tipo cheque
            else if(dr2.GetString(7).Trim() == "CHEQUE")
            {   //depósito do tipo CHEQUE - RO 42887
                Automacao.selecionaCombo("selDeposito", "4", "value");
            }

           Automacao.ExecutarJS("filtrarCamposPorTipoDeposito(document.forms[0].elements['selDeposito']);");
            Automacao.espera();

            //finalidade
            if (dr2.GetInt32(1) == 1)
            {
                //acordo
                Automacao.selecionaCombo("selFinalidade", "26", "value");
            }
            else
            {
                //liquidacao
                Automacao.selecionaCombo("selFinalidade", "25", "value");
            }


            //DataTable dtTeste = new DataTable();
            //dtTeste.Load(dr2);


            //forma de pagamento
            if (dr2.GetString(7).Trim() == "JUDICIAL")
            {
                Automacao.selecionaCombo("tipoPagamentoVO.cdTipo", "1", "value");
                Automacao.espera();
                Automacao.ExecutarJS("limparCampos()");
                Automacao.espera();
                //conferindo o número do ID
                if (dr2.GetString(9).Length != 18)
                {
                    //erro ao solicitar o deposito
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'NRO DO ID JUDICIAL INCORRETO' WHERE GCPJ = " + dr2.GetDouble(0));
                    preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                    return;
                }

                Automacao.setaValorNome("depositoEnvolvidoVO.idTedDJ", dr2.GetString(9));
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.vlDeposito", dr2.GetDouble(6).ToString("N"));
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.banco", dr2.GetInt32(8).ToString());
                Automacao.espera();
                Automacao.selecionaCombo("depositoEnvolvidoVO.cdTipoConta", "3", "value");
                Automacao.espera();
                Automacao.clicar("btoIncluir");
                if (Automacao.mataPossivelMsgBox())
                {
                    //erro ao solicitar o deposito
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'ERRO AO INCLUIR O DEPOSITO' WHERE GCPJ = " + dr2.GetDouble(0));
                    preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                    return;
                }

            }
            //(dr2.GetString(7) == "CREDITO EM CONTA")
            //else if (dr2.GetString(30).Trim() == "TED-CRED CONTA" || dr2.GetString(7).Trim() == "CREDITO EM CONTA")


           


            else if (dr2.GetString(7).Trim() == "TED-DEP JUDICIAL" || dr2.GetString(7).Trim() == "CREDITO EM CONTA")
            {
                //credito em conta....
                //A FORMA DE PAGAMENTO VIRA TED CREDITO EM CONTA....
                Automacao.selecionaCombo("tipoPagamentoVO.cdTipo", "2", "value");
                Automacao.espera();
                Automacao.ExecutarJS("limparCampos();");
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.vlDeposito", dr2.GetDouble(6).ToString("N"));
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.banco", dr2.GetInt32(8).ToString());
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.agenciaBanco", dr2.GetInt32(10).ToString());
                Automacao.espera();

                if (dr2.GetString(11).Equals("CORRENTE"))
                {
                    Automacao.selecionaCombo("depositoEnvolvidoVO.cdTipoConta", "1", "value");
                }
                else if (dr2.GetString(11).Equals("POUPANCA"))
                {
                    Automacao.selecionaCombo("depositoEnvolvidoVO.cdTipoConta", "2", "value");
                }
                else
                {
                    Automacao.selecionaCombo("depositoEnvolvidoVO.cdTipoConta", "3", "value");
                }

                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.contaBancaria", dr2.GetInt32(12).ToString());
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.digitoContaBancaria", dr2.GetInt32(13).ToString());

                if (dr2.GetInt32(1).ToString() == "1")
                {
                    if (dr2.GetString(25).ToString().ToUpper() == "AUTOR") 
                    {
                        //if (Automacao.buscarValorTabela(dr2.GetString(22).ToString(), dr2.GetString(24).ToString()) == true)
                        //{
                            Automacao.clicar("btoIncluir");
                            if (Automacao.mataPossivelMsgBox() == true)
                            {
                                Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS ='" + Automacao.textMsgBox + "' WHERE GCPJ = " + dr2.GetDouble(0));
                                preencheGrade("Erro nas informações de encerramento, indo para o proximo...");
                                return;
                            }
                       // }
                        else
                        {
                            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'DOCUMENTO AUTOR DIVERGENTE NO GCPJ' WHERE GCPJ = " + dr2.GetDouble(0));
                            preencheGrade("Documento autor divergente no GCPJ, indo para o proximo...");
                            return;
                        }

                    }
                    else if (dr2.GetString(25).ToString().ToUpper() == "OUTROS")
                    {
                        Automacao.selecionarRadio(1, "depositoEnvolvidoVO.cdIndicativoFavorecido");
                        Automacao.espera();
                        Automacao.ExecutarJS("acertarFavorecido();");
                        if(dr2.GetInt32(28).ToString() == "0")
                        {
                            Automacao.espera();
                            Automacao.setaValorNome("depositoEnvolvidoVO.nuCPF", dr2.GetInt32(27).ToString());
                            Automacao.espera();
                            Automacao.setaValorNome("depositoEnvolvidoVO.nuCtrlCPF", dr2.GetInt32(29).ToString());
                            Automacao.espera();
                            Automacao.ExecutarJS("javascript: pesquisarPorDocumento();");
                            Automacao.espera();
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=3&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetInt32(27).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetInt32(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCPF']&OUT_cdFilialCnpjPessoaExterna=FIELD_OFF&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCPF']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                            if(Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                            {
                                Automacao.clicaTabela("lnkTab1", dr2.GetString(26).ToString().ToUpper().Trim());
                                Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                            }
                            else
                            {
                                Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=3&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetInt32(27).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetInt32(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCPF']&OUT_cdFilialCnpjPessoaExterna=FIELD_OFF&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCPF']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                                Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                Automacao.ExecutarJS("javascript: inserirNovoFavorecido();");
                                if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA FISICA") == true)
                                {
                                    Automacao.espera();
                                    Automacao.setaValorNome("cdCpfPessoaExterna", dr2.GetInt32(27).ToString());
                                    Automacao.espera();
                                    Automacao.setaValorNome("cdCtrlCpfPessoaExterna", dr2.GetInt32(29).ToString());
                                    Automacao.espera();
                                    Automacao.clicar("btoCNSE");
                                    if (Automacao.mataPossivelMsgBox() == true)
                                    {
                                        Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA FISICA");
                                        Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'DADOS NAO LOCALIZADOS NO CNSE' WHERE GCPJ = " + dr2.GetDouble(0));
                                        preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                                        return;
                                    }                                    
                                    if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=obterCnse&cdCnpj=&cdFilialCnpj=&cdCtrlCnpj=&cdCpf=" + dr2.GetInt32(27).ToString() + "&cdCtrlCpf=" + dr2.GetInt32(29).ToString()))
                                    {
                                        if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                                        {
                                            Automacao.ExecutarJS("javascript:if( typeof(opener.document.forms[0].nmFuncionarioEmpresaGrupo) != 'undefined' ) opener.document.forms[0].nmFuncionarioEmpresaGrupo.value = '" + dr2.GetString(26).ToString() + "';if( typeof(opener.document.forms[0].nmPessoaExternaProcesso) != 'undefined' ) opener.document.forms[0].nmPessoaExternaProcesso.value = '" + dr2.GetString(26).ToString() + "'; window.close()");
                                        }
                                        else
                                        {
                                            //Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA FISICA");
                                            Automacao.espera();
                                            Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=obterCnse&cdCnpj=&cdFilialCnpj=&cdCtrlCnpj=&cdCpf=" + dr2.GetInt32(27).ToString() + "&cdCtrlCpf=" + dr2.GetInt32(29).ToString());
                                            Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=acionarCnse&paginaChamadora=pessoaExternaBradescoCadastrar&paginaCorrente=pessoaExternaBradescoIncluir&campoFoco=&cdTipoDocumento=1&cdIndicativoPopUp=S&itensSelecionados=&habilitaEndereco=false&cdTipoPessoaExterna=5&nmPessoaExternaProcesso=&cdCpfPessoaExterna=" + dr2.GetString(27).ToString() + "&cdCtrlCpfPessoaExterna=" + dr2.GetString(29).ToString() + "&cdCnpjPessoaExterna=&cdFilialCnpjPessoaExterna=&cdCtrlCnpjPessoaExterna=&cdBanco=&cdAgenciaBancaria=&cdCcorrPessoaExterna=&cdDddPessoaExterna=&cdTelefonePessoaExterna=&cdTipoDocumentoRg=1&cdRgPessoaExterna=&cdRgOrgaoEmissor=&dtEmissaoRg=&cdTipoDocumentoEnvolvido=&cdDocumentoPessoaExterna=&cdSiglaUFOab=&dtNascimentoPessoaExterna=&dtAdmissaoPessoaExterna=&cdCarteiraProfissionalPessoa=&cdSerieCarteiraPessoa=&cdPisPasepPessoa=&enEmailPessoaExterna=&cdCpfMaster=&cdCtrlCpfMaster=&tipoEndereco=N&cdCep=&cdCepComplemento=&nmMunicipioPessoaExterna=&cdSiglaUFPessoaExterna=&numSeqFone=&cdTipoFone=&cdDddPfPjParc=&cdTelefonePfPjParc=&enderecoPfPjParc.numSeq=&enderecoPfPjParc.cdOrigem=&enderecoPfPjParc.tipoLogradouro=&enderecoPfPjParc.logradouro=&enderecoPfPjParc.numero=&enderecoPfPjParc.complemento=&enderecoPfPjParc.bairro=&enderecoPfPjParc.municipio=&enderecoPfPjParc.cep=&enderecoPfPjParc.complementoCep=&enderecoPfPjParc.uf=");
                                            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'DADOS NAO LOCALIZADOS NO CNSE' WHERE GCPJ = " + dr2.GetDouble(0));
                                            preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                                            return;

                                            //Automacao.setaValorNome("nmPessoaExternaProcesso", dr2.GetString(26).ToString().Trim());
                                            //Automacao.espera();
                                        }
                                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=acionarCnse&paginaChamadora=pessoaExternaBradescoCadastrar&paginaCorrente=pessoaExternaBradescoIncluir&campoFoco=&cdTipoDocumento=1&cdIndicativoPopUp=S&itensSelecionados=&habilitaEndereco=false&cdTipoPessoaExterna=5&nmPessoaExternaProcesso=&cdCpfPessoaExterna=" + dr2.GetInt32(27).ToString() + "&cdCtrlCpfPessoaExterna=" + dr2.GetInt32(29).ToString() + "&cdCnpjPessoaExterna=&cdFilialCnpjPessoaExterna=&cdCtrlCnpjPessoaExterna=&cdBanco=&cdAgenciaBancaria=&cdCcorrPessoaExterna=&cdDddPessoaExterna=&cdTelefonePessoaExterna=&cdTipoDocumentoRg=1&cdRgPessoaExterna=&cdRgOrgaoEmissor=&dtEmissaoRg=&cdTipoDocumentoEnvolvido=&cdDocumentoPessoaExterna=&cdSiglaUFOab=&dtNascimentoPessoaExterna=&dtAdmissaoPessoaExterna=&cdCarteiraProfissionalPessoa=&cdSerieCarteiraPessoa=&cdPisPasepPessoa=&enEmailPessoaExterna=&cdCpfMaster=&cdCtrlCpfMaster=&tipoEndereco=N&cdCep=&cdCepComplemento=&nmMunicipioPessoaExterna=&cdSiglaUFPessoaExterna=&numSeqFone=&cdTipoFone=&cdDddPfPjParc=&cdTelefonePfPjParc=&enderecoPfPjParc.numSeq=&enderecoPfPjParc.cdOrigem=&enderecoPfPjParc.tipoLogradouro=&enderecoPfPjParc.logradouro=&enderecoPfPjParc.numero=&enderecoPfPjParc.complemento=&enderecoPfPjParc.bairro=&enderecoPfPjParc.municipio=&enderecoPfPjParc.cep=&enderecoPfPjParc.complementoCep=&enderecoPfPjParc.uf=");
                                        Automacao.clicar("btoSalvar");
                                        Automacao.mataPossivelMsgBox();
                                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                        Automacao.espera();
                                        Automacao.setaValorNome("depositoEnvolvidoVO.nuCPF", dr2.GetInt32(27).ToString());
                                        Automacao.espera();
                                        Automacao.setaValorNome("depositoEnvolvidoVO.nuCtrlCPF", dr2.GetInt32(29).ToString());
                                        Automacao.espera();
                                        Automacao.ExecutarJS("javascript: pesquisarPorDocumento();");
                                        Automacao.espera();
                                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=3&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetInt32(27).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetInt32(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCPF']&OUT_cdFilialCnpjPessoaExterna=FIELD_OFF&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCPF']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                                        if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                                        {
                                            Automacao.clicaTabela("lnkTab1", dr2.GetString(26).ToString().ToUpper().Trim());
                                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            Automacao.selecionarRadio(1, "depositoEnvolvidoVO.tipoDocumento");
                            Automacao.espera();
                            Automacao.ExecutarJS("acertarDocumento(false); limpaCodigoPessoaExterna();");
                            Automacao.espera();
                            Automacao.setaValorNome("depositoEnvolvidoVO.nuCNPJ", dr2.GetInt32(27).ToString());
                            Automacao.espera();
                            Automacao.setaValorNome("depositoEnvolvidoVO.nuFilialCNPJ", dr2.GetInt32(28).ToString());
                            Automacao.espera();
                            Automacao.setaValorNome("depositoEnvolvidoVO.nuCtrlCNPJ", dr2.GetInt32(29).ToString());
                            Automacao.espera();
                            Automacao.ExecutarJS("javascript: pesquisarPorDocumento();");
                            Automacao.espera();
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=4&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetInt32(27).ToString() + "&IN_cdFilialCnpjPessoaExterna=" + dr2.GetInt32(28).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetInt32(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCNPJ']&OUT_cdFilialCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuFilialCNPJ']&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCNPJ']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                            if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                            {
                                Automacao.clicaTabela("lnkTab1", dr2.GetString(26).ToString().ToUpper().Trim());
                                Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                
                            }
                            else
                            {
                                Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=4&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetInt32(27).ToString() + "&IN_cdFilialCnpjPessoaExterna=" + dr2.GetInt32(28).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetInt32(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCNPJ']&OUT_cdFilialCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuFilialCNPJ']&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCNPJ']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                                Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                Automacao.ExecutarJS("javascript: inserirNovoFavorecido();");
                                Automacao.espera();
                                if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA JURIDICA"))
                                {
                                    Thread.Sleep(3000);
                                    Automacao.espera();
                                    Automacao.setaValorNome("cdCnpjPessoaExterna", dr2.GetInt32(27).ToString());
                                    Automacao.espera();
                                    Automacao.setaValorNome("cdFilialCnpjPessoaExterna", dr2.GetInt32(28).ToString());
                                    Automacao.espera();
                                    Automacao.setaValorNome("cdCtrlCnpjPessoaExterna", dr2.GetInt32(29).ToString());
                                    Automacao.espera();
                                    Automacao.clicar("btoCNSE");
                                    Automacao.espera();

                                    if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=obterCnse&cdCnpj=" + dr2.GetInt32(27).ToString() + "&cdFilialCnpj=" + dr2.GetInt32(28).ToString() + "&cdCtrlCnpj=" + dr2.GetInt32(29).ToString() + "&cdCpf=&cdCtrlCpf="))
                                    {
                                        if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                                        {
                                            Automacao.ExecutarJS("javascript:if( typeof(opener.document.forms[0].nmFuncionarioEmpresaGrupo) != 'undefined' ) opener.document.forms[0].nmFuncionarioEmpresaGrupo.value = '" + dr2.GetString(26).ToString() + "';if( typeof(opener.document.forms[0].nmPessoaExternaProcesso) != 'undefined' ) opener.document.forms[0].nmPessoaExternaProcesso.value = '" + dr2.GetString(26).ToString() + "'; window.close()");
                                        }
                                        else
                                        {
                                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=obterCnse&cdCnpj=" + dr2.GetInt32(27).ToString() + "&cdFilialCnpj=" + dr2.GetInt32(28).ToString() + "&cdCtrlCnpj=" + dr2.GetInt32(29).ToString() + "&cdCpf=&cdCtrlCpf=");
                                            Automacao.setaValorNome("nmPessoaExternaProcesso", dr2.GetString(26).ToString().ToUpper().Trim());
                                        }
                                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=acionarCnse&paginaChamadora=pessoaExternaBradescoCadastrar&paginaCorrente=pessoaExternaBradescoIncluir&campoFoco=&cdTipoDocumento=2&cdIndicativoPopUp=S&itensSelecionados=&habilitaEndereco=false&cdTipoPessoaExterna=6&nmPessoaExternaProcesso=&cdCpfPessoaExterna=&cdCtrlCpfPessoaExterna=&cdCnpjPessoaExterna=" + dr2.GetInt32(27).ToString() + "&cdFilialCnpjPessoaExterna=" + dr2.GetInt32(28).ToString() + "&cdCtrlCnpjPessoaExterna=" + dr2.GetInt32(29).ToString() + "&cdBanco=&cdAgenciaBancaria=&cdCcorrPessoaExterna=&cdDddPessoaExterna=&cdTelefonePessoaExterna=&cdTipoDocumentoRg=&cdRgPessoaExterna=&cdRgOrgaoEmissor=&dtEmissaoRg=&cdTipoDocumentoEnvolvido=&cdDocumentoPessoaExterna=&cdSiglaUFOab=&dtNascimentoPessoaExterna=&dtAdmissaoPessoaExterna=&cdCarteiraProfissionalPessoa=&cdSerieCarteiraPessoa=&cdPisPasepPessoa=&enEmailPessoaExterna=&cdCpfMaster=&cdCtrlCpfMaster=&tipoEndereco=N&cdCep=&cdCepComplemento=&nmMunicipioPessoaExterna=&cdSiglaUFPessoaExterna=&numSeqFone=&cdTipoFone=&cdDddPfPjParc=&cdTelefonePfPjParc=&enderecoPfPjParc.numSeq=&enderecoPfPjParc.cdOrigem=&enderecoPfPjParc.tipoLogradouro=&enderecoPfPjParc.logradouro=&enderecoPfPjParc.numero=&enderecoPfPjParc.complemento=&enderecoPfPjParc.bairro=&enderecoPfPjParc.municipio=&enderecoPfPjParc.cep=&enderecoPfPjParc.complementoCep=&enderecoPfPjParc.uf=");
                                        Automacao.clicar("btoSalvar");
                                        if (Automacao.mataPossivelMsgBox())
                                        {
                                            Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=acionarCnse&paginaChamadora=pessoaExternaBradescoCadastrar&paginaCorrente=pessoaExternaBradescoIncluir&campoFoco=&cdTipoDocumento=2&cdIndicativoPopUp=S&itensSelecionados=&habilitaEndereco=false&cdTipoPessoaExterna=6&nmPessoaExternaProcesso=&cdCpfPessoaExterna=&cdCtrlCpfPessoaExterna=&cdCnpjPessoaExterna=" + dr2.GetInt32(27).ToString() + "&cdFilialCnpjPessoaExterna=" + dr2.GetInt32(28).ToString() + "&cdCtrlCnpjPessoaExterna=" + dr2.GetInt32(29).ToString() + "&cdBanco=&cdAgenciaBancaria=&cdCcorrPessoaExterna=&cdDddPessoaExterna=&cdTelefonePessoaExterna=&cdTipoDocumentoRg=&cdRgPessoaExterna=&cdRgOrgaoEmissor=&dtEmissaoRg=&cdTipoDocumentoEnvolvido=&cdDocumentoPessoaExterna=&cdSiglaUFOab=&dtNascimentoPessoaExterna=&dtAdmissaoPessoaExterna=&cdCarteiraProfissionalPessoa=&cdSerieCarteiraPessoa=&cdPisPasepPessoa=&enEmailPessoaExterna=&cdCpfMaster=&cdCtrlCpfMaster=&tipoEndereco=N&cdCep=&cdCepComplemento=&nmMunicipioPessoaExterna=&cdSiglaUFPessoaExterna=&numSeqFone=&cdTipoFone=&cdDddPfPjParc=&cdTelefonePfPjParc=&enderecoPfPjParc.numSeq=&enderecoPfPjParc.cdOrigem=&enderecoPfPjParc.tipoLogradouro=&enderecoPfPjParc.logradouro=&enderecoPfPjParc.numero=&enderecoPfPjParc.complemento=&enderecoPfPjParc.bairro=&enderecoPfPjParc.municipio=&enderecoPfPjParc.cep=&enderecoPfPjParc.complementoCep=&enderecoPfPjParc.uf=");

                                        }
                                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                    }

                                }
                            }
                        }
                        Automacao.clicar("btoIncluir");
                        Automacao.espera();
                        string documento = Automacao.retornaValorTela("B");

                    }
                    else
                    {
                        Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'TIPO FAVORECIDO INVALIDO' WHERE GCPJ = " + dr2.GetDouble(0));
                        preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                        return;
                    }
                }

                //Automacao.clicar("btoIncluir");
                if (Automacao.mataPossivelMsgBox())
                {
                    //erro ao solicitar o deposito
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'ERRO AO INCLUIR O DEPOSITO' WHERE GCPJ = " + dr2.GetDouble(0));
                    preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                    return;
                }
            }
            //(dr2.GetString(7) == "CHEQUE")
            else if (dr2.GetString(7).Trim() == "CHEQUE" || dr2.GetString(7).Trim() == "CHEQUE-DEP JUDICIAL")
            {
                Automacao.espera();
                Automacao.selecionaCombo("tipoPagamentoVO.cdTipo", "3", "value");
                Automacao.espera();
                Automacao.ExecutarJS("limparCampos()");
                Automacao.espera();
                //conferindo se possui ID no campo pois CHEQUE nao deve possuir numero de ID(NAO FUNCIONA)
                //if (dr2.GetString(9) != "")
                //{
                //    //erro ao solicitar o deposito
                //    Conexao.executar("UPDATE TB_ENCERRAMENTO SET ENCERRADO = TRUE, OBS = 'NAO PODE POSSUIR NUMERO DE ID' WHERE GCPJ = " + dr2.GetDouble(0));
                //    preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                //    return;
                //}

                Automacao.setaValorNome("depositoEnvolvidoVO.vlDeposito", dr2.GetDouble(6).ToString("N"));
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.banco", dr2.GetInt32(8).ToString());
                Automacao.espera();
                Automacao.selecionaCombo("depositoEnvolvidoVO.cdTipoConta", "3", "value");
                Automacao.espera();
                Automacao.clicar("btoIncluir");
                Automacao.espera();
                if (Automacao.mataPossivelMsgBox())
                {
                    //erro ao solicitar o deposito
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'ERRO AO INCLUIR O DEPOSITO' WHERE GCPJ = " + dr2.GetDouble(0));
                    preencheGrade("Erro ao solicitar o deposito, indo para o proximo...");
                    return;
                }
            }
            else if (dr2.GetString(30).Trim() == "TRANSF.ENTRE CONTAS")
            {
                Automacao.selecionaCombo("tipoPagamentoVO.cdTipo", "3", "value");
                Automacao.espera();
                Automacao.ExecutarJS("limparCampos()");
                Automacao.espera();
                Automacao.setaValorNome("depositoEnvolvidoVO.vlDeposito", dr2.GetDouble(6).ToString("N"));
                Automacao.espera();
                if (dr2.GetString(25).ToString().ToUpper() == "AUTOR")
                {
                    if (dr2.GetString(23).ToString() == "0")
                    {
                        Automacao.clicarTag();
                        Automacao.espera();
                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos?metodo=carregarPopup&popupClassName=gcpj.popup.fin.PopUpContaBancariaFavorecido&IN_cpfCompleto=" + dr2.GetString(22).ToString() + dr2.GetString(24).ToString() + "&IN_cnpjCompleto=&IN_bancoFixo=true&OUT_nmEnvolvido=FIELD_OFF&OUT_cdAgencia=elements['depositoEnvolvidoVO.cdAgenciaBancaria']&OUT_nmAgencia=elements['depositoEnvolvidoVO.nmAgenciaBancaria']&OUT_cdBanco=elements['depositoEnvolvidoVO.banco']&OUT_cdContaBancaria=elements['depositoEnvolvidoVO.contaBancaria']&OUT_cdDigContaBancaria=elements['depositoEnvolvidoVO.digitoContaBancaria']&OUT_cep=FIELD_OFF&OUT_complementoCep=FIELD_OFF&OUT_logradouro=FIELD_OFF&OUT_cdTipoContaBancaria=elements['depositoEnvolvidoVO.cdTipoConta']&OUT_nmTipoContaBancaria=elements['depositoEnvolvidoVO.nmTipoConta']&beforeClose=opener.setOpcoes();");
                        if (Automacao.clicaContaTabela("txt1", dr2.GetInt32(12).ToString(), dr2.GetInt32(13).ToString()) == false)
                        {
                            Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos?metodo=carregarPopup&popupClassName=gcpj.popup.fin.PopUpContaBancariaFavorecido&IN_cpfCompleto=" + dr2.GetString(22).ToString() + dr2.GetString(24).ToString() + "&IN_cnpjCompleto=&IN_bancoFixo=true&OUT_nmEnvolvido=FIELD_OFF&OUT_cdAgencia=elements['depositoEnvolvidoVO.cdAgenciaBancaria']&OUT_nmAgencia=elements['depositoEnvolvidoVO.nmAgenciaBancaria']&OUT_cdBanco=elements['depositoEnvolvidoVO.banco']&OUT_cdContaBancaria=elements['depositoEnvolvidoVO.contaBancaria']&OUT_cdDigContaBancaria=elements['depositoEnvolvidoVO.digitoContaBancaria']&OUT_cep=FIELD_OFF&OUT_complementoCep=FIELD_OFF&OUT_logradouro=FIELD_OFF&OUT_cdTipoContaBancaria=elements['depositoEnvolvidoVO.cdTipoConta']&OUT_nmTipoContaBancaria=elements['depositoEnvolvidoVO.nmTipoConta']&beforeClose=opener.setOpcoes();");
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'CONTA NAO LOCALIZADA' WHERE GCPJ = " + dr2.GetDouble(0));
                            preencheGrade("Conta não localizada, indo para o proximo...");
                            return;
                        }
                    }
                    else 
                    {
                        Automacao.clicarTag();
                        Automacao.espera();
                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos?metodo=carregarPopup&popupClassName=gcpj.popup.fin.PopUpContaBancariaFavorecido&IN_cpfCompleto=&IN_cnpjCompleto" + dr2.GetString(22).ToString() + dr2.GetString(23).ToString()+ dr2.GetString(24).ToString() + "=&IN_bancoFixo=true&OUT_nmEnvolvido=FIELD_OFF&OUT_cdAgencia=elements['depositoEnvolvidoVO.cdAgenciaBancaria']&OUT_nmAgencia=elements['depositoEnvolvidoVO.nmAgenciaBancaria']&OUT_cdBanco=elements['depositoEnvolvidoVO.banco']&OUT_cdContaBancaria=elements['depositoEnvolvidoVO.contaBancaria']&OUT_cdDigContaBancaria=elements['depositoEnvolvidoVO.digitoContaBancaria']&OUT_cep=FIELD_OFF&OUT_complementoCep=FIELD_OFF&OUT_logradouro=FIELD_OFF&OUT_cdTipoContaBancaria=elements['depositoEnvolvidoVO.cdTipoConta']&OUT_nmTipoContaBancaria=elements['depositoEnvolvidoVO.nmTipoConta']&beforeClose=opener.setOpcoes();");
                        if (Automacao.clicaContaTabela("txt1", dr2.GetInt32(12).ToString(), dr2.GetInt32(13).ToString()) == false)
                        {
                            Automacao.fecharPopUp("Popup");
                            //Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos?metodo=carregarPopup&popupClassName=gcpj.popup.fin.PopUpContaBancariaFavorecido&IN_cpfCompleto=&IN_cnpjCompleto="+ dr2.GetString(22).ToString() + dr2.GetString(23).ToString() + dr2.GetString(24).ToString() +"&IN_bancoFixo=true&OUT_nmEnvolvido=FIELD_OFF&OUT_cdAgencia=elements['depositoEnvolvidoVO.cdAgenciaBancaria']&OUT_nmAgencia=elements['depositoEnvolvidoVO.nmAgenciaBancaria']&OUT_cdBanco=elements['depositoEnvolvidoVO.banco']&OUT_cdContaBancaria=elements['depositoEnvolvidoVO.contaBancaria']&OUT_cdDigContaBancaria=elements['depositoEnvolvidoVO.digitoContaBancaria']&OUT_cep=FIELD_OFF&OUT_complementoCep=FIELD_OFF&OUT_logradouro=FIELD_OFF&OUT_cdTipoContaBancaria=elements['depositoEnvolvidoVO.cdTipoConta']&OUT_nmTipoContaBancaria=elements['depositoEnvolvidoVO.nmTipoConta']&beforeClose=opener.setOpcoes();");
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'CONTA NAO LOCALIZADA' WHERE GCPJ = " + dr2.GetDouble(0));
                            preencheGrade("Conta não localizada, indo para o proximo...");
                            return;
                        }

                    }
                }
                else
                {
                    Automacao.selecionarRadio(1, "depositoEnvolvidoVO.cdIndicativoFavorecidoTransf");
                    Automacao.espera();
                    Automacao.ExecutarJS("limparDadosContaFav();acertarFavorecidoTransf();;");
                    Automacao.espera();
                    if (dr2.GetString(28).ToString() == "0")
                    {
                        Automacao.setaValorNome("depositoEnvolvidoVO.nuCPF", dr2.GetString(27).ToString());
                        Automacao.espera();
                        Automacao.setaValorNome("depositoEnvolvidoVO.nuCtrlCPF", dr2.GetString(29).ToString());
                        Automacao.espera();
                        Automacao.ExecutarJS("javascript: pesquisarPorDocumento();");
                        Automacao.espera();
                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=3&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetString(27).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetString(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCPF']&OUT_cdFilialCnpjPessoaExterna=FIELD_OFF&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCPF']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                        if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                        {
                            Automacao.clicaTabela("lnkTab1", dr2.GetString(26).ToString().ToUpper().Trim());                            
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                        }
                        else
                        {
                            Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=3&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetString(27).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetString(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCPF']&OUT_cdFilialCnpjPessoaExterna=FIELD_OFF&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCPF']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                            Automacao.ExecutarJS("javascript: inserirNovoFavorecido();");
                            Automacao.espera();
                            if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA FISICA") == true)
                            {
                                Automacao.setaValorNome("cdCpfPessoaExterna", dr2.GetString(27).ToString());
                                Automacao.espera();
                                Automacao.setaValorNome("cdCtrlCpfPessoaExterna", dr2.GetString(29).ToString());
                                Automacao.espera();
                                Automacao.clicar("btoCNSE");
                                Automacao.espera();
                                if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=obterCnse&cdCnpj=&cdFilialCnpj=&cdCtrlCnpj=&cdCpf=" + dr2.GetString(27).ToString() + "&cdCtrlCpf=" + dr2.GetString(29).ToString()))
                                {
                                    if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                                    {
                                        Automacao.ExecutarJS("javascript:if( typeof(opener.document.forms[0].nmFuncionarioEmpresaGrupo) != 'undefined' ) opener.document.forms[0].nmFuncionarioEmpresaGrupo.value = '" + dr2.GetString(26).ToString().ToUpper().Trim() + "';if( typeof(opener.document.forms[0].nmPessoaExternaProcesso) != 'undefined' ) opener.document.forms[0].nmPessoaExternaProcesso.value = '" + dr2.GetString(26).ToString() + "'; window.close()");
                                        Automacao.espera();
                                    }
                                    else
                                    {
                                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA FISICA");
                                        Automacao.setaValorNome("nmPessoaExternaProcesso", dr2.GetString(26).ToString().Trim());
                                        Automacao.espera();
                                    }
                                    Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=acionarCnse&paginaChamadora=pessoaExternaBradescoCadastrar&paginaCorrente=pessoaExternaBradescoIncluir&campoFoco=&cdTipoDocumento=1&cdIndicativoPopUp=S&itensSelecionados=&habilitaEndereco=false&cdTipoPessoaExterna=5&nmPessoaExternaProcesso=&cdCpfPessoaExterna=" + dr2.GetString(27).ToString() + "&cdCtrlCpfPessoaExterna=" + dr2.GetString(29).ToString() + "&cdCnpjPessoaExterna=&cdFilialCnpjPessoaExterna=&cdCtrlCnpjPessoaExterna=&cdBanco=&cdAgenciaBancaria=&cdCcorrPessoaExterna=&cdDddPessoaExterna=&cdTelefonePessoaExterna=&cdTipoDocumentoRg=1&cdRgPessoaExterna=&cdRgOrgaoEmissor=&dtEmissaoRg=&cdTipoDocumentoEnvolvido=&cdDocumentoPessoaExterna=&cdSiglaUFOab=&dtNascimentoPessoaExterna=&dtAdmissaoPessoaExterna=&cdCarteiraProfissionalPessoa=&cdSerieCarteiraPessoa=&cdPisPasepPessoa=&enEmailPessoaExterna=&cdCpfMaster=&cdCtrlCpfMaster=&tipoEndereco=N&cdCep=&cdCepComplemento=&nmMunicipioPessoaExterna=&cdSiglaUFPessoaExterna=&numSeqFone=&cdTipoFone=&cdDddPfPjParc=&cdTelefonePfPjParc=&enderecoPfPjParc.numSeq=&enderecoPfPjParc.cdOrigem=&enderecoPfPjParc.tipoLogradouro=&enderecoPfPjParc.logradouro=&enderecoPfPjParc.numero=&enderecoPfPjParc.complemento=&enderecoPfPjParc.bairro=&enderecoPfPjParc.municipio=&enderecoPfPjParc.cep=&enderecoPfPjParc.complementoCep=&enderecoPfPjParc.uf=");
                                    Automacao.clicar("btoSalvar");
                                    Automacao.mataPossivelMsgBox();
                                    Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                }
                            }
                        }

                        Automacao.clicarTag();
                        Automacao.espera();
                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos?metodo=carregarPopup&popupClassName=gcpj.popup.fin.PopUpContaBancariaFavorecido&IN_cpfCompleto=" + dr2.GetString(27).ToString() + dr2.GetString(29).ToString() + "&IN_cnpjCompleto=&IN_bancoFixo=true&OUT_nmEnvolvido=FIELD_OFF&OUT_cdAgencia=elements['depositoEnvolvidoVO.cdAgenciaBancaria']&OUT_nmAgencia=elements['depositoEnvolvidoVO.nmAgenciaBancaria']&OUT_cdBanco=elements['depositoEnvolvidoVO.banco']&OUT_cdContaBancaria=elements['depositoEnvolvidoVO.contaBancaria']&OUT_cdDigContaBancaria=elements['depositoEnvolvidoVO.digitoContaBancaria']&OUT_cep=FIELD_OFF&OUT_complementoCep=FIELD_OFF&OUT_logradouro=FIELD_OFF&OUT_cdTipoContaBancaria=elements['depositoEnvolvidoVO.cdTipoConta']&OUT_nmTipoContaBancaria=elements['depositoEnvolvidoVO.nmTipoConta']&beforeClose=opener.setOpcoes();");
                        if (Automacao.clicaContaTabela("txt1", dr2.GetInt32(12).ToString(), dr2.GetInt32(13).ToString()) == false)
                        {
                            Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos?metodo=carregarPopup&popupClassName=gcpj.popup.fin.PopUpContaBancariaFavorecido&IN_cpfCompleto=" + dr2.GetString(27).ToString() + dr2.GetString(29).ToString() + "&IN_cnpjCompleto=&IN_bancoFixo=true&OUT_nmEnvolvido=FIELD_OFF&OUT_cdAgencia=elements['depositoEnvolvidoVO.cdAgenciaBancaria']&OUT_nmAgencia=elements['depositoEnvolvidoVO.nmAgenciaBancaria']&OUT_cdBanco=elements['depositoEnvolvidoVO.banco']&OUT_cdContaBancaria=elements['depositoEnvolvidoVO.contaBancaria']&OUT_cdDigContaBancaria=elements['depositoEnvolvidoVO.digitoContaBancaria']&OUT_cep=FIELD_OFF&OUT_complementoCep=FIELD_OFF&OUT_logradouro=FIELD_OFF&OUT_cdTipoContaBancaria=elements['depositoEnvolvidoVO.cdTipoConta']&OUT_nmTipoContaBancaria=elements['depositoEnvolvidoVO.nmTipoConta']&beforeClose=opener.setOpcoes();");
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'CONTA NAO LOCALIZADA' WHERE GCPJ = " + dr2.GetDouble(0));
                            preencheGrade("Conta não localizada, indo para o proximo...");
                            return;
                        }

                    }
                    else
                    {
                        Automacao.selecionarRadio(1, "depositoEnvolvidoVO.tipoDocumento");
                        Automacao.espera();
                        Automacao.ExecutarJS("acertarDocumento(false); limpaCodigoPessoaExterna();");
                        Automacao.espera();
                        Automacao.setaValorNome("depositoEnvolvidoVO.nuCNPJ", dr2.GetString(27).ToString());
                        Automacao.espera();
                        Automacao.setaValorNome("depositoEnvolvidoVO.nuFilialCNPJ", dr2.GetString(28).ToString());
                        Automacao.espera();
                        Automacao.setaValorNome("depositoEnvolvidoVO.nuCtrlCNPJ", dr2.GetString(29).ToString());
                        Automacao.espera();
                        Automacao.ExecutarJS("javascript: pesquisarPorDocumento();");
                        Automacao.espera();
                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=4&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetString(27).ToString() + "&IN_cdFilialCnpjPessoaExterna=" + dr2.GetString(28).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetString(29).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCNPJ']&OUT_cdFilialCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuFilialCNPJ']&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCNPJ']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                        if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                        {
                            Automacao.clicaTabela("lnkTab1", dr2.GetString(26).ToString().ToUpper().Trim());
                            Automacao.espera();
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                        }
                        else
                        {
                            Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcCivilAutorAction?acao=carregarPopup&popupClassName=gcpj.popup.cad.PssoaEnvdaEncer&IN_cdTipoDocumento=4&IN_cdTipoPessoaEnvolvida=5&IN_dsTitulo=NÃO-FUNCIONARIO&IN_cdCnpjPessoaExterna=" + dr2.GetString(27).ToString() + "&IN_cdFilialCnpjPessoaExterna=" + dr2.GetString(27).ToString() + "&IN_cdCtrlCnpjPessoaExterna=" + dr2.GetString(27).ToString() + "&OUT_cdPessoaExternaBradesco=elements['depositoEnvolvidoVO.cdPessoaExterna']&OUT_nmPessoaExternaProcesso=elements['depositoEnvolvidoVO.nmFavorecidoOutro']&OUT_cdCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCNPJ']&OUT_cdFilialCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuFilialCNPJ']&OUT_cdCtrlCnpjPessoaExterna=elements['depositoEnvolvidoVO.nuCtrlCNPJ']&OUT_dsTipoPessoaExterna=FIELD_OFF");
                            Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                            Automacao.espera();
                            Automacao.ExecutarJS("javascript: inserirNovoFavorecido();");
                            if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA JURIDICA"))
                            {
                                Automacao.espera();
                                Automacao.setaValorNome("cdCnpjPessoaExterna", dr2.GetString(27).ToString());
                                Automacao.espera();
                                Automacao.setaValorNome("cdFilialCnpjPessoaExterna", dr2.GetString(28).ToString());
                                Automacao.espera();
                                Automacao.setaValorNome("cdCtrlCnpjPessoaExterna", dr2.GetString(29).ToString());
                                Automacao.espera();
                                Automacao.clicar("btoCNSE");
                                Automacao.espera();
                                if (Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=obterCnse&cdCnpj=" + dr2.GetString(27).ToString() + "&cdFilialCnpj=" + dr2.GetString(28).ToString() + "&cdCtrlCnpj=" + dr2.GetString(29).ToString() + "&cdCpf=&cdCtrlCpf="))
                                {
                                    if (Automacao.localizaValorTabela("txt1", dr2.GetString(26).ToString().ToUpper().Trim()) == true)
                                    {
                                        Automacao.ExecutarJS("javascript:if( typeof(opener.document.forms[0].nmFuncionarioEmpresaGrupo) != 'undefined' ) opener.document.forms[0].nmFuncionarioEmpresaGrupo.value = '" + dr2.GetString(26).ToString() + "';if( typeof(opener.document.forms[0].nmPessoaExternaProcesso) != 'undefined' ) opener.document.forms[0].nmPessoaExternaProcesso.value = '" + dr2.GetString(26).ToString() + "'; window.close()");
                                    }
                                    else
                                    {
                                        Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=obterCnse&cdCnpj=" + dr2.GetString(27).ToString() + "&cdFilialCnpj=" + dr2.GetString(28).ToString() + "&cdCtrlCnpj=" + dr2.GetString(29).ToString() + "&cdCpf=&cdCtrlCpf=");
                                        Automacao.setaValorNome("nmPessoaExternaProcesso", dr2.GetString(26).ToString().ToUpper().Trim());
                                        Automacao.espera();
                                    }
                                    Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/pessoaExternaBradescoAction?acao=cadastroIncluir&cdIndicativoPopUp=C&origem=encerramentoDeposito&modulo=encerramentoDeposito&dsTipoPessoa=PESSOA JURIDICA");
                                    Automacao.clicar("btoSalvar");
                                    Automacao.mataPossivelMsgBox();
                                    Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                                }
                            }
                        }
                    }
                }

                Automacao.localizarJanelaURL("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrDepos");
                Automacao.clicar("btoIncluir");
            }

            //COMPOSIÇÃO DO DEPOSITO
            Automacao.selecionarTabela("tab1", dt.ToShortDateString());
            Automacao.clicar("btoComposicao");
            Automacao.espera();

            //verificando valores para inserir
            //principal
            if (dr2.GetDouble(14) != 0)
            {
                Automacao.selecionaCombo("selTipoComposicao", "1", "value");
                Automacao.setaValorNome("depositoComposicao.compsDepJudicVO.vrComposicaoDepositoJudicial", dr2.GetDouble(14).ToString("N"));
                Automacao.clicar("btoIncluir");
                Automacao.espera();
            }

            //CUSTAS
            if (dr2.GetDouble(15) != 0)
            {
                Automacao.selecionaCombo("selTipoComposicao", "8", "value");
                Automacao.setaValorNome("depositoComposicao.compsDepJudicVO.vrComposicaoDepositoJudicial", dr2.GetDouble(15).ToString("N"));
                Automacao.clicar("btoIncluir");
                Automacao.espera();
            }

            //HONORARIOS DE SUCUMBENCIA
            if (dr2.GetDouble(16) != 0)
            {
                Automacao.selecionaCombo("selTipoComposicao", "7", "value");
                Automacao.setaValorNome("depositoComposicao.compsDepJudicVO.vrComposicaoDepositoJudicial", dr2.GetDouble(16).ToString("N"));
                Automacao.clicar("btoIncluir");
                Automacao.espera();
            }

            //HONORARIOS PERICIAIS
            if (dr2.GetDouble(17) != 0)
            {
                Automacao.selecionaCombo("selTipoComposicao", "6", "value");
                Automacao.setaValorNome("depositoComposicao.compsDepJudicVO.vrComposicaoDepositoJudicial", dr2.GetDouble(17).ToString("N"));
                Automacao.clicar("btoIncluir");
                Automacao.espera();
            }

            //IR
            if (dr2.GetDouble(18) != 0)
            {
                Automacao.selecionaCombo("selTipoComposicao", "4", "value");
                Automacao.setaValorNome("depositoComposicao.compsDepJudicVO.vrComposicaoDepositoJudicial", dr2.GetDouble(18).ToString("N"));
                Automacao.clicar("btoIncluir");
                Automacao.espera();
            }

            //JUROS
            if (dr2.GetDouble(19) != 0)
            {
                Automacao.selecionaCombo("selTipoComposicao", "5", "value");
                Automacao.setaValorNome("depositoComposicao.compsDepJudicVO.vrComposicaoDepositoJudicial", dr2.GetDouble(19).ToString("N"));
                Automacao.clicar("btoIncluir");
                Automacao.espera();
            }

            //feita a composição....
            Automacao.clicar("btoVoltar");
            Automacao.espera();

            Automacao.clicar("btoSalvar");
            //erro ao solicitar o deposito
            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = '" + Automacao.lerMsgBox() + "' WHERE GCPJ = " + dr2.GetDouble(0));
            Automacao.mataMsgBox();

            //tem mais envolvidos?
            if(dr2.GetInt32(20) > 1)
            {
                preencheGrade("Encerrando demais envolvidos como solucionado");
                //chamar a funcao de encerrar todos os demais envolvidos como solucionado.
                encerrarDemais(dr2.GetDouble(0));
            }

        }

        private static string atualizatabela(string tipoencerramento)
        {
            if (tipoencerramento == "ENCERRAMENTO")            {

                return "TB_ENCERRAMENTO";
            }
            else
            {
                return "TB_ACORDOS";
            }
            return "";
        }

        private void encerrarDemais(double gcpj)
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrEncerProce?metodo=carregar&origem=1");
            Automacao.espera();

            //informando o processo.....
            Automacao.setaValorNome("nuProcessoBradesco", gcpj.ToString());
            Automacao.clicar("btoPesquisar");
            Automacao.espera();

            //selecionar os envolvidos e os motivos
            //selecionando o motivo....
            Automacao.selecionaCombo("cdMotivo", 25.ToString(), "value");
            Automacao.ExecutarJS("montarCombo();");
            Automacao.espera();


            //classificacao
            Automacao.selecionaCombo("classificacaoSelecionado.codigoClassificacao", 81.ToString(), "value");
            Automacao.checaCampo("selecionados", 1);
            Automacao.checaCampo("selecionados", 2);
            Automacao.checaCampo("selecionados", 3);
            Automacao.checaCampo("selecionados", 4);
            Automacao.checaCampo("selecionados", 5);

            //clicar em salvar para finalizar totalmente o encerramento
            Automacao.clicar("btoSalvar");
            if (Automacao.mataPossivelMsgBox())
            {
                //tudo certo, acabou
                return;
            } else
            {
                Automacao.espera();
                //Automacao.clicar("btoEncerrar");
                if (!Automacao.clicarBotao("btoEncerrar"))
                    preencheGrade("Processo " + gcpj.ToString() + ": não achou o botão Encerrar habilitado para os demais envolvidos. Conferir no GCPJ.");
                Automacao.mataPossivelMsgBox();
                return;
            }
        }

        private void atualizaSucumbencia()
        {
            //atualizando informação de sucumbencia
            //Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrPende?metodo=incluirHonorSucumbAutor");
            Automacao.espera();

            Automacao.setaValorNome("honorarioSucumbencia.dtDecisaoFinal", DateTime.Now.ToShortDateString());
            Automacao.selecionarRadio(1, "honorarioSucumbencia.sucumbenciaRecebida");
            Automacao.ExecutarJS("submeterEncerramento('processarAcaoSucumRecebida')");
            Automacao.espera();
            Automacao.selecionarRadio(1, "honorarioSucumbencia.executarSucumbencia");
            Automacao.clicar("btoSalvar");
            Automacao.mataMsgBox();
        }

        private void atualizaEvento(string gcpj, int motivo)
        {
            //Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrPende?metodo=atualizarResumo");
            Automacao.espera();

            Automacao.ExecutarJS("paginacao('8');");
            Automacao.espera();

            for (int x = 0; x < 5; x++)
            {
                if (!Automacao.selecionarTabela("tab1", "Não"))
                {
                    Automacao.ExecutarJS("paginacao('1');");
                    Automacao.espera();
                }
            }

            int eventosAtualizados = 0;
            while (Automacao.selecionarTabela("tab1", "Não"))
            {
                // trava de segurança: se o mesmo evento não sair da lista, não fica em laço para sempre
                if (++eventosAtualizados > 30)
                {
                    preencheGrade("Processo " + gcpj + ": mais de 30 eventos para atualizar, parando a atualização de eventos.");
                    Automacao.registrarLog("GCPJ " + gcpj + " | mais de 30 eventos sem atualizar, parando. Tela: " + Automacao.paginaAtual());
                    break;
                }

                //atualizando todos os eventos
                Automacao.clicar("btoDetalhar");
                Automacao.espera();

                if (motivo == 1)
                {
                    Automacao.setaValorNome("dsResumoEventoJudicial", "Deposito para acordo.");
                }
                
                if (motivo == 2)
                {
                    Automacao.setaValorNome("dsResumoEventoJudicial", "Deposito para liquidacao.");
                }

                if (motivo != 1 && motivo != 2)
                {
                    Automacao.setaValorNome("dsResumoEventoJudicial", "Processo para encerramento.");
                }

                //verificar se tem botão continuar ou não.....
                //if (Automacao.elementoAtivo_Capiroto("btoContinuar"))
                // Sem botão Continuar na tela, ou com ele desabilitado: apenas salva (antes, botão inexistente era tratado como habilitado)
                if (Automacao.estadoBotao("btoContinuar") != 0)
                {
                    //se o botão continuar está inativo vamos apenas salvar...
                    Automacao.clicar("btoSalvar");
                    Automacao.mataMsgBox();
                }
                else
                {
                    Automacao.clicar("btoContinuar");
                    Automacao.espera();

                    //vamos fazer a leitura dos itens pendentes
                    string link;
                    //link = Automacao.clicaPrimeiroObjeto("a", gcpj);
                    link = Automacao.clicaLinkPendenciaEvento(gcpj); // só clica em pendência de decisão, valor ou preposto
                    int pendenciasEvento = 0;
                    while (link != "")
                    {
                        // trava de segurança: nunca fica preso clicando em links
                        if (++pendenciasEvento > 15)
                        {
                            Automacao.registrarLog("GCPJ " + gcpj + " | mais de 15 pendências no evento, parando. Último link: " + link);
                            break;
                        }

                        if (link.Contains("decis"))
                        {
                            //Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/traTraPendAtulzResDecisAction?acao=carregar&sessaoClear=false");
                            Automacao.espera();

                            Automacao.clicar("btoSalvar");
                            Automacao.mataMsgBox();
                            Automacao.espera();
                        }

                        if (link.Contains("valor"))
                        {
                            //Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/traTraPendAtulzResCalcAction?acao=carregar&sessaoClear=false");
                            Automacao.espera();
                            Automacao.selecionaPrimeiroCombo("cdTipoCalculadoProcesso");
                            Automacao.selecionarRadio(1, "cdFlagDesconhecido");
                            Automacao.ExecutarJS("mostrarMotivoDesconhecido()");
                            Automacao.espera();
                            Automacao.clicar("btoIncluir");
                            if (Automacao.mataPossivelMsgBox())
                            {
                                Automacao.selecionaSegundoCombo("cdTipoCalculadoProcesso");
                                Automacao.selecionarRadio(1, "cdFlagDesconhecido");
                                Automacao.ExecutarJS("mostrarMotivoDesconhecido()");
                                Automacao.espera();
                                Automacao.clicar("btoIncluir");
                                Automacao.espera();
                            }
                            Automacao.clicar("btoSalvar");
                            Automacao.espera();
                        }

                        if (link.Contains("preposto"))
                        {
                            //informar depoimento de preposto e testemunha
                            //Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/traTraPendAtulzResDpoimAction?acao=carregar&sessaoClear=false");
                            Automacao.espera();
                            Automacao.clicar("btoSalvar");
                            Automacao.mataMsgBox();
                            Thread.Sleep(1000);
                            Automacao.mataMsgBox();

                        }
                        //link = Automacao.clicaPrimeiroObjeto("a", gcpj);
                        link = Automacao.clicaLinkPendenciaEvento(gcpj);
                    }

                    Automacao.clicar("btoVoltar");
                    Automacao.espera();

                    Automacao.clicar("btoSalvar");
                    Automacao.mataMsgBox();
                }
            }
            //acabaram os eventos, vamos voltar
            Automacao.clicar("btoVoltar");
            Automacao.espera();

            // garante que voltou para a tela de ENCERRAMENTO, e não para a do evento
            VoltarParaTelaEncerramento(gcpj);
        }

        private void btnDistribuir_Click(object sender, EventArgs e)
        {
            if (CBSelecionaProcessamento.Text == "")
            {
                MessageBox.Show("Selecione um tipo de processamento!");
                return;
            }

            if (CBSelecionaProcessamento.Text == "ENCERRAMENTO")
            {
                distribuirEncerramento();
            }
            else if (CBSelecionaProcessamento.Text == "COMPLEMENTAR")
            {
                distribuirComplementar();
            }
            else
            {
                distribuirAcordos();
            }

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            OleDbDataReader dr2;
            dr2 = Conexao.consultar("SELECT * FROM TB_ENCERRAMENTO");
            dr2.Read();

            while (dr2.Read())
            {
                //verificando valores para inserir
                //principal
                if (dr2.GetDouble(14) != 0)
                {
                    MessageBox.Show(dr2.GetDouble(14).ToString("N"));
                }

                //CUSTAS
                if (dr2.GetDouble(15) != 0)
                {
                    MessageBox.Show(dr2.GetDouble(15).ToString("N"));
                }

                //HONORARIOS DE SUCUMBENCIA
                if (dr2.GetDouble(16) != 0)
                {
                    MessageBox.Show(dr2.GetDouble(16).ToString("N"));
                }

                //HONORARIOS PERICIAIS
                if (dr2.GetDouble(17) != 0)
                {
                    MessageBox.Show(dr2.GetDouble(17).ToString("N"));
                }

                //IR
                if (dr2.GetDouble(18) != 0)
                {
                    MessageBox.Show(dr2.GetDouble(18).ToString("N"));
                }

                //JUROS
                if (dr2.GetDouble(19) != 0)
                {
                    MessageBox.Show(dr2.GetDouble(19).ToString("N"));
                }
            }
        }

        private void toolStripButton1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show(Automacao.ValidaDigitoDeposito(1, "081040000026062900").ToString());
        }

        private void ChamaGCPJ()
        {
            Thread.Sleep(1000);
            Automacao.novaJanela("https://intranet85.net.bradesco.com.br/gcpj");
            Thread.Sleep(1000);
            Automacao.acessarSistema(txtLogin.ToString(), txtPassword.ToString());
            Automacao.localizarJanela("GCPJ");
        }

        private void MataProcesso(string Processo)
        {
            Process.Start("taskkill", "/F /IM" + " " + Processo);
        }

        public void FinalizaTarefa(string vProceso)
        {
            foreach (var process in Process.GetProcessesByName(vProceso))
            {
                process.Kill();
            }
        }

        private void cmdGCPJCompleto_Click(object sender, EventArgs e)
        {
            if (validarCamposLogin() == true)
            {
                MataProcesso("iexplore.exe");
                FinalizaTarefa("iexplore");
                Thread.Sleep(1000);
                ChamaGCPJ();
                Thread.Sleep(5000);
                Automacao.localizarJanela("GCPJ");
            }
            else
            {

            }
        }

        public bool validarCamposLogin()
        {
            if (txtLogin.Text == "")
            {
                MessageBox.Show("ATENÇÃO! Campo Login não informado", "",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                return false;
            }

            if (txtPassword.Text == "")
            {
                MessageBox.Show("ATENÇÃO! Campo Password não informado", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return false;
            }
            return true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        // ---------------------------------------------------------------------------------
        // Volta para a tela de ENCERRAMENTO do MESMO processo (a que tem o botão Encerrar).
        // Depois de tratar uma pendência (evento, sucumbência, CPF), o GCPJ pode ficar na tela do
        // evento. Aqui o robô clica em Voltar, até 3 vezes, até o botão Encerrar aparecer.
        // NÃO abre o processo de novo e NÃO clica em outros links.
        // ---------------------------------------------------------------------------------
        private bool VoltarParaTelaEncerramento(string gcpj)
        {
            for (int volta = 0; volta <= 3; volta++)
            {
                Automacao.espera();
                if (Automacao.estadoBotao("btoEncerrar") != -1) return true;
                if (volta == 3) break;

                Automacao.registrarLog("GCPJ " + gcpj + " | fora da tela de encerramento (" + Automacao.paginaAtual() + "), clicando em Voltar");
                if (!Automacao.clicar("btoVoltar")) break;   // sem botão Voltar na tela: não tem como voltar
                Thread.Sleep(1000);
            }
            Automacao.registrarLog("GCPJ " + gcpj + " | NAO voltou para a tela de encerramento. Tela atual: " + Automacao.paginaAtual());
            return false;
        }

        // ---------------------------------------------------------------------------------
        // Tratativa quando o botão Encerrar NÃO aparece na tela do GCPJ:
        //   1) espera a tela por até 10 segundos (GCPJ lento);
        //   2) se o GCPJ mostrou alguma mensagem, guarda o texto, fecha e confere de novo;
        //   3) se o robô ficou em outra tela (por exemplo, a do evento), volta para a tela de
        //      encerramento do mesmo processo pelo botão Voltar (sem abrir o processo de novo);
        //   4) se nem assim aparecer, grava na OBS a tela e a mensagem do GCPJ, e o processo entra
        //      no aviso do fim da execução para ser tratado manualmente.
        // Devolve "APARECEU" ou "DESISTIR".
        // ---------------------------------------------------------------------------------
        private List<double> processosSemBotaoEncerrar = new List<double>();

        private string TratarBotaoEncerrarAusente(double gcpj, string tipoprocessamento)
        {
            for (int espera = 1; espera <= 5; espera++)
            {
                Thread.Sleep(2000);
                Automacao.espera();
                if (Automacao.estadoBotao("btoEncerrar") != -1) return "APARECEU";
            }

            string mensagem = "";
            if (Automacao.mataPossivelMsgBox())
            {
                mensagem = Automacao.textMsgBox ?? "";
                Automacao.espera();
                if (Automacao.estadoBotao("btoEncerrar") != -1) return "APARECEU";
            }

            string tela = Automacao.paginaAtual();
            if (VoltarParaTelaEncerramento(gcpj.ToString())) return "APARECEU";

            int q = tela.IndexOf('?');
            if (q >= 0) tela = tela.Substring(0, q);
            string obs = "BOTAO ENCERRAR NAO ENCONTRADO NO GCPJ - TELA: " + tela;
            if (mensagem.Trim() != "") obs += " - MSG: " + mensagem.Trim();
            obs = obs.Replace("'", "").Replace("\r", " ").Replace("\n", " ");
            if (obs.Length > 250) obs = obs.Substring(0, 250);

            preencheGrade("Processo " + gcpj.ToString() + ": botão Encerrar não encontrado, nem voltando para a tela de encerramento. Ver a OBS e tratar manualmente.");
            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = '" + obs + "' WHERE GCPJ = " + gcpj);
            processosSemBotaoEncerrar.Add(gcpj);
            return "DESISTIR";
        }

        // Grava na OBS por que o processo não foi encerrado, mostra na grade e coloca no aviso do fim.
        private void RegistrarFalhaEncerrar(double gcpj, string tipoprocessamento, string motivo)
        {
            string mensagem = "";
            if (Automacao.mataPossivelMsgBox()) mensagem = Automacao.textMsgBox ?? "";
            string tela = Automacao.paginaAtual();
            int q = tela.IndexOf('?');
            if (q >= 0) tela = tela.Substring(0, q);

            string obs = motivo + " - TELA: " + tela;
            if (mensagem.Trim() != "") obs += " - MSG: " + mensagem.Trim();
            obs = obs.Replace("'", "").Replace("\r", " ").Replace("\n", " ");
            if (obs.Length > 250) obs = obs.Substring(0, 250);

            preencheGrade("Processo " + gcpj.ToString() + ": " + motivo + ". Ver a OBS e tratar manualmente.");
            Automacao.registrarLog("GCPJ " + gcpj.ToString() + " | " + obs);
            Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = '" + obs + "' WHERE GCPJ = " + gcpj);
            processosSemBotaoEncerrar.Add(gcpj);
        }

        // Clica em ENCERRAR só se o botão estiver na tela e habilitado, e confere se o clique funcionou.
        // Quando o encerramento é com depósito (acordo ou liquidação), espera a tela de valores abrir
        // (campo do valor base) antes de seguir. Se algo der errado, grava o motivo e devolve false:
        // o robô NÃO segue preenchendo campos numa tela errada.
        private bool ClicarEncerrarEConferir(double gcpj, string tipoprocessamento, bool esperaTelaDeValores)
        {
            int estado = Automacao.estadoBotao("btoEncerrar");
            if (estado != 0)
            {
                RegistrarFalhaEncerrar(gcpj, tipoprocessamento, estado == 1 ? "BOTAO ENCERRAR AINDA DESABILITADO (PENDENCIA NAO RESOLVIDA)" : "BOTAO ENCERRAR NAO ENCONTRADO NO GCPJ");
                return false;
            }
            if (!Automacao.clicarBotao("btoEncerrar"))
            {
                RegistrarFalhaEncerrar(gcpj, tipoprocessamento, "NAO FOI POSSIVEL CLICAR NO BOTAO ENCERRAR");
                return false;
            }
            if (!esperaTelaDeValores) return true;

            for (int espera = 1; espera <= 8; espera++)
            {
                Thread.Sleep(2000);
                Automacao.espera();
                if (Automacao.existeCampo("valoresEncerramentoVO.vlBaseEncerramento")) return true;
            }
            RegistrarFalhaEncerrar(gcpj, tipoprocessamento, "TELA DE VALORES DO ENCERRAMENTO NAO ABRIU APOS CLICAR EM ENCERRAR");
            return false;
        }

        // Aviso no fim da execução com os processos que ficaram sem o botão Encerrar.
        private void AvisarProcessosSemBotaoEncerrar()
        {
            if (processosSemBotaoEncerrar.Count == 0) return;
            string lista = "";
            foreach (double g in processosSemBotaoEncerrar) lista += "\n  • GCPJ " + g.ToString();
            MessageBox.Show(processosSemBotaoEncerrar.Count + " processo(s) não foram encerrados pelo robô:" + lista +
                "\n\nEles precisam ser tratados manualmente. O motivo está na coluna OBS da base.",
                "Atenção: processos não encerrados", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }

        private void encerramento()
        {
            if (txtMaquina.ToString().Length == 0)
            {
                MessageBox.Show("Informe a quantidade de maquinas!");
                return;
            }

            try
            {
                int.Parse(txtMaquina.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Informe um número válido");
                return;
            }

            OleDbDataReader dr;
            OleDbDataReader dr2;
            DataTable dt3 = new DataTable();
            int contador = 0;
            int qtdOperacoesS5 = 0; // [S5] contador de processos tratados nesta execução
            processosSemBotaoEncerrar.Clear(); // processos sem o botão Encerrar (aviso no fim)

            //carregando os processos para o encerramento...
            if (CBSelecionaProcessamento.Text == "ENCERRAMENTO")
            {
                dr = Conexao.consultar("SELECT * FROM TB_ENCERRAMENTO WHERE ENCERRADO = FALSE AND MAQUINA = " + txtMaquina.ToString());
                dr2 = Conexao.consultar("SELECT * FROM TB_ENCERRAMENTO WHERE ENCERRADO = FALSE AND MAQUINA = " + txtMaquina.ToString());
            }
            else
            {
                dr = Conexao.consultar("SELECT * FROM TB_ACORDOS WHERE ENCERRADO = FALSE AND MAQUINA = " + txtMaquina.ToString());
                dr2 = Conexao.consultar("SELECT * FROM TB_ACORDOS WHERE ENCERRADO = FALSE AND MAQUINA = " + txtMaquina.ToString());
            }

            string tipoprocessamento;
            tipoprocessamento = atualizatabela(CBSelecionaProcessamento.Text);

            dt3.Load(dr2);

            BarraProgresso.Minimum = 0;
            BarraProgresso.Maximum = dt3.Rows.Count;

            while (dr.Read())
            {
                // [S5] Limitador de operações: para o processamento ao atingir o limite (ver LimitadorS5.cs)
                if (LimitadorS5.LimiteAtingido(qtdOperacoesS5))
                {
                    preencheGrade(LimitadorS5.MensagemLog());
                    break;
                }
                qtdOperacoesS5++;

                contador++;
                BarraProgresso.Value = contador;
            reinicia:
                //navegando para a tela de encerramento
                Automacao.espera();
                Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrEncerProce?metodo=carregar&origem=1");
                Automacao.espera();

                //informando o processo.....
                preencheGrade("Encerrando processo " + dr.GetDouble(0).ToString());
                Automacao.setaValorNome("nuProcessoBradesco", dr.GetDouble(0).ToString());
                Automacao.clicar("btoPesquisar");

                if (Automacao.mataPossivelMsgBox())
                {
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'PROCESSO JA ENCERRADO' WHERE GCPJ = " + dr.GetDouble(0));
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " já encerrado");
                    continue;
                }

                Automacao.espera();

                //selecionando o motivo....
                Automacao.selecionaCombo("cdMotivo", dr.GetInt32(1).ToString(), "value");
                Automacao.ExecutarJS("montarCombo();");
                Automacao.espera();

                //classificacao
                Automacao.selecionaCombo("classificacaoSelecionado.codigoClassificacao", dr.GetInt32(2).ToString(), "value");

                //SEGURANCA PARA MAIS DE 5 ENVOLVIDOS.
                if (dr.GetInt32(20) > 5)
                {
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " tem mais de cinco envolvidos!");
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'MAIS DE 5 ENVOLVIDOS NO PROCESSO!' WHERE GCPJ = " + dr.GetDouble(0));
                    continue;
                }

                // NOS CASOS DE ACORDO, O ENVOLVIDO SELECIONADO TERÁ QUE SER O INFOMRADO NA PLANILHA PREENCHIDA
                //se o processo for sem custos, vamos selecionar os todos os envolvidos.

                if (dr.GetInt32(1) != 1 && dr.GetInt32(1) != 2)
                {
                    Automacao.checaCampo("selecionados", 0);
                    Automacao.checaCampo("selecionados", 1);
                    Automacao.checaCampo("selecionados", 2);
                    Automacao.checaCampo("selecionados", 3);
                    Automacao.checaCampo("selecionados", 4);
                    Automacao.checaCampo("selecionados", 5);
                }
                else if (dr.GetInt32(1) == 1)
                {
                    Automacao.selecionarTabela("tab1", dr.GetString(21).ToString());
                }
                else
                {                    
                    //se o processo for com custos, vamos selecionar somente o primeiro
                    Automacao.checaCampo("selecionados", 0);
                }
                ///////////////////////////////////////////////////////////

                if (Automacao.selecionarTabela("tab1", "ENCERRADO"))
                {
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " já encerrado!");
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'JÁ EXISTEM ENVOLVIDOS ENCERRADOS PARA O PROCESSO' WHERE GCPJ = " + dr.GetDouble(0));
                    continue;
                }

                if (Automacao.selecionarTabela("tab1", "EM ENCERRAMENTO"))
                {
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " já encerrado!");
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'JÁ EXISTEM ENVOLVIDOS EM ENCERRAMENTO PARA O PROCESSO' WHERE GCPJ = " + dr.GetDouble(0));
                    continue;
                }

                if (Automacao.selecionarTabela("tab1", "BAIXADO"))
                {
                    //temos um envolvido baixado e uma galera aitva ainda....
                    //CHAMAR A FUNCAO DE ENCERRAR DEMAIS ENVOLVIDOS....
                    preencheGrade("Processo" + dr.GetDouble(0).ToString() + " tem mais envolvidos ativos...");
                    encerrarDemais(dr.GetDouble(0));
                    Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'ENCERRADOS APENAS OS DEMAIS ENVOLVIDOS DO PROCESSO, POIS O PRINCIPAL JÁ ESTAVA ENCERRADO COM CUSTOS' WHERE GCPJ = " + dr.GetDouble(0));
                    continue;
                }

                //acionando o botão salvar....
                Automacao.clicar("btoSalvar");
                if (Automacao.mataPossivelMsgBox())
                {
                    //processo encerrado com sucesso.
                }
                else
                {
                    //podemos continuar o encerramento?
                    //if (Automacao.elementoAtivo("btoEncerrar") == false)
                    //if (Automacao.elementoAtivo_Capiroto("btoEncerrar") == false)
                    // O botão Encerrar precisa EXISTIR na tela antes de decidir. Antes, botão que não existe
                    // era tratado como habilitado: o robô "clicava" num botão inexistente e quebrava depois,
                    // no selecionaCombo do solicitarEncerramento (erro "referência nula").
                    int estadoEncerrar = Automacao.estadoBotao("btoEncerrar");
                    if (estadoEncerrar == -1)
                    {
                        // tratativa: espera, lê mensagem do GCPJ, volta para a tela de encerramento (ver TratarBotaoEncerrarAusente)
                        string acaoEncerrar = TratarBotaoEncerrarAusente(dr.GetDouble(0), tipoprocessamento);
                        if (acaoEncerrar == "DESISTIR") continue;
                        estadoEncerrar = Automacao.estadoBotao("btoEncerrar"); // o botão apareceu
                    }
                    if (estadoEncerrar == 0)
                    {
                        //vamos encerrar direto...
                        preencheGrade("Processo com pendencia mas é possivel encerrar");
                        //Automacao.clicar("btoEncerrar");
                        // clica só se o botão estiver na tela e habilitado; com depósito, espera a tela de valores abrir
                        if (!ClicarEncerrarEConferir(dr.GetDouble(0), tipoprocessamento, dr.GetInt32(1) == 1 || dr.GetInt32(1) == 2)) continue;

                        Thread.Sleep(7000);

                        if (dr.GetInt32(1) == 1 || dr.GetInt32(1) == 2)
                        {
                            //solicitar depositos...
                            Automacao.espera();
                            solicitarEncerramento(dr.GetDouble(0));
                        }
                        else
                        {
                            //fim
                            //Automacao.mataMsgBox();
                            if (Automacao.localizarJanela("ERRO!") == true)
                            {
                                MataProcesso("iexplore.exe");
                                FinalizaTarefa("iexplore");
                                Thread.Sleep(1000);
                                ChamaGCPJ();
                                Thread.Sleep(5000);
                                Automacao.localizarJanela("GCPJ");
                                goto reinicia;
                            }

                            vMSGSalvar2 = Automacao.lerMsgBox();
                            if (vMSGSalvar2.Contains("Encerramento efetuado com sucesso"))
                            {
                                //SEGUE O FLUXO NORMAL
                                Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = '" + vMSGSalvar2 + "' WHERE GCPJ = " + dr.GetDouble(0));
                                Automacao.mataMsgBox();
                                continue;
                            }

                            if (Automacao.mataMsgBoxSalvaCadastro() == false)
                            {
                                MataProcesso("iexplore.exe");
                                FinalizaTarefa("iexplore");
                                Thread.Sleep(1000);
                                ChamaGCPJ();
                                Thread.Sleep(5000);
                                Automacao.localizarJanela("GCPJ");
                                goto reinicia;
                            }

                        }

                    }
                    else
                    {
                        preencheGrade("Processo com pendencia obrigatoria");

                        int reentrada = 0;
                        bool pendenciaDesconhecida = false;

                        while (Automacao.elementoAtivo_Capiroto("btoEncerrar") == true)
                        {
                        recheck:
                            string retorno;
                            //retorno = Automacao.clicaPrimeiroObjeto("a");
                            // só clica em link de pendência que o robô sabe tratar (antes clicava no primeiro link da tela)
                            retorno = Automacao.clicaLinkPendenciaEncerramento("Atualização de Resumo", "Valor", "Sucumb", "GFIP", "CPF", "Fato");
                            if (retorno == "")
                            {
                                pendenciaDesconhecida = true;
                                break;
                            }
                            Automacao.espera();
                            if (retorno.Contains("Atualização de Resumo"))
                            {
                                //evento realizado pendente....
                                preencheGrade("Atualizando eventos realizados");
                                atualizaEvento(dr.GetDouble(0).ToString(), dr.GetInt32(1));
                            }

                            if (retorno.Contains("Valor"))
                            {
                                //evento realizado pendente....
                                Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'NÃO É POSSIVEL ENCERRAR PENDENCIA DE VALORES' WHERE GCPJ = " + dr.GetDouble(0));
                                preencheGrade("GCPJ com pendencia de valores");
                                goto proximo;
                            }

                            if (retorno.Contains("Sucumb"))
                            {
                                //temos valor de sucumbencia....
                                //quando tem sucumbencia e é liquidacao ou acordo...
                                preencheGrade("Atualiza dados de sucumbencia");
                                atualizaSucumbencia();

                            }

                            if (retorno.Contains("GFIP"))
                            {
                                //temos GFIP....
                                //quando tiver.....
                                MessageBox.Show("Caso com pendencia de GFIP... desenvolver...");
                                return;
                            }

                            if (retorno.Contains("CPF"))
                            {
                                //temos CPF_CNPJ....
                                //quando tiver.....
                                Automacao.espera();
                                Automacao.selecionarRadio(0, "selecionados");
                                Automacao.clicar("btoExecutar");
                                Automacao.espera();
                                //Automacao.selecionarRadio(1, "cdFlagCPF");
                                Automacao.selecionarRadio(0, "cdFlagCPF");
                                Automacao.ExecutarJS("tratarDocumento(1)");
                                Automacao.espera();
                                
                                if (dr.GetString(23).ToString() != "0")
                                {
                                    Automacao.setaValorNome("cdCpfPessoaExterna", dr.GetString(23).ToString());
                                }
                                else
                                {
                                    Automacao.setaValorNome("cdCpfPessoaExterna", dr.GetString(22).ToString());
                                    Automacao.setaValorNome("cdCtrlCpfPessoaExterna", dr.GetString(24).ToString());
                                }                                
                                //Automacao.setaValorNome("dsJustificativa", "Desconhecido");
                                Automacao.clicar("btoSalvar");
                                Automacao.mataMsgBox();
                                Automacao.clicar("btoVoltar");
                                Automacao.espera();
                                //MessageBox.Show("Caso com pendencia de cpf_cnpj... desenvolver...");
                            }

                            if (retorno.Contains("Fato"))
                            {
                                //temos DATA FATO....
                                //quando tiver.....
                                Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = 'NÃO É POSSIVEL ENCERRAR PENDENCIA DE DATA DO FATO GERADOR' WHERE GCPJ = " + dr.GetDouble(0));
                                preencheGrade("GCPJ com pendencia de data do fato gerador");
                                return;
                            }

                            // depois de tratar a pendência, o robô tem que estar de novo na tela de ENCERRAMENTO
                            // (antes ficava na tela do evento e clicava no primeiro link dela: outro evento)
                            VoltarParaTelaEncerramento(dr.GetDouble(0).ToString());

                            reentrada++;

                            if (reentrada > 10)
                            {
                                MessageBox.Show("Reentrada! " + retorno + "Verificar qual pendencia está sendo exibida", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                return;
                            }
                        }

                        if (pendenciaDesconhecida)
                        {
                            RegistrarFalhaEncerrar(dr.GetDouble(0), tipoprocessamento, "PENDENCIA QUE O ROBO NAO SABE TRATAR");
                            continue;
                        }

                        // O laço acima também termina quando o botão Encerrar SOME da tela. Nesse caso não dá para
                        // encerrar: antes o robô "clicava" no botão inexistente e quebrava no solicitarEncerramento.
                        if (Automacao.estadoBotao("btoEncerrar") == -1)
                        {
                            // mesma tratativa do outro ponto (ver TratarBotaoEncerrarAusente)
                            string acaoEncerrar = TratarBotaoEncerrarAusente(dr.GetDouble(0), tipoprocessamento);
                            if (acaoEncerrar == "DESISTIR") continue;
                        }

                        preencheGrade("Pendencias liberadas, vamos encerrar");

                        Thread tr1 = new Thread(clicarEncerrar);

                        if (dr.GetInt32(1) != 1 && dr.GetInt32(1) != 2)
                        {
                            // confere ANTES de ligar a leitura da mensagem: se o botão não está habilitado, não clica
                            int estadoFinal = Automacao.estadoBotao("btoEncerrar");
                            if (estadoFinal != 0)
                            {
                                RegistrarFalhaEncerrar(dr.GetDouble(0), tipoprocessamento, estadoFinal == 1 ? "BOTAO ENCERRAR AINDA DESABILITADO (PENDENCIA NAO RESOLVIDA)" : "BOTAO ENCERRAR NAO ENCONTRADO NO GCPJ");
                                continue;
                            }
                            tr1.Start();
                            //Automacao.clicar("btoEncerrar");
                            Automacao.clicarBotao("btoEncerrar");
                            //Automacao.espera();

                            Thread.Sleep(7000);
                            //Automacao.mataMsgBox();

                            if (vMSGSalvar.Contains("Encerramento efetuado com sucesso"))
                            {
                                //SEGUE O FLUXO NORMAL
                                Conexao.executar("UPDATE " + tipoprocessamento + " SET ENCERRADO = TRUE, OBS = '" + vMSGSalvar + "' WHERE GCPJ = " + dr.GetDouble(0));
                                Automacao.mataMsgBox();
                            }
                            else
                            {
                                if (Automacao.localizarJanela("ERRO!") == true)
                                {
                                    MataProcesso("iexplore.exe");
                                    FinalizaTarefa("iexplore");
                                    Thread.Sleep(1000);
                                    ChamaGCPJ();
                                    Thread.Sleep(5000);
                                    Automacao.localizarJanela("GCPJ");
                                    goto reinicia;
                                }

                                if (Automacao.mataMsgBoxSalvaCadastro() == false)
                                {
                                    MataProcesso("iexplore.exe");
                                    FinalizaTarefa("iexplore");
                                    Thread.Sleep(1000);
                                    ChamaGCPJ();
                                    Thread.Sleep(5000);
                                    Automacao.localizarJanela("GCPJ");
                                    goto reinicia;
                                }
                            }

                        }
                        else
                        {
                            //AGORA VAMOS FAZER O FLUXO DE ENCERRAMENTO DE PROCESSO COM CUSTOS...
                            //Automacao.clicar("btoEncerrar");
                            // clica só se o botão estiver habilitado e espera a tela de valores abrir
                            if (!ClicarEncerrarEConferir(dr.GetDouble(0), tipoprocessamento, true)) continue;
                            Automacao.espera();
                            //solicitar depositos...
                            solicitarEncerramento(dr.GetDouble(0));
                        }

                    }

                }
            proximo:
                //nada a fazer pois o caso está com problemas
                preencheGrade("Processo " + dr.GetDouble(0).ToString() + " processado com sucesso!");

            }

            AvisarProcessosSemBotaoEncerrar();
        }

        private void complementar()
        {
            if (txtMaquina.ToString().Length == 0)
            {
                MessageBox.Show("Informe a quantidade de maquinas!");
                return;
            }

            try
            {
                int.Parse(txtMaquina.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Informe um número válido");
                return;
            }

            DateTime dt;
            OleDbDataReader dr;
            OleDbDataReader dr2;
            OleDbDataReader drComplementar;
            DataTable dt3 = new DataTable();
            int contador = 0;
            int qtdOperacoesS5 = 0; // [S5] contador de processos tratados nesta execução

            //carregando os processos para o encerramento...
            dr = Conexao.consultar("SELECT * FROM TB_COMPLEMENTAR WHERE PROCESSADO = FALSE AND MAQUINA = " + txtMaquina.ToString());
            dr2 = Conexao.consultar("SELECT * FROM TB_COMPLEMENTAR WHERE PROCESSADO = FALSE AND MAQUINA = " + txtMaquina.ToString());

            String valorgcpj;
            String verifvalorcomposi;
            double gcpj = 0;
            double valor = 0;
            verifvalorcomposi = "";
            valorgcpj = "";

            dt3.Load(dr2);

            BarraProgresso.Minimum = 0;
            BarraProgresso.Maximum = dt3.Rows.Count;

            while (dr.Read())
            {

                if (gcpj == dr.GetDouble(0) && valor == dr.GetDouble(6))
                {
                    contador++;
                    BarraProgresso.Value = contador;
                    gcpj = dr.GetDouble(0);
                    valor = dr.GetDouble(6);
                    continue;
                }

                // [S5] Limitador de operações: conta só processos de verdade (as linhas repetidas puladas acima não contam); para ao atingir o limite (ver LimitadorS5.cs)
                if (LimitadorS5.LimiteAtingido(qtdOperacoesS5))
                {
                    preencheGrade(LimitadorS5.MensagemLog());
                    break;
                }
                qtdOperacoesS5++;

                //drComplementar = Conexao.consultar("SELECT * FROM TB_COMPLEMENTAR WHERE GCPJ = " + dr.GetDouble(0).ToString() + " and VALOR = '" + dr.GetString(6).ToString() + "'");
                drComplementar = Conexao.consultar("SELECT * FROM TB_COMPLEMENTAR WHERE GCPJ = " + dr.GetDouble(0).ToString() + " and VALOR = " + dr.GetDouble(6).ToString().Replace(",", "."));

                contador++;
                BarraProgresso.Value = contador;

                //navegando para a tela de pagamento avulso
                Automacao.espera();
                Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/finDepositoNovoAlteracaoAction?metodo=carregar");
                Automacao.espera();

                //informando o processo.....
                preencheGrade("Rodando processo " + dr.GetDouble(0).ToString());
                Automacao.setaValorNome("envolvidoVO.processo.cdNumeroProcessoBradesco", dr.GetDouble(0).ToString());
                valorgcpj = dr.GetDouble(0).ToString();
                Automacao.clicar("btoPesquisar");

                if (Automacao.mataPossivelMsgBox())
                {
                    Conexao.executar("UPDATE TB_INCLUSAO SET INCLUIDO = TRUE, OBS = 'FALHA AO PROCESSAR' WHERE GCPJ = " + dr.GetDouble(0) + " and VALOR = " + dr.GetDouble(6).ToString().Replace(",", "."));
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " já encerrado");
                    continue;
                }

                Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/finDepositoNovoAlteracaoAction?metodo=abrirPopupDepositosAnteriores");

                Automacao.espera();

                //selecionando o Tipo de Deposito....
                string pegaDeposito = tipoDeposito(dr.GetString(2));

                if (pegaDeposito == null)
                {
                    Conexao.executar("UPDATE TB_INCLUSAO SET INCLUIDO = TRUE, OBS = 'Tipo de deposito invalido' WHERE GCPJ = " + dr.GetDouble(0) + " and VALOR = " + dr.GetDouble(6).ToString().Replace(",", "."));
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " já encerrado");
                    continue;
                }
                Automacao.selecionaCombo("selTipoDeposito", pegaDeposito, "value");
                Automacao.ExecutarJS("filtrarCamposPorDeposito();");
                Automacao.espera();

                //selecionando a Finalidade....
                string pegaFinalidade = tipoFinalidade(dr.GetString(3));

                if (pegaFinalidade == null)
                {
                    Conexao.executar("UPDATE TB_INCLUSAO SET INCLUIDO = TRUE, OBS = 'Finalidade invalida' WHERE GCPJ = " + dr.GetDouble(0) + " and VALOR = " + dr.GetDouble(6).ToString().Replace(",", "."));
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " já encerrado");
                    continue;
                }
                Automacao.selecionaCombo("selFinalidade", pegaFinalidade, "value");
                Automacao.ExecutarJS("filtrarCamposPorFinalidade();");
                Automacao.espera();

                //selecionando a Forma de Pagamento....
                string pegaPagamento = tipoPagamento(dr.GetString(4));

                if (pegaPagamento == null)
                {
                    Conexao.executar("UPDATE TB_INCLUSAO SET INCLUIDO = TRUE, OBS = 'Forma de pagamento invalida' WHERE GCPJ = " + dr.GetDouble(0) + " and VALOR = " + dr.GetDouble(6).ToString().Replace(",", "."));
                    preencheGrade("Processo " + dr.GetDouble(0).ToString() + " já encerrado");
                    continue;
                }
                Automacao.selecionaCombo("selFormaPagamento", pegaPagamento, "value");
                Automacao.ExecutarJS("filtrarCamposPorFormaPagto();");
                Automacao.espera();

                Automacao.setaValorNome("depositoJudicialEfetuadoVo.contaDepositoJudicial.cdBanco", dr.GetString(5).ToString());
                Automacao.clicar("null");
                Automacao.espera();

                preencheGrade("Validando data depósito");

                dt = retornaDataPagamento();

                Automacao.setaValorNome("depositoJudicialEfetuadoVo.dtDepositoJudicialProcesso", dt.ToShortDateString());
                Automacao.espera();

                Automacao.setaValorNome("depositoJudicialEfetuadoVo.vrDepositoJudicialProcesso", dr.GetDouble(6).ToString("N"));
                Automacao.espera();

                if (dr.GetString(4) != "CHEQUE DEP JUDICIAL")
                {
                    Automacao.setaValorNome("depositoJudicialEfetuadoVo.cdNumeroDocumentoDeposito", dr.GetString(7).ToString());
                    Automacao.espera();
                }

                while (drComplementar.Read())
                {

                    var cdDeposito = depositoComplementar(drComplementar.GetString(12));

                    Automacao.selecionaCombo("selTipoComposicao", cdDeposito, "value");
                    Automacao.ExecutarJS("filtrarCamposPorFormaPagto();");
                    Automacao.espera();

                    Automacao.setaValorNome("depositoJudicialEfetuadoVo.compsDepJudicVO.vrComposicaoDepositoJudicial", drComplementar.GetDouble(13).ToString("N"));
                    Automacao.espera();

                    Automacao.clicar("btoIncluir");
                    Automacao.espera();

                }               

                if (dr.GetString(3) == "LIQUIDACAO - CIVEL")
                {
                    Automacao.clicar("btoContinuar");
                    Automacao.espera();
                    Automacao.selecionarRadio(1,"vrBruto");
                    Automacao.espera();
                    Automacao.selecionarRadio(1,"impsIR");
                    Automacao.espera();
                    if (Automacao.retornaValor("vrBaseIr") == "0,00")
                    {
                        Automacao.setaValorNome("vrBaseIr", dr.GetDouble(6).ToString("N"));
                    }
                    Automacao.espera();
                    Automacao.clicar("btoContinuar");
                    goto finalizar;
                }
                Automacao.clicar("btoSalvar");

                finalizar:
                String Mensagem = Automacao.lerMsgBox();
                Conexao.executar("UPDATE TB_COMPLEMENTAR SET PROCESSADO = TRUE, OBS = '" + Mensagem + "' WHERE GCPJ = " + valorgcpj + " and VALOR = " + dr.GetDouble(6).ToString().Replace(",", "."));
                Automacao.mataPossivelMsgBox();

                preencheGrade("Passando para o proximo processo");

                gcpj = dr.GetDouble(0);
                valor = dr.GetDouble(6);

            }

            MessageBox.Show("PROCESSAMENTO FINALIZADO COM SUCESSO!");

        }

        public DateTime retornaDataPagamento()
        {
            //data deposito hoje mais dois dias uteis
            DateTime dt = new DateTime();
            String validaferiado = "";
            dt = DateTime.Now;
            dt = dt.AddDays(2);
        checagem:
            if (dt.DayOfWeek == DayOfWeek.Saturday)
            {
                dt = dt.AddDays(2);
            }
            if (dt.DayOfWeek == DayOfWeek.Sunday)
            {
                dt = dt.AddDays(2);
            }

            //verificando feriados....
            preencheGrade("Verificando feriados");
            OleDbDataReader drFeriado;
            int dia = dt.Day;
            int mes = dt.Month;
            int dia2 = 0;
            int mes2 = 0;
            if (validaferiado == "" || validaferiado == "dt2")
            {
                DateTime dt2 = dt;
                dt2 = dt2.AddDays(-1);
                dia2 = dt2.Day;
                mes2 = dt2.Month;

            }

            drFeriado = Conexao.consultar("SELECT * FROM SYS_FERIADOS");
            while (drFeriado.Read())
            {
                if (drFeriado.GetInt32(0) == dia2 && drFeriado.GetInt32(1) == mes2)
                {
                    dt = dt.AddDays(1);
                    drFeriado.Close();
                    validaferiado = "dt2";
                    goto checagem;
                }
                if (drFeriado.GetInt32(0) == dia && drFeriado.GetInt32(1) == mes)
                {
                    //dia e mes é feriado
                    dt = dt.AddDays(1);
                    drFeriado.Close();
                    validaferiado = "dt";
                    //iniciando a consistencia novamente
                    goto checagem;
                }
            }
                        
            drFeriado.Close();
            return dt;

        }

        public string depositoComplementar (string depositoInformado)
        {
            Dictionary<string, string> depositos = new Dictionary<string, string>();
            depositos.Add("1", "PRINCIPAL");
            depositos.Add("8", "CUSTAS");
            depositos.Add("7", "HONORARIOS SUCUMBENCIA");
            depositos.Add("6", "HONORARIOS PERICIAIS");
            depositos.Add("4", "IR");
            depositos.Add("5", "JUROS");
            depositos.Add("15", "MULTA-ART. 475-J - RESP. CONTR");
            depositos.Add("16", "MULTA-ART. 475-J - RESP. BANCO");
            depositos.Add("17", "MULTA-ART. 557 CPC");
            depositos.Add("18", "MULTA-DESC.ORD.JUD.-RESP BANCO");
            depositos.Add("19", "MULTA-DESC.ORD.JUD.-RESP CONTR");
            depositos.Add("20", "MULTA-LIT. MA-FE - RESP. BANCO");
            depositos.Add("21", "MULTA-LIT. MA-FE - RESP. CONTR");
            depositos.Add("37", "MULTA-ART. 475-J -RESP.GESTOR");
            depositos.Add("38", "MULTA-ART.475-J-RESP.INDEVIDA");
            depositos.Add("39", "MULTA-DESC.ORD.JUD.-RES GESTOR");
            depositos.Add("40", "MULTA-DESC.ORD.JUD.-RES INDEVI");
            depositos.Add("45", "MULTA-ART.475-J -RESP.JURIDICO");
            depositos.Add("46", "MULTA-ART.475-J -RESP.ESCRITOR");
            depositos.Add("47", "MULTA-DESC.ORD.JUD.-RES JURIDI");
            depositos.Add("48", "MULTA-DESC.ORD.JUD.-RES ESCRIT");

            foreach (var deposito in depositos)
            {
                if (depositoInformado == deposito.Value)
                {
                    return deposito.Key;
                }
            }
            return null;
        }

        public string tipoPagamento(string pagamentoInformado)
        {
            Dictionary<string, string> pagamentos = new Dictionary<string, string>();
            pagamentos.Add("2", "CHEQUE DEP JUDICIAL");
            pagamentos.Add("1", "TED-DEP JUDICIAL");
            pagamentos.Add("3", "TITULO PUBLICO");
            pagamentos.Add("8", "TRANSF.ENTRE CONTAS");

            foreach (var pagamento in pagamentos)
            {
                if (pagamentoInformado == pagamento.Value)
                {
                    return pagamento.Key;
                }
            }
            return null;
        }

        public string tipoFinalidade(string finalidadeInformada)
        {
            Dictionary<string, string> finalidades = new Dictionary<string, string>();
            finalidades.Add("25", "LIQUIDACAO - CIVEL");
            finalidades.Add("26", "ACORDO - CIVEL DIVERSOS");
            finalidades.Add("27", "COMPL LIQUIDACAO - CIVEL DIVERSOS");
            finalidades.Add("30", "EMBARGOS - CIVEL DIVERSOS");            

            foreach (var finalidade in finalidades)
            {
                if (finalidadeInformada == finalidade.Value)
                {
                    return finalidade.Key;
                }
            }
            return null;
        }

        public string tipoDeposito(string depositoInformado)
        {
            Dictionary<string, string> depositos = new Dictionary<string, string>();
            depositos.Add("2", "DEPOSITO CREDITO EM CONTA");
            depositos.Add("4", "GARANTIA DE EXECUCAO");            

            foreach (var deposito in depositos)
            {
                if (depositoInformado == deposito.Value)
                {
                    return deposito.Key;
                }
            }
            return null;
        }

        public string pegarCodigoMulta(string multaInformada) 
        {
            Dictionary<string, string> multas = new Dictionary<string, string>();
            multas.Add("15", "MULTA-LIT. MA-FE - RESP. BANCO");
            multas.Add("16", "MULTA-LIT. MA-FE - RESP. BANCO");
            multas.Add("17", "MULTA-LIT. MA-FE - RESP. BANCO");
            multas.Add("18", "MULTA-LIT. MA-FE - RESP. BANCO");
            multas.Add("19", "MULTA-LIT. MA-FE - RESP. BANCO");
            multas.Add("20", "MULTA-LIT. MA-FE - RESP. BANCO");
            multas.Add("21", "MULTA-LIT. MA-FE - RESP. CONTR");
            multas.Add("37", "MULTA-ART. 475-J -RESP.GESTOR");
            multas.Add("38", "MULTA-ART.475-J-RESP.INDEVIDA");
            multas.Add("39", "MULTA-DESC.ORD.JUD.-RES GESTOR");
            multas.Add("40", "MULTA-DESC.ORD.JUD.-RES INDEVI");
            multas.Add("45", "MULTA-ART.475-J -RESP.JURIDICO");
            multas.Add("46", "MULTA-ART.475-J -RESP.ESCRITOR");
            multas.Add("47", "MULTA-DESC.ORD.JUD.-RES JURIDI");
            multas.Add("48", "MULTA-DESC.ORD.JUD.-RES ESCRIT");            

            foreach (var multa in multas)
            {
                if (multaInformada == multa.Value) 
                {
                    return multa.Key;
                }
            }
            return null;
        }

        private void distribuirEncerramento()
        {
            if (txtMaquina.ToString().Length == 0)
            {
                MessageBox.Show("Informe a quantidade de maquinas!");
                return;
            }

            try
            {
                int.Parse(txtMaquina.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Informe um número válido");
                return;
            }

            //validado o numero de maquinas
            int i = 1;
            OleDbDataReader dr;
            DataTable dt = new DataTable();
            OleDbDataReader dr2;
            int contador = 0;
            dr = Conexao.consultar("select * from tb_encerramento where encerrado = false");
            dr2 = Conexao.consultar("select * from tb_encerramento where encerrado = false");
            dt.Load(dr2);

            int contarlinhas = dt.Rows.Count;
            BarraProgresso.Minimum = 0;
            BarraProgresso.Maximum = contarlinhas;

            while (dr.Read())
            {
                Conexao.executar("UPDATE TB_ENCERRAMENTO SET MAQUINA = " + i + " where GCPJ = " + dr.GetDouble(0));
                i++;
                if (i > int.Parse(txtMaquina.ToString()))
                {
                    i = 1;
                }

                contador++;
                BarraProgresso.Value = contador;
            }
            dr.Close();
            preencheGrade("Maquinas distribuidas com sucesso!");

        }
        private void distribuirComplementar()
        {
            if (txtMaquina.ToString().Length == 0)
            {
                MessageBox.Show("Informe a quantidade de maquinas!");
                return;
            }

            try
            {
                int.Parse(txtMaquina.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Informe um número válido");
                return;
            }

            //validado o numero de maquinas
            int i = 1;
            OleDbDataReader dr;
            DataTable dt = new DataTable();
            OleDbDataReader dr2;
            int contador = 0;
            double gcpj = 0;
            dr = Conexao.consultar("select * from TB_COMPLEMENTAR where PROCESSADO = false");
            dr2 = Conexao.consultar("select * from TB_COMPLEMENTAR where PROCESSADO = false");
            dt.Load(dr2);

            int contarlinhas = dt.Rows.Count;
            BarraProgresso.Minimum = 0;
            BarraProgresso.Maximum = contarlinhas;

            while (dr.Read())
            {
                if (gcpj == dr.GetDouble(0))
                {
                    contador++;
                    BarraProgresso.Value = contador;
                    gcpj = dr.GetDouble(0);
                    continue;
                }                
                Conexao.executar("UPDATE TB_COMPLEMENTAR SET MAQUINA = " + i + " where GCPJ = " + dr.GetDouble(0));
                i++;
                if (i > int.Parse(txtMaquina.ToString()))
                {
                    i = 1;
                }
                contador++;
                BarraProgresso.Value = contador;
                gcpj = dr.GetDouble(0);
            }
            dr.Close();
            preencheGrade("Maquinas distribuidas com sucesso!");

        }

        private void distribuirAcordos()
        {
            if (txtMaquina.ToString().Length == 0)
            {
                MessageBox.Show("Informe a quantidade de maquinas!");
                return;
            }

            try
            {
                int.Parse(txtMaquina.ToString());
            }
            catch (Exception)
            {
                MessageBox.Show("Informe um número válido");
                return;
            }

            //validado o numero de maquinas
            int i = 1;
            OleDbDataReader dr;
            DataTable dt = new DataTable();
            OleDbDataReader dr2;
            int contador = 0;
            dr = Conexao.consultar("select * from TB_ACORDOS where encerrado = false");
            dr2 = Conexao.consultar("select * from TB_ACORDOS where encerrado = false");
            dt.Load(dr2);

            int contarlinhas = dt.Rows.Count;
            BarraProgresso.Minimum = 0;
            BarraProgresso.Maximum = contarlinhas;

            while (dr.Read())
            {
                Conexao.executar("UPDATE TB_ACORDOS SET MAQUINA = " + i + " where GCPJ = " + dr.GetDouble(0));
                i++;
                if (i > int.Parse(txtMaquina.ToString()))
                {
                    i = 1;
                }

                contador++;
                BarraProgresso.Value = contador;
            }
            dr.Close();
            preencheGrade("Maquinas distribuidas com sucesso!");

        }


    }
}
