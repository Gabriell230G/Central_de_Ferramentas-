<div align="center">

<img src="docs/readme/header.svg" alt="Atualizador de Eventos: baixa no GCPJ as pendências de evento do tipo reclamante/autor em mais de um processo" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: VB.NET" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET 4.8" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="navegador: Internet Explorer" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o robô percorre a lista de pendências do GCPJ e, em cada pendência do tipo **RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO**, grava o texto do campo *Resumo Evento* e salva. As de outro tipo ele pula.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 1 tipo de pendência baixada; 5.000 pendências por execução (Controle S5); 11 mensagens da tela explicadas; 10 linhas por página da lista" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Conectar no GCPJ pelo Internet Explorer ➜ 2 Lista de pendências de atualização de resumo ➜ 3 Robô com Controle S5 olha uma pendência por vez ➜ 4 Filtro: só reclamante/autor em mais de um processo ➜ 5 Resultado: evento salvo com o resumo e andamento na grade" width="100%">
</picture>

### A tela

| Campo ou botão | O que faz |
| :--- | :--- |
| **Conectar** | Procura um Internet Explorer com o GCPJ aberto. Se não achar, abre um novo para você fazer login |
| **Processar** | Começa a automação |
| **Pagina** | Em que página da lista o robô começa. `0` = primeira página |
| **Linha** | Em que linha da página o robô começa. `0` = primeira linha. O próprio robô vai mudando esse número enquanto pula pendências |
| **Resumo Evento** | Texto gravado em **todas** as pendências baixadas nesta execução. Já vem preenchido com *"Aguardando informação do escritório contratado."* |
| **Grade** (lista grande) | Mostra, com hora, cada passo que o robô deu |

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `aajr-cmn-atualizaeventos-auto` |
| **Inventário** | **C@KG** · ATUALIZAÇÃO EVENTOS · *"Realizar a atualização de um determinado evento nos processos solicitados"* |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em VB.NET Windows Forms, .NET Framework 4.8, compilado em **x86** |
| **Sistema que altera** | GCPJ (tela de pendências de atualização de resumo) |
| **Entrada** | Texto do campo *Resumo Evento* + a lista de pendências do próprio GCPJ |
| **Saída** | Pendência salva no GCPJ com o resumo + mensagens na grade da tela |
| **Base local / log** | **Não tem.** Nada é gravado fora do GCPJ. A grade some quando a janela fecha |
| **Instalação** | `\\mz-vv-fs-138\D4040_4\Publico\Backup_sistemas\InsereEventos_4785\ATUALIZA_EVENTO_REALIZADO\` |
| **Controle S5** | Até **5.000 pendências por execução** |

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Conectar no GCPJ ➜ 2 Conferir o Resumo Evento ➜ 3 Página e Linha (opcional, 0 e 0 = do início) ➜ 4 Processar ➜ 5 O robô trabalha (até 5.000 por execução, pula os outros tipos) ➜ 6 Conferir a grade e a lista no GCPJ" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Clique em **Conectar**. Se aparecer *"Por favor, insira seu login e senha!"*, faça login no Internet Explorer que abriu |
| **2** | Confira o texto do **Resumo Evento**. Ele vai igual para todas as pendências desta execução |
| **3** | *(opcional)* Ajuste **Pagina** e **Linha**. Em branco ou `0` e `0`, o robô começa do início da lista |
| **4** | Clique em **Processar** |
| **5** | Acompanhe pela grade. Se passar de 5.000, o robô para sozinho e avisa (Controle S5) |
| **6** | Confira a grade e a lista no GCPJ. **Tire um print da grade antes de fechar**, porque ela não fica salva |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e como o robô lê a lista</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com **Internet Explorer** e acesso ao GCPJ (`https://intranet85.net.bradesco.com.br/gcpj`)
- Usuário do GCPJ com acesso à tela de pendências de atualização de resumo
- O executável da pasta de instalação (ver *Ficha rápida*). Não precisa de Access nem de Excel

**Como o robô lê a lista do GCPJ:**

| O que ele olha | Regra |
| :--- | :--- |
| Tipo da pendência | O texto da **4ª coluna** da linha. Só baixa se for exatamente `RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO` |
| Tamanho da página | Conta **10 linhas por página** (Linha vai de `0` a `9`). Na 10ª pendência pulada, soma 1 na Pagina e volta a Linha para `0` |
| Pendência baixada | Some da lista. Por isso, quando baixa, a Linha não muda: a próxima pendência sobe para aquela posição |

> [!TIP]
> **Pagina** e **Linha** guardam onde o robô parou. Se você rodar de novo **sem fechar a janela**, ele continua dali. Para recomeçar do início da lista, coloque `0` nos dois.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** este robô **não tem banco nem log**. O registro do que ele fez está em dois lugares: a **grade da tela** (ou o print dela, se alguém tirou) e o **próprio GCPJ**, onde a pendência baixada sai da lista e fica com o resumo gravado.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um processo ➜ 2 Ler a grade da tela ou o print da execução ➜ 3 Conferir no GCPJ a pendência e o resumo ➜ resultado verde (deu certo, pendência baixada com o resumo), amarelo (o robô pulou ou parou no meio) ou vermelho (corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que a pendência *RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO* do processo 123456 continua aberta. No print da grade não existe a linha `Baixando pendência do processo bradesco: 123456`, e a última linha é `Processamento realizado com sucesso!`. Pelo quadro vermelho, o robô parou antes de chegar nesse processo. Basta clicar em **Conectar**, conferir o login e rodar de novo.

> [!IMPORTANT]
> **A hora da grade usa relógio de 12 horas, sem AM/PM.** Uma linha com `02:15:00` pode ter sido às 2h15 ou às 14h15. Ao juntar evidência para uma RO, anote também a data e o período da execução.

#### 🟢 Deu certo: não precisa fazer nada

| O que está escrito na grade | O que quer dizer |
| :--- | :--- |
| GCPJ Localizado! Prossiga com o processamento! | O robô achou o GCPJ aberto e já pode rodar |
| Iniciando o processamento da atualização de eventos, desde que sejam CONSIDERAÇÕES SOBRE O PROCESSO | O robô começou. O texto fala em *Considerações sobre o processo*, mas é sobra de uma versão antiga: o tipo tratado hoje é *RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO* |
| Baixando pendência do processo bradesco: *(número)* | O robô abriu a pendência desse processo, gravou o *Resumo Evento* e salvou |
| Foram percorridos *(N)* até o momento | Andamento: quantas pendências ele já olhou, somando as baixadas e as puladas |

#### 🟡 Precisa que alguém olhe

| O que está escrito na grade | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| Evento não é RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO, ignorando... | A pendência daquela linha é de outro tipo. O robô não mexe nela | Se a RO for sobre ela, tratar manualmente no GCPJ: está fora do que o robô faz |
| Processamento realizado com sucesso! | Só quer dizer que o robô **terminou**. Ele escreve isso sempre no fim, até quando parou por erro ou pelo Controle S5 | Ler as linhas de cima e conferir no GCPJ se o processo ainda está na lista |
| Controle S5: limite de 5.000 registros atingido. Processamento interrompido. | Chegou a 5.000 pendências olhadas nesta execução | Normal. Rodar de novo: o que faltou continua na lista do GCPJ |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| Não existe a linha *Baixando pendência do processo bradesco: (número)* para o processo da RO, e a grade termina em *Processamento realizado com sucesso!* | O robô parou antes de chegar nesse processo. Qualquer erro no meio da lista (sessão do GCPJ caiu, tela lenta) encerra a execução sem aviso | Clicar em **Conectar**, conferir o login e rodar de novo |
| A grade parou em *Baixando pendência do processo bradesco: (número)* e não anda mais | Depois de salvar, o robô espera o alerta do GCPJ (*Mensagem da página da web*). Se o alerta não vem, ele fica esperando para sempre | Olhar o Internet Explorer. Se o GCPJ mostrou erro, fechar o robô, conferir o processo no GCPJ e rodar de novo |
| A pendência foi baixada com o **resumo errado** | O robô grava o que estava no campo *Resumo Evento*, igual para todas da execução | Corrigir o resumo direto no GCPJ. Conferir o campo antes da próxima execução |

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| *ATENÇÃO! Preencha o resumo!* | O campo *Resumo Evento* está vazio | Preencher o resumo. O padrão é *"Aguardando informação do escritório contratado."* |
| *Abrindo nova instância do GCPJ...* e *Por favor, insira seu login e senha!*, mesmo com o GCPJ aberto | O robô procura uma janela do IE com "GCPJ" no nome e não achou | Fazer login no IE que ele abriu e usar esse |
| Janela de erro do .NET logo ao clicar em **Processar** | Não clicou em **Conectar** antes, ou o login não foi concluído | Fechar, abrir o robô, clicar em **Conectar**, logar e só depois **Processar** |
| A grade só mostra *Evento não é RECLAMANTE/AUTOR...* | Não há pendência desse tipo a partir da Pagina/Linha informada | Conferir a lista no GCPJ. Para recomeçar do início, colocar `0` em Pagina e Linha |
| Aviso **Processamento Limitado - Controle S5** | Chegou a 5.000 pendências olhadas nesta execução | Normal. Rodar de novo continua o trabalho |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim (automação que atualiza dados em sistema estruturado). O código **C@KG** agora tem o controle: no máximo **5.000** pendências por execução.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada pendência o robô confere se já olhou 5.000; se não, olha, baixa ou pula e soma 1; se sim, para, avisa o usuário e escreve na grade" width="100%">
</picture>

O contador soma 1 a **cada pendência que o robô olha**, inclusive as que ele pula. Na prática ele pode parar antes de baixar 5.000, porque as puladas também contam. É o jeito mais conservador de cumprir o limite.

Quando o limite é atingido, aparece o aviso **Processamento Limitado - Controle S5** com o texto *"O limite de processamento de 5.000 registros foi atingido. Os itens restantes continuam pendentes no GCPJ e podem ser processados em uma nova execução."*, e a grade mostra *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*. O que sobrou continua na lista do GCPJ para a próxima execução.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `Mod_LimitadorS5.vb` | constante `LIMITE_OPERACOES_S5`, linha 22 |
| Mensagem do aviso | `Mod_LimitadorS5.vb` | função `LimiteS5Atingido`, linha 31 |
| Contador da execução | `Form1.vb` | `btnProcessar_Click`, variável `qtdOperacoesS5` na linha 102 |
| Checagem no laço | `Form1.vb` | `btnProcessar_Click`, bloco `[S5]` na linha 128, logo no início do `Do Until vFim` |

> [!TIP]
> Para testar sem esperar 5.000 pendências: troque `LIMITE_OPERACOES_S5` para `2`, rode com pelo menos 3 pendências na lista, tire os prints com o relógio do Windows aparecendo e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra todos os pontos. As evidências oficiais estão em [`docs/Evidencias_S5_AtualizaEventos.docx`](docs/Evidencias_S5_AtualizaEventos.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `atualizaEventos\atualizaEventos.vbproj` (solução `atualizaEventos.sln`)

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `Form1.vb` | `Espera_Ate_Que_Abra` | 24 | Espera o IE terminar de carregar a página |
| | `MataPossivelMsgbox` | 34 | Fecha um alerta do GCPJ, se houver. **Não é usada** |
| | `btnConectar_Click` | 53 | Botão **Conectar**: acha ou abre o IE do GCPJ |
| | `VerificaGCPJ` | 68 | Procura uma janela do IE com "GCPJ" no `LocationName` |
| | `preencheGrade` | 78 | Escreve uma linha na grade, com hora |
| | `MataMsgbox` | 89 | Espera o alerta *Mensagem da página da web* e clica em OK |
| | `btnProcessar_Click` | 101 | Botão **Processar**: toda a automação |
| | bloco `[S5]` | 128 | Controle S5 |
| | 4ª coluna / filtro do tipo | 157 / 160 | Lê o tipo da pendência e compara com o texto alvo |
| | `Catch` | 186 | Caso de lista com uma linha só, ou fim da lista |
| `Form1.Designer.vb` | `txtResumo.Text` | 150 | Resumo padrão |
| `Mod_LimitadorS5.vb` | `LIMITE_OPERACOES_S5` | 22 | Controle S5 |

</details>

<details>
<summary><b>Como funciona por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>


1. Abre a tela de pendências: `servlet/traTraPendAdvogAtulzResAction?acao=carregar` (linha 124).
2. A cada volta do laço `Do Until vFim`: confere o Controle S5 e soma 1 no contador.
3. Se a volta anterior pulou uma pendência (`vAtualiza = True`), recarrega a tela. Depois avança de página chamando o JavaScript `paginacao('7')` uma vez para cada número em **Pagina** (linhas 141 a 144).
4. Marca o checkbox `selecionados` da posição **Linha** e lê a 4ª célula da linha da tabela.
5. Se o texto for `RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO`: clica em `btoExecutar`, lê o número em `cdNumeroProcessoBradesco`, preenche `dsResumoEventoJudicial` com o *Resumo Evento*, clica em `btoSalvar` e fecha o alerta do GCPJ com `MataMsgbox`.
6. Se não for: escreve *"Evento não é ..."*, soma 1 na Linha e, ao chegar em 10, soma 1 na Pagina e zera a Linha.
7. Quando a lista tem **uma linha só**, `selecionados` não é uma lista e o acesso por posição dá erro. O `Catch` (linha 186) trata esse caso quando Pagina e Linha são `0`. Em qualquer outra posição, o `Catch` entende que a lista acabou e encerra (linha 223).
8. No fim, escreve *"Processamento realizado com sucesso!"* (linha 229).

</details>

<details>
<summary><b>Campos do GCPJ que o robô usa</b> &nbsp;·&nbsp; o que quebra se o GCPJ mudar a tela</summary>
<br>


| Elemento | Tipo | Uso |
| :--- | :--- | :--- |
| `traTraPendAdvogAtulzResAction?acao=carregar` | Endereço | Tela com a lista de pendências |
| `paginacao('7')` | JavaScript da página | Avança uma página da lista |
| `selecionados` | Checkbox de cada linha | Escolhe a pendência e chega até a linha da tabela |
| 4ª célula da linha | Texto | Tipo da pendência |
| `btoExecutar` | Botão | Abre a pendência |
| `cdNumeroProcessoBradesco` | Campo | Número do processo, só para escrever na grade |
| `dsResumoEventoJudicial` | Campo | Recebe o *Resumo Evento* |
| `btoSalvar` | Botão | Salva |
| *Mensagem da página da web* | Alerta do IE | Confirmação depois de salvar, fechada pelo robô |

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>


| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `Mod_LimitadorS5.vb` ➜ `LIMITE_OPERACOES_S5` |
| Mudar o tipo de pendência tratada | `Form1.vb` ➜ comparação nas linhas 160 e 202 (e o texto das mensagens nas linhas 174 e 215) |
| Mudar o resumo padrão | `Form1.Designer.vb` ➜ `txtResumo.Text`, linha 150 |
| Mudar a tela do GCPJ | `Form1.vb` ➜ `traTraPendAdvogAtulzResAction`, linhas 124 e 137 |
| Mudar o endereço do GCPJ | `Form1.vb` ➜ procure `intranet85.net.bradesco.com.br/gcpj` |
| Mudar quantas linhas tem cada página | `Form1.vb` ➜ `If txtLinha.Text >= 10`, linha 177 |
| Mudar o formato da hora na grade | `Form1.vb` ➜ `preencheGrade`, linha 79 |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>


- **Erro no meio da lista parece sucesso.** Qualquer erro dentro do `Try` com Pagina ou Linha diferente de `0` cai no `Catch` (linha 186), que só faz `vFim = True` (linha 223), sem mensagem. Depois a grade mostra *"Processamento realizado com sucesso!"* (linha 229). Sessão do GCPJ que caiu ou página lenta encerram a execução como se estivesse tudo certo.
- **Pode travar para sempre.** `MataMsgbox` (linha 89) repete a busca pelo alerta *Mensagem da página da web* sem limite de tempo. Se o GCPJ não mostrar o alerta depois do *Salvar*, o robô congela. `Espera_Ate_Que_Abra` (linha 24) também espera sem limite.
- **Processar sem Conectar quebra.** `btnProcessar_Click` usa `objIndex` na linha 124 sem conferir se ele existe. Sem clicar em **Conectar** antes, sai uma exceção não tratada do .NET.
- **Hora da grade em 12 horas.** `Format(Date.Now, "hh:mm:ss")` na linha 79 não mostra AM/PM. Trocar para `"HH:mm:ss"` resolve.
- **Mensagem de início desatualizada.** A linha 122 fala em *CONSIDERAÇÕES SOBRE O PROCESSO*, mas o filtro (linhas 160 e 202) é *RECLAMANTE/AUTOR ENVOLVIDO EM MAIS DE UM PROCESSO*. Os comentários das linhas 173 e 214 têm a mesma sobra.
- **Depende do layout do GCPJ.** O tipo é lido pela **posição** (4ª célula, linha 157) e a página é assumida com **10 linhas** (linha 177). Se o GCPJ mudar a tabela ou a paginação, o robô pula ou erra a posição.
- **Código repetido.** O caso de uma linha só (linhas 190 a 220) repete o fluxo principal. Mudança no fluxo precisa ser feita nos dois lugares. Erro dentro desse trecho não é tratado.
- **Sem log.** Nada fica salvo depois que a janela fecha. A evidência de uma execução depende de print da grade.
- `MataPossivelMsgbox` (linha 34) e `limpaGrade` (linha 84) não são chamadas em lugar nenhum.
- As pastas `bin`, `obj` e `.vs` estão versionadas, junto com executáveis antigos (`atualizaEventos1.exe`, `atualizaEventos_new.exe`). São geradas na compilação e podem ser ignoradas.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 10/2025 repositório criado no GitHub; 01/2026 primeiro commit do código; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: avisar quando a execução parar por erro" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 10/2025 | vogon-fleet-app (bot) | Criação do repositório e do `CODEOWNERS` via Terramate |
| 01/2026 | Daniela Chirinian | Primeiro commit do código (migração para o GitHub) |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`Mod_LimitadorS5.vb`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
