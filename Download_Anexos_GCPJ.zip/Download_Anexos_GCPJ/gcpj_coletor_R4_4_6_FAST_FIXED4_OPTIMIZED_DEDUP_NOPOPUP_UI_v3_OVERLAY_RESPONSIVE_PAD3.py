# -*- coding: utf-8 -*-
"""
GCPJ Coletor — R4.4.6 (monólito pronto para deploy, UX/StatusBarPro compacta)
Arquitetura: Core vs UI (no mesmo arquivo, com fronteiras explícitas)
- Core: Contracts/Errors, Ports, Infra (HTTP/Parser/FileWriter/Telemetry), Strategies (Naming/Layout),
        Services (Auth, List, Plan, Download, Report, Orchestrator)
- UI:   Config/Views/Controllers + Adapters (Logger/Progress/Table) + StatusBarPro (compacta)
- HTTP: httpx (único, síncrono), sem HTTP/2/async/curl-cffi
- TLS:  dois clientes httpx (externo verify=True; intranet verify=False). NUNCA passa verify por request.
- Paginação: robusta por conteúdo + confirmação “8” + fallback páginas vazias consecutivas (N=3), executor fechado corretamente
- Download: resume .part + Range, os.replace atômico; status HTTP verificado; telemetria para stream (TTFB)
- Caminho Windows: truncamento path-aware
- Content-Disposition: suporte a filename*= (RFC 5987), preferência segura por nome do servidor quando possível
- Relatórios: CSV (BOM UTF-8) e XLSX
- Telemetria/ETA: RPS/MB/s/latência média + ETA adaptativa; Telemetry.snapshot() persistido (telemetry.json)
- Controle S5 (normativo 05.1073): no máximo LIMITE_OPERACOES_S5 processos por execução. Pesquise "[S5]".

Melhorias desta versão (R4.4.4):
- StatusBarPro: **compacta/minimalista**, barra inferior com 3 zonas, micro‑label (ETA/MB/s) na **mesma linha** do progresso,
  tooltip de status, cores com maior contraste, callout com slide‑in/out e ações ícone‑only com auto‑hide responsivo.
- API atômica update_state() para evitar flicker; popover de métricas ancorado ao botão “ⓘ”.
- Orchestrator envia ETA/MB/s via callback (sem sobrescrever o status humano).
- Layout e densidade visuais refinados; ações apenas no done.
- Mantida a robustez do core e os fluxos de cancelamento e telemetria.
"""

from __future__ import annotations
import os, re, csv, time, math, queue, logging, threading, errno, sys, subprocess, hashlib, unicodedata, random, json
from typing import List, Optional, Sequence, Tuple, Dict, Any, Protocol, runtime_checkable, Callable
from dataclasses import dataclass
from functools import lru_cache
from datetime import datetime
from collections import deque, Counter
import urllib.parse  # para Content-Disposition filename*=
# ------------ Dependências de 3ºs ------------
import httpx
from selectolax.parser import HTMLParser
import orjson as fastjson
import xlsxwriter
import customtkinter as ctk
from unidecode import unidecode
import urllib3

# Tkinter base
import tkinter as tk
from tkinter import messagebox, filedialog, ttk

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============================================
# CORE: Constants, Regex, Utils & Telemetry
# ============================================

LOG_FMT = "[%(levelname)s] %(asctime)s → %(message)s"
logging.basicConfig(level=logging.INFO, format=LOG_FMT, datefmt="%Y-%m-%d %H:%M:%S")
logger = logging.getLogger("gcpj")

INTERNAL_HOST_SUFFIX = "intranet85.net.bradesco.com.br"
BASE_GCPJ = f"https://{INTERNAL_HOST_SUFFIX}/gcpj/servlet/"
BASE_MENU = (
    f"https://{INTERNAL_HOST_SUFFIX}/inet/servlet/"
    "menuSenhasServlet?parAcao=1&parVisual=padrao2&parUsuario=null&parRotina=GCPJ"
)

DEFAULT_POOL_MAX = 24
DEFAULT_WORKERS_COLETA = 8
DEFAULT_COLETA_RETRIES = 2  # retries de coleta por processo (mismatch/instabilidade)
DEFAULT_WORKERS_DOWNLOAD = 20
DEFAULT_WINDOW_FACTOR = 2
DEFAULT_CHUNK = 1024 * 1024
MAX_PAGINAS_FAILSAFE = 1000

# ====================================================================================
# [S5] CONTROLE S5: LIMITADOR DE OPERAÇÕES (normativo 05.1073)
# ------------------------------------------------------------------------------------
# Quantidade máxima de processos tratados em UMA execução do coletor.
# Se o usuário informar mais do que isso, o robô baixa os anexos dos primeiros
# LIMITE_OPERACOES_S5 processos, avisa na tela e salva os que sobraram em
# "processos_pendentes_S5.txt" (dentro da pasta da execução) para a próxima rodada.
#
# Para mudar o limite, altere SÓ o valor abaixo.
# Para achar todos os pontos do controle, pesquise por "[S5]".
# ====================================================================================
LIMITE_OPERACOES_S5 = 5000
TITULO_AVISO_S5 = "Processamento Limitado - Controle S5"
ARQUIVO_PENDENTES_S5 = "processos_pendentes_S5.txt"


def aplicar_limite_s5(itens: Sequence[Any], limite: Optional[int] = None) -> Tuple[List[Any], List[Any]]:
    """[S5] Divide a lista em (processar agora, deixar para a próxima execução), mantendo a ordem."""
    itens = list(itens or [])
    limite = max(0, int(LIMITE_OPERACOES_S5 if limite is None else limite))
    return itens[:limite], itens[limite:]


def _fmt_n(n: int) -> str:
    """[S5] Número no padrão brasileiro: 5000 -> 5.000."""
    return f"{int(n):,}".replace(",", ".")


def mensagem_s5(qtd_informada: int, qtd_pendente: int, limite: Optional[int] = None) -> str:
    """[S5] Texto do aviso exibido ao usuário quando o limite é atingido."""
    limite = LIMITE_OPERACOES_S5 if limite is None else limite
    return (
        f"Foram informados {_fmt_n(qtd_informada)} processos, mas o limite por execução é de {_fmt_n(limite)}.\n\n"
        f"Serão processados agora os primeiros {_fmt_n(limite)}. Os {_fmt_n(qtd_pendente)} restantes foram salvos em "
        f"\"{ARQUIVO_PENDENTES_S5}\", na pasta desta execução, para serem processados em uma nova execução."
    )


def mensagem_log_s5(qtd_pendente: int, limite: Optional[int] = None) -> str:
    """[S5] Linha registrada no log da tela."""
    limite = LIMITE_OPERACOES_S5 if limite is None else limite
    return (f"Controle S5: limite de {_fmt_n(limite)} processos por execução atingido. "
            f"{_fmt_n(qtd_pendente)} processo(s) ficaram para a próxima execução.")


RE_LAST_INT = re.compile(r"(\d+)(?!.*\d)")

def _extract_last_int(s: str) -> str:
    """Extrai o último bloco numérico de uma string. Retorna '' se não houver."""
    if not s:
        return ""
    m = RE_LAST_INT.search(str(s))
    return m.group(1) if m else ""


def _pick_radio_id(attrs: dict) -> str:
    """Obtém o identificador numérico do radio/linha de anexo.

    Alguns HTMLs do GCPJ podem não preencher o atributo 'value' do <input type=radio>.
    Nesses casos o ID aparece em 'id', 'onclick', 'onClick' ou atributos data-*.
    Esta função tenta várias fontes e devolve sempre um ID numérico (string).
    """
    if not attrs:
        return ""
    candidates = [
        (attrs.get("value") or "").strip(),
        (attrs.get("data-value") or "").strip(),
        (attrs.get("data-id") or "").strip(),
        (attrs.get("id") or "").strip(),
        (attrs.get("onclick") or "").strip(),
        (attrs.get("onClick") or "").strip(),
    ]
    raw = next((c for c in candidates if c), "")
    if not raw:
        return ""
    num = _extract_last_int(raw)
    # Se não houver número, devolve o raw (último recurso) — mas isso deve ser raro.
    return num or raw

def _dc_seq_from_radio_id_plus_one(radio_id: str) -> str:
    """dc_sequencia = (ID do anexo) + 1.

    Regra de negócio: a subpasta é derivada do número do anexo (selecionados=ID) + 1.
    A extração do ID é tolerante a formatos como 'id=123', 'selecionados=123', etc.
    """
    rid = _extract_last_int(radio_id)
    if not rid:
        return "1"
    try:
        return str(int(rid) + 1)
    except Exception:
        return "1"

RE_SPLIT_PROC = re.compile(r"[;,\s]+")

def _only_digits(s: str) -> str:
    import re as _re
    return _re.sub(r"\D+", "", s or "")




def _extract_canonical_num_from_html(html: str) -> str:
    """Tenta extrair o número do processo que o portal está exibindo.
    Otimização: regex-first (barato) e só faz parse DOM se necessário.
    """
    if not html:
        return ''
    try:
        m = re.search(r'cdNumeroProcessoBradesco\s*=\s*(\d+)', html, flags=re.I)
        if m:
            return m.group(1)
        m = re.search(r'cdNumeroProcessoBradesco=(\d+)', html, flags=re.I)
        if m:
            return m.group(1)
    except Exception:
        pass
    try:
        tree = HTMLParser(html)
        node = tree.css_first('input[name="cdNumeroProcessoBradesco"], input#cdNumeroProcessoBradesco')
        if node and node.attributes:
            v = (node.attributes.get('value') or '').strip()
            if v:
                return v
        for n in tree.css('input'):
            attrs = n.attributes or {}
            nm = (attrs.get('name') or '').lower()
            _id = (attrs.get('id') or '').lower()
            if 'cdnumeroprocessobradesco' in nm or 'cdnumeroprocessobradesco' in _id:
                v = (attrs.get('value') or '').strip()
                if v:
                    return v
    except Exception:
        pass
    try:
        m = re.search(r'processo[^0-9]{0,40}([0-9\.\-/]{6,40})', html, flags=re.I)
        if m:
            return m.group(1)
    except Exception:
        pass
    return ''
RE_WS = re.compile(r"\s+")
RESERVED = {"CON","PRN","AUX","NUL"} | {f"COM{i}" for i in range(1,10)} | {f"LPT{i}" for i in range(1,10)}


def _sanitize_filename(name: str) -> str:
    if not name:
        return "arquivo"
    name = unicodedata.normalize('NFKD', name)
    name = "".join(ch for ch in name if not unicodedata.combining(ch))
    for c in '<>:"/\\\n?*\r\t':
        name = name.replace(c, '_')
    name = ''.join(ch for ch in name if ch >= ' ')
    name = RE_WS.sub(' ', name).strip()
    name = name.rstrip(' .')
    if not name:
        name = 'arquivo'
    base, ext = os.path.splitext(name)
    if base.upper() in RESERVED:
        base = base + '_'
    base = base.rstrip(' .') or 'arquivo'
    safe = f"{base}{ext}"
    if len(safe) > 240:
        b2, e2 = os.path.splitext(safe)
        keep = max(1, 240 - len(e2))
        safe = b2[:keep] + e2
    return safe


def _truncate_for_path(dirpath: str, filename: str, max_path: int = 248) -> str:
    """
    Garante que os.path.join(dirpath, filename) não ultrapasse max_path (Windows safe).
    248 é um valor conservador para caminho completo sem prefixos \\?\
    """
    full = os.path.join(dirpath, filename)
    if len(full) <= max_path:
        return filename
    base, ext = os.path.splitext(filename)
    overflow = len(full) - max_path
    keep = max(1, len(base) - overflow)
    return base[:keep] + ext


def _norm_tipo(s: str) -> str:
    return unidecode(s or '').strip().replace(' ', '_').lower()


@lru_cache(maxsize=16384)
def _u_upper_cached(s: str) -> str:
    """Normaliza string para comparação (unidecode + upper) com cache."""
    return unidecode(str(s or '')).upper()


def _norm_data(d: Optional[str]) -> str:
    return (d or '').replace('/', '-')


def dumps_fast(obj: Any) -> bytes:
    return fastjson.dumps(obj)


class Telemetry:
    lock = threading.Lock(); t0 = time.perf_counter()
    req_count = 0; err_count = 0; bytes_down = 0; req_time_acc = 0.0

    @classmethod
    def mark_request(cls, dt: float):
        with cls.lock:
            cls.req_count += 1; cls.req_time_acc += dt

    @classmethod
    def mark_error(cls):
        with cls.lock:
            cls.err_count += 1

    @classmethod
    def add_bytes(cls, n:int):
        if not n: return
        with cls.lock:
            cls.bytes_down += int(n)

    @classmethod
    def snapshot(cls):
        with cls.lock:
            el = max(1e-6, time.perf_counter()-cls.t0)
            rps = cls.req_count/el
            mbps = (cls.bytes_down/(1024*1024))/el
            lat = (cls.req_time_acc/max(1,cls.req_count)) if cls.req_count else 0.0
            return {"elapsed_s":el,"rps":rps,"mbps":mbps,"avg_req_s":lat, "errors":cls.err_count}


# ============================================
# CORE: Contracts (DTOs) & Errors
# ============================================

@dataclass
class ProcessoInput:
    numero: str
    tipos: Sequence[str]
    data_inicial: Optional[str] = None
    data_final: Optional[str] = None
    modo_busca: str = "tipo"  # "tipo" | "nome" | "ambos"


@dataclass
class AnexoItem:
    radio_id: str
    nome_doc: str
    tipo_txt: str
    arquivo: str
    data_raw: str


@dataclass
class DownloadPlanItem:
    url: str
    destino: str
    meta: Dict[str, Any]


@dataclass
class ProcessoResult:
    numero: str
    found: int
    ok: int
    skip: int
    fail: int
    bytes: int
    elapsed_s: float
    pages: int
    stop_reason: str
    dest_dirs: List[str]
    errors: List[Dict[str, Any]]


@dataclass
class JobSummary:
    total_processos: int
    total_anexos: int
    ok: int
    skip: int
    fail: int
    bytes_total: int
    tempo_total_s: float
    vazao_mbps: float
    top_erros: List[Tuple[str,int]]
    relatorio_csv: str
    relatorio_xlsx: str
    telemetria_json: Optional[str] = None


class CoreError(Exception): ...
class AuthError(CoreError): ...
class NetworkError(CoreError): ...
class ParseError(CoreError): ...
class DownloadError(CoreError): ...
class IOErrorCore(CoreError): ...


# ============================================
# CORE: Ports (Interfaces/Protocols)
# ============================================

@runtime_checkable
class HttpPort(Protocol):
    def get_text(self, url: str) -> str: ...
    def post_text(self, url: str, data: Dict[str, Any]) -> str: ...
    def stream_get(self, url: str, headers: Dict[str,str]): ...


@runtime_checkable
class LoggerPort(Protocol):
    def log(self, level:str, msg:str, proc:Optional[str]=None, run_id:Optional[str]=None) -> None: ...


@runtime_checkable
class ProgressPort(Protocol):
    def set_status(self, text:str) -> None: ...
    def set_fraction(self, frac:float) -> None: ...


@runtime_checkable
class ReportPort(Protocol):
    def generate(self, anexos: List['ProcessoAnexo'], base_dir:str) -> Tuple[str,str]: ...


@runtime_checkable
class NamingStrategy(Protocol):
    def build_base_name(self, numero:str, tipo_txt:str, data_raw:str, nome_doc:str, rid:str, cd_seq:str) -> str: ...
    def finalize_with_disposition(self, caminho_tmp:str, destino:str, headers:Dict[str,str]) -> str: ...


@runtime_checkable
class LayoutStrategy(Protocol):
    def resolve_destination(self, base_dir:str, numero:str, cd_seq:str, safe_name:str) -> Tuple[str,str]: ...
    # retorna (pasta_destino, caminho_destino)


@runtime_checkable
class FileWriterPort(Protocol):
    def baixar_uma(self, client: HttpPort, url:str, destino:str, chunk:int, max_retries:int) -> Tuple[str, Dict[str,Any]]: ...
    def baixar_lote(self, client: HttpPort, entries:Sequence['DownloadEntry'], max_workers:int, window_factor:int, chunk:int) -> Dict[str,Any]: ...


# ============================================
# CORE: Infra (HTTP, Parser, FileWriter, Telemetry helpers)
# ============================================

class HttpxClient(HttpPort):
    """
    Implementação correta para httpx:
    - DOIS clientes internos:
        * client_ext (verify=True) -> uso para hosts externos
        * client_int (verify=False) -> uso para host intranet (com inspeção TLS)
    - NUNCA passa 'verify=' por request; a escolha do client é via _pick(url).
    - Authorization Basic é aplicada só para host interno (via _merge_headers).
    """
    def __init__(self, max_pool=DEFAULT_POOL_MAX, ua=None, internal_host_suffix=INTERNAL_HOST_SUFFIX):
        self.internal_host_suffix = internal_host_suffix
        self.basic_auth_header = None
        common_headers = {
            "User-Agent": ua or "GCPJ-Coletor/4.4.6 +httpx",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/*,*/*;q=0.8",
            "Accept-Language": "pt-BR,pt;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Connection": "keep-alive",
        }
        to = httpx.Timeout(connect=5.0, read=180.0, write=30.0, pool=5.0)
        limits = httpx.Limits(max_keepalive_connections=max_pool, max_connections=max_pool)
        # Dois clientes: externo (verify=True) e intranet (verify=False), ambos com follow_redirects
        self.client_ext = httpx.Client(headers=dict(common_headers), timeout=to, limits=limits, verify=True, follow_redirects=True)
        self.client_int = httpx.Client(headers=dict(common_headers), timeout=to, limits=limits, verify=False, follow_redirects=True)

    def _is_internal(self, url: str) -> bool:
        from urllib.parse import urlparse
        host = (urlparse(url).hostname or '').lower()
        return host.endswith(self.internal_host_suffix)

    def _pick(self, url: str) -> httpx.Client:
        return self.client_int if self._is_internal(url) else self.client_ext

    def _merge_headers(self, url: str, headers: Dict[str,str] | None) -> Dict[str,str]:
        h = dict(headers or {})
        if self._is_internal(url) and self.basic_auth_header:
            h.setdefault("Authorization", self.basic_auth_header)
        return h

    def get_text(self, url: str) -> str:
        t0 = time.perf_counter()
        r = self._pick(url).get(url, headers=self._merge_headers(url, None))
        Telemetry.mark_request(time.perf_counter() - t0)
        r.raise_for_status()
        r.encoding = r.encoding or 'ISO-8859-1'
        return r.text

    def post_text(self, url: str, data: Dict[str, Any]) -> str:
        t0 = time.perf_counter()
        r = self._pick(url).post(url, data=data, headers=self._merge_headers(url, None))
        Telemetry.mark_request(time.perf_counter() - t0)
        r.raise_for_status()
        r.encoding = r.encoding or 'ISO-8859-1'
        return r.text

    def stream_get(self, url: str, headers: Dict[str,str]):
        return self._pick(url).stream("GET", url, headers=self._merge_headers(url, headers))

    def close(self):
        for c in (self.client_ext, self.client_int):
            try: c.close()
            except Exception: pass
def _new_isolated_client_from(base_client: 'HttpxClient', max_pool: int = 8, *, seed_menu: bool = False) -> 'HttpxClient':
    """Cria um HttpxClient novo (cookiejar/sessão isolada) e reaproveita o Basic Auth do client base.

    Otimização (R4.4.6): evita o GET extra no BASE_MENU por processo/tentativa.
    Em vez disso, faz *cookie seeding* copiando cookies do client base para o novo client.

    Se algum ambiente exigir *warm-up* via rede (backends que dependem de hit no menu),
    use `seed_menu=True` para reativar a chamada ao BASE_MENU.
    """
    c = HttpxClient(max_pool=max_pool)

    # Basic Auth (apenas host interno)
    try:
        c.basic_auth_header = getattr(base_client, 'basic_auth_header', None)
    except Exception:
        pass

    # Cookie seeding (evita 1 request por processo/tentativa)
    try:
        c.client_int.cookies.update(base_client.client_int.cookies)
    except Exception:
        pass
    try:
        c.client_ext.cookies.update(base_client.client_ext.cookies)
    except Exception:
        pass

    # Warm-up opcional via rede
    if seed_menu:
        try:
            _ = c.get_text(BASE_MENU)
        except Exception:
            pass

    return c

# LEGACY (removido do fluxo hot-path)
# def _hash_table_html(html:str)->str: ...


def _extract_ids_from_html(html:str)->List[Tuple[str,str,str,str,str]]:
    tree = HTMLParser(html)
    table = tree.css_first('#oTable')
    if not table:
        return []
    rows=[]
    for tr in table.css('tr'):
        rid_node = tr.css_first('input[type="radio"][name="selecionados"]')
        if not rid_node:
            continue
        tds = tr.css('td')
        try:
            radio_id = _pick_radio_id(rid_node.attributes)
            nome_doc = tds[2].text(strip=True) if len(tds)>2 else ''
            tipo_txt = tds[3].text(strip=True) if len(tds)>3 else ''
            arquivo  = tds[4].text(strip=True) if len(tds)>4 else ''
            data_raw = tds[6].text(strip=True) if len(tds)>6 else ''
            rows.append((radio_id, nome_doc, tipo_txt, arquivo, data_raw))
        except Exception:
            continue
    return rows


def _sig_from_rows(rows: List[Tuple[str,str,str,str,str]]) -> str:
    """Assinatura barata/semântica baseada nos IDs (radio_id) da tabela.
    Evita regex custosa em HTML e é mais estável a mudanças cosméticas no markup.
    """
    ids = [r[0] for r in (rows or []) if r and r[0]]
    core = "|".join(ids)
    return hashlib.md5(core.encode('utf-8', 'ignore')).hexdigest()


def _parse_page(html: str, prefer_form_name: str = 'frmGCPJ') -> Tuple[Dict[str, str], List[Tuple[str,str,str,str,str]], str]:
    """Parseia a página UMA única vez e devolve:

    - payload do form (contexto do backend)
    - rows da tabela (#oTable)
    - assinatura (hash) baseada nos IDs

    Otimização (R4.4.6): reduz pela metade o custo de parsing por página
    (antes: _extract_form_payload + _extract_ids_from_html + _hash_table_html).
    """
    payload: Dict[str, str] = {}
    rows: List[Tuple[str,str,str,str,str]] = []

    if not html:
        return payload, rows, hashlib.md5(b'').hexdigest()

    try:
        tree = HTMLParser(html)

        # ---- payload do form ----
        form = None
        if prefer_form_name:
            form = tree.css_first(f'form[name="{prefer_form_name}"]')
        if not form:
            form = tree.css_first('form')
        if form:
            for inp in form.css('input'):
                attrs = inp.attributes or {}
                name = (attrs.get('name') or '').strip()
                if not name:
                    continue
                itype = (attrs.get('type') or '').strip().lower()
                if itype and itype not in ('hidden', 'text', 'password', 'checkbox', 'radio'):
                    continue
                payload[name] = (attrs.get('value') or '')

        # ---- rows da tabela ----
        table = tree.css_first('#oTable')
        if table:
            for tr in table.css('tr'):
                rid_node = tr.css_first('input[type="radio"][name="selecionados"]')
                if not rid_node:
                    continue
                tds = tr.css('td')
                radio_id = _pick_radio_id(rid_node.attributes)
                nome_doc = tds[2].text(strip=True) if len(tds) > 2 else ''
                tipo_txt = tds[3].text(strip=True) if len(tds) > 3 else ''
                arquivo  = tds[4].text(strip=True) if len(tds) > 4 else ''
                data_raw = tds[6].text(strip=True) if len(tds) > 6 else ''
                rows.append((radio_id, nome_doc, tipo_txt, arquivo, data_raw))

    except Exception:
        # fallback conservador: reaproveita helpers antigos se algo der errado
        try:
            payload = _extract_form_payload(html, prefer_form_name=prefer_form_name) or {}
        except Exception:
            payload = {}
        try:
            rows = _extract_ids_from_html(html) or []
        except Exception:
            rows = []

    sig = _sig_from_rows(rows)
    return payload, rows, sig

def _extract_form_payload(html: str, prefer_form_name: str = 'frmGCPJ') -> Dict[str, str]:
    """Extrai um payload base para POSTs do fluxo de paginação.

    O GCPJ navega via submit de um <form> com diversos inputs (muitos hidden). Mesmo quando
    vários valores parecem vazios, o backend pode depender desse contexto.

    Estratégia:
      1) Seleciona form por name (preferencial) ou o primeiro form disponível.
      2) Coleta inputs com atributo name (prioriza hidden, mas inclui text/checkbox/radio quando tiver value).
      3) Não inclui campos sem name.

    Retorna dict(name -> value). Valores ausentes viram ''.
    """
    payload: Dict[str, str] = {}
    if not html:
        return payload
    try:
        tree = HTMLParser(html)
        form = None
        if prefer_form_name:
            form = tree.css_first(f'form[name="{prefer_form_name}"]')
        if not form:
            # fallback: primeiro form
            form = tree.css_first('form')
        if not form:
            return payload
        # inputs dentro do form
        for inp in form.css('input'):
            attrs = inp.attributes or {}
            name = (attrs.get('name') or '').strip()
            if not name:
                continue
            itype = (attrs.get('type') or '').strip().lower()
            # Em geral, hidden são suficientes; incluir outros apenas se tiver value.
            if itype and itype not in ('hidden', 'text', 'password', 'checkbox', 'radio'):
                # ignora submit/button/file etc.
                continue
            val = (attrs.get('value') or '')
            payload[name] = val
        # alguns fluxos podem ter <select>/<textarea> relevantes (raro aqui); mantemos conservador.
        return payload
    except Exception:
        return payload


def _classify_exception(e: Exception) -> Dict[str, str]:
    kind = 'UNKNOWN'; code = None; msg = str(e)
    # Classificação refinada httpx
    if isinstance(e, httpx.TimeoutException):
        kind = 'TIMEOUT'
    elif isinstance(e, httpx.HTTPStatusError):
        status = getattr(getattr(e, 'response', None), 'status_code', None)
        kind = f'HTTP_{status if status is not None else "ERR"}'
    elif isinstance(e, httpx.TransportError):
        kind = 'NETWORK'
    elif isinstance(e, OSError):
        if e.errno in (errno.EACCES, errno.EPERM): kind = 'PERM';  code = e.errno
        elif e.errno in (errno.ENOSPC,):          kind = 'SPACE'; code = e.errno
        else:                                     kind = 'IO';    code = e.errno
    return {'kind': kind, 'code': code, 'msg': msg}


# LEGACY (não utilizado pela estratégia de naming atual)
# def _content_disposition_filename(headers: Dict[str,str]) -> Optional[str]: ...

    # Tenta filename*= (RFC 5987), ex: filename*=UTF-8''Relat%C3%B3rio.pdf
    mstar = re.search(r'filename\*\s*=\s*([^;]+)', cd, flags=re.I)
    if mstar:
        val = mstar.group(1).strip().strip('"')
        try:
            if "''" in val:
                _, enc_val = val.split("''", 1)
                name = urllib.parse.unquote(enc_val)
                return _sanitize_filename(name)
            name = urllib.parse.unquote(val)
            return _sanitize_filename(name)
        except Exception:
            pass

    # Fallback: filename="..."
    m = re.search(r'filename\s*=\s*"([^"]+)"', cd, flags=re.I)
    if not m:
        m = re.search(r'filename\s*=\s*([^;]+)', cd, flags=re.I)
    if not m:
        return None
    name = m.group(1).strip().strip('"')
    return _sanitize_filename(name)


def _safe_replace(src:str, dst:str, retries:int=3, base_wait:float=0.2):
    last_e=None
    for _ in range(max(1,retries)):
        try:
            os.replace(src, dst); return
        except OSError as e:
            last_e=e
            if e.errno in (errno.EACCES, errno.EPERM):
                time.sleep(base_wait + random.uniform(0.0, 0.2)); continue
            raise
    if last_e: raise last_e


def _validate_lengths(escritos:int, offset:int, cl:int, is_partial:bool, status:int):
    if cl:
        if not is_partial:  # 200
            if escritos != cl:
                raise IOError(f'Mismatch length (200): got={escritos} expected={cl}')
        else:  # 206
            if (escritos - offset) != cl:
                raise IOError(f'Mismatch length (206): got={escritos-offset} expected={cl}')


# ============================================
# CORE: Strategies (Naming & Layout)
# ============================================

class DefaultNamingStrategy(NamingStrategy):
    def build_base_name(self, numero:str, tipo_txt:str, data_raw:str, nome_doc:str, rid:str, cd_seq:str) -> str:
        tipo_norm=_norm_tipo(tipo_txt); data_norm=_norm_data(data_raw); nome_base=_sanitize_filename(os.path.splitext(nome_doc or '')[0])
        return f"{numero}_{tipo_norm}_{data_norm}_{nome_base}_{rid}" if rid else f"{numero}_{tipo_norm}_{data_norm}_{nome_base}"

    def finalize_with_disposition(self, caminho_tmp:str, destino:str, headers:Dict[str,str]) -> str:
        """Mantém o nome planejado (destino) e NÃO renomeia pelo Content-Disposition.
        Objetivo: preservar o nome original do portal (campo 'arquivo').
        """
        _safe_replace(caminho_tmp, destino)
        return destino


class ByProcessAndSeqLayout(LayoutStrategy):
    def resolve_destination(self, base_dir:str, numero:str, cd_seq:str, safe_name:str) -> Tuple[str,str]:
        pasta_proc=os.path.join(base_dir, str(numero), f"{numero}_{cd_seq or '0'}")
        os.makedirs(pasta_proc, exist_ok=True)
        return pasta_proc, os.path.join(pasta_proc, safe_name)


# ============================================
# CORE: FileWriter (I/O robusto com resume) — implementação de FileWriterPort
# ============================================

@dataclass
class DownloadEntry:
    idx: int
    url: str
    destino: str
    registro: 'ProcessoAnexo'  # definido depois para UI/relatório


class FileSystemWriter(FileWriterPort):
    def __init__(self, naming: NamingStrategy):
        self.naming = naming
        self.cancel_event: Optional[threading.Event] = None

    def set_cancel_event(self, evt: threading.Event):
        self.cancel_event = evt

    def baixar_uma(self, client: HttpPort, url:str, destino:str, chunk:int=DEFAULT_CHUNK, max_retries:int=2):
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        if os.path.exists(destino) and os.path.getsize(destino)>0:
            return 'skip', {'attempts':0,'bytes':0,'elapsed_s':0.0,'resumed':False,'error':None}

        tentativa=0; t0=time.perf_counter(); total_written=0; last_error=None; resumed=False
        while tentativa<=max_retries:
            tentativa+=1; tmp=destino+".part"; headers={}; offset=0
            if os.path.exists(tmp):
                try:
                    offset=os.path.getsize(tmp)
                    if offset>0:
                        headers['Range']=f'bytes={offset}-'; resumed=True
                except Exception:
                    offset=0
            try:
                # Marca TTFB de stream_get (telemetria de requisição para downloads)
                t_req = time.perf_counter()
                with client.stream_get(url, headers=headers) as r:
                    Telemetry.mark_request(time.perf_counter() - t_req)

                    status = r.status_code
                    # Status HTTP explícito: falha em >= 400 (exceto 416 tratado adiante)
                    if status >= 400 and status != 416:
                        raise IOError(f"HTTP {status} ao baixar {url}")

                    hdrs = {k.title(): v for k,v in r.headers.items()}
                    cl_hdr = hdrs.get('Content-Length'); cl = int(cl_hdr) if (cl_hdr and cl_hdr.isdigit()) else 0

                    # Servidor ignorou Range?
                    if 'Range' in headers and status==200:
                        if cl and os.path.exists(tmp) and os.path.getsize(tmp)>=cl:
                            _safe_replace(tmp, destino)
                            return 'ok', {'attempts':tentativa,'bytes':0,'elapsed_s':time.perf_counter()-t0,'resumed':True,'error':None, 'path': destino}
                        headers.pop('Range', None); offset=0; resumed=True

                    # 416: Range Not Satisfiable — tratar caso já completo
                    if status == 416:
                        # Alguns servidores retornam Content-Range: bytes */TOTAL
                        cr_any = hdrs.get('Content-Range') or ''
                        m = re.search(r'bytes\s+\*/(\d+)', cr_any)
                        total_size = int(m.group(1)) if m else None
                        tmp_sz = os.path.getsize(tmp) if os.path.exists(tmp) else 0
                        if total_size and tmp_sz >= total_size:
                            final_path = self.naming.finalize_with_disposition(tmp, destino, hdrs)
                            return 'ok', {'attempts':tentativa,'bytes':total_written,'elapsed_s':time.perf_counter()-t0,'resumed':resumed,'error':None, 'path': final_path}
                        # Reinicie sem Range
                        headers.pop('Range', None)
                        continue

                    mode='ab' if ('Range' in headers and status==206) else 'wb'
                    escritos=offset
                    wrote_any = False
                    with open(tmp, mode) as f:
                        for part in r.iter_bytes(chunk_size=chunk):
                            # Cancelamento soft: interrompe entre chunks
                            if self.cancel_event and self.cancel_event.is_set():
                                raise RuntimeError("CANCELLED")
                            if part:
                                f.write(part); n=len(part); escritos+=n; total_written+=n; Telemetry.add_bytes(n); wrote_any = True

                    # 200/204 sem corpo efetivo e sem CL -> tratar como erro
                    if status in (200, 204) and not wrote_any and cl == 0:
                        raise IOError("Resposta sem corpo (0 bytes)")

                    _validate_lengths(escritos, offset, cl, is_partial=('Range' in headers and status==206), status=status)
                    final_path = self.naming.finalize_with_disposition(tmp, destino, hdrs)
                    return 'ok', {'attempts':tentativa,'bytes':total_written,'elapsed_s':time.perf_counter()-t0,'resumed':resumed,'error':None, 'path': final_path}
            except Exception as e:
                if last_error is None: last_error=_classify_exception(e)
                # Cancelamento padronizado
                if str(e) == "CANCELLED":
                    last_error = {'kind': 'CANCELLED', 'code': None, 'msg': 'Operação cancelada pelo usuário.'}
                Telemetry.mark_error()
                time.sleep(0.8*tentativa + random.uniform(0.0, 0.2))
        return 'fail', {'attempts':tentativa,'bytes':total_written,'elapsed_s':time.perf_counter()-t0,'resumed':resumed,'error':last_error or {'kind':'UNKNOWN','code':None,'msg':'Falha desconhecida'}}

    def baixar_lote(self, client: HttpPort, entries:Sequence[DownloadEntry], max_workers:int=DEFAULT_WORKERS_DOWNLOAD, window_factor:int=DEFAULT_WINDOW_FACTOR, chunk:int=DEFAULT_CHUNK):
        import concurrent.futures as cf
        t0=time.perf_counter(); results=[]
        max_outstanding = max(1, max_workers*max(1,window_factor))
        outstanding: Dict[Any, DownloadEntry] = {}
        it = iter(entries)
        with cf.ThreadPoolExecutor(max_workers=max_workers) as pool:
            try:
                for _ in range(min(max_outstanding, len(entries))):
                    if self.cancel_event and self.cancel_event.is_set():
                        break
                    e = next(it)
                    fut = pool.submit(self.baixar_uma, client, e.url, e.destino, chunk)
                    outstanding[fut] = e
            except StopIteration:
                pass
            while outstanding:
                done, _ = cf.wait(list(outstanding.keys()), return_when=cf.FIRST_COMPLETED)
                for fut in done:
                    e = outstanding.pop(fut)
                    try:
                        status, meta = fut.result()
                    except Exception as err:
                        Telemetry.mark_error()
                        status, meta = 'fail', {'attempts':0,'bytes':0,'elapsed_s':0.0,'resumed':False,'error':_classify_exception(err)}
                    results.append((e, status, meta))
                    # Soft-cancel: não agendar novos, apenas drenar outstanding
                    if self.cancel_event and self.cancel_event.is_set():
                        continue
                    try:
                        nxt = next(it)
                        nfut = pool.submit(self.baixar_uma, client, nxt.url, nxt.destino, chunk)
                        outstanding[nfut] = nxt
                    except StopIteration:
                        pass
        elapsed=time.perf_counter()-t0
        agg={'ok':0,'skip':0,'fail':0,'bytes':0,'elapsed_s':elapsed,'results':results,'errors':[]}
        for (_e, status, meta) in results:
            if status in ('ok','skip','fail'): agg[status]+=1
            agg['bytes']+=int(meta.get('bytes',0))
            if status=='fail' and meta.get('error'): agg['errors'].append(meta['error'])
        return agg


# ============================================
# CORE: Services (Auth, List, Plan, Download, Report, Orchestrator)
# ============================================

def autenticar_menu_http(client: HttpxClient, usuario: str, senha: str) -> bool:
    import base64
    basic = base64.b64encode(f"{usuario}:{senha}".encode('utf-8')).decode('ascii')
    client.basic_auth_header = f"Basic {basic}"  # apenas host interno
    try:
        html = client.get_text(BASE_MENU)
        ok = ("GCPJ" in (html or "").upper()) or (len(html) > 200)
        if not ok:
            logger.warning("Autenticação não confirmada pelo conteúdo do menu INET")
        return ok
    except Exception as e:
        Telemetry.mark_error()
        logger.error("Falha na autenticação: %s", e)
        return False




def coletar_anexos(
    client: HttpPort,
    numero_processo: str,
    tipos_desejados: Sequence[str],
    data_inicial: Optional[str] = None,
    data_final: Optional[str] = None,
    modo_busca: str = "tipo",
    max_paginas: int = MAX_PAGINAS_FAILSAFE,
    logger_cb: Optional[Callable[[str], None]] = None,
    cancel_cb: Optional[Callable[[], bool]] = None,
) -> Tuple[List[AnexoItem], int, Dict[str, Any]]:
    """Coleta anexos do processo, navegando a tabela por comandos do pager.

    Importante (domínio GCPJ):
      - pagina=7  => comando "Próxima página" (NEXT)
      - pagina=8  => comando "Última página" (LAST)

    Melhorias (R4.4.6 core):
      - Paginação mais determinística: envia payload completo do form (inputs hidden) a cada POST.
      - Stop policy baseada em assinatura/hash da tabela, com confirmação via LAST.
      - Correções de telemetria (table_items_initial) e otimizações de filtro.
    """
    from datetime import datetime as _dt

    url_get = (
        f"{BASE_GCPJ}cadMantemCadProcConsultaTodosAction?acao=obterAnexo&cdNumeroProcessoBradesco={numero_processo}"
    )
    url_post = f"{BASE_GCPJ}cadMantemCadProcConsultaTodosAction"

    # --- GET inicial ---
    html = client.get_text(url_get)

    # Validação pós-GET: comparar número exibido no portal com o solicitado
    _num_consulta = _only_digits(numero_processo)
    _num_html = _only_digits(_extract_canonical_num_from_html(html)) if html else ''
    if _num_consulta and _num_html and _num_consulta != _num_html:
        if logger_cb:
            logger_cb(f"Numero divergente no portal: solicitado={_num_consulta} vs portal={_num_html}.")
        return [], 0, {"stop_reason": "mismatch_server_number", "pages": 0, "total_ids": 0}

    # Payload base do form (estado/contexto do backend)
    payload_base, reg_rows, sig_prev = _parse_page(html)
    seen_ids: set = set()
    sig_initial = sig_prev
    initial_table_items = len({r[0] for r in reg_rows if r[0]})

    # Heurística conservadora para detectar paginação e evitar POSTs extras em processos de 1 página.
    # Só pula paginação quando NÃO há indício de pager e a primeira página parece curta.
    def _has_pager_hint(_html: str) -> bool:
        if not _html:
            return False
        h = _html.lower()
        if 'paginacaoanexos' in h:
            return True
        if 'pagina=7' in h or 'pagina=8' in h:
            return True
        if 'próxima' in h or 'proxima' in h or 'última' in h or 'ultima' in h:
            return True
        return False

    pager_hint = _has_pager_hint(html)
    page_size_hint = initial_table_items
    likely_single_page = (not pager_hint) and (page_size_hint < 18)

    # ---- Diagnósticos de filtro (observabilidade) ----
    stats = {
        'rows_total': 0,
        'added_total': 0,
        'rejected_type': 0,
        'rejected_date': 0,
        'duplicates': 0,
    }

    # Pré-normaliza termos e alvos (performance)
    tipos_list = list(tipos_desejados) if tipos_desejados is not None else []
    all_types = (not tipos_list) or (tipos_list == ['*'])
    termos_norm = [_u_upper_cached(str(t)) for t in tipos_list] if not all_types else []

    def ok_tipo(tipo_txt: str, arquivo: str) -> bool:
        if all_types:
            return True
        alvo_tipo = _u_upper_cached(tipo_txt)
        alvo_nome = _u_upper_cached(arquivo)
        for termo in termos_norm:
            if modo_busca == "tipo" and termo in alvo_tipo:
                return True
            if modo_busca == "nome" and termo in alvo_nome:
                return True
            if modo_busca == "ambos" and (termo in alvo_tipo or termo in alvo_nome):
                return True
        return False

    # -------- Filtro de datas (dd/mm/aaaa) --------
    def _parse_date(s: Optional[str]):
        if not s:
            return None
        s = str(s).strip()
        if len(s) < 10 or s[2:3] != '/' or s[5:6] != '/':
            return None
        try:
            return _dt(int(s[6:10]), int(s[3:5]), int(s[0:2])).date()
        except Exception:
            return None

    dt_ini = _parse_date(data_inicial)
    dt_fim = _parse_date(data_final)

    def ok_data(data_raw: str) -> bool:
        if not (dt_ini or dt_fim):
            return True
        try:
            _s = (data_raw or '').strip()
            if len(_s) < 10 or _s[2:3] != '/' or _s[5:6] != '/':
                return False
            d = _dt(int(_s[6:10]), int(_s[3:5]), int(_s[0:2])).date()
        except Exception:
            # Política: se filtro foi solicitado e a linha não tem data válida, descarta
            return False
        if dt_ini and d < dt_ini:
            return False
        if dt_fim and d > dt_fim:
            return False
        return True

    registros: List[AnexoItem] = []

    def filtrar_adicionar(rows) -> Tuple[int, int, int, int]:
        """Filtra linhas e atualiza contadores. Retorna deltas (add, rej_tipo, rej_data, dup)."""
        add = rej_tipo = rej_data = dup = 0
        for (rid, nome_doc, tipo_txt, arquivo, data_raw) in rows:
            stats['rows_total'] += 1
            if not rid:
                continue
            if rid in seen_ids:
                stats['duplicates'] += 1
                dup += 1
                continue
            if not ok_tipo(tipo_txt, arquivo):
                stats['rejected_type'] += 1
                rej_tipo += 1
                continue
            if not ok_data(data_raw):
                stats['rejected_date'] += 1
                rej_data += 1
                continue
            registros.append(AnexoItem(rid, nome_doc, tipo_txt, arquivo, data_raw or ''))
            seen_ids.add(rid)
            stats['added_total'] += 1
            add += 1
        return add, rej_tipo, rej_data, dup

    # Processa página inicial
    add0, rjt0, rjd0, dup0 = filtrar_adicionar(reg_rows)
    paginas = 1

    if logger_cb:
        tipos_txt = ','.join([str(t) for t in (tipos_list or [])]) if tipos_list else ''
        logger_cb(f"Filtro: tipos=[{tipos_txt or '*'}] modo={modo_busca} datas={data_inicial or '-'}..{data_final or '-'}")
        logger_cb(
            f"Passo {paginas} (GET) — itens_tabela={initial_table_items} aprovados={add0} "
            f"rejeitados_tipo={rjt0} rejeitados_data={rjd0} dup={dup0} sig={sig_prev[:8]}"
        )

    

    # Se não há indício de pager e a página inicial parece ser a única, evita roundtrips desnecessários.
    if likely_single_page:
        telem = {
            "stop_reason": "no_pager_single_page",
            "pages": 1,
            "total_ids": len(seen_ids),
            "table_items_initial": int(initial_table_items),
            "sig_initial": sig_initial,
            "rows_total": stats.get('rows_total', 0),
            "matched_total": stats.get('added_total', 0),
            "rejected_type": stats.get('rejected_type', 0),
            "rejected_date": stats.get('rejected_date', 0),
            "duplicates": stats.get('duplicates', 0),
            "filter": {
                "tipos": tipos_list,
                "modo": modo_busca,
                "data_inicial": data_inicial,
                "data_final": data_final,
            },
        }
        return registros, 1, telem# ---- Loop de paginação (NEXT=7, LAST=8) ----
    stop_reason = ''
    used_last = False
    repeat_count = 0
    empty_pages_consecutive = 0
    EMPTY_PAGES_LIMIT = 3

    
    # Prepara dict reutilizável para POSTs (reduz alocações no hot-loop)
    post_data = dict(payload_base or {})
    post_data['acao'] = 'paginacaoANEXOS'

    def _refresh_post_data(new_payload: Dict[str, str]):
        nonlocal payload_base, post_data
        payload_base = new_payload
        post_data = dict(payload_base or {})
        post_data['acao'] = 'paginacaoANEXOS'

    def _post_paginacao(cmd: str) -> str:
        # cmd: '7' (NEXT) ou '8' (LAST)
        post_data['pagina'] = str(cmd)
        return client.post_text(url_post, post_data)

    while paginas < max_paginas:
        if cancel_cb and cancel_cb():
            stop_reason = 'cancelled'
            break

        html_next = _post_paginacao('7')  # NEXT
        if not html_next:
            empty_pages_consecutive += 1
            if empty_pages_consecutive >= EMPTY_PAGES_LIMIT:
                stop_reason = 'empty_pages_threshold'
                if logger_cb:
                    logger_cb(f"Parando: {EMPTY_PAGES_LIMIT} respostas vazias consecutivas (passo_atual={paginas})")
                break
            continue

        # Atualiza estado do form (tokens/contexto) + extrai tabela (1 parse)
        payload_n, rows_next, sig_next = _parse_page(html_next)
        if payload_n: _refresh_post_data(payload_n)

        # Fallback defensivo: páginas sem tabela/sem linhas (ex.: HTML incompleto)
        if len(rows_next) == 0:
            empty_pages_consecutive += 1
            if empty_pages_consecutive >= EMPTY_PAGES_LIMIT:
                stop_reason = 'empty_pages_threshold'
                if logger_cb:
                    logger_cb(f"Parando: {EMPTY_PAGES_LIMIT} páginas sem linhas consecutivas (passo_atual={paginas})")
                break
        else:
            empty_pages_consecutive = 0

        # Detecta estagnação por assinatura
        if sig_next == sig_prev:
            repeat_count += 1
        else:
            repeat_count = 0

        add, rjt, rjd, dup = filtrar_adicionar(rows_next)
        paginas += 1

        if logger_cb:
            logger_cb(
                f"Passo {paginas} (NEXT=7) — itens_tabela={len({r[0] for r in rows_next if r[0]})} novos={add} "
                f"rejeitados_tipo={rjt} rejeitados_data={rjd} dup={dup} rep={repeat_count} sig={sig_next[:8]}"
            )
            if add == 0 and rows_next:
                try:
                    amostra = []
                    for (rid, _nome_doc, tipo_txt, arquivo, data_raw) in rows_next[:3]:
                        t = (tipo_txt or '').strip()
                        a = (arquivo or '').strip()
                        dtr = (data_raw or '').strip()
                        if len(t) > 60:
                            t = t[:57] + '…'
                        if len(a) > 60:
                            a = a[:57] + '…'
                        amostra.append(f"tipo='{t}' arquivo='{a}' data='{dtr}'")
                    if amostra:
                        logger_cb("Amostra (até 3 linhas): " + " | ".join(amostra))
                except Exception:
                    pass

        # Se estagnou, usa LAST uma única vez como checkpoint terminal
        if repeat_count >= 1 and not used_last:
            if cancel_cb and cancel_cb():
                stop_reason = 'cancelled'
                break
            if logger_cb:
                logger_cb("Estagnação detectada (sig repetida). Aplicando LAST=8 para ir ao fim e confirmar EOF…")

            html_last = _post_paginacao('8')  # LAST
            if html_last:
                payload_l, rows_last, sig_last = _parse_page(html_last)
                if payload_l: _refresh_post_data(payload_l)
                addL, rjtL, rjdL, dupL = filtrar_adicionar(rows_last)
                paginas += 1
                if logger_cb:
                    logger_cb(
                        f"Passo {paginas} (LAST=8) — itens_tabela={len({r[0] for r in rows_last if r[0]})} novos={addL} "
                        f"rejeitados_tipo={rjtL} rejeitados_data={rjdL} dup={dupL} sig={sig_last[:8]}"
                    )

                # NEXT após LAST: se não muda, estamos no fim
                html_after = _post_paginacao('7')
                if html_after:
                    payload_a, rows_after, sig_after = _parse_page(html_after)
                    if payload_a: _refresh_post_data(payload_a)
                    if sig_after == sig_last:
                        stop_reason = 'eof_confirmed_after_last'
                        break
                    # Caso raro: LAST não fixou no fim ou a UI reordenou; continua loop com nova referência
                    sig_prev = sig_after
                    used_last = True
                    repeat_count = 0
                    continue
                else:
                    stop_reason = 'eof_assumed_after_last'
                    break
            else:
                # LAST falhou -> mantém stop por repetição
                stop_reason = 'no_change_last_failed'
                break

        # Estagnação prolongada sem necessidade de LAST (já usado) -> parar
        if repeat_count >= 2 and used_last:
            stop_reason = 'no_change_repeated'
            break

        sig_prev = sig_next

    if paginas >= max_paginas and not stop_reason:
        stop_reason = 'max_pages_reached'

    telem = {
        "stop_reason": stop_reason or 'completed',
        "pages": paginas,
        "total_ids": len(seen_ids),
        "table_items_initial": int(initial_table_items),
        "sig_initial": sig_initial,
        "rows_total": stats.get('rows_total', 0),
        "matched_total": stats.get('added_total', 0),
        "rejected_type": stats.get('rejected_type', 0),
        "rejected_date": stats.get('rejected_date', 0),
        "duplicates": stats.get('duplicates', 0),
        "filter": {
            "tipos": tipos_list,
            "modo": modo_busca,
            "data_inicial": data_inicial,
            "data_final": data_final,
        },
    }
    return registros, paginas, telem


# Relatórios (ReportPort)
@dataclass
class ProcessoAnexo:
    numero_processo:str; nome_arquivo:str; tipo_anexo:str; arquivo:str; data_inclusao:str; link_pesquisa:str; link_anexo:str; caminho_local:Optional[str]=None


class CsvXlsxReport(ReportPort):
    def generate(self, dados: List[ProcessoAnexo], base_dir:str)->Tuple[str,str]:
        csv_path=os.path.join(base_dir, "relatorio_processos.csv"); xlsx_path=os.path.join(base_dir, "relatorio_processos.xlsx")
        cols=["Numero do processo","Tipo do anexo","Nome do arquivo","Arquivo","Caminho Local","Data de inclusão","Link Pesquisa","Link Anexo"]
        try:
            with open(csv_path,'w',newline='',encoding='utf-8-sig') as f:
                w=csv.writer(f); w.writerow(cols)
                for d in dados:
                    w.writerow([
                        d.numero_processo,
                        d.tipo_anexo,
                        _sanitize_filename(d.nome_arquivo),
                        _sanitize_filename(d.arquivo),
                        d.caminho_local or "",
                        d.data_inclusao,
                        d.link_pesquisa,
                        d.link_anexo
                    ])
        except Exception as e:
            logger.error("Erro ao salvar CSV: %s", e)

        try:
            wb = xlsxwriter.Workbook(xlsx_path)
            ws = wb.add_worksheet("Anexos")
            for j, h in enumerate(cols): ws.write(0, j, h)
            for i, d in enumerate(dados, start=1):
                ws.write_row(i, 0, [
                    d.numero_processo,
                    d.tipo_anexo,
                    _sanitize_filename(d.nome_arquivo),
                    _sanitize_filename(d.arquivo),
                    d.caminho_local or "",
                    d.data_inclusao,
                    d.link_pesquisa,
                    d.link_anexo
                ])
            wb.close()
        except Exception as e:
            logger.error("Erro ao salvar XLSX: %s", e)
        return csv_path, xlsx_path


# Orquestração de um processo e do job completo
class JobOrchestrator:
    def __init__(self, http: HttpxClient, file_writer: FileWriterPort, naming: NamingStrategy, layout: LayoutStrategy, reporter: ReportPort,
                 logger_port: LoggerPort, progress_port: ProgressPort, on_file_done: Optional[Callable[['ProcessoAnexo'], None]] = None,
                 on_aux_update: Optional[Callable[[str], None]] = None):
        self.http=http; self.file_writer=file_writer; self.naming=naming; self.layout=layout; self.reporter=reporter
        self.log=logger_port; self.progress=progress_port
        self.run_id = datetime.now().strftime('%Y-%m-%dT%H-%M-%S')
        self.on_file_done = on_file_done
        self.on_aux_update = on_aux_update
        # Cancelamento soft (parar novo agendamento e concluir in-flight)
        self._cancel = threading.Event()

    def cancel(self) -> None:
        """Sinaliza cancelamento soft do job."""
        self._cancel.set()

    def is_cancelled(self) -> bool:
        return self._cancel.is_set()

    def _build_plan(self, base_dir:str, numero:str, anexos:List[AnexoItem]) -> Tuple[List[DownloadPlanItem], List[ProcessoAnexo], List[str]]:
        entries: List[DownloadPlanItem]=[]
        registros: List[ProcessoAnexo]=[]
        dest_dirs: set = set()
        for (idx,an) in enumerate(anexos):
            link_anexo=f"{BASE_GCPJ}cadMantemCadProcAnexosAction?acao=visualizarArquivo&selecionados={an.radio_id}"
            cd_seq = _dc_seq_from_radio_id_plus_one(an.radio_id)
            # Nome do arquivo: preservar o nome original do portal (sem prefixos/sufixos automáticos)
            arquivo_sanit = _sanitize_filename(an.arquivo or '')
            nome_portal = _sanitize_filename(an.arquivo or an.nome_doc or 'arquivo')
            pasta_proc, destino = self.layout.resolve_destination(base_dir, numero, cd_seq, nome_portal)
            # Ajuste de comprimento do caminho (Windows-safe)
            safe2 = _truncate_for_path(pasta_proc, os.path.basename(destino), max_path=248)
            destino = os.path.join(pasta_proc, safe2)
            dest_dirs.add(pasta_proc)
            reg=ProcessoAnexo(numero, an.nome_doc, an.tipo_txt, arquivo_sanit, an.data_raw or "",
                              f"{BASE_GCPJ}cadMantemCadProcConsultaTodosAction?acao=obterAnexo&cdNumeroProcessoBradesco={numero}",
                              link_anexo, destino)
            registros.append(reg)
            entries.append(DownloadPlanItem(url=link_anexo, destino=destino, meta={"idx":idx, "numero":numero}))
        return entries, registros, sorted(dest_dirs)

    def processar_processo(self, inp: ProcessoInput, base_dir: str, workers_dl: int, chunk: int) -> Tuple[List[ProcessoAnexo], ProcessoResult]:
        t0 = time.perf_counter()
        # (UX) Não sobrescrever o status global (ex.: 1/N). Detalhe vai para log.
        self.log.log('INFO', 'Coletando anexos…', proc=inp.numero, run_id=self.run_id)
        self.log.log('INFO', 'Coleta iniciada.', proc=inp.numero, run_id=self.run_id)
        self.log.log('INFO', f"Mapeamento numero: exib='{inp.numero}' -> consulta='{_only_digits(inp.numero)}'", proc=inp.numero, run_id=self.run_id)

        if self.is_cancelled():
            return [], ProcessoResult(numero=inp.numero, found=0, ok=0, skip=0, fail=0, bytes=0,
                                      elapsed_s=time.perf_counter()-t0, pages=0, stop_reason='cancelled',
                                      dest_dirs=[], errors=[])

        max_retries = int(DEFAULT_COLETA_RETRIES)
        last_regs: List[AnexoItem] = []
        last_paginas: int = 0
        last_telem: Dict[str, Any] = {"stop_reason": "", "pages": 0, "total_ids": 0}
        last_err: Optional[Exception] = None
        client_ok: Optional[HttpxClient] = None

        for attempt in range(max_retries + 1):
            if self.is_cancelled():
                break
            client = _new_isolated_client_from(self.http, max_pool=max(DEFAULT_POOL_MAX, workers_dl))
            try:
                regs, paginas, telem = coletar_anexos(
                    client,
                    _only_digits(inp.numero),
                    inp.tipos,
                    inp.data_inicial,
                    inp.data_final,
                    inp.modo_busca,
                    logger_cb=lambda msg: self.log.log('INFO', msg, proc=inp.numero, run_id=self.run_id),
                    cancel_cb=self.is_cancelled,
                )
                last_regs, last_paginas, last_telem = regs, paginas, (telem or {})
                sr = (last_telem.get('stop_reason') or '').lower()

                if regs:
                    client_ok = client
                    client = None
                    break

                retryable = sr in ('mismatch_server_number', 'empty_pages_threshold')
                if retryable and attempt < max_retries:
                    self.log.log('WARN', f"Coleta instavel/vazia (stop_reason={sr}) — retry {attempt+1}/{max_retries}.", proc=inp.numero, run_id=self.run_id)
                    time.sleep(1.5 * (attempt + 1))
                    continue
                break
            except Exception as ex:
                last_err = ex
                self.log.log('WARN', f"Falha na coleta (tentativa {attempt+1}/{max_retries+1}): {ex}", proc=inp.numero, run_id=self.run_id)
                if attempt < max_retries:
                    time.sleep(1.5 * (attempt + 1))
                    continue
                last_telem = {"stop_reason": "exception", "pages": last_paginas, "total_ids": 0}
                break
            finally:
                if client is not None:
                    try:
                        client.close()
                    except Exception:
                        pass

        regs, paginas, telem = last_regs, last_paginas, last_telem
        stop_reason = (telem.get('stop_reason') or '') if isinstance(telem, dict) else ''

        if not regs:
            # Diferenciar: vazio por filtro vs vazio real no portal
            table_items = 0
            matched_total = 0
            rej_tipo = rej_data = dups = 0
            try:
                if isinstance(telem, dict):
                    table_items = int(telem.get('table_items_initial', 0) or 0)
                    matched_total = int(telem.get('matched_total', 0) or 0)
                    rej_tipo = int(telem.get('rejected_type', 0) or 0)
                    rej_data = int(telem.get('rejected_date', 0) or 0)
                    dups = int(telem.get('duplicates', 0) or 0)
            except Exception:
                pass

            empty_kind = 'EMPTY_BY_FILTER' if (table_items > 0 and matched_total == 0 and (rej_tipo > 0 or rej_data > 0)) else 'EMPTY_BY_PORTAL'

            if empty_kind == 'EMPTY_BY_FILTER':
                self.log.log(
                    'WARN',
                    f"Nenhum anexo passou no filtro (itens_tabela={table_items}, rejeitados_tipo={rej_tipo}, "
                    f"rejeitados_data={rej_data}, dup={dups}, stop_reason={stop_reason}).",
                    proc=inp.numero,
                    run_id=self.run_id
                )
            else:
                self.log.log('WARN', f"Nenhum anexo encontrado no portal (itens_tabela={table_items}, stop_reason={stop_reason}).", proc=inp.numero, run_id=self.run_id)

            errs = []
            # Stop reasons (COLETA_*) viram alerta, não erro fatal
            if stop_reason:
                errs.append({'kind': 'COLETA_' + str(stop_reason).upper(), 'code': None, 'msg': f'Parada de coleta. stop_reason={stop_reason}'})
            # Categoria de vazio
            errs.append({'kind': empty_kind, 'code': None, 'msg': f'Coleta vazia ({empty_kind}).'})
            if last_err:
                errs.append(_classify_exception(last_err))

            return [], ProcessoResult(
                numero=inp.numero, found=0, ok=0, skip=0, fail=0, bytes=0,
                elapsed_s=time.perf_counter()-t0, pages=paginas, stop_reason=stop_reason,
                dest_dirs=[], errors=errs
            )

        entries, registros, dest_dirs = self._build_plan(base_dir, inp.numero, regs)
        dl_entries = [DownloadEntry(idx=plan.meta["idx"], url=plan.url, destino=plan.destino, registro=registros[i])
                      for i, plan in enumerate(entries)]

        if hasattr(self.file_writer, 'set_cancel_event'):
            try:
                self.file_writer.set_cancel_event(self._cancel)
            except Exception:
                pass

        dl_client = client_ok or _new_isolated_client_from(self.http, max_pool=max(DEFAULT_POOL_MAX, workers_dl))
        try:
            lote = self.file_writer.baixar_lote(
                dl_client,
                dl_entries,
                max_workers=max(1, workers_dl),
                window_factor=DEFAULT_WINDOW_FACTOR,
                chunk=max(64*1024, chunk),
            )
        finally:
            try:
                dl_client.close()
            except Exception:
                pass

        ok, skip, fail, total_bytes = lote['ok'], lote['skip'], lote['fail'], lote['bytes']

        registros_ok: List[ProcessoAnexo] = []
        for (e, status, meta) in lote['results']:
            if status in ('ok', 'skip'):
                caminho_final = meta.get('path', e.destino)
                e.registro.caminho_local = caminho_final
                registros_ok.append(e.registro)
                if self.on_file_done:
                    try:
                        self.on_file_done(e.registro)
                    except Exception:
                        pass

        mbps = (total_bytes/(1024*1024))/max(1e-6, time.perf_counter()-t0)
        self.log.log('INFO', f"Download: {len(entries)} arq (OK={ok}, SKIP={skip}, FAIL={fail}) — {mbps:.1f} MB/s.", proc=inp.numero, run_id=self.run_id)

        return registros_ok, ProcessoResult(
            numero=inp.numero, found=len(regs), ok=ok, skip=skip, fail=fail, bytes=total_bytes,
            elapsed_s=time.perf_counter()-t0, pages=paginas, stop_reason=stop_reason,
            dest_dirs=dest_dirs, errors=lote.get('errors', [])
        )


    def run(self, processos:List[ProcessoInput], base_dir:str, workers_col:int, workers_dl:int, chunk_kb:int) -> JobSummary:
        # [S5] Limitador de operações (garantia no núcleo): mesmo que o run seja chamado por outro
        # ponto do código, nunca envia mais do que LIMITE_OPERACOES_S5 processos para o GCPJ.
        processos, excedentes_s5 = aplicar_limite_s5(processos)
        if excedentes_s5:
            self.log.log('WARN', mensagem_log_s5(len(excedentes_s5)), run_id=self.run_id)
        total=len(processos)
        self.progress.set_status(f"Coletando anexos de {total} processo(s)…")
        self.progress.set_fraction(0.02)

        job_t0=time.perf_counter(); job_bytes=0; job_ok=job_skip=job_fail=job_found=0
        error_causes=Counter(); warning_causes=Counter(); dados:List[ProcessoAnexo]=[]

        import concurrent.futures as cf
        concl=0; files_done_total=0; ewma_spf=None; alpha=0.3

        with cf.ThreadPoolExecutor(max_workers=workers_col) as pool:
            futs=[pool.submit(self.processar_processo, pi, base_dir, workers_dl, chunk_kb*1024) for pi in processos]
            for f in cf.as_completed(futs):
                if self.is_cancelled():
                    # Drenar apenas os já submetidos; não há novo submit aqui.
                    pass
                registros_ok, pstats=f.result(); dados.extend(registros_ok); concl+=1
                ok_s=pstats.ok; skip_s=pstats.skip; fail_s=pstats.fail
                job_ok+=ok_s; job_skip+=skip_s; job_fail+=fail_s; job_found+=pstats.found; job_bytes+=pstats.bytes
                for err in pstats.errors:
                    if not (err and isinstance(err, dict)):
                        continue
                    kind = err.get('kind', 'UNKNOWN')
                    # COLETA_* e EMPTY_* são alertas operacionais (não erros)
                    if str(kind).startswith('COLETA_') or str(kind).startswith('EMPTY_'):
                        warning_causes[kind] += 1
                    else:
                        error_causes[kind] += 1
                files_this = max(1, ok_s + skip_s)
                spf_this = (pstats.elapsed_s/files_this) if files_this>0 else 0.0
                ewma_spf = spf_this if ewma_spf is None else (alpha*spf_this + (1-alpha)*ewma_spf)
                files_done_total += files_this
                avg_files_per_proc = max(1e-6, files_done_total/concl)
                remaining_procs = max(0, total-concl)
                est_remaining_files = avg_files_per_proc * remaining_procs
                eta = (ewma_spf or 0.0) * est_remaining_files

                frac=0.1+0.8*(concl/total)
                self.progress.set_fraction(min(frac,0.95))

                # Atualização separada: status humano curto + micro label com ETA/MBps
                s = Telemetry.snapshot()
                aux_txt = f"ETA ~ {self._fmt_secs(eta)} • {s['mbps']:.1f} MB/s"
                if self.on_aux_update:
                    try: self.on_aux_update(aux_txt)
                    except Exception: pass

                if self.is_cancelled():
                    self.progress.set_status(f"{concl}/{total} proc. — Cancelando…")
                else:
                    self.progress.set_status(f"{concl}/{total} proc.")

        self.progress.set_status("Concluído" + (" (cancelado)" if self.is_cancelled() else "")); self.progress.set_fraction(1.0)

        csv_path, xlsx_path = self.reporter.generate(dados, base_dir)

        job_elapsed=time.perf_counter()-job_t0
        mbps=(job_bytes/(1024*1024))/max(1e-6, job_elapsed)
        top3=error_causes.most_common(3)
        top3_warn=warning_causes.most_common(3)
        self.log.log('INFO', 'RESUMO GERAL', run_id=self.run_id)
        self.log.log('INFO', f" - Processos: {total} | Anexos: {job_found} (OK={job_ok}, SKIP={job_skip}, FAIL={job_fail})", run_id=self.run_id)
        self.log.log('INFO', f" - Tempo total: {self._fmt_secs(job_elapsed)} | Vazão média: {mbps:.1f} MB/s", run_id=self.run_id)
        self.log.log('INFO', f" - Top 3 erros: {', '.join([f'{k} ({v})' for k,v in top3]) if top3 else '—'}", run_id=self.run_id)
        self.log.log('INFO', f" - Top 3 alertas: {', '.join([f'{k} ({v})' for k,v in top3_warn]) if top3_warn else '—'}", run_id=self.run_id)
        self.log.log('INFO', f" - Relatórios: CSV={csv_path} | XLSX={xlsx_path}", run_id=self.run_id)

        # Persistir telemetria (opcional implementado)
        telem_path = os.path.join(base_dir, "telemetry.json")
        try:
            with open(telem_path, "w", encoding="utf-8") as f:
                json.dump({
                    "run_id": self.run_id,
                    "snapshot": Telemetry.snapshot(),
                    "summary": {
                        "processos": total,
                        "anexos": job_found,
                        "ok": job_ok,
                        "skip": job_skip,
                        "fail": job_fail,
                        "bytes": job_bytes,
                        "elapsed_s": job_elapsed,
                        "vazao_mbps": mbps,
                        "top_erros": top3,
                "top_alertas": top3_warn
                    }
                }, f, ensure_ascii=False, indent=2)
            self.log.log('INFO', f" - Telemetria: {telem_path}", run_id=self.run_id)
        except Exception as e:
            logger.debug("Falha ao salvar telemetry.json: %s", e)
            telem_path = None

        return JobSummary(
            total_processos=total, total_anexos=job_found, ok=job_ok, skip=job_skip, fail=job_fail,
            bytes_total=job_bytes, tempo_total_s=job_elapsed, vazao_mbps=mbps,
            top_erros=top3, relatorio_csv=csv_path, relatorio_xlsx=xlsx_path, telemetria_json=telem_path
        )

    @staticmethod
    def _fmt_secs(s:float)->str:
        s=int(max(0,s)); h,rem=divmod(s,3600); m,s=divmod(rem,60); return f"{h:02d}:{m:02d}:{s:02d}"


# ============================================
# UI: Config/State, Views, Controllers, Adapters

# --- UI tokens (cores e fontes leves) ---
UI_TOKENS = {
    "font_title": ("Segoe UI", 14, "bold"),
    "font_sub": ("Segoe UI", 10),
    "font_label": ("Segoe UI", 14, "bold"),
    "font_hint": ("Segoe UI", 10),
    "fg_muted": "#7d7d7d",
    "panel_bg": "#14141a",
    "panel_border": "#2a2f38",
}

# ============================================

# Adapters UI → Core
class LoggerAdapter(LoggerPort):
    def __init__(self, enqueue_log:Callable[[str],None]): self.enqueue_log = enqueue_log
    @staticmethod
    def _now() -> str: return time.strftime('%H:%M:%S')
    def log(self, level:str, msg:str, proc:Optional[str]=None, run_id:Optional[str]=None) -> None:
        prefix=f"[{LoggerAdapter._now()}] {level.upper():<5}"
        if proc: prefix+=f" [P:{proc}]"
        if run_id: prefix+=f" [RUN:{run_id}]"
        self.enqueue_log(f"{prefix} {msg}")


class ProgressAdapter(ProgressPort):
    def __init__(self, set_status_cb:Callable[[str],None], set_frac_cb:Callable[[float],None]):
        self._set_status = set_status_cb; self._set_frac = set_frac_cb
    def set_status(self, text:str)->None: self._set_status(text)
    def set_fraction(self, frac:float)->None: self._set_frac(frac)


# Pretty Tree + UIUpdater
class PrettyTreeview:
    def __init__(self, parent, columns, headings, widths, stretch_last=True):
        self.parent=parent; self.columns=list(columns)
        self._bg="#0f0f12"; self._fg="#e6e6e6"; self._hdr_bg="#14141a"; self._hdr_fg="#a9b1bd"
        self._row_alt="#111318"; self._hover_bg="#162235"; self._sel_bg="#1f3b5b"; self._sel_fg="#ffffff"
        self.frame=ctk.CTkFrame(parent, fg_color="transparent")
        self._build_style()
        self.tree=ttk.Treeview(self.frame, columns=self.columns, show="headings", style="Pro.Treeview")
        self.tree.pack(side="left", fill="both", expand=True)
        self.vsb=ctk.CTkScrollbar(self.frame, command=self.tree.yview); self.vsb.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=self.vsb.set)
        for c,h,w in zip(self.columns, headings, widths):
            self.tree.heading(c, text=h, command=lambda col=c: self._sort_by_column(col))
            self.tree.column(c, width=w, anchor="w", stretch=(c==self.columns[-1] and stretch_last))
        self.tree.tag_configure("odd", background=self._row_alt); self.tree.tag_configure("hover", background=self._hover_bg)
        self._last_hover_iid=None; self.tree.bind("<Motion>", self._on_mouse_move); self.tree.bind("<Leave>", self._on_mouse_leave)
        self._setup_context_menu(); self.tree.bind("<Double-1>", self._on_double_click)
    def _build_style(self):
        st=ttk.Style(self.parent)
        try: st.theme_use("default")
        except: pass
        st.configure("Pro.Treeview", background=self._bg, foreground=self._fg, fieldbackground=self._bg,
                     rowheight=24, borderwidth=0, relief="flat", font=("Segoe UI",11))
        st.configure("Pro.Treeview.Heading", background=self._hdr_bg, foreground=self._hdr_fg,
                     font=("Segoe UI Semibold",11), relief="flat")
        st.map("Pro.Treeview", background=[("selected", self._sel_bg)], foreground=[("selected", self._sel_fg)])
        st.layout("Pro.Treeview.Heading", [("Treeheading.cell", {"sticky":"nswe"}),
                                           ("Treeheading.padding", {"sticky":"nswe", "children":[("Treeheading.image", {"side":"right","sticky":""}),
                                                                                                   ("Treeheading.text", {"sticky":"we"})]})])
    def clear(self): self.tree.delete(*self.tree.get_children())
    def insert_rows(self, rows):
        start=len(self.tree.get_children())
        for i,vals in enumerate(rows, start=1):
            tag="odd" if (start+i)%2 else ""; self.tree.insert("","end", values=vals, tags=(tag,))
    def insert_row(self, values):
        idx=len(self.tree.get_children())+1; tag="odd" if (idx%2) else ""; self.tree.insert("","end", values=values, tags=(tag,))
    def _on_mouse_move(self, e):
        row_id=self.tree.identify_row(e.y)
        if row_id!=self._last_hover_iid:
            if self._last_hover_iid and self.tree.exists(self._last_hover_iid): self._remove_hover(self._last_hover_iid)
            if row_id: self._apply_hover(row_id)
            self._last_hover_iid=row_id
    def _on_mouse_leave(self,_):
        if self._last_hover_iid and self.tree.exists(self._last_hover_iid): self._remove_hover(self._last_hover_iid)
        self._last_hover_iid=None
    def _apply_hover(self,iid):
        tags=set(self.tree.item(iid,"tags")); tags.add("hover"); self.tree.item(iid, tags=tuple(tags))
    def _remove_hover(self,iid):
        tags=set(self.tree.item(iid,"tags"))
        if "hover" in tags: tags.remove("hover"); self.tree.item(iid, tags=tuple(tags))
    def _setup_context_menu(self):
        self.menu=tk.Menu(self.tree, tearoff=False)
        self.menu.add_command(label="Copiar linha", command=self._copy_selected)
        self.menu.add_command(label="Copiar célula", command=self._copy_cell)
        self.tree.bind("<Button-3>", self._show_menu)
    def _show_menu(self,e):
        try: self.menu.tk_popup(e.x_root,e.y_root)
        finally: self.menu.grab_release()
    def _copy_selected(self):
        sel=self.tree.selection()
        if not sel: return
        lines=["\t".join(map(str,self.tree.item(i,"values"))) for i in sel]
        self.frame.clipboard_clear(); self.frame.clipboard_append("\n".join(lines))
    def _copy_cell(self):
        x=self.tree.winfo_pointerx()-self.tree.winfo_rootx(); y=self.tree.winfo_pointery()-self.tree.winfo_rooty()
        iid=self.tree.identify_row(y); col=self.tree.identify_column(x)
        if not iid or not col: return
        ci=int(col.replace("#",""))-1; vals=self.tree.item(iid,"values")
        if 0<=ci<len(vals): self.frame.clipboard_clear(); self.frame.clipboard_append(str(vals[ci]))
    def _sort_by_column(self,col_key):
        items=list(self.tree.get_children(""))
        if not items: return
        ci=self.columns.index(col_key)
        reverse=False
        if len(items)>=2:
            a=str(self.tree.item(items[0],"values")[ci]).lower(); b=str(self.tree.item(items[1],"values")[ci]).lower(); reverse=a<=b
        items.sort(key=lambda iid: str(self.tree.item(iid,"values")[ci]).lower(), reverse=reverse)
        for i,iid in enumerate(items): self.tree.move(iid, "", i)
        for i,iid in enumerate(self.tree.get_children(""), start=1):
            tags=set(self.tree.item(iid,"tags")); tags.discard("odd")
            if i%2: tags.add("odd"); self.tree.item(iid, tags=tuple(tags))
    def _open_path(self, path:str):
        try:
            if not path or not os.path.exists(path): return
            if sys.platform.startswith('win'): os.startfile(path)
            elif sys.platform=='darwin': subprocess.Popen(['open', path])
            else: subprocess.Popen(['xdg-open', path])
        except Exception as e:
            logger.debug("Falha ao abrir caminho: %s", e)
    def _on_double_click(self,_):
        iid=self.tree.focus()
        if not iid: return
        vals=self.tree.item(iid,"values"); caminho=vals[3] if len(vals)>3 else ""
        self._open_path(caminho)


class UIUpdater:
    def __init__(self, owner, table_adapter:PrettyTreeview, txt_log:ctk.CTkTextbox):
        self.owner=owner; self.root=owner; self.table=table_adapter; self.txt_log=txt_log
        self._rows=deque(); self._logs=deque(); self._lock=threading.Lock()
        self.flush_interval_busy_ms=33; self.flush_interval_idle_ms=200
        self.time_budget_ms=20; self.max_rows_per_tick=400; self.max_logs_per_tick=600
        self._want_busy_tick=False; self._disposed=False
        try: self.root.after(self.flush_interval_idle_ms, self._flush)
        except tk.TclError: pass
    def dispose(self): self._disposed=True
    def enqueue_row(self,row):
        with self._lock: self._rows.append(row); self._want_busy_tick=True
    def enqueue_rows(self,rows):
        if not rows: return
        with self._lock: self._rows.extend(rows); self._want_busy_tick=True
    def enqueue_log(self,msg):
        if not msg: return
        with self._lock: self._logs.append(msg); self._want_busy_tick=True
    def enqueue_logs(self,msgs):
        if not msgs: return
        with self._lock: self._logs.extend(msgs); self._want_busy_tick=True
    def backlog_sizes(self)->Tuple[int,int]:
        with self._lock: return (len(self._rows), len(self._logs))
    def _flush(self):
        if self._disposed or not self.root.winfo_exists(): return
        t0=time.perf_counter(); rows_done=0; logs_done=0
        while rows_done<self.max_rows_per_tick:
            with self._lock:
                if not self._rows: break
                row=self._rows.popleft()
            try: self.table.insert_row(row)
            except Exception as e: logger.debug("Falha add_row: %s", e)
            rows_done+=1
            if (time.perf_counter()-t0)*1000>self.time_budget_ms: break
        batch=[]
        with self._lock:
            while self._logs and logs_done<self.max_logs_per_tick:
                batch.append(self._logs.popleft()); logs_done+=1
        if batch:
            try:
                if self.txt_log.winfo_exists():
                    self.txt_log.configure(state='normal')
                    for line in batch:
                        # Detecta nível e aplica tag
                        lvl = "INFO"
                        if "] ERROR" in line: lvl = "ERROR"
                        elif "] WARN" in line: lvl = "WARN"
                        self.txt_log.insert('end', line + "\n", lvl)
                    current_lines=int(self.txt_log.index('end-1c').split('.')[0])
                    if current_lines>8000: self.txt_log.delete('1.0', f'{current_lines-8000}.0')
                    self.txt_log.configure(state='disabled'); self.txt_log.see('end')
            except Exception as e:
                logger.debug("Falha log: %s", e)
        try:
            with self._lock:
                has_more=(len(self._rows)+len(self._logs))>0; want_busy=self._want_busy_tick; self._want_busy_tick=False
            if not self._disposed and self.root.winfo_exists():
                self.root.after(self.flush_interval_busy_ms if (has_more or want_busy) else self.flush_interval_idle_ms, self._flush)
        except tk.TclError: pass


# -------------------------------
# StatusBarPro (compacta/minimalista)
# -------------------------------
class StatusBarPro(ctk.CTkFrame):
    """
    Barra inferior compacta e responsiva:
      - Coluna 0: status (ellipsis adaptativo + tooltip)
      - Coluna 1: progresso (determinado/indeterminado) + micro-label (ETA/MB/s) na MESMA linha
      - Coluna 2: ações ícone-only (📂 CSV XLSX ⓘ), com auto-hide por largura

    Estados: idle | running | success | error | cancelled | warning
    """
    TOKENS = {
        "bg":          "#0f0f12",
        "txt":         "#e6e6e6",
        "muted":       "#a9b1bd",
        "success":     "#0aa35c",
        "error":       "#e5484d",
        "busy":        "#3a7ebf",
        "warn":        "#f5a524",
        "callout_txt": "#ffffff",
    }

    def __init__(self, master):
        super().__init__(master, height=28, fg_color=self.TOKENS["bg"])
        self.grid_propagate(False)
        self._state = "idle"
        self._metrics_win: Optional[ctk.CTkToplevel] = None
        self._metrics_text: Optional[ctk.CTkTextbox] = None
        self._callout = None
        self._callout_anim = None
        self._max_status_chars = 80  # recalculado on_resize
        self._last_status_text = "Pronto"

        # ==== Grid principal ====
        # 0 = Status (w=1); 1 = Progresso + micro (w=1); 2 = Ações (w=0)
        for c, w in ((0, 1), (1, 1), (2, 0)):
            self.grid_columnconfigure(c, weight=w)
        self.grid_rowconfigure(0, weight=1)

        # ------- Status (esquerda) -------
        self.lbl_status = ctk.CTkLabel(self, text="Pronto", anchor="w", font=("Segoe UI", 11))
        self.lbl_status.grid(row=0, column=0, sticky="nsew", padx=(8, 6), pady=0)
        self._install_tooltip(self.lbl_status, "Status do sistema")

        # ------- Progresso + micro-label (centro, 1 linha) -------
        prog_wrap = ctk.CTkFrame(self, fg_color="transparent")
        prog_wrap.grid(row=0, column=1, sticky="ew", padx=4, pady=0)
        prog_wrap.grid_columnconfigure(0, weight=1)  # barra
        prog_wrap.grid_columnconfigure(1, weight=0)  # micro-label

        self.pbar = ctk.CTkProgressBar(prog_wrap, height=6)
        self.pbar.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        self.pbar.set(0.0)

        self.lbl_aux = ctk.CTkLabel(
            prog_wrap, text="", text_color=self.TOKENS["muted"], font=("Segoe UI", 10), anchor="e"
        )
        self.lbl_aux.grid(row=0, column=1, sticky="e")

        # ------- Ações (direita, ícone-only) -------
        self.actions = ctk.CTkFrame(self, fg_color="transparent")
        self.actions.grid(row=0, column=2, sticky="e", padx=(4, 6), pady=0)
        # Ícones (ou use textos curtos como fallback: "DIR", "CSV", "XLSX", "i")
        self.btn_open_dir  = ctk.CTkButton(self.actions, text="📂", width=30, command=lambda: None)
        self.btn_open_csv  = ctk.CTkButton(self.actions, text="CSV", width=40, command=lambda: None)
        self.btn_open_xlsx = ctk.CTkButton(self.actions, text="XLSX", width=44, command=lambda: None)
        self.btn_info      = ctk.CTkButton(self.actions, text="ⓘ",  width=30, command=self._toggle_metrics)

        # Aparência mais enxuta
        for b in (self.btn_open_dir, self.btn_open_csv, self.btn_open_xlsx, self.btn_info):
            try:
                b.configure(font=("Segoe UI", 11), height=24)
            except Exception:
                pass

        self.btn_open_dir.grid(row=0, column=0, padx=(0, 4))
        self.btn_open_csv.grid(row=0, column=1, padx=2)
        self.btn_open_xlsx.grid(row=0, column=2, padx=2)
        self.btn_info.grid(row=0, column=3, padx=(4, 0))

        self._install_tooltip(self.btn_open_dir, "Abrir pasta de saída")
        self._install_tooltip(self.btn_open_csv, "Abrir relatório CSV")
        self._install_tooltip(self.btn_open_xlsx, "Abrir relatório XLSX")
        self._install_tooltip(self.btn_info, "Ver métricas (RPS, MB/s, latência)")

        # Callout overlay
        self._callout_visible = False

        # Redimensionamento responsivo
        self.bind("<Configure>", self._on_resize)

        # defaults
        self.set_mode("idle")

    # ---------- API pública ----------
    def set_status(self, text: str):
        self._last_status_text = text or ""
        short = self._ellipsis(self._last_status_text, max_chars=self._max_status_chars)
        try:
            self.lbl_status.configure(text=short)
            self._install_tooltip(self.lbl_status, self._last_status_text)
        except Exception:
            pass

    def set_fraction(self, frac: float):
        try:
            self.pbar.configure(mode="determinate")
            self.pbar.set(max(0.0, min(1.0, frac)))
        except Exception:
            pass

    def set_indeterminate(self, on: bool):
        try:
            if on:
                self.lbl_aux.configure(text="")
                self.pbar.configure(mode="indeterminate")
                self.pbar.start()
            else:
                self.pbar.stop()
                self.pbar.configure(mode="determinate")
        except Exception:
            pass

    def set_mode(self, mode: str):
        self._state = mode
        try:
            if mode == "success":
                self.pbar.configure(progress_color=self.TOKENS["success"])
            elif mode in ("error", "cancelled"):
                self.pbar.configure(progress_color=self.TOKENS["error"])
            elif mode in ("running", "busy"):
                self.pbar.configure(progress_color=self.TOKENS["busy"])
            elif mode == "warning":
                self.pbar.configure(progress_color=self.TOKENS["warn"])
            else:
                self.pbar.configure(progress_color=None)
        except Exception:
            pass

    def show_actions(self, show: bool, on_open_dir=None, on_open_csv=None, on_open_xlsx=None):
        """Mostra/oculta ações e associa callbacks. Em telas estreitas,
        _on_resize decide ocultar CSV/XLSX dinamicamente."""
        try:
            if show:
                # Liga/desliga callbacks e estados
                if on_open_dir:
                    self.btn_open_dir.configure(command=on_open_dir, state="normal")
                else:
                    self.btn_open_dir.configure(state="disabled")
                if on_open_csv:
                    self.btn_open_csv.configure(command=on_open_csv, state="normal")
                else:
                    self.btn_open_csv.configure(state="disabled")
                if on_open_xlsx:
                    self.btn_open_xlsx.configure(command=on_open_xlsx, state="normal")
                else:
                    self.btn_open_xlsx.configure(state="disabled")

                # (re)coloca tudo — _on_resize cuida de esconder conforme largura
                self.btn_open_dir.grid(row=0, column=0, padx=(0, 4))
                self.btn_open_csv.grid(row=0, column=1, padx=2)
                self.btn_open_xlsx.grid(row=0, column=2, padx=2)
                self.btn_info.grid(row=0, column=3, padx=(4, 0))
            else:
                for b in (self.btn_open_dir, self.btn_open_csv, self.btn_open_xlsx):
                    b.grid_remove()
                self.btn_info.grid(row=0, column=0, padx=(0, 0))
        except Exception:
            pass

    def show_callout(self, text: str, success: bool = True, timeout_ms: int = 3500):
        try:
            color = self.TOKENS["success"] if success else self.TOKENS["error"]
            if not self._callout or not self._callout.winfo_exists():
                self._callout = ctk.CTkLabel(self, text="", text_color=self.TOKENS["callout_txt"])
            self._callout.configure(text=f"  {text}  ", fg_color=color)
            # aparece no canto esquerdo, ligeiramente acima, deslizando
            self._callout.place(relx=0.012, rely=0.0, x=0, y=-22)
            self._callout_visible = True

            def slide_down(step=0):
                try:
                    if not self._callout or not self._callout.winfo_exists():
                        return
                    y = -22 + min(22, step)
                    self._callout.place_configure(y=y - 22)
                    if step < 22:
                        self._callout_anim = self.after(12, lambda: slide_down(step + 2))
                except Exception:
                    pass

            slide_down()

            def hide():
                try:
                    if self._callout and self._callout.winfo_exists():
                        self._callout.place_forget()
                except Exception:
                    pass
                self._callout_visible = False

            self.after(timeout_ms, hide)
        except Exception:
            pass

    def set_metrics_text(self, txt: str):
        try:
            if self._metrics_win and self._metrics_win.winfo_exists() and self._metrics_text:
                self._metrics_text.configure(state="normal")
                self._metrics_text.delete("1.0", "end")
                self._metrics_text.insert("end", txt)
                self._metrics_text.configure(state="disabled")
        except Exception:
            pass

    def update_aux_label(self, text: str):
        try:
            self.lbl_aux.configure(text=text or "")
        except Exception:
            pass

    def update_state(self, *, state: Optional[str] = None, progress: Optional[float] = None,
                     status: Optional[str] = None, aux: Optional[str] = None,
                     actions: Optional[Dict[str, Optional[Callable]]] = None,
                     indeterminate: Optional[bool] = None):
        try:
            if state is not None:
                self.set_mode(state)
            if status is not None:
                self.set_status(status)
            if indeterminate is not None:
                self.set_indeterminate(indeterminate)
            if progress is not None:
                self.set_fraction(progress)
            if aux is not None:
                self.update_aux_label(aux)
            if actions is not None:
                self.show_actions(bool(actions), actions.get("dir"), actions.get("csv"), actions.get("xlsx"))
        except Exception:
            pass

    # ---------- Internals ----------
    def _toggle_metrics(self):
        try:
            if self._metrics_win and self._metrics_win.winfo_exists():
                self._metrics_win.destroy()
                self._metrics_win = None
                return
            self._metrics_win = ctk.CTkToplevel(self)
            self._metrics_win.title("Métricas")
            self._metrics_win.resizable(False, False)

            bx = self.btn_info.winfo_rootx()
            by = self.btn_info.winfo_rooty()
            try:
                self._metrics_win.geometry(f"460x240+{bx-420}+{by-240}")
            except Exception:
                pass

            self._metrics_text = ctk.CTkTextbox(self._metrics_win, width=440, height=200)
            self._metrics_text.pack(fill="both", expand=True, padx=8, pady=8)
            self._metrics_text.insert("end", "Carregando métricas...\n")
            self._metrics_text.configure(state="disabled")
        except Exception as e:
            logger.debug("Falha ao abrir popover de métricas: %s", e)

    @staticmethod
    def _ellipsis(text: str, max_chars: int) -> str:
        text = str(text or "")
        if len(text) <= max_chars:
            return text
        return text[:max(0, max_chars - 1)] + "…"

    def _on_resize(self, _e=None):
        """Ajusta ellipsis e oculta/mostra botões conforme a largura disponível."""
        try:
            w = max(0, self.winfo_width())
            # Aproximação: ~7px por char na fonte 11 (ajuste fino)
            self._max_status_chars = max(24, min(140, int((w * 0.38) / 7)))
        except Exception:
            self._max_status_chars = 80

        # Reaplica truncagem com novo limite
        try:
            self.set_status(self._last_status_text)
        except Exception:
            pass

        # Oculta/mostra botões para não quebrar o grid
        try:
            if w < 680:
                # Só pasta + info
                self._grid_show(self.btn_open_dir, col=0)
                self.btn_open_csv.grid_remove()
                self.btn_open_xlsx.grid_remove()
                self._grid_show(self.btn_info, col=1)
            elif w < 820:
                # Pasta + CSV + info
                self._grid_show(self.btn_open_dir, col=0)
                self._grid_show(self.btn_open_csv, col=1)
                self.btn_open_xlsx.grid_remove()
                self._grid_show(self.btn_info, col=2)
            else:
                # Tudo
                self._grid_show(self.btn_open_dir, col=0)
                self._grid_show(self.btn_open_csv, col=1)
                self._grid_show(self.btn_open_xlsx, col=2)
                self._grid_show(self.btn_info, col=3)
        except Exception:
            pass

    def _grid_show(self, widget, col: int):
        try:
            widget.grid(row=0, column=col)
        except Exception:
            pass

    def _install_tooltip(self, widget, text: str):
        try:
            if getattr(widget, "_has_tooltip", False):
                widget._tooltip_text = text
                return
            widget._tooltip_text = text
            widget._has_tooltip = True

            tip = {"win": None}

            def show_tip(_e=None):
                try:
                    if tip["win"] and tip["win"].winfo_exists():
                        tip["win"].destroy()
                    if not widget._tooltip_text:
                        return
                    tip["win"] = tw = ctk.CTkToplevel(widget)
                    tw.overrideredirect(True)
                    try:
                        tw.attributes("-topmost", True)
                    except Exception:
                        pass
                    x = widget.winfo_rootx() + 12
                    y = widget.winfo_rooty() + widget.winfo_height() + 6
                    try:
                        tw.geometry(f"+{x}+{y}")
                    except Exception:
                        pass
                    lbl = ctk.CTkLabel(
                        tw,
                        text=widget._tooltip_text,
                        fg_color="#14141a",
                        text_color="#e6e6e6",
                        corner_radius=6,
                        padx=8,
                        pady=4,
                        font=("Segoe UI", 10),
                    )
                    lbl.pack()
                    try:
                        tip["win"].after(4500, hide_tip)
                    except Exception:
                        pass
                except Exception:
                    pass

            def hide_tip(_e=None):
                try:
                    if tip["win"] and tip["win"].winfo_exists():
                        tip["win"].destroy()
                    tip["win"] = None
                except Exception:
                    pass

            widget.bind("<Enter>", show_tip)
            widget.bind("<Leave>", hide_tip)
        except Exception:
            pass


# Login helpers
LOGIN_DATA_FILE="login_data.json"

def save_login_user(username:str):
    try:
        with open(LOGIN_DATA_FILE,"w",encoding="utf-8") as f: f.write(dumps_fast({"username":username}).decode('utf-8','ignore'))
    except: pass


def load_login_user()->str:
    try:
        with open(LOGIN_DATA_FILE,"r",encoding="utf-8") as f:
            txt=f.read(); return fastjson.loads(txt).get("username","")
    except: return ""
try:
    import win32security, win32con
except Exception:
    win32security=None; win32con=None


def verify_credentials(username:str, password:str)->bool:
    if not username or not password: return False
    try:
        if win32security and win32con:
            token=win32security.LogonUser(username,None,password, win32con.LOGON32_LOGON_NETWORK, win32con.LOGON32_PROVIDER_DEFAULT)
            token.Close(); return True
    except Exception as e:
        logger.warning("Win32 LogonUser falhou: %s", e)
    try:
        client=HttpxClient(max_pool=8)
        ok=autenticar_menu_http(client, username, password)
        client.close(); return ok
    except Exception:
        return False


# Views/Janela
class SplashScreen(ctk.CTkToplevel):
    def __init__(self, master):
        super().__init__(master); self.title("Carregando…"); self.overrideredirect(True); self.geometry("400x260"); self.configure(fg_color="#101010")
        try:
            self.update_idletasks(); w,h=400,260; sw,sh=self.winfo_screenwidth(), self.winfo_screenheight(); x,y=max(0,(sw-w)//2), max(0,(sh-h)//2); self.geometry(f"{w}x{h}+{x}+{y}")
        except: pass
        frame=ctk.CTkFrame(self, fg_color="transparent"); frame.pack(expand=True, fill="both")
        ctk.CTkLabel(frame, text="Sistema de Coleta Judicial de Anexos", font=("Segoe UI",20,"bold")).pack(pady=(30,16))
        self.canvas=ctk.CTkCanvas(frame, width=100, height=100, bg="#101010", highlightthickness=0); self.canvas.pack()
        self.canvas.create_oval(10,10,90,90, outline="#3a7ebf", width=6); self.dot=self.canvas.create_oval(85,45,95,55, fill="#3a7ebf", outline="")
        self._angle=0; self._anim_id=None
        self._anim_id=self.after(16,self._animate)
        self.after(1000,self._abrir_login)
        self.protocol("WM_DELETE_WINDOW", self._abrir_login)
    def _animate(self):
        try:
            self._angle=(self._angle+4)%360; rad=math.radians(self._angle); cx,cy,r=50,50,40
            x=cx+r*math.cos(rad)
            y=cy+r*math.sin(rad)
            self.canvas.coords(self.dot, x-6,y-6,x+6,y+6); self._anim_id=self.after(16,self._animate)
        except tk.TclError:
            return
    def _abrir_login(self):
        try:
            if self._anim_id: self.after_cancel(self._anim_id)
        except: pass
        try: self.destroy()
        except: pass
        try: create_login_frame(self.master)
        except: pass


_login_frame: Optional[ctk.CTkFrame] = None

def create_login_frame(root:ctk.CTk):
    global _login_frame
    if _login_frame and _login_frame.winfo_exists():
        try: _login_frame.destroy()
        except: pass
    root.deiconify()
    root.title("Login"); root.geometry("380x420")
    saved_user=load_login_user(); font_title=("Segoe UI",18,"bold"); font_norm=("Segoe UI",14)
    _login_frame = ctk.CTkFrame(root); _login_frame.pack(expand=True, fill="both")
    ctk.CTkLabel(_login_frame, text="Acesso ao Coletor", font=font_title).pack(pady=(24, 8))
    entry_user=ctk.CTkEntry(_login_frame, placeholder_text="Usuário", width=300, font=font_norm); entry_user.pack(pady=6)
    if saved_user: entry_user.insert(0, saved_user)
    entry_pass=ctk.CTkEntry(_login_frame, placeholder_text="Senha", show="*", width=300, font=font_norm); entry_pass.pack(pady=(6, 8))
    status=ctk.CTkLabel(_login_frame, text="Digite suas credenciais", font=("Segoe UI", 12)); status.pack(pady=(4, 8))

    # Indicador de progresso (indeterminado)
    pbar = ctk.CTkProgressBar(_login_frame, mode="indeterminate")
    pbar.pack(pady=(0, 8))
    pbar.stop(); pbar.pack_forget()  # inicia oculto

    def do_login():
        u=entry_user.get().strip(); p=entry_pass.get().strip()
        if not u or not p:
            status.configure(text="Preencha usuário e senha."); return
        status.configure(text="Validando…")
        # Desabilita botão e mostra progresso
        btn_login.configure(state="disabled")
        pbar.pack(pady=(0,8)); pbar.start()

        def _bg():
            ok = False
            try:
                ok = verify_credentials(u, p)
            except Exception:
                ok = False
            def _ui_done():
                pbar.stop(); pbar.pack_forget()
                btn_login.configure(state="normal")
                if ok:
                    status.configure(text="Ok, carregando…"); save_login_user(u)
                    try: root.withdraw()
                    except: pass
                    JanelaPrincipal(root, u, p)
                else:
                    messagebox.showerror("Erro", "Credenciais inválidas ou rede indisponível.")
                    status.configure(text="Falha na validação.")
            try:
                root.after(0, _ui_done)
            except tk.TclError:
                pass

        threading.Thread(target=_bg, daemon=True).start()

    btn_login = ctk.CTkButton(_login_frame, text="Acessar", command=do_login, font=font_norm)
    btn_login.pack(pady=8)
    root.bind("<Return>", lambda e: do_login())


class JanelaPrincipal(ctk.CTkToplevel):
    def __init__(self, master:ctk.CTk, username:str, password:str):
        super().__init__(master)
        self.title("Coleta de Anexos — GCPJ")
        self.geometry("1100x880")
        self.username=username; self.password=password
        self._app_closing=False

        # UI: Tabs
        self.tab=ctk.CTkTabview(self); # Reserva área inferior para a status bar overlay (altura fixa + 3px de respiro)
        self._bottom_safe_pad = 31  # 28px (status bar) + 3px
        self.tab.pack(fill="both", expand=True, padx=8, pady=(8, 8 + self._bottom_safe_pad))
        self.tab.add("Principal"); self.tab.add("Config"); self.tab.add("Relatório")
        # Principal
        frame_p=self.tab.tab("Principal"); frame_p.grid_columnconfigure(0,weight=1); frame_p.grid_columnconfigure(1,weight=1)

        # Responsividade vertical da Aba Principal:
        # Faz a linha 4 (resultados: tabela/logs) expandir até o fim inferior da aba.
        # Linhas 0..3 ficam com altura natural.
        try:
            frame_p.grid_rowconfigure(0, weight=0)
            frame_p.grid_rowconfigure(1, weight=0)
            frame_p.grid_rowconfigure(2, weight=0)
            frame_p.grid_rowconfigure(3, weight=0)
            frame_p.grid_rowconfigure(4, weight=1)
            frame_p.grid_rowconfigure(4, minsize=260)
        except Exception:
            pass

        # --- Cabeçalho (título + subtítulo) ---
        frame_header = ctk.CTkFrame(frame_p, fg_color="transparent")
        frame_header.grid(row=0, column=0, columnspan=2, sticky='ew', padx=6, pady=(4, 0))
        frame_header.grid_columnconfigure(0, weight=1)
        frame_header.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(frame_header, text="Aba Principal", font=UI_TOKENS["font_title"], anchor='w').grid(row=0, column=0, sticky='w')
        ctk.CTkLabel(frame_header, text="Dejur - Bradesco", font=UI_TOKENS["font_sub"], text_color=UI_TOKENS["fg_muted"], anchor='e', justify='right').grid(row=0, column=1, sticky='e')

        # --- container_elementos (2 colunas) ---
        container_elementos = ctk.CTkFrame(frame_p, fg_color="transparent")
        container_elementos.grid(row=1, column=0, columnspan=2, sticky='nsew', padx=6, pady=6)
        container_elementos.grid_columnconfigure(0, weight=1)
        container_elementos.grid_columnconfigure(1, weight=1)

        # frame_numeros_processos
        frame_numeros_processos = ctk.CTkFrame(container_elementos, corner_radius=10, fg_color=UI_TOKENS["panel_bg"], border_width=1, border_color=UI_TOKENS["panel_border"])
        frame_numeros_processos.grid(row=0, column=0, sticky='nsew', padx=(0, 6), pady=0)
        frame_numeros_processos.grid_columnconfigure(0, weight=1)
        frame_numeros_processos.grid_rowconfigure(1, weight=1)
        ctk.CTkLabel(frame_numeros_processos, text="Números de Processo:", font=UI_TOKENS["font_label"]).grid(row=0, column=0, sticky='w', padx=10, pady=(8, 2))
        self.txt_processos=ctk.CTkTextbox(frame_numeros_processos, height=150); self.txt_processos.grid(row=1, column=0, sticky='nsew', padx=10, pady=(0, 2))
        ctk.CTkLabel(frame_numeros_processos, text="Ex.: 123456, 789012 …", font=UI_TOKENS["font_hint"], text_color=UI_TOKENS["fg_muted"]).grid(row=2, column=0, sticky='w', padx=10, pady=(0, 8))

        # frame_tipos_anexo
        frame_tipos_anexo = ctk.CTkFrame(container_elementos, corner_radius=10, fg_color=UI_TOKENS["panel_bg"], border_width=1, border_color=UI_TOKENS["panel_border"])
        frame_tipos_anexo.grid(row=0, column=1, sticky='nsew', padx=(6, 0), pady=0)
        frame_tipos_anexo.grid_columnconfigure(0, weight=1)
        frame_tipos_anexo.grid_rowconfigure(1, weight=1)
        ctk.CTkLabel(frame_tipos_anexo, text="Tipos de Anexo Desejados:", font=UI_TOKENS["font_label"]).grid(row=0, column=0, sticky='w', padx=10, pady=(8, 2))
        self.txt_tipos=ctk.CTkTextbox(frame_tipos_anexo, height=150); self.txt_tipos.grid(row=1, column=0, sticky='nsew', padx=10, pady=(0, 2))
        ctk.CTkLabel(frame_tipos_anexo, text="Ex.: Inicial, Sentença, Contestação …", font=UI_TOKENS["font_hint"], text_color=UI_TOKENS["fg_muted"]).grid(row=2, column=0, sticky='w', padx=10, pady=(0, 8))

        bloc=ctk.CTkFrame(frame_p); bloc.grid(row=2,column=0,columnspan=2,sticky='ew',padx=6,pady=6)
        for i in range(10): bloc.grid_columnconfigure(i,weight=1)
        ctk.CTkLabel(bloc,text="Data inicial (dd/mm/aaaa)").grid(row=0,column=0,sticky='w',padx=6)
        self.entry_ini=ctk.CTkEntry(bloc, placeholder_text="opcional"); self.entry_ini.grid(row=0,column=1,sticky='ew',padx=6)
        ctk.CTkLabel(bloc,text="Data final (dd/mm/aaaa)").grid(row=0,column=2,sticky='w',padx=6)
        self.entry_fim=ctk.CTkEntry(bloc, placeholder_text="opcional"); self.entry_fim.grid(row=0,column=3,sticky='ew',padx=6)

        # Botões de execução (Iniciar / Cancelar)
        btns = ctk.CTkFrame(frame_p)
        btns.grid(row=3, column=0, columnspan=2, sticky='ew', padx=6, pady=8)
        btns.grid_columnconfigure(0, weight=1)
        btns.grid_columnconfigure(1, weight=1)
        self.btn_start = ctk.CTkButton(btns, text="Iniciar Coleta", command=self._iniciar)
        self.btn_start.grid(row=0, column=0, sticky='ew', padx=(0,4))
        self.btn_cancel = ctk.CTkButton(btns, text="Cancelar", command=self._cancelar, state="disabled", fg_color="#7a1e1e")
        self.btn_cancel.grid(row=0, column=1, sticky='ew', padx=(4,0))

        pane=ctk.CTkFrame(frame_p); pane.grid(row=4,column=0,columnspan=2,sticky='nsew',padx=6,pady=6)
        pane.grid_columnconfigure(0,weight=3); pane.grid_columnconfigure(1,weight=2); pane.grid_rowconfigure(0,weight=1)
        columns=("processo","tipo","arquivo","caminho"); headings=("Processo","Tipo","Arquivo","Caminho Local"); widths=(160,140,360,520)
        self.tree_pro=PrettyTreeview(pane, columns, headings, widths, stretch_last=True)
        self.tree_pro.frame.grid(row=0,column=0,sticky='nsew',padx=(0,6),pady=(0,3))
        self.txt_log=ctk.CTkTextbox(pane, state='disabled'); self.txt_log.grid(row=0,column=1,sticky='nsew',padx=(6,0),pady=(0,3))
        # Tags de cor por nível
        try:
            self.txt_log.tag_config("INFO", foreground="#cfd8dc")
            self.txt_log.tag_config("WARN", foreground="#ffd166")
            self.txt_log.tag_config("ERROR", foreground="#ef476f")
        except Exception:
            pass

        self.ui=UIUpdater(self, self.tree_pro, self.txt_log)

        # Config
        frame_c=self.tab.tab("Config"); frame_c.grid_columnconfigure(0,weight=1); frame_c.grid_columnconfigure(1,weight=1)
        ctk.CTkLabel(frame_c,text="Diretório de Relatórios",font=("Segoe UI",14,"bold")).grid(row=0,column=0,sticky='w',padx=6,pady=(8,2))
        self.entry_dir=ctk.CTkEntry(frame_c); self.entry_dir.grid(row=1,column=0,sticky='ew',padx=6)
        def _pick_dir():
            p=filedialog.askdirectory()
            if p: self.entry_dir.delete(0,'end'); self.entry_dir.insert(0,p)
        ctk.CTkButton(frame_c,text="Selecionar",command=_pick_dir).grid(row=1,column=1,sticky='w',padx=6)

        ctk.CTkLabel(frame_c,text="Workers de DOWNLOAD (baseline 20)",font=("Segoe UI",14,"bold")).grid(row=6,column=0,sticky='w',padx=6,pady=(16,2))
        self.workers_dl_var=tk.IntVar(value=DEFAULT_WORKERS_DOWNLOAD)
        self.slider_dl=ctk.CTkSlider(frame_c,from_=4,to=64,number_of_steps=60,variable=self.workers_dl_var)
        self.slider_dl.grid(row=7,column=0,sticky='ew',padx=6); ctk.CTkLabel(frame_c,textvariable=self.workers_dl_var).grid(row=7,column=1,sticky='w',padx=6)

        ctk.CTkLabel(frame_c,text="Workers de COLETA (baseline 8)",font=("Segoe UI",14,"bold")).grid(row=8,column=0,sticky='w',padx=6,pady=(16,2))
        self.workers_col_var=tk.IntVar(value=DEFAULT_WORKERS_COLETA)
        self.slider_col=ctk.CTkSlider(frame_c,from_=1,to=16,number_of_steps=15,variable=self.workers_col_var)
        self.slider_col.grid(row=9,column=0,sticky='ew',padx=6); ctk.CTkLabel(frame_c,textvariable=self.workers_col_var).grid(row=9,column=1,sticky='w',padx=6)

        ctk.CTkLabel(frame_c,text="Chunk de download (KB) — baseline 1024",font=("Segoe UI",14,"bold")).grid(row=10,column=0,sticky='w',padx=6,pady=(16,2))
        self.chunk_var=tk.IntVar(value=DEFAULT_CHUNK//1024)
        self.slider_chunk=ctk.CTkSlider(frame_c,from_=128,to=2048,number_of_steps=1920,variable=self.chunk_var)
        self.slider_chunk.grid(row=11,column=0,sticky='ew',padx=6); ctk.CTkLabel(frame_c,textvariable=self.chunk_var).grid(row=11,column=1,sticky='w',padx=6)

        try:
            desktop=os.path.join(os.path.expanduser("~"), 'OneDrive - Banco Bradesco S.A', 'Área de Trabalho')
            if not os.path.isdir(desktop):
                desktop=os.path.join(os.path.expanduser("~"),'Desktop')
        except Exception:
            desktop=os.path.expanduser(r"~\Desktop")
        if desktop and not self.entry_dir.get():
            self.entry_dir.insert(0, desktop)

        # Relatório
        frame_r=self.tab.tab("Relatório"); frame_r.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(frame_r, text="Logs de telemetria aparecem no popover (ⓘ) e os eventos na lateral direita da aba Principal.", font=("Segoe UI",13)).pack(fill='x', padx=6, pady=12)

        # Status bar (novo componente compacto)
        self.statusbar = StatusBarPro(self)
        # Status bar com altura fixa em overlay (não empurra o layout).
        # Se a janela ficar pequena, a barra pode sobrepor conteúdo (comportamento desejado).
        self.statusbar.place(relx=0.0, rely=1.0, relwidth=1.0, anchor='sw')
        try: self.statusbar.lift()
        except Exception: pass
        def _lift_statusbar(_e=None):
            try: self.statusbar.lift()
            except Exception: pass
        try: self.bind('<Configure>', _lift_statusbar)
        except Exception: pass
        # Timers
        self._gui_queue:queue.Queue=queue.Queue()
        try: self.after(120,self._process_gui_updates); self.after(1000,self._tick_metrics)
        except tk.TclError: pass
        self.protocol("WM_DELETE_WINDOW", self.on_close)

        # Placeholders
        self._init_placeholders()

        # Atalhos
        self._bind_shortcuts()

    def on_close(self):
        self._app_closing=True
        try:
            if hasattr(self,'ui'): self.ui.dispose()
        except Exception: pass
        try:
            if hasattr(self,'orchestrator') and self.orchestrator and hasattr(self.orchestrator.http,'close'):
                self.orchestrator.http.close()
        except Exception: pass
        try: self.destroy()
        except Exception: pass
        try: self.master.deiconify()
        except Exception: pass

    # ---------- Placeholders (CTkTextbox helpers) ----------
    def _init_placeholders(self):
        self._ph_style = {"fg": "#7d7d7d"}
        self._ph_proc = "Cole números de processo separados por vírgula, espaço ou linha.\nEx.: 123456, 789012"
        self._ph_tipos = "Use * para todos ou liste termos: SENTENCA, ACORDAO\nModo de busca atual: tipo"
        self._apply_placeholder(self.txt_processos, self._ph_proc)
        self._apply_placeholder(self.txt_tipos, self._ph_tipos)
        self.txt_processos.bind("<FocusIn>", lambda e: self._clear_placeholder(self.txt_processos, self._ph_proc))
        self.txt_processos.bind("<FocusOut>", lambda e: self._apply_placeholder(self.txt_processos, self._ph_proc))
        self.txt_tipos.bind("<FocusIn>", lambda e: self._clear_placeholder(self.txt_tipos, self._ph_tipos))
        self.txt_tipos.bind("<FocusOut>", lambda e: self._apply_placeholder(self.txt_tipos, self._ph_tipos))

    def _apply_placeholder(self, tb: ctk.CTkTextbox, text: str):
        try:
            content = tb.get("1.0","end-1c")
            if not content.strip():
                tb.configure(state='normal')
                tb.delete("1.0","end")
                tb.insert("1.0", text)
                tb.tag_add("ph", "1.0", "end")
                tb.tag_config("ph", foreground=self._ph_style["fg"])
        except Exception:
            pass

    def _clear_placeholder(self, tb: ctk.CTkTextbox, text: str):
        try:
            content = tb.get("1.0","end-1c")
            if content.strip() == text:
                tb.configure(state='normal')
                tb.delete("1.0","end")
        except Exception:
            pass

    # Atalhos
    def _bind_shortcuts(self):
        try:
            self.bind_all("<Control-Return>", lambda e: self._iniciar())
            self.bind_all("<Escape>", lambda e: self._cancelar())
            self.bind_all("<F2>", lambda e: self.txt_processos.focus_set())
            self.bind_all("<F6>", lambda e: self.tab.set("Config"))
            self.bind_all("<F7>", lambda e: self.tab.set("Relatório"))
        except Exception:
            pass

    # Adapters UI (ajustados para StatusBarPro)
    def _log(self, level:str, msg:str, proc:Optional[str]=None, run_id:Optional[str]=None):
        if getattr(self,'_app_closing',False): return
        prefix=f"[{time.strftime('%H:%M:%S')}] {level.upper():<5}"
        if proc: prefix+=f" [P:{proc}]"
        if run_id: prefix+=f" [RUN:{run_id}]"
        if self.txt_log.winfo_exists():
            self.txt_log.configure(state='normal')
            tag = level.upper()
            self.txt_log.insert('end', f"{prefix} {msg}\n", tag)
            current_lines=int(self.txt_log.index('end-1c').split('.')[0])
            if current_lines>8000: self.txt_log.delete('1.0', f'{current_lines-8000}.0')
            self.txt_log.configure(state='disabled'); self.txt_log.see('end')

    def _set_status(self, text:str):
        if getattr(self,'_app_closing',False) or not self.winfo_exists(): return
        try: self.statusbar.set_status(text)
        except: pass

    def _set_pbar(self, frac:float):
        if getattr(self,'_app_closing',False) or not self.winfo_exists(): return
        try: self.statusbar.set_fraction(max(0.0, min(1.0, frac)))
        except: pass

    # Background UI timers
    def _process_gui_updates(self):
        if getattr(self,'_app_closing',False) or not self.winfo_exists(): return
        try:
            while True:
                kind,payload=self._gui_queue.get_nowait()
                if kind=='status': self._set_status(payload)
                elif kind=='pbar': self._set_pbar(payload)
                elif kind=='aux': self.statusbar.update_aux_label(payload)
        except queue.Empty:
            pass
        try:
            if not getattr(self,'_app_closing',False) and self.winfo_exists(): self.after(120,self._process_gui_updates)
        except tk.TclError:
            pass

    def _tick_metrics(self):
        if getattr(self,'_app_closing',False) or not self.winfo_exists(): return
        s=Telemetry.snapshot(); rows_backlog,logs_backlog=self.ui.backlog_sizes() if hasattr(self,'ui') else (0,0)
        msg=(f"RPS: {s['rps']:.2f} | MB/s: {s['mbps']:.2f} | Latência média: {s['avg_req_s']*1000:.0f} ms | Erros: {s['errors']} | "
             f"Rows pend.: {rows_backlog} | Logs pend.: {logs_backlog}")
        try:
            # Atualiza apenas o popover de métricas (não sobrescreve o status humano)
            self.statusbar.set_metrics_text(msg)
        except: pass
        try:
            if not getattr(self,'_app_closing',False) and self.winfo_exists(): self.after(1000,self._tick_metrics)
        except tk.TclError: pass

    # Execução
    def _iniciar(self):
        try:
            # Remove placeholders antes de ler
            self._clear_placeholder(self.txt_processos, self._ph_proc)
            self._clear_placeholder(self.txt_tipos, self._ph_tipos)
            processos_raw=self.txt_processos.get("1.0","end-1c").strip(); tipos_raw=self.txt_tipos.get("1.0","end-1c").strip() or "*"
            data_ini=self.entry_ini.get().strip() or None; data_fim=self.entry_fim.get().strip() or None; modo_busca='tipo'
            if not processos_raw:
                messagebox.showwarning("Atenção","Informe ao menos um número de processo."); return
            processos = [p.strip() for p in RE_SPLIT_PROC.split(processos_raw) if p.strip()]
            # --- Deduplicação de processos (preserva ordem, normaliza dígitos) ---
            processos_in = processos
            processos_norm = []
            vistos = set()
            duplicados = []
            for p in processos_in:
                d = _only_digits(p)
                if not d:
                    continue
                if d in vistos:
                    duplicados.append(d)
                    continue
                vistos.add(d)
                processos_norm.append(d)

            total_in = len(processos_in)
            total_unique = len(processos_norm)
            removidos = total_in - total_unique

            # Log explícito: total vs únicos + lista final (limitada)
            self._log('INFO', f"Processos informados={total_in} | únicos={total_unique} | duplicados_removidos={removidos}")
            if total_unique:
                preview_final = ", ".join(processos_norm[:20])
                suf = " …" if total_unique > 20 else ""
                self._log('INFO', f"Lista final (até 20): {preview_final}{suf}")
            # Aviso de duplicados removidos (UX)
            if removidos > 0:
                ex = ", ".join(duplicados[:10])
                more = f" (+{len(duplicados)-10} outros)" if len(duplicados) > 10 else ""
                self._log('WARN', f"Duplicados detectados e removidos: {removidos} (únicos={total_unique} de {total_in}). Ex.: {ex}{more}")
                try:
                    # Aviso não-bloqueante (sem MessageBox): usa callout na barra de status
                    if hasattr(self, 'statusbar') and self.statusbar:
                        self.statusbar.show_callout(f"Duplicados removidos: {removidos}", success=True)
                except Exception:
                    pass

            processos = processos_norm
            if not processos:
                messagebox.showwarning("Atenção", "Nenhum número de processo válido após normalização (somente dígitos).")
                return

            # [S5] Limitador de operações: processa no máximo LIMITE_OPERACOES_S5 processos por execução.
            # O que passar do limite não é baixado agora; vai para processos_pendentes_S5.txt (ver abaixo).
            processos, pendentes_s5 = aplicar_limite_s5(processos)
            if pendentes_s5:
                self._log('WARN', mensagem_log_s5(len(pendentes_s5)))
                messagebox.showwarning(TITULO_AVISO_S5, mensagem_s5(total_unique, len(pendentes_s5)))

            tipos=[t.strip() for t in tipos_raw.split(',') if t.strip()] or ["*"]
            out_dir=self.entry_dir.get().strip()
            if not out_dir or not os.path.isdir(out_dir):
                messagebox.showerror("Erro","Diretório de relatórios inválido."); return
            ts=datetime.now().strftime('%Y-%m-%d %H-%M-%S')
            final_dir=os.path.join(out_dir, f"downloads - {ts}")
            os.makedirs(final_dir, exist_ok=True)

            # [S5] Guarda os processos que passaram do limite, um por linha, prontos para colar na próxima execução
            if pendentes_s5:
                caminho_pendentes = os.path.join(final_dir, ARQUIVO_PENDENTES_S5)
                with open(caminho_pendentes, "w", encoding="utf-8") as fp:
                    fp.write("\n".join(pendentes_s5) + "\n")
                self._log('WARN', f"Controle S5: processos pendentes salvos em {caminho_pendentes}")
            workers_col=max(1,int(self.workers_col_var.get())); workers_dl=max(1,int(self.workers_dl_var.get()))
            # NÃO altera DEFAULT_CHUNK global; apenas coleta valor para passar adiante
            chunk_kb = max(64, int(self.chunk_var.get()))

            http = HttpxClient(max_pool=max(DEFAULT_POOL_MAX, workers_dl))
            if not autenticar_menu_http(http, self.username, self.password):
                messagebox.showerror("Erro","Falha na autenticação."); return

            naming = DefaultNamingStrategy()
            layout = ByProcessAndSeqLayout()
            writer = FileSystemWriter(naming)
            reporter = CsvXlsxReport()
            logger_adapter = LoggerAdapter(self.ui.enqueue_log)
            progress_adapter = ProgressAdapter(
                set_status_cb=lambda text: self._gui_queue.put(("status", text)),
                set_frac_cb=lambda frac: self._gui_queue.put(("pbar", frac))
            )

            def _on_file_done(reg: ProcessoAnexo):
                # ordem das colunas na UI: ("processo","tipo","arquivo","caminho")
                self.ui.enqueue_row((reg.numero_processo, reg.tipo_anexo, reg.arquivo, reg.caminho_local or ""))

            def _on_aux_update(text: str):
                try:
                    self._gui_queue.put(("aux", text))
                except Exception:
                    pass

            self.orchestrator = JobOrchestrator(http, writer, naming, layout, reporter, logger_adapter, progress_adapter,
                                                on_file_done=_on_file_done, on_aux_update=_on_aux_update)
            self._log('INFO', f'Run={self.orchestrator.run_id} | Dir={final_dir} | Wcol={workers_col} | Wdl={workers_dl} | ChunkKB={chunk_kb}')

            inputs=[ProcessoInput(numero=n, tipos=tipos, data_inicial=data_ini, data_final=data_fim, modo_busca=modo_busca) for n in processos]

            # Atualiza estado de execução (bloqueia inputs, habilita Cancelar)
            self._set_running_state(True)

            def _bg():
                try:
                    summary = self.orchestrator.run(inputs, final_dir, workers_col, workers_dl, chunk_kb)
                    self._log('INFO', f"Relatórios prontos: CSV={summary.relatorio_csv} | XLSX={summary.relatorio_xlsx}")
                    if summary.telemetria_json:
                        self._log('INFO', f"Telemetria salva em: {summary.telemetria_json}")

                    # Exibir callout, ajustar modo e ações (na thread da UI)
                    def _done_ui():
                        cancelled = self.orchestrator.is_cancelled()
                        self.statusbar.set_mode("cancelled" if cancelled else "success")
                        self.statusbar.show_callout("Concluído" + (" (cancelado)" if cancelled else ""), success=not cancelled)
                        self.statusbar.show_actions(
                            True,
                            on_open_dir=lambda: self._abrir_item(final_dir),
                            on_open_csv=(lambda: self._abrir_item(summary.relatorio_csv)) if summary.relatorio_csv else None,
                            on_open_xlsx=(lambda: self._abrir_item(summary.relatorio_xlsx)) if summary.relatorio_xlsx else None,
                        )
                        # Status humano final + limpa aux
                        self.statusbar.set_status("Concluído" + (" (cancelado)" if cancelled else ""))
                        self.statusbar.update_aux_label("")
                        self.statusbar.set_fraction(1.0)
                    try:
                        self.after(0, _done_ui)
                    except Exception:
                        pass
                except Exception as e:
                    self._log('ERROR', f"Erro geral: {e}")
                    try:
                        self.after(0, lambda: self.statusbar.set_status("Erro"))
                        self.after(0, lambda: self.statusbar.set_mode("error"))
                        self.after(0, lambda: self.statusbar.update_aux_label("Verifique o log à direita"))
                    except Exception:
                        pass
                finally:
                    # Volta UI ao estado inativo
                    try: self.after(0, lambda: self._set_running_state(False))
                    except: pass

            threading.Thread(target=_bg, daemon=True).start()

        except Exception as e:
            messagebox.showerror("Erro", str(e))

    def _cancelar(self):
        try:
            if hasattr(self, 'orchestrator') and self.orchestrator:
                self._log('INFO', "Cancelamento solicitado pelo usuário.")
                self._set_status("Cancelando…")
                self.statusbar.set_mode("busy")
                self.orchestrator.cancel()
                self.btn_cancel.configure(state="disabled")
        except Exception:
            pass

    def _set_running_state(self, is_running: bool):
        # Botões
        try:
            self.btn_start.configure(state="disabled" if is_running else "normal")
            self.btn_cancel.configure(state="normal" if is_running else "disabled")
        except Exception:
            pass
        # Campos principais
        for w in [self.txt_processos, self.txt_tipos, self.entry_ini, self.entry_fim]:
            try: w.configure(state="disabled" if is_running else "normal")
            except Exception: pass
        # Sliders (Config)
        for w in [self.slider_dl, self.slider_col, self.slider_chunk]:
            try: w.configure(state="disabled" if is_running else "normal")
            except Exception: pass
        # Status + Progress + Ações
        try:
            if is_running:
                self.statusbar.update_state(state="running", progress=0.1, status="Processando…", aux="Preparando lotes", actions=None)
            else:
                pass
        except Exception:
            pass

    def _show_callout(self, text: str, success: bool = True):
        # Mantém compatibilidade com chamadas antigas
        try:
            self.statusbar.show_callout(text, success=success)
        except Exception:
            pass

    def _abrir_item(self, path:str):
        try:
            if not path or not os.path.exists(path): return
            if sys.platform.startswith('win'): os.startfile(path)
            elif sys.platform=='darwin': subprocess.Popen(['open', path])
            else: subprocess.Popen(['xdg-open', path])
        except Exception as e:
            logger.debug("Falha ao abrir item: %s", e)


# ============================================
# BOOTSTRAP (main)
# ============================================

if __name__ == "__main__":
    ctk.set_appearance_mode("dark"); ctk.set_default_color_theme("blue")
    root=ctk.CTk(); root.withdraw(); SplashScreen(root); root.mainloop()
