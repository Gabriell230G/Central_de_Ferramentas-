<div align="center">

<img src="docs/readme/header.svg" alt="Download Anexos GCPJ: baixa em lote os anexos dos processos do GCPJ, com filtro por tipo e data e relatório CSV/XLSX" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: Python 3" height="26">
<img src="docs/readme/badge-2.svg" alt="interface: customtkinter" height="26">
<img src="docs/readme/badge-3.svg" alt="acesso: httpx" height="26">
<img src="docs/readme/badge-4.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-5.svg" alt="relatórios: CSV e XLSX" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o coletor de anexos recebe uma lista de processos, entra no GCPJ, baixa os anexos de cada um (só os tipos e datas pedidos) para uma pasta e, no fim, entrega um relatório em CSV e XLSX com tudo o que foi baixado.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 2 relatórios, CSV e XLSX; 5.000 processos por execução (Controle S5); até 8 processos ao mesmo tempo (padrão); 3 tentativas antes de desistir" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Lista de números de processo colados na tela ➜ 2 Coletor com Controle S5, tira repetidos e separa até 5.000 ➜ 3 GCPJ, lê a lista de anexos página por página ➜ 4 Filtro por tipo e data de inclusão ➜ 5 Resultado: arquivos na pasta e relatórios CSV e XLSX" width="100%">
</picture>

### O que tem na tela

| Na tela | Aba | O que faz |
| :--- | :---: | :--- |
| **Números de Processo** | Principal | Lista dos processos a baixar. Pode separar por vírgula, ponto e vírgula, espaço ou linha. Números repetidos são tirados sozinhos |
| **Tipos de Anexo Desejados** | Principal | Quais tipos de anexo baixar, separados por **vírgula** (ex.: `Inicial, Sentença`). `*` ou vazio baixa todos |
| **Data inicial / Data final** | Principal | *(opcional)* Só baixa anexos incluídos nesse período, no formato `dd/mm/aaaa` |
| **Iniciar Coleta** | Principal | Começa a execução (atalho **Ctrl+Enter**) |
| **Cancelar** | Principal | Para de começar processos novos e termina os que já estavam em andamento (atalho **Esc**) |
| Tabela e log | Principal | À esquerda, uma linha por arquivo baixado (duplo clique abre o arquivo). À direita, o log da execução |
| **Diretório de Relatórios** | Config | Onde a pasta da execução será criada. Botão **Selecionar** para escolher |
| **Workers de COLETA / DOWNLOAD** | Config | Quantos processos ao mesmo tempo (padrão 8) e quantos arquivos de cada processo ao mesmo tempo (padrão 20) |
| Botões da barra de baixo | todas | Ao terminar: abrir a pasta, abrir o **CSV**, abrir o **XLSX** e ver as métricas (ⓘ) |

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Código no inventário** | `A@KU` · Download_Anexos_GCPJ · *"Efetuar download dos anexos de Processos do GCPJ"* |
| **Área dona** | Dejur (4040) · Legal Ops |
| **Tipo** | Aplicativo de desktop em Python 3 com tela em customtkinter, distribuído como `.exe` |
| **Onde fica** | `\\mz-vv-fs-140\D4040_1\Publico\BackUp_Sistemas\Compartilhado\Download_Anexos_GCPJ\` |
| **Sistema que acessa** | GCPJ, direto pela intranet (sem Internet Explorer). Só consulta e baixa, não altera nada no processo |
| **Entrada** | Números de processo colados na tela, tipos de anexo e datas (opcionais) |
| **Saída** | Pasta `downloads - AAAA-MM-DD HH-MM-SS` com os arquivos, `relatorio_processos.csv`, `relatorio_processos.xlsx` e `telemetry.json` |
| **Login** | Usuário e senha da rede, na tela *Acesso ao Coletor* |
| **Controle S5** | Até **5.000 processos por execução**. O que passar vai para `processos_pendentes_S5.txt` |

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Fazer login com usuário e senha da rede ➜ 2 Colar os processos na aba Principal ➜ 3 Tipos e datas (opcional) ➜ 4 Conferir a pasta na aba Config e clicar em Iniciar Coleta ➜ 5 O robô trabalha (até 5.000 por execução, vários ao mesmo tempo) ➜ 6 Conferir o resultado na pasta, no CSV, no XLSX e no log" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Abra o programa, digite **usuário e senha da rede** e clique em **Acessar**. O usuário fica lembrado para a próxima vez (a senha não) |
| **2** | Na aba **Principal**, cole os números em **Números de Processo** |
| **3** | *(opcional)* Em **Tipos de Anexo Desejados**, escreva os tipos separados por vírgula. Para baixar tudo, deixe `*`. Se quiser, preencha **Data inicial** e **Data final** |
| **4** | Na aba **Config**, confira o **Diretório de Relatórios**. Volte à aba **Principal** e clique em **Iniciar Coleta** |
| **5** | Acompanhe pela tabela, pelo log e pela barra de baixo. Se a lista passar de 5.000, aparece o aviso do Controle S5 e o resto fica guardado para a próxima |
| **6** | Quando aparecer **Concluído**, use os botões da barra de baixo para abrir a pasta e o relatório. Confira no log a linha **RESUMO GERAL** |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e como preencher a tela</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com acesso à intranet do banco e ao **GCPJ**
- O `.exe` da pasta de rede **ou**, para rodar pelo código, **Python 3** com as bibliotecas abaixo
- Uma pasta onde gravar (por padrão, a Área de Trabalho do OneDrive do banco ou, se ela não existir, a `Desktop`)

**Para rodar pelo código:**

```bash
pip install httpx selectolax orjson xlsxwriter customtkinter unidecode urllib3
pip install pywin32   # opcional: usado para validar o login no Windows
python gcpj_coletor_R4_4_6_FAST_FIXED4_OPTIMIZED_DEDUP_NOPOPUP_UI_v3_OVERLAY_RESPONSIVE_PAD3.py
```

**Como preencher:**

| Campo | Exemplo | Regra |
| :--- | :--- | :--- |
| `Números de Processo` | `123456, 789012` | Número do processo no GCPJ. Pode separar por vírgula, ponto e vírgula, espaço ou linha. Pontos, traços e letras são ignorados (fica só o que é número) |
| `Tipos de Anexo Desejados` | `Inicial, Sentença` | Separados por **vírgula**. Basta um pedaço do nome do tipo; acento e maiúscula não importam. `*` ou vazio = todos |
| `Data inicial` / `Data final` | `01/01/2024` | Exatamente `dd/mm/aaaa`. Vazio = sem filtro de data |
| `Diretório de Relatórios` (aba Config) | Área de Trabalho | A pasta precisa existir. Cada execução cria dentro dela uma pasta nova `downloads - AAAA-MM-DD HH-MM-SS` |

**Como fica a pasta da execução:**

```text
downloads - 2026-10-21 14-30-00\
├── 123456\
│   └── 123456_<sequência>\<arquivo com o nome do GCPJ>
├── relatorio_processos.csv
├── relatorio_processos.xlsx
├── telemetry.json
└── processos_pendentes_S5.txt   (só quando passa de 5.000)
```

> [!TIP]
> Atalhos: **Ctrl+Enter** inicia, **Esc** cancela, **F2** vai para a lista de processos, **F6** abre a aba Config e **F7** a aba Relatório. Na tabela, o botão direito copia a linha ou a célula.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** todo arquivo que foi baixado aparece no relatório (CSV/XLSX) com o caminho onde foi salvo. Se o anexo não está no relatório, o log diz o porquê, numa linha marcada com o número do processo (`[P:123456]`).

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um processo ➜ 2 Abrir o relatório CSV ou XLSX da execução ➜ 3 Ler o log nas linhas do processo ➜ resultado verde (deu certo, o arquivo está no relatório), amarelo (conferir o filtro ou o processo no GCPJ) ou vermelho (rodar de novo só esse processo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que a sentença do processo 123456 não veio. No XLSX não há nenhuma linha desse processo. No log, a linha `[P:123456]` diz `Nenhum anexo passou no filtro (itens_tabela=14, rejeitados_tipo=14, ...)`. Pelo quadro amarelo, o processo tem anexos, mas nenhum bateu com o tipo digitado. Normalmente é o tipo escrito em linhas separadas, sem vírgula. Basta corrigir e rodar de novo só esse processo.

#### 🟢 Deu certo: não precisa fazer nada

| O que aparece | Onde | O que quer dizer |
| :--- | :--- | :--- |
| Linha do arquivo com **Caminho Local** preenchido | Relatório CSV/XLSX | O anexo foi baixado e está nesse caminho |
| `Download: N arq (OK=N, SKIP=0, FAIL=0)` | Log | Todos os anexos aprovados no filtro foram baixados |
| `SKIP` maior que zero | Log | O arquivo já estava na pasta, então não baixou de novo |
| `Duplicados detectados e removidos: N` | Log e aviso na barra | Número repetido na lista; ele é baixado uma vez só |

#### 🟡 Precisa que alguém olhe

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| `Nenhum anexo passou no filtro (...)`<br>alerta `EMPTY_BY_FILTER` | O processo tem anexos, mas nenhum bateu com o tipo ou a data pedidos | Conferir os tipos (separados por **vírgula**) e as datas (`dd/mm/aaaa`) |
| `Nenhum anexo encontrado no portal (...)`<br>alerta `EMPTY_BY_PORTAL` | O GCPJ não mostrou nenhum anexo para esse processo | Abrir o processo no GCPJ e ver se ele tem anexos |
| `Numero divergente no portal: solicitado=... vs portal=...`<br>alerta `COLETA_MISMATCH_SERVER_NUMBER` | O GCPJ abriu um processo com número diferente do pedido, mesmo depois de 3 tentativas | Conferir o número na lista e no GCPJ |
| `Coleta instavel/vazia (stop_reason=...)` | O GCPJ respondeu vazio e o coletor tentou de novo sozinho | Nada, se depois vier a linha `Download:`. Se não vier, ver as linhas acima |
| Status **Concluído (cancelado)**<br>erro `CANCELLED` | Alguém clicou em **Cancelar** (ou apertou **Esc**) | Rodar de novo os processos que ficaram faltando |
| Aviso **Processamento Limitado - Controle S5** | A lista passou de 5.000 processos | Normal. Rodar de novo com a lista de `processos_pendentes_S5.txt` |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| `FAIL=` maior que zero na linha `Download:`<br>arquivo fora do relatório | Esse arquivo falhou nas 3 tentativas | Rodar de novo o processo |
| `Falha na coleta (tentativa 3/3): ...` | Deu erro ao ler a lista de anexos em todas as tentativas | Ler o erro no fim da linha e rodar de novo |
| Erro `TIMEOUT` | O GCPJ demorou demais para responder | Rodar de novo, se possível com menos workers na aba Config |
| Erro `HTTP_` + número (ex.: `HTTP_401`, `HTTP_500`) | O GCPJ recusou ou deu erro ao listar os anexos | `401`/`403`: conferir login e acesso ao GCPJ. `5xx`: GCPJ instável, rodar de novo |
| Erro `NETWORK` | Caiu a conexão com a intranet | Conferir a rede e rodar de novo |
| Erro `PERM` | Sem permissão para gravar na pasta | Escolher outra pasta na aba Config |
| Erro `SPACE` | Disco cheio | Liberar espaço ou trocar de pasta |
| Erro `IO` | Falha ao gravar, arquivo veio incompleto ou o GCPJ recusou o download | Rodar de novo. Se repetir, baixar manualmente no GCPJ |
| `Erro geral: ...` (linha vermelha) e status **Erro** | A execução parou no meio | Ler a mensagem e rodar de novo |

> [!IMPORTANT]
> **O log da tela não é salvo em arquivo.** Ele some quando a janela fecha. O que fica gravado na pasta é o relatório (só com o que **deu certo**) e o `telemetry.json`, que guarda os totais (OK, SKIP, FAIL) e os 3 erros e 3 alertas mais comuns da execução, sem dizer de qual processo. Se for investigar depois, compare a lista que foi pedida com o relatório.
>
> **Para rodar de novo,** cole só os processos que faltaram. Cada execução cria uma pasta nova, então rodar a lista inteira baixa tudo outra vez.

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| *Preencha usuário e senha.* | Campo de login em branco | Preencher os dois |
| *Credenciais inválidas ou rede indisponível.* | Senha errada ou máquina fora da rede do banco | Conferir a senha de rede e a conexão |
| *Informe ao menos um número de processo.* | Lista vazia | Colar os números |
| *Nenhum número de processo válido após normalização (somente dígitos).* | A lista só tinha letras ou símbolos | Colar os números do GCPJ |
| *Diretório de relatórios inválido.* | A pasta da aba Config não existe | Clicar em **Selecionar** e escolher outra |
| *Falha na autenticação.* | O login passou na tela, mas o GCPJ recusou na hora de começar | Fechar, entrar de novo e conferir se o usuário tem acesso ao GCPJ |
| Aviso **Processamento Limitado - Controle S5** | A lista passou de 5.000 processos | Normal. Ver a seção [Controle S5](#controle-s5) |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073**: o aplicativo precisa ter um limite de operações por execução. No coletor, o limite é de **5.000 processos por execução**, contados depois de tirar os repetidos.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: o coletor separa os primeiros 5.000 processos da lista; o que passar disso não vai ao GCPJ, o usuário é avisado e os números ficam em processos_pendentes_S5.txt" width="100%">
</picture>

Quando a lista passa do limite:

1. Aparece o aviso **Processamento Limitado - Controle S5**: *"Foram informados 7.200 processos, mas o limite por execução é de 5.000. Serão processados agora os primeiros 5.000. Os 2.200 restantes foram salvos em "processos_pendentes_S5.txt", na pasta desta execução, para serem processados em uma nova execução."*
2. O log recebe *"Controle S5: limite de 5.000 processos por execução atingido. 2.200 processo(s) ficaram para a próxima execução."*
3. Os primeiros 5.000 são baixados normalmente, com relatório e tudo.
4. Os que sobraram ficam em `processos_pendentes_S5.txt`, dentro da pasta da execução, um por linha, prontos para colar na próxima rodada. O log avisa onde: *"Controle S5: processos pendentes salvos em (caminho)"*.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `gcpj_coletor_...PAD3.py` | constante `LIMITE_OPERACOES_S5`, linha 84 |
| Título do aviso | `gcpj_coletor_...PAD3.py` | constante `TITULO_AVISO_S5`, linha 85 |
| Nome do arquivo de pendentes | `gcpj_coletor_...PAD3.py` | constante `ARQUIVO_PENDENTES_S5`, linha 86 |
| Texto do aviso e do log | `gcpj_coletor_...PAD3.py` | funções `mensagem_s5` (linha 101) e `mensagem_log_s5` (linha 111) |
| Corte da lista na tela | `gcpj_coletor_...PAD3.py` | `JanelaPrincipal._iniciar`, bloco `[S5]` na linha 2636 |
| Gravação dos pendentes | `gcpj_coletor_...PAD3.py` | `JanelaPrincipal._iniciar`, bloco `[S5]` na linha 2651 |
| Garantia no núcleo | `gcpj_coletor_...PAD3.py` | `JobOrchestrator.run`, bloco `[S5]` na linha 1509 |

> [!TIP]
> Para testar sem colar 5.000 números: troque `LIMITE_OPERACOES_S5` para `2`, rode com 3 processos, tire os prints com o relógio do Windows aparecendo e **volte para 5000**. **Ctrl+F** em `[S5]` mostra todos os pontos do controle. No teste automático da entrega, a versão com S5 passou em 19 de 19 verificações e a versão antiga, sem S5, baixou os 7 processos de teste (prova de que antes não havia limite). As evidências oficiais estão em [`docs/Evidencias_S5_DownloadAnexosGCPJ.docx`](docs/Evidencias_S5_DownloadAnexosGCPJ.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Arquivo único: `gcpj_coletor_R4_4_6_FAST_FIXED4_OPTIMIZED_DEDUP_NOPOPUP_UI_v3_OVERLAY_RESPONSIVE_PAD3.py`

| Parte | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| Constantes | `INTERNAL_HOST_SUFFIX`, `BASE_GCPJ`, `BASE_MENU` | 58 | Endereços do GCPJ e do menu INET na intranet |
| | `DEFAULT_WORKERS_COLETA` / `DEFAULT_WORKERS_DOWNLOAD` | 66 / 68 | Paralelismo padrão (8 processos, 20 arquivos por processo) |
| | `DEFAULT_COLETA_RETRIES` | 67 | Tentativas extras por processo (2, ou seja, 3 no total) |
| Controle S5 | `LIMITE_OPERACOES_S5` | 84 | Limite de 5.000 processos por execução |
| | `aplicar_limite_s5` | 89 | Divide a lista em "agora" e "próxima execução" |
| | `mensagem_s5` / `mensagem_log_s5` | 101 / 111 | Textos do aviso e do log |
| Utilitários | `_only_digits` | 168 | Deixa só os números do processo |
| | `_extract_canonical_num_from_html` | 175 | Descobre qual número o GCPJ abriu, para conferir |
| | `_sanitize_filename` / `_truncate_for_path` | 218 / 242 | Nome de arquivo válido no Windows e caminho com até 248 caracteres |
| | `Telemetry` | 274 | Contadores de requisições, erros, bytes e velocidade |
| Acesso ao GCPJ | `HttpxClient` | 421 | Dois clientes httpx (intranet e externo), login Basic só na intranet |
| | `_new_isolated_client_from` | 483 | Sessão nova por processo, copiando os cookies da sessão principal |
| | `_parse_page` | 555 | Lê o formulário e a tabela de anexos (`#oTable`) de uma página |
| | `_classify_exception` | 665 | Transforma o erro em `TIMEOUT`, `HTTP_xxx`, `NETWORK`, `PERM`, `SPACE`, `IO` ou `UNKNOWN` |
| | `autenticar_menu_http` | 901 | Confere usuário e senha no menu INET |
| | `coletar_anexos` | 919 | Lista os anexos de um processo, página por página, e aplica o filtro |
| Download | `ByProcessAndSeqLayout` | 749 | Monta a pasta `<processo>\<processo>_<sequência>` |
| | `FileSystemWriter.baixar_uma` | 776 | Baixa um arquivo, com retomada (`.part`) e 3 tentativas |
| | `FileSystemWriter.baixar_lote` | 853 | Baixa vários arquivos ao mesmo tempo |
| Relatório | `CsvXlsxReport` | 1266 | Gera `relatorio_processos.csv` e `.xlsx` (aba `Anexos`) |
| Orquestração | `JobOrchestrator.processar_processo` | 1350 | Coleta, planeja e baixa um processo |
| | `JobOrchestrator.run` | 1508 | Roda todos os processos, gera relatório, `telemetry.json` e o RESUMO GERAL |
| Tela | `StatusBarPro` | 1813 | Barra de baixo: status, progresso, botões e métricas |
| | `verify_credentials` | 2208 | Valida o login (Windows e, se falhar, menu INET) |
| | `create_login_frame` | 2259 | Tela *Acesso ao Coletor* |
| | `JanelaPrincipal` | 2317 | Janela principal com as abas Principal, Config e Relatório |
| | `JanelaPrincipal._iniciar` | 2584 | Lê a tela, tira repetidos, aplica o S5 e dispara a execução |
| | `JanelaPrincipal._cancelar` | 2738 | Cancelamento |
| Início | `if __name__ == "__main__"` | 2794 | Abre a tela de carregamento e depois o login |

</details>

<details>
<summary><b>Como funciona por dentro</b> &nbsp;·&nbsp; passo a passo de uma execução</summary>
<br>

**Login**

1. `verify_credentials` tenta validar no Windows (`LogonUser`, via pywin32). Se não der, testa usuário e senha no menu INET do GCPJ.
2. O usuário é salvo em `login_data.json`. A senha fica só na memória, para autenticar de novo a cada **Iniciar Coleta**.

**Iniciar Coleta**

1. Separa a lista por `;`, `,`, espaço ou quebra de linha, deixa só os dígitos e tira os repetidos, mantendo a ordem.
2. **[S5]** corta a lista em 5.000 e avisa, se for o caso.
3. Cria a pasta `downloads - AAAA-MM-DD HH-MM-SS` e, se houve corte, grava `processos_pendentes_S5.txt`.
4. Autentica no menu INET e chama o `JobOrchestrator.run`, que também aplica o S5 de novo por garantia.

**Cada processo** (até 8 ao mesmo tempo, por padrão)

1. Abre uma sessão própria e faz `GET` em `cadMantemCadProcConsultaTodosAction?acao=obterAnexo`.
2. Confere se o número exibido é o pedido. Se não for, para com `mismatch_server_number`.
3. Lê a tabela `#oTable`: id do anexo, nome, tipo, arquivo e data de inclusão.
4. Se a primeira página parece ser a única, para aí. Senão, pagina com `POST acao=paginacaoANEXOS` (`pagina=7` é *próxima*, `pagina=8` é *última*) até a tabela parar de mudar, vir 3 páginas vazias seguidas ou chegar a 1.000 páginas.
5. Aplica o filtro de tipo (pedaço do texto, sem acento, sem diferença de maiúscula) e de data.
6. Se veio vazio por número divergente, páginas vazias ou erro, tenta de novo (até 3 tentativas no total).

**Download** (por padrão, até 20 arquivos do mesmo processo ao mesmo tempo)

1. Link: `cadMantemCadProcAnexosAction?acao=visualizarArquivo&selecionados=<id>`.
2. Destino: `<processo>\<processo>_<id + 1>\<nome do arquivo no GCPJ>`.
3. Grava primeiro em `.part`. Se cair, a próxima tentativa continua de onde parou (`Range`).
4. Confere o tamanho recebido. Arquivo já existente com tamanho maior que zero vira `SKIP`.

**Fim**

1. Gera o CSV (UTF-8 com BOM) e o XLSX só com os arquivos `OK` e `SKIP`.
2. Escreve no log o **RESUMO GERAL** e grava o `telemetry.json`.

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `LIMITE_OPERACOES_S5` (linha 84) |
| Mudar o endereço do GCPJ | `INTERNAL_HOST_SUFFIX`, `BASE_GCPJ` e `BASE_MENU` (linhas 58 a 63) |
| Mudar o paralelismo padrão | `DEFAULT_WORKERS_COLETA` e `DEFAULT_WORKERS_DOWNLOAD` (linhas 66 e 68), ou os controles da aba Config |
| Mudar o número de tentativas | `DEFAULT_COLETA_RETRIES` (linha 67) e `max_retries` de `baixar_uma` (linha 776) |
| Mudar como o tipo é comparado | `ok_tipo` dentro de `coletar_anexos` (linha 997). O modo de busca está fixo em `'tipo'` na linha 2590 |
| Mudar o filtro de datas | `_parse_date` e `ok_data` dentro de `coletar_anexos` (linhas 1012 e 1026) |
| Mudar as colunas do relatório | `CsvXlsxReport.generate`, lista `cols` (linha 1269) |
| Mudar a organização das pastas | `ByProcessAndSeqLayout` (linha 749) e `JobOrchestrator._build_plan` (linha 1328) |
| Mudar a pasta padrão | `JanelaPrincipal.__init__` (linha 2436) |
| Ajustar se o GCPJ mudar a tela de anexos | `_parse_page` (linha 555) |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **Certificado da intranet não é conferido.** O cliente da intranet usa `verify=False` (linha 444) e os avisos disso são desligados (linha 48). Como o login vai em todo pedido à intranet (`Authorization: Basic`, linhas 454 a 458), vale avaliar com Segurança.
- **A senha fica na memória** durante toda a sessão (linha 2322), para autenticar de novo a cada execução (linha 2662). Só o usuário vai para o disco, em `login_data.json`, gravado na pasta de onde o programa foi aberto (caminho relativo, linha 2189).
- **Confirmação de login fraca.** `autenticar_menu_http` aceita qualquer resposta sem erro que tenha mais de 200 caracteres (linha 907), mesmo sem a palavra GCPJ.
- **O log não é salvo** e o relatório só lista o que deu certo. Para saber o que falhou depois que a janela fechou, só sobram os totais e o "top 3" do `telemetry.json`.
- **"Concluído" em verde mesmo com falhas.** A barra fica verde sempre que não houve cancelamento (linha 2704), mesmo com `FAIL` maior que zero.
- **Tipos só por vírgula.** Os tipos são separados só por vírgula (linha 2643). Um tipo por linha vira um termo só e nada é baixado (`EMPTY_BY_FILTER`).
- **Data fora do formato é ignorada sem aviso.** Se a data não estiver exatamente em `dd/mm/aaaa`, o filtro de data simplesmente não é aplicado (linhas 1012 a 1021).
- **Erros ao salvar o relatório não aparecem na tela.** `CsvXlsxReport` registra a falha só no log interno do Python (linhas 1285 e 1304), que não aparece na janela.
- **Métricas acumulam.** `Telemetry` guarda os contadores desde que o programa abriu (linha 275), então o `telemetry.json` da segunda execução na mesma sessão soma a primeira.
- **Pasta criada antes do login.** Se a autenticação falhar ao iniciar, a pasta da execução (e o `processos_pendentes_S5.txt`, se houver) já foi criada (linhas 2649 a 2663).
- **Código morto.** Depois do `return` de `_classify_exception` (linha 679) há um pedaço de uma função antiga (linhas 685 a 706) que nunca roda.
- **Depende do layout do GCPJ.** O coletor lê a tabela `#oTable`, o rádio `selecionados` e as colunas 2, 3, 4 e 6 (linhas 594 a 604). Se o GCPJ mudar essa tela, a coleta para de achar anexos.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: R4.4.4 barra de status nova; R4.4.6 versão atual, menos chamadas ao GCPJ por processo; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: versionar no GitHub" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Versão / Data | Autor | Alteração |
| :--- | :--- | :--- |
| R4.4.4 (sem data) | não registrado | Barra de status compacta, com tempo restante e MB/s na mesma linha do progresso |
| R4.4.6 (sem data) | não registrado | Versão atual: cookies copiados entre sessões e cada página lida uma vez só, para fazer menos chamadas ao GCPJ |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LIMITE_OPERACOES_S5`, pendentes em `processos_pendentes_S5.txt`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
