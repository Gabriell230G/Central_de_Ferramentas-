<div align="center">

<img src="docs/readme/header.svg" alt="Aprova Depósitos: aprova no GCPJ depósitos avulsos e encerramentos cíveis até o valor limite, página por página" width="100%">

<br><br>

<img src="docs/readme/badge-1.svg" alt="linguagem: C#" height="26">
<img src="docs/readme/badge-2.svg" alt="framework: .NET 4.8" height="26">
<img src="docs/readme/badge-3.svg" alt="interface: Windows Forms" height="26">
<img src="docs/readme/badge-4.svg" alt="base: Access" height="26">
<img src="docs/readme/badge-5.svg" alt="sistema: GCPJ" height="26">
<img src="docs/readme/badge-6.svg" alt="controle S5: 5.000 por execução" height="26">

<br><br>

**[Visão geral](#visao-geral)** · **[Roadmap de uso](#roadmap-de-uso)** · **[Recebi uma RO](#recebi-uma-ro)** · **[Controle S5](#controle-s5)** · **[Visão técnica](#visao-tecnica)** · **[Roadmap do projeto](#roadmap-do-projeto)**

</div>

<br>

<a id="visao-geral"></a>

## <img src="docs/readme/ic-visao.svg" width="30" align="top"> Visão geral

> **Em uma frase:** o robô entra no GCPJ, procura os depósitos avulsos e os encerramentos cíveis da data informada e aprova, um por um, os que estão dentro do valor limite em R$.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/numeros-dark.svg">
  <img src="docs/readme/numeros-light.svg" alt="Em números: 4 rotinas de aprovação no GCPJ; 5.000 itens por execução (Controle S5); 14 mensagens da tela explicadas; só itens da área cível (CI)" width="100%">
</picture>

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/fluxo-dark.svg">
  <img src="docs/readme/fluxo-light.svg" alt="Fluxo: 1 Valor limite da tabela SYS_VALOR_LIMITE ➜ 2 Data digitada na tela ➜ 3 Robô com Controle S5 procura itens CI da data com valor até o limite ➜ 4 GCPJ no Internet Explorer, onde detalha e aprova ➜ 5 Resultado: item aprovado no GCPJ e mensagem na grade" width="100%">
</picture>

### As ações

| Botão na tela | O que faz | Tela do GCPJ | Data usada |
| :--- | :--- | :--- | :---: |
| **Conectar GCPJ** | Procura uma janela do Internet Explorer com "GCPJ" no título. Se não achar, abre uma nova | Página inicial | |
| **Processar Avulsos** | Aprova os depósitos avulsos pagos por **TED** e, em seguida, os pagos por **crédito em conta Bradesco** | Depósitos aguardando aprovação | **Data Depósito** |
| **Processar Encerramentos** | Aprova os encerramentos pagos por **TED** e, em seguida, os pagos por **crédito em conta Bradesco** | Trâmite de pendências, pendência 103 | **Data Solicitação** |

Cada botão de processar roda **duas rotinas** seguidas, uma para TED e outra para crédito em conta, e conta como **uma execução** do Controle S5. Os quatro botões separados (*Avulsos TED*, *Avulso Cred Conta*, *Encerramento TED*, *Encerramento Cred Conta*) ainda existem no código, mas estão escondidos da tela.

### Ficha rápida

| Item | Detalhe |
| :--- | :--- |
| **Repositório** | `aajr-cmn-aprovadepositos-auto` |
| **Código no inventário** | `C@JX` · Aprovação de depósito (aprovação dos depósitos cíveis) |
| **Área dona** | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| **Tipo** | Robô de tela (RPA) em C# Windows Forms, .NET Framework 4.8, compilado como **AnyCPU** |
| **Sistema que altera** | GCPJ (aprova depósitos e encerramentos) |
| **Entrada** | Data digitada na tela + valor limite em R$ da tabela `SYS_VALOR_LIMITE` |
| **Saída** | Itens aprovados no GCPJ + mensagens na grade da tela (não ficam salvas) |
| **Base local** | `BD_DADOS.accdb`, ao lado do executável |
| **Instalação** | `\\d4040s006\D4040_01\Publico\SISTEMAS\4040006\Aprovacao_Depositos\` |
| **Controle S5** | Até **5.000 itens por execução** (cada clique em *Processar*) |

> [!NOTE]
> A pasta do projeto se chama `Auto_Encerramento_Plus` por herança de outro sistema. Este **não** é o Auto Encerramento: o executável gerado é o `Aprova_Depositos.exe`.

<br>

<a id="roadmap-de-uso"></a>

## <img src="docs/readme/ic-roadmap.svg" width="30" align="top"> Roadmap de uso

O caminho completo de uma execução, do começo ao fim:

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/roadmap-dark.svg">
  <img src="docs/readme/roadmap-light.svg" alt="Roadmap de uso: 1 Abrir o programa e conferir o valor limite ➜ 2 Conectar no GCPJ ➜ 3 Digitar a data (Data Depósito ou Data Solicitação) ➜ 4 Escolher a rotina: Processar Avulsos ou Processar Encerramentos ➜ 5 O robô trabalha, até 5.000 por execução ➜ 6 Conferir a grade antes de fechar" width="100%">
</picture>

| Parada | O que fazer na tela |
| :---: | :--- |
| **1** | Abra o `Aprova_Depositos.exe`. A grade mostra *"O valor limite para aprovação de encerramento é: R$ ..."*. Confira se o valor está certo: ele vale para avulsos **e** encerramentos |
| **2** | Clique em **Conectar GCPJ**. Se aparecer *"GCPJ não localizado, abrindo nova janela."*, faça login no Internet Explorer que abrir |
| **3** | Digite a data no campo certo: **Data Depósito** para avulsos, **Data Solicitação** para encerramentos |
| **4** | Clique em **Processar Avulsos** ou **Processar Encerramentos** |
| **5** | Deixe o robô trabalhar. Ele mesmo fecha os alertas do GCPJ, então **não feche os alertas na mão**. Se a execução chegar a 5.000 itens, ele para e avisa (Controle S5) |
| **6** | Leia a grade. Ela **some quando o programa fecha**: se precisar guardar, tire um print antes |

<details>
<summary><b>Antes da primeira vez</b> &nbsp;·&nbsp; o que a máquina precisa ter e como preencher a tela</summary>
<br>

**Antes de começar, a máquina precisa ter:**

- Windows com **Internet Explorer** e acesso ao GCPJ
- **Microsoft Access Database Engine** (ACE OLEDB 12.0), na mesma arquitetura (32 ou 64 bits) em que o programa roda
- O arquivo `BD_DADOS.accdb` na **mesma pasta** do executável, com o valor limite preenchido na tabela `SYS_VALOR_LIMITE`

Não tem planilha: tudo o que o robô precisa é a data e o valor limite.

| Campo | Exemplo | Regra |
| :--- | :--- | :--- |
| **Data Depósito** | `15/10/2026` | Usada pelo *Processar Avulsos*. Tem que estar escrita **igual** à data que aparece na lista do GCPJ (dia/mês/ano, com barras) |
| **Data Solicitação** | `15/10/2026` | Usada pelo *Processar Encerramentos*. Digite com barras; o robô troca por pontos para comparar com a lista do GCPJ |
| `SYS_VALOR_LIMITE` | `5000` | Primeira coluna da primeira linha, em R$. Só é aprovado item com valor **até** esse número |

> [!TIP]
> Os dois campos de data são independentes. *Processar Avulsos* só olha a **Data Depósito**; *Processar Encerramentos* só olha a **Data Solicitação**. Se o campo usado estiver vazio, a grade avisa e nada é processado.

</details>

<br>

<a id="recebi-uma-ro"></a>

## <img src="docs/readme/ic-ro.svg" width="30" align="top"> Recebi uma RO, e agora?

**A ideia é simples:** o robô só aprova itens da área **CI** (cível), da **data informada** e com valor **até o limite**. Quando chega uma RO, o caminho é olhar a grade (ou o print dela) e conferir o item no GCPJ contra essas regras.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/triagem-dark.svg">
  <img src="docs/readme/triagem-light.svg" alt="Triagem de RO: 1 Chegou uma RO sobre um depósito ➜ 2 Olhar a grade ou o print da execução ➜ 3 Conferir as regras: área CI, data e valor ➜ resultado verde (deu certo, nada a fazer), amarelo (alguém precisa olhar) ou vermelho (corrigir e rodar de novo)" width="100%">
</picture>

> [!NOTE]
> **Exemplo:** chega uma RO dizendo que um depósito avulso de 15/10/2026 não foi aprovado. A grade mostra `Depósitos avulsos TED aprovados com sucesso!`, mas essa frase aparece **sempre** no fim da rotina. No GCPJ, o depósito continua aguardando aprovação e o valor dele é maior que o limite mostrado na abertura. Pelo quadro *"O item ficou para trás"*, isso é esperado: aprovar manualmente ou combinar com a área um novo limite.

#### 🟢 Deu certo: não precisa fazer nada

| O que está escrito na grade | O que quer dizer |
| :--- | :--- |
| Bem vindo ao aprova depósitos<br>Conecte ao GCPJ para iniciar o processamento | O programa abriu normalmente |
| O valor limite para aprovação de encerramento é: R$ ... | Leu o limite em R$ da base. Vale para avulsos e encerramentos |
| Localizando GCPJ....<br>GCPJ localizado, prossiga com o procedimento | Achou o GCPJ aberto e já pode processar |
| Depósitos avulsos TED aprovados com sucesso!<br>Depósitos avulsos crédito em conta aprovados com sucesso!<br>Aprovados encerramentos por TED<br>Aprovados os encerramentos por Crédito em Conta Bradesco! | A rotina **terminou** de percorrer a lista. Atenção: a frase aparece mesmo que nenhum item tenha sido aprovado |

#### 🟡 Precisa que alguém olhe

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| GCPJ não localizado, abrindo nova janela. | Não havia GCPJ aberto e o robô abriu um Internet Explorer novo | Fazer login nessa janela antes de processar |
| Aviso **Processamento Limitado - Controle S5**<br>Controle S5: limite de 5.000 registros atingido. Processamento interrompido. | A execução (o clique) chegou a 5.000 itens e parou. O aviso aparece uma vez só; se foi na rotina de TED, a de crédito em conta para logo no primeiro item. O que sobrou continua aguardando aprovação no GCPJ | Normal. Clicar de novo para continuar |

#### 🔴 Não foi feito: corrigir e rodar de novo

| O que aparece | O que quer dizer | O que fazer |
| :--- | :--- | :--- |
| ATENÇÃO! Obrigatório o preenchimento da data do depósito! | O campo de data usado pela rotina está vazio. Nos encerramentos o texto fala "depósito", mas o campo é a **Data Solicitação** | Preencher a data certa e clicar de novo |
| Janela com **erro!** | O robô não achou um botão na tela do GCPJ (página não carregou, sessão caiu ou a tela mudou). Depois do OK ele segue, sem garantia de ter aprovado | Conferir o item no GCPJ. Se repetir, fechar e rodar de novo |

#### O item ficou para trás e nenhuma mensagem explica

| O que conferir no GCPJ | Por que o robô pulou | O que fazer |
| :--- | :--- | :--- |
| A área do item **não é CI** | O robô só aprova itens cíveis | Fora do escopo do robô: tratar manualmente |
| A data é diferente da digitada | A data é comparada como texto, letra por letra | Rodar de novo com a data exatamente como está no GCPJ |
| O valor é **maior** que o limite | Avulsos: nem são selecionados. Encerramentos: o robô abre, confere o valor e volta sem aprovar | Aprovar manualmente ou rever o valor em `SYS_VALOR_LIMITE` com a área |
| Depósito avulso **solicitado hoje** | O robô pula avulsos com a data de hoje na coluna de solicitação | Rodar de novo em outro dia |

> [!IMPORTANT]
> **A grade não fica salva.** O registro em arquivo `.txt` existe no código, mas está desligado. Ao fechar o programa, todas as mensagens somem. Como uma RO pode chegar dias depois, **tire um print da grade** no fim de cada execução. E lembre: as frases de *"aprovados com sucesso"* só dizem que a rotina terminou; a confirmação de cada item está no próprio GCPJ.

**Problemas antes mesmo de rodar:**

| O que aparece | Causa provável | Solução |
| :--- | :--- | :--- |
| Janela de erro do Windows assim que o programa abre | O `BD_DADOS.accdb` não está na mesma pasta do executável | Copiar a base para a pasta do `Aprova_Depositos.exe` |
| O provedor *Microsoft.ACE.OLEDB.12.0* não está registrado | Falta o Access Database Engine na arquitetura certa | Instalar o Access Database Engine |
| A linha *"O valor limite para aprovação..."* não aparece | A tabela `SYS_VALOR_LIMITE` está vazia. Sem limite, nenhum item passa | Preencher o valor na tabela |
| Janela de erro do Windows ao clicar em processar | O GCPJ não foi conectado antes | Clicar em **Conectar GCPJ** primeiro |
| O robô fica parado, sem linha nova na grade | Está esperando um alerta do GCPJ que não veio (ou que alguém fechou na mão) | Fechar o programa e rodar de novo. O que já foi aprovado sai da lista de pendentes |

<br>

<a id="controle-s5"></a>

## <img src="docs/readme/ic-s5.svg" width="30" align="top"> Controle S5

Exigência do normativo **05.1073** para aplicativos com C10 = Sim (automação que atualiza dados em sistema estruturado). O robô não pode aprovar sem limite no GCPJ, por isso o `C@JX` agora tem o controle.

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/s5-dark.svg">
  <img src="docs/readme/s5-light.svg" alt="Controle S5: a cada item o robô confere se já tratou 5.000 nesta execução; enquanto não chegou, abre o item, aprova no GCPJ e soma 1; ao chegar em 5.000, para, avisa o usuário e escreve na grade" width="100%">
</picture>

O contador é **da execução**, ou seja, de cada clique. Um clique em *Processar Avulsos* ou *Processar Encerramentos* começa do zero, e as duas rotinas do clique (TED e crédito em conta) somam no **mesmo contador**. O robô soma 1 a cada item que ele abre; nos encerramentos isso inclui os itens que ele abre e devolve por estarem acima do valor limite.

Quando o contador chega a 5.000, aparece **uma única vez** o aviso **Processamento Limitado - Controle S5** e a grade recebe *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*. Se isso acontecer ainda na rotina de TED, a de crédito em conta para logo no primeiro item, sem aviso repetido. O que sobrou continua aguardando aprovação no GCPJ para a próxima execução.

| O que mudar | Arquivo | Onde |
| :--- | :--- | :--- |
| **Valor do limite** | `LimitadorS5.cs` | constante `LIMITE_OPERACOES`, linha 33 |
| Mensagem do aviso | `LimitadorS5.cs` | método `LimiteAtingido`, linha 42 |
| Texto da grade | `LimitadorS5.cs` | método `MensagemLog`, linha 54 |
| Contador da execução | `Form1.cs` | campos `qtdOperacoesS5` e `limiteS5Atingido`, linhas 25 e 26 |
| Começo de uma execução (zera o contador) | `Form1.cs` | método `IniciarExecucaoS5`, linha 46. Chamado em `processar_Click` (linha 429) e `encerrar_Click` (linha 436) |
| Checagem do limite (aviso uma vez só) | `Form1.cs` | método `LimiteS5Atingido`, linha 54 |
| Botões escondidos | `Form1.cs` | `if (sender == ...) IniciarExecucaoS5();` nas linhas 86, 174, 401 e 414: só zeram quando clicados direto |
| Checagem dos avulsos TED | `Form1.cs` | `processarAvulsosTED`, bloco `[S5]` na linha 116 |
| Checagem dos avulsos crédito em conta | `Form1.cs` | `processarAvulsosCreditoConta`, bloco `[S5]` na linha 149 |
| Checagem dos encerramentos TED | `Form1.cs` | `aprovarEncerramentoTed`, bloco `[S5]` na linha 215 |
| Checagem dos encerramentos crédito em conta | `Form1.cs` | `aprovarEncerramentoCCBradesco`, bloco `[S5]` na linha 306 |

> [!TIP]
> Para testar sem esperar 5.000 itens: troque `LIMITE_OPERACOES` para `2`, rode um clique com pelo menos 3 itens disponíveis (somando TED e crédito em conta), tire os prints com o relógio do Windows aparecendo e **volte para 5000**. No Visual Studio, **Ctrl+Shift+F** em `[S5]` mostra todos os pontos. Não confunda com `Gl_ValorLimite`, que é o limite de **valor em R$** e já existia. As evidências oficiais estão em [`docs/Evidencias_S5_AprovaDepositos.docx`](docs/Evidencias_S5_AprovaDepositos.docx).

<br>

<a id="visao-tecnica"></a>

## <img src="docs/readme/ic-tecnica.svg" width="30" align="top"> Visão técnica

<details>
<summary><b>Mapa do código</b> &nbsp;·&nbsp; onde fica cada coisa</summary>
<br>

Projeto: `Auto_Encerramento_Plus\Aprova_Depositos.csproj` (namespace `Auto_Encerramento_Plus`)

| Arquivo | Trecho | Linha | Para que serve |
| :--- | :--- | :---: | :--- |
| `Form1.cs` | `btnConectar_Click` | 33 | Botão **Conectar GCPJ** |
| | `IniciarExecucaoS5` / `LimiteS5Atingido` | 46 / 54 | Controle S5: zera o contador do clique e confere o limite |
| | `preencheGrade` | 63 | Escreve uma linha com data e hora na grade |
| | `Form1_Load` | 69 | Lê o valor limite em R$ da `SYS_VALOR_LIMITE` para `Gl_ValorLimite` |
| | `processarAvulsosTED` | 105 | Rotina de avulsos por TED |
| | `processarAvulsosCreditoConta` | 138 | Rotina de avulsos por crédito em conta |
| | `aprovarEncerramentoTed` | 196 | Rotina de encerramentos por TED |
| | `aprovarEncerramentoCCBradesco` | 287 | Rotina de encerramentos por crédito em conta Bradesco |
| | `processar_Click` / `encerrar_Click` | 427 / 434 | Botões **Processar Avulsos** e **Processar Encerramentos** (cada um é uma execução do Controle S5) |
| `Form1.Designer.cs` | `Visible = false` | 110, 147, 158, 169 | Esconde os quatro botões separados |
| `Automacao.cs` | `localizarJanela` / `novaJanela` | 101 / 115 | Acha ou abre o IE do GCPJ |
| | `navegar`, `clicar`, `espera` | 144 / 207 / 251 | Comandos básicos de tela |
| | `mataMsgBox` / `mataPossivelMsgBox` | 281 / 324 | Fecham o alerta *"Mensagem da página da web"* |
| | `selecionarTabelaValor` | 1052 | Marca o primeiro avulso que passa nas regras |
| | `selecionarTabelaValorEncerramento` | 1137 | Marca o primeiro encerramento que passa nas regras |
| `Conexao.cs` | `con` | 12 | Caminho do banco: `BD_DADOS.accdb` ao lado do `.exe` |
| `LimitadorS5.cs` | `LIMITE_OPERACOES` | 33 | Controle S5: valor do limite |

</details>

<details>
<summary><b>Como cada rotina funciona por dentro</b> &nbsp;·&nbsp; passo a passo no GCPJ</summary>
<br>

**Avulsos · TED e crédito em conta**

1. Abre *Depósitos aguardando aprovação* (`depositoAguardAprovAction`, método `carregarTed` ou `carregarCreditoBradesco`).
2. `selecionarTabelaValor` percorre a tabela `tab1` e marca a primeira linha que é **CI**, tem a **data digitada**, valor **até o limite** e **não foi solicitada hoje**.
3. Confere o contador da execução (Controle S5) e soma 1.
4. Clica em `btoDetalhe`, depois em `btoAprov`, e `mataMsgBox` fecha o alerta de confirmação.
5. Se a página não tem item que sirva, vai para a próxima (`paginarFinanceiro('paginarDepositos')`) até a página 100.

**Encerramentos · TED e crédito em conta**

1. Abre *Trâmite de pendências* (`menuTramitePendencias`), entra na pendência `103` e escolhe o tipo de pagamento (`cdTpoPagamento`: 0 = TED, 1 = crédito em conta).
2. `selecionarTabelaValorEncerramento` marca a primeira linha que é **CI**, tem a **data de solicitação** (com pontos no lugar das barras) e não está na lista de ignorados.
3. Confere o contador da execução (Controle S5) e soma 1.
4. Clica em `btoDetalhar` e lê o valor: `vlDepositoComplementar` se existir e for diferente de zero, senão `vlBaseEncerramento`.
5. **Valor até o limite:** `btoSalvar` duas vezes, fecha o pop-up de IR (`traEncerrRecolIR`), `btoContinuar` e `btoAprovar`. Uma thread paralela (`mataMensagem`) ajuda a fechar os alertas.
6. **Valor acima do limite:** guarda o número do processo numa lista de ignorados (só na memória) e clica em `btoVoltar`.
7. Sem item na página, pagina com `paginarEncerramento('paginar')` até a página 200 (TED) ou 80 (crédito). Depois de cada item, volta a contar da página 2.

</details>

<details>
<summary><b>Banco de dados</b> &nbsp;·&nbsp; tabelas do Access</summary>
<br>

| Objeto | Tipo | Conteúdo |
| :--- | :--- | :--- |
| `SYS_VALOR_LIMITE` | Tabela | Valor limite em R$. O robô lê a **primeira coluna da primeira linha** como número (`GetDouble`) |

É a única tabela que o programa usa. Ele não grava nada no banco.

</details>

<details>
<summary><b>Quero mudar X, onde vou?</b></summary>
<br>

| Quero... | Vá em |
| :--- | :--- |
| Mudar o limite do Controle S5 | `LimitadorS5.cs` ➜ `LIMITE_OPERACOES` |
| Mudar o que conta como uma execução | `Form1.cs` ➜ chamadas de `IniciarExecucaoS5()` |
| Mudar o limite de valor em R$ | Tabela `SYS_VALOR_LIMITE` no `BD_DADOS.accdb` |
| Mudar as regras de escolha do item (CI, data, valor) | `Automacao.cs` ➜ `selecionarTabelaValor` / `selecionarTabelaValorEncerramento` |
| Mudar até que página o robô procura | `Form1.cs` ➜ `while (contagem <= ...)` de cada rotina (linhas 112, 145, 210 e 301) |
| Mostrar os quatro botões separados | `Form1.Designer.cs` ➜ `Visible = false` nas linhas 110, 147, 158 e 169 |
| Mudar os textos da grade | `Form1.cs` ➜ chamadas `preencheGrade(...)` |
| Religar o log em `.txt` | `Form1.cs` ➜ linhas comentadas com `//sw` |
| Mudar o endereço do GCPJ | `Form1.cs` ➜ procure `intranet85.net.bradesco.com.br/gcpj` |

</details>

<details>
<summary><b>Pontos de atenção</b> &nbsp;·&nbsp; o que já se sabe e ainda não foi mexido</summary>
<br>

- **"Aprovados com sucesso" sem conferir nada.** As frases das linhas 101, 190, 409 e 424 do `Form1.cs` são escritas sempre que a rotina termina, mesmo sem nenhum item aprovado ou quando o Controle S5 parou a rotina. Não existe contador de aprovados.
- **A grade não é salva.** O log em `.txt` está comentado no `Form1.cs` (linhas que começam com `//sw`, a primeira na linha 95). Depois de fechar o programa não há como saber o que foi aprovado, só pelo GCPJ.
- **Pode travar esperando alerta.** `mataMsgBox` (`Automacao.cs`, linha 281) fica em laço até aparecer a janela *"Mensagem da página da web"*. É usado depois de cada aprovação de avulso (`Form1.cs`, linhas 125 e 159). Se o alerta não vier, ou alguém fechar na mão, o robô para ali para sempre.
- **Não confere se o GCPJ está conectado.** Se clicar em processar antes de *Conectar GCPJ*, o `espera()` acessa uma janela que não existe e o programa dá erro.
- **Não sabe quando a lista acabou.** Sem item na página, continua pedindo páginas até 100 (avulsos), 200 (encerramento TED) ou 80 (encerramento crédito), mesmo que a lista já tenha terminado.
- **Mensagem genérica "erro!".** `clicar` (`Automacao.cs`, linha 223) não diz qual botão falhou, e quem chama ignora a falha e segue.
- **Textos trocados.** Nos encerramentos, o aviso de campo vazio fala "data do depósito" (linhas 178 e 418), mas o campo é a *Data Solicitação*. Na abertura, a linha 79 fala "aprovação de encerramento", mas o limite vale para avulsos também.
- **Arquivos que não deveriam estar no Git.** As pastas `bin`, `obj` e `.vs` estão versionadas, inclusive dois logs antigos (`bin\Debug\18_10_2019.txt` e `21_10_2019.txt`) com números de processo e valores.
- **Código herdado sem uso.** `Automacao.cs` tem funções de outros robôs (anexos, cadastro de PF/PJ) que este programa não chama.

</details>

<br>

<a id="roadmap-do-projeto"></a>

## <img src="docs/readme/ic-projeto.svg" width="30" align="top"> Roadmap do projeto

<picture>
  <source media="(prefers-color-scheme: dark)" srcset="docs/readme/timeline-dark.svg">
  <img src="docs/readme/timeline-light.svg" alt="Roadmap do projeto: 10/2025 repositório criado no GitHub; 12/2025 primeiro commit do código; 10/2026 Controle S5 e documentação nova (agora); 12/2026 prazo do normativo 05.1073; sugerido: contar o que foi aprovado" width="100%">
</picture>

<details>
<summary><b>Histórico de alterações</b></summary>
<br>

| Data | Autor | Alteração |
| :--- | :--- | :--- |
| 10/2025 | vogon-fleet-app (bot) | Criação do repositório e do `CODEOWNERS` via Terramate |
| 12/2025 | Daniela Chirinian | Primeiro commit: código migrado para o GitHub |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LimitadorS5.cs`) e novo README |

</details>

<br>

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
