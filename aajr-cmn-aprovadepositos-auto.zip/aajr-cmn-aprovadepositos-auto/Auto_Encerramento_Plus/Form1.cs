﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Threading;
using System.IO;

namespace Auto_Encerramento_Plus
{
    public partial class Form1 : Form
    {
        double Gl_ValorLimite;
        //StreamWriter sw;

        // [S5] Controle S5: contador da execução atual. Fica aqui na classe (e não dentro de cada rotina)
        //      porque um clique em "Processar Avulsos" roda TED + Crédito em Conta, e um clique em
        //      "Processar Encerramentos" roda TED + Crédito em Conta Bradesco. Assim o limite vale
        //      para o clique inteiro, somando as duas rotinas (ver IniciarExecucaoS5 e LimiteS5Atingido).
        int qtdOperacoesS5 = 0;
        bool limiteS5Atingido = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, EventArgs e)
        {
            preencheGrade("Localizando GCPJ....");
            if (Automacao.localizarJanela("GCPJ") == false)
            {
                preencheGrade("GCPJ não localizado, abrindo nova janela.");
                Automacao.novaJanela("https://intranet85.net.bradesco.com.br/gcpj/");

            }
            preencheGrade("GCPJ localizado, prossiga com o procedimento");
        }

        // [S5] Começa uma nova execução: zera o contador do Controle S5
        private void IniciarExecucaoS5()
        {
            qtdOperacoesS5 = 0;
            limiteS5Atingido = false;
        }

        // [S5] Confere o limite antes de cada aprovação. O aviso aparece uma única vez por execução;
        //      se a primeira rotina do clique já atingiu o limite, a segunda para logo no primeiro item.
        private bool LimiteS5Atingido()
        {
            if (limiteS5Atingido) return true;
            if (!LimitadorS5.LimiteAtingido(qtdOperacoesS5)) return false;
            limiteS5Atingido = true;
            preencheGrade(LimitadorS5.MensagemLog());
            return true;
        }

        private void preencheGrade(String texto)
        {
            Grade.Items.Add(DateTime.Now.ToShortDateString() + " - " + DateTime.Now.ToShortTimeString() + " " + texto);
            Grade.SelectedIndex = Grade.Items.Count - 1;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            preencheGrade("Bem vindo ao aprova depósitos");
            preencheGrade("Conecte ao GCPJ para iniciar o processamento");

            OleDbDataReader dr = Conexao.consultar("SELECT * FROM SYS_VALOR_LIMITE");
            if (dr.HasRows)
            {
                dr.Read();
                Gl_ValorLimite = dr.GetDouble(0);
                preencheGrade("O valor limite para aprovação de encerramento é: R$ " + dr.GetDouble(0).ToString("N"));
            }
            dr.Close();
        }

        private void btnProcessar_Click(object sender, EventArgs e)
        {
            if (sender == btnProcessar) IniciarExecucaoS5(); // [S5] clique direto neste botão = nova execução

            if (txtDataDeposito.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }

            //criando arquivo de log
            //sw = new StreamWriter(Application.StartupPath + "\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt", true);
            //sw.AutoFlush = true;
            //sw.WriteLine("++++++++++++++INICIO DO PROCESSAMENTO DEPÓSITOS AVULSOS+++++++++++++++++++");

            //sw.WriteLine("==APROVAÇÃO DE DEPÓSITOS AVULSO - TED==");
            processarAvulsosTED();
            preencheGrade("Depósitos avulsos TED aprovados com sucesso!");
            //sw.WriteLine("==APROVAÇÃO DE DEPÓSITOS AVULSO - CRÉDITO EM CONTA==");
        }

        private void processarAvulsosTED()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/depositoAguardAprovAction?metodo=carregarTed&origem=");
            Automacao.espera();

            int contagem = 2;

            while (contagem <= 100)
            {
                if (Automacao.selecionarTabelaValor("tab1", txtDataDeposito.Text, Gl_ValorLimite))
                {
                    // [S5] Limitador de operações: para ao atingir o limite da execução (ver LimiteS5Atingido)
                    if (LimiteS5Atingido()) break;
                    qtdOperacoesS5++;

                    //selecionado depósito
                    Automacao.clicar("btoDetalhe");
                    Automacao.espera();
                    //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + Automacao.retornaValue("vrTotalGridComposicao"));
                    Automacao.clicar("btoAprov");
                    Automacao.mataMsgBox();
                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['paginaDeposito'].value=" + contagem + "");
                    Automacao.ExecutarJS("paginarFinanceiro('paginarDepositos')");
                    Automacao.espera();
                    contagem++;
                 }
            }
        }

        private void processarAvulsosCreditoConta()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/depositoAguardAprovAction?metodo=carregarCreditoBradesco&origem=");
            Automacao.espera();

            int contagem = 1;

            while (contagem <= 100)
            {
                if (Automacao.selecionarTabelaValor("tab1", txtDataDeposito.Text, Gl_ValorLimite))
                {
                    // [S5] Limitador de operações: para ao atingir o limite da execução (ver LimiteS5Atingido)
                    if (LimiteS5Atingido()) break;
                    qtdOperacoesS5++;

                    //selecionado depósito
                    Automacao.clicar("btoDetalhe");
                    Automacao.espera();
                    //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + Automacao.retornaValue("vrTotalGridComposicao"));

                    Automacao.clicar("btoAprov");
                    Automacao.mataMsgBox();
                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['paginaDeposito'].value=" + contagem + "");
                    Automacao.ExecutarJS("paginarFinanceiro('paginarDepositos')");
                    Automacao.espera();
                    contagem++;
                }
            }
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            if (sender == toolStripButton1) IniciarExecucaoS5(); // [S5] clique direto neste botão = nova execução

            if (txtDataSolicitacao.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }

            //criando arquivo de log
            //sw = new StreamWriter(Application.StartupPath + "\\" + DateTime.Now.ToShortDateString().Replace("/", "_") + ".txt", true);
            //sw.AutoFlush = true;
            //sw.WriteLine("++++++++++++++INICIO DO PROCESSAMENTO ENCERRAMENTOS+++++++++++++++++++");

            //sw.WriteLine("==APROVAÇÃO DE ENCERRAMENTOS - TED==");
            
            aprovarEncerramentoTed();
            preencheGrade("Aprovados encerramentos por TED");

            //sw.WriteLine("==APROVAÇÃO DE ENCERRAMENTOS - CREDITO EM CONTA BRADESCO==");
            //sw.Close();
        }

        public void aprovarEncerramentoTed()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/menuTramitePendencias?metodo=carregar&origem=tramite");
            Automacao.espera();
            Automacao.ExecutarJS("enviarPendencia(103)");
            Automacao.espera();

            Automacao.selecionarRadio(0, "cdTpoPagamento");
            Automacao.clicar("btoDetalhar");
            Automacao.espera();

            int contagem = 2;
            List<double> ignorarN = new List<double>();

            while (contagem <= 200)
            {
                //estamos na tela de aprovação de encerramento com TED.
                if (Automacao.selecionarTabelaValorEncerramento("tab1", txtDataSolicitacao.Text, Gl_ValorLimite, ignorarN))
                {
                    // [S5] Limitador de operações: para ao atingir o limite da execução (ver LimiteS5Atingido)
                    if (LimiteS5Atingido()) break;
                    qtdOperacoesS5++;

                    Automacao.clicar("btoDetalhar");
                    Automacao.espera();

                    Double valorPagamento = 0.0;

                    //verificando se existe valor base complementar
                    try
                    {
                        Automacao.campoExiste("valoresEncerramentoVO.vlDepositoComplementar");
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlDepositoComplementar"));
                    }
                    catch (Exception)
                    {
                        //nao existe valor base complementar.
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    if (valorPagamento == 0)
                    {
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    //verificando o valor....
                    if (valorPagamento <= Gl_ValorLimite)
                    {

                        //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + valorPagamento.ToString("N"));
                        Thread tr1 = new Thread(mataMensagem);
                        tr1.Start();
                        //estamos no valor para a provar... se não vamos voltar.
                        Automacao.clicar("btoSalvar");
                        //7286997
                        Automacao.espera();
                        Automacao.clicar("btoSalvar");
                        Automacao.mataPossivelMsgBox();
                        Thread.Sleep(750);
                        Automacao.espera();
                        Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrRecolIR?metodo=carregPopup");
                        Automacao.clicar("btoContinuar");
                        Automacao.espera();
                        Automacao.clicar("btoAprovar");
                        Automacao.mataPossivelMsgBox();
                        Automacao.mataPossivelMsgBox();
                        contagem = 2;

                    }
                    else
                    {
                        //voltar
                        ignorarN.Add(double.Parse(Automacao.RetornaConteudo("lnk1", "a")));
                        Automacao.clicar("btoVoltar");
                        Automacao.espera();

                        //resetando pagina
                        contagem = 2;
                    }

                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['pagina'].value=" + contagem + ";paginarEncerramento('paginar')");
                    Automacao.espera();
                    contagem++;
                }
            }
        }

        public void aprovarEncerramentoCCBradesco()
        {
            Automacao.navegar("https://intranet85.net.bradesco.com.br/gcpj/servlet/menuTramitePendencias?metodo=carregar&origem=tramite");
            Automacao.espera();
            Automacao.ExecutarJS("enviarPendencia(103)");
            Automacao.espera();

            Automacao.selecionarRadio(1, "cdTpoPagamento");
            Automacao.clicar("btoDetalhar");
            Automacao.espera();

            int contagem = 2;
            List<double> ignorarN = new List<double>();

            while (contagem <= 80)
            {
                //estamos na tela de aprovação de encerramento com TED.
                if (Automacao.selecionarTabelaValorEncerramento("tab1", txtDataSolicitacao.Text, Gl_ValorLimite, ignorarN))
                {
                    // [S5] Limitador de operações: para ao atingir o limite da execução (ver LimiteS5Atingido)
                    if (LimiteS5Atingido()) break;
                    qtdOperacoesS5++;

                    Automacao.clicar("btoDetalhar");
                    Automacao.espera();

                    Double valorPagamento = 0.0;

                    //verificando se existe valor base complementar
                    try
                    {
                        Automacao.campoExiste("valoresEncerramentoVO.vlDepositoComplementar");
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlDepositoComplementar"));
                    }
                    catch (Exception)
                    {
                        //nao existe valor base complementar.
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    if (valorPagamento == 0)
                    {
                        valorPagamento = double.Parse(Automacao.retornaValue("valoresEncerramentoVO.vlBaseEncerramento"));
                    }

                    //verificando o valor....
                    if (valorPagamento <= Gl_ValorLimite)
                    {
                        //sw.Write(Automacao.textoPrimeiroObjeto("a") + " - R$ " + valorPagamento.ToString("N"));
                        Thread tr1 = new Thread(mataMensagem);
                        tr1.Start();
                        //estamos no valor para a provar... se não vamos voltar.
                        Automacao.clicar("btoSalvar");
                        //7286997
                        Automacao.espera();
                        Automacao.clicar("btoSalvar");
                        Automacao.mataPossivelMsgBox();
                        Thread.Sleep(750);
                        Automacao.espera();
                        Automacao.fecharPopUp("https://intranet85.net.bradesco.com.br/gcpj/servlet/traEncerrRecolIR?metodo=carregPopup");
                        Automacao.clicar("btoContinuar");
                        Automacao.espera();
                        Automacao.clicar("btoAprovar");
                        Automacao.mataPossivelMsgBox();
                        Automacao.mataPossivelMsgBox();
                        contagem = 2;

                    }
                    else
                    {
                        //voltar
                        ignorarN.Add(double.Parse(Automacao.RetornaConteudo("lnk1", "a")));
                        Automacao.clicar("btoVoltar");
                        Automacao.espera();

                        //resetando pagina
                        contagem = 2;
                    }

                }
                else
                {
                    //nao achei nada nesta lista
                    Automacao.ExecutarJS("document.forms[0].elements['pagina'].value=" + contagem + ";paginarEncerramento('paginar')");
                    Automacao.espera();
                    contagem++;
                }
            }
        }

        public void mataMensagem()
        {
            Automacao.mataPossivelMsgBox();
        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                //sw.Close();
            }
            catch (Exception)
            {

            }
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (sender == toolStripButton2) IniciarExecucaoS5(); // [S5] clique direto neste botão = nova execução

            if (txtDataDeposito.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }
            processarAvulsosCreditoConta();
            preencheGrade("Depósitos avulsos crédito em conta aprovados com sucesso!");
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (sender == toolStripButton3) IniciarExecucaoS5(); // [S5] clique direto neste botão = nova execução

            if (txtDataSolicitacao.Text.Length == 0)
            {
                preencheGrade("ATENÇÃO! Obrigatório o preenchimento da data do depósito!");
                return;
            }
            //sw.WriteLine("==APROVAÇÃO DE ENCERRAMENTOS - CREDITO EM CONTA BRADESCO==");

            aprovarEncerramentoCCBradesco();
            preencheGrade("Aprovados os encerramentos por Crédito em Conta Bradesco!");
        }

        private void processar_Click(object sender, EventArgs e)
        {
            IniciarExecucaoS5(); // [S5] as duas rotinas abaixo dividem o mesmo limite do Controle S5
            btnProcessar_Click(sender, e);
            toolStripButton2_Click(sender, e);
        }

        private void encerrar_Click(object sender, EventArgs e)
        {
            IniciarExecucaoS5(); // [S5] as duas rotinas abaixo dividem o mesmo limite do Controle S5
            toolStripButton1_Click(sender, e);
            toolStripButton3_Click(sender, e);

        }
    }
}
