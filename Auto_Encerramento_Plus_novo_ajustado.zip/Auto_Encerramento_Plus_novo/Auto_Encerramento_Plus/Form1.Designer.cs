﻿namespace Auto_Encerramento_Plus
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.btnConectar = new System.Windows.Forms.ToolStripButton();
            this.btnProcessar = new System.Windows.Forms.ToolStripButton();
            this.btnDistribuir = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.txtMaquina = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.txtLogin = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.txtPassword = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cmdGCPJCompleto = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Grade = new System.Windows.Forms.ListBox();
            this.CBSelecionaProcessamento = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BarraProgresso = new System.Windows.Forms.ProgressBar();
            this.toolStrip1.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.btnConectar,
            this.btnProcessar,
            this.btnDistribuir,
            this.toolStripSeparator1,
            this.txtMaquina,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripLabel2,
            this.txtLogin,
            this.toolStripSeparator3,
            this.toolStripLabel3,
            this.txtPassword,
            this.toolStripSeparator4,
            this.cmdGCPJCompleto,
            this.toolStripSeparator5});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1169, 27);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked);
            // 
            // btnConectar
            // 
            this.btnConectar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnConectar.Image = ((System.Drawing.Image)(resources.GetObject("btnConectar.Image")));
            this.btnConectar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnConectar.Name = "btnConectar";
            this.btnConectar.Size = new System.Drawing.Size(107, 24);
            this.btnConectar.Text = "Conectar GCPJ";
            this.btnConectar.Click += new System.EventHandler(this.btnConectar_Click);
            // 
            // btnProcessar
            // 
            this.btnProcessar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnProcessar.Image = ((System.Drawing.Image)(resources.GetObject("btnProcessar.Image")));
            this.btnProcessar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnProcessar.Name = "btnProcessar";
            this.btnProcessar.Size = new System.Drawing.Size(75, 28);
            this.btnProcessar.Text = "Processar";
            this.btnProcessar.Click += new System.EventHandler(this.btnProcessar_Click);
            // 
            // btnDistribuir
            // 
            this.btnDistribuir.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.btnDistribuir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.btnDistribuir.Image = ((System.Drawing.Image)(resources.GetObject("btnDistribuir.Image")));
            this.btnDistribuir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.btnDistribuir.Name = "btnDistribuir";
            this.btnDistribuir.Size = new System.Drawing.Size(142, 28);
            this.btnDistribuir.Text = "Distribuir Maquinas";
            this.btnDistribuir.Click += new System.EventHandler(this.btnDistribuir_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // txtMaquina
            // 
            this.txtMaquina.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.txtMaquina.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaquina.Name = "txtMaquina";
            this.txtMaquina.Size = new System.Drawing.Size(32, 31);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(70, 28);
            this.toolStripLabel1.Text = "Maquina:";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(46, 28);
            this.toolStripLabel2.Text = "Login";
            // 
            // txtLogin
            // 
            this.txtLogin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(132, 31);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 31);
            // 
            // toolStripLabel3
            // 
            this.toolStripLabel3.Name = "toolStripLabel3";
            this.toolStripLabel3.Size = new System.Drawing.Size(70, 28);
            this.toolStripLabel3.Text = "Password";
            // 
            // txtPassword
            // 
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(132, 31);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 31);
            // 
            // cmdGCPJCompleto
            // 
            this.cmdGCPJCompleto.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.cmdGCPJCompleto.Image = ((System.Drawing.Image)(resources.GetObject("cmdGCPJCompleto.Image")));
            this.cmdGCPJCompleto.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cmdGCPJCompleto.Name = "cmdGCPJCompleto";
            this.cmdGCPJCompleto.Size = new System.Drawing.Size(177, 28);
            this.cmdGCPJCompleto.Text = "Conectar GCPJ Completo";
            this.cmdGCPJCompleto.Click += new System.EventHandler(this.cmdGCPJCompleto_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 31);
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 532);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1169, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(1149, 16);
            this.toolStripStatusLabel1.Spring = true;
            // 
            // Grade
            // 
            this.Grade.FormattingEnabled = true;
            this.Grade.ItemHeight = 16;
            this.Grade.Location = new System.Drawing.Point(16, 34);
            this.Grade.Margin = new System.Windows.Forms.Padding(4);
            this.Grade.Name = "Grade";
            this.Grade.Size = new System.Drawing.Size(1136, 340);
            this.Grade.TabIndex = 2;
            // 
            // CBSelecionaProcessamento
            // 
            this.CBSelecionaProcessamento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.CBSelecionaProcessamento.FormattingEnabled = true;
            this.CBSelecionaProcessamento.Location = new System.Drawing.Point(16, 415);
            this.CBSelecionaProcessamento.Margin = new System.Windows.Forms.Padding(4);
            this.CBSelecionaProcessamento.Name = "CBSelecionaProcessamento";
            this.CBSelecionaProcessamento.Size = new System.Drawing.Size(160, 24);
            this.CBSelecionaProcessamento.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(16, 395);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Tipo Processamento";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // BarraProgresso
            // 
            this.BarraProgresso.Location = new System.Drawing.Point(16, 476);
            this.BarraProgresso.Margin = new System.Windows.Forms.Padding(4);
            this.BarraProgresso.Name = "BarraProgresso";
            this.BarraProgresso.Size = new System.Drawing.Size(343, 28);
            this.BarraProgresso.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1169, 554);
            this.Controls.Add(this.BarraProgresso);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CBSelecionaProcessamento);
            this.Controls.Add(this.Grade);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Auto Encerramento Plus";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ListBox Grade;
        private System.Windows.Forms.ToolStripButton btnConectar;
        private System.Windows.Forms.ToolStripButton btnProcessar;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox txtMaquina;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton btnDistribuir;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        internal System.Windows.Forms.ToolStripLabel toolStripLabel2;
        internal System.Windows.Forms.ToolStripTextBox txtLogin;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        internal System.Windows.Forms.ToolStripTextBox txtPassword;
        internal System.Windows.Forms.ToolStripLabel toolStripLabel3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripButton cmdGCPJCompleto;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ComboBox CBSelecionaProcessamento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ProgressBar BarraProgresso;
    }
}

