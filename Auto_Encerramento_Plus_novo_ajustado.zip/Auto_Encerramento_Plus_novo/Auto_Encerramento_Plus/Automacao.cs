﻿using SHDocVw;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Automation;
using System.Windows.Forms;



namespace Auto_Encerramento_Plus
{
    static class Automacao
    {

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr SendMessage(IntPtr hWnd, UInt32 Msg, int wParam, IntPtr lParam);

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        private static extern IntPtr FindWindowByCaption(IntPtr zero, String lpWindowName);

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = false)]
        private static extern IntPtr FindWindowEx(IntPtr parentHandle, IntPtr childAfter, String lclassName, String windowTitle);
        

        public const uint WM_CLOSE = 0x0010;
        public const uint BM_CLICK = 0x00F5;
        public const UInt32 WM_ACTIVATE = 0x0006;
        public const int WA_ACTIVE = 1;

        public static AutomationElement aeDesktop;
        public static AutomationElement frmSelecionar;
        public static AutomationElement arquivo;
        public static AutomationElement btnAbrir;

        public static ValuePattern arquivoTexto;

        public static InvokePattern btnAbrirClick;

        public static bool telaCompleta { set; get; }
        static InternetExplorer instancia { set; get; }
        static InternetExplorer instAnexo { set; get; }
        static InternetExplorer instCad { set; get; }

        public static string textMsgBox;
        public static bool fecharPopUp(string url)
        {
            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationURL.Contains(url))
                {
                    ie.Quit();
                }
            }
            return true;
        }


        public static bool localizarJanela(String nome_janela)
        {
            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationName.IndexOf(nome_janela) >= 0)
                {
                    instancia = ie;
                    instancia.Visible = true;
                    return true;
                }
            }
            return false;
        }

        public static bool localizarJanelaURL(String nome_janela)
        {
            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationURL.IndexOf(nome_janela) >= 0)
                {
                    instancia = ie;
                    instancia.Visible = true;
                    return true;
                }
            }
            return false;
        }
        public static bool novaJanela(String url)
        {
            instancia = new InternetExplorer();
            try
            {
                instancia.Navigate(url);
            }
            catch (Exception)
            {

                return false;
            }

            return true;
        }

        public static bool setaVisibilidade(Boolean visibilidade)
        {
            try
            {
                instancia.Visible = visibilidade;
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public static bool navegar(String url)
        {
            try
            {
                if (telaCompleta)
                {
                    instancia.Document.frames(2).navigate2(url);
                }
                else
                {
                    instancia.Navigate2(url);
                }

            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public static bool setaValorNome(String nome_componente, String valor)
        {
            try
            {
                if (telaCompleta)
                {
                    instancia.Document.frames(2).Document.forms(0).elements(nome_componente).innertext = valor;
                }
                else
                {
                    instancia.Document.forms(0).elements(nome_componente).innertext = valor;
                }

            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public static bool setaValorId(String id_componente, String valor)
        {
            try
            {
                if (telaCompleta)
                {
                    instancia.Document.frames(2).Document.getElementById(id_componente).innertext = valor;
                }
                else
                {
                    instancia.Document.getElementById(id_componente).innertext = valor;
                }

            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }

        public static bool clicar(String botao)
        {
            try
            {
                if (telaCompleta)
                {
                    instancia.Document.frames(2).Document.forms(0).elements(botao).click();
                }
                else
                {
                    instancia.Document.forms(0).elements(botao).click();
                }

            }
            catch (Exception)
            {
                //MessageBox.Show("erro!");
                return false;
            }
            return true;
        }

        public static bool clicarTag()
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.all.tags("a");
            var i = 0;
            string nome = "";

            for (i = 0; i <= Tabelas.length; i += 1)
            {
                //Tabelas.item(i).className == "lnkTab1"
                if (Tabelas.item(i).className == "lnk1")
                {
                    if (i == 4)
                    {
                        Tabelas.item(i).click();
                        return true;
                    }
                }

            }

            return false;

        }

        public static bool onClick(String botao)
        {
            try
            {
                if (telaCompleta)
                {
                    instancia.Document.frames(2).Document.forms(0).elements(botao).onclick();
                }
                else
                {
                    instancia.Document.forms(0).elements(botao).onclick();
                }

            }
            catch (Exception)
            {

                return false;
            }
            return true;
        }

        public static bool espera()
        {
            Thread.Sleep(1000);
            while ((instancia.ReadyState == tagREADYSTATE.READYSTATE_INTERACTIVE) || (instancia.ReadyState == tagREADYSTATE.READYSTATE_LOADING) || (instancia.ReadyState == tagREADYSTATE.READYSTATE_UNINITIALIZED))
            {
                //aguarde
            }

            while (instancia.Busy)
            {
                //aguarde
            }
            return true;
        }

        public static bool esperaAnexo()
        {
            Thread.Sleep(500);
            while ((instAnexo.ReadyState == tagREADYSTATE.READYSTATE_INTERACTIVE) || (instAnexo.ReadyState == tagREADYSTATE.READYSTATE_LOADING) || (instAnexo.ReadyState == tagREADYSTATE.READYSTATE_UNINITIALIZED))
            {
                //aguarde
            }

            while (instAnexo.Busy)
            {
                //aguarde
            }
            return true;
        }

        public static bool mataMsgBoxSalvaCadastro()
        {
            int vqtdeLooping = 0;
            IntPtr winHwnd = IntPtr.Zero;
            while (winHwnd == IntPtr.Zero)
            {
                winHwnd = FindWindowByCaption(IntPtr.Zero, "Mensagem da página da web");
                vqtdeLooping++;
                if (vqtdeLooping > 100000)
                {
                    vqtdeLooping = 1;
                    Thread.Sleep(2500);
                    return false;
                }
            }

            Thread.Sleep(1000);
            IntPtr btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK");
            SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, IntPtr.Zero);
            SendMessage(btn, BM_CLICK, 0, IntPtr.Zero);
            return true;
        }

        public static bool mataMsgBox()
        {
            IntPtr winHwnd = IntPtr.Zero;
            while (winHwnd == IntPtr.Zero)
            {
                winHwnd = FindWindowByCaption(IntPtr.Zero, "Mensagem da página da web");
            }

            Thread.Sleep(1000);
            IntPtr btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK");
            SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, IntPtr.Zero);
            SendMessage(btn, BM_CLICK, 0, IntPtr.Zero);
            return true;
        }

        public static string lerMsgBox()
        {
            int vqtdeLooping = 0;
            IntPtr winHwnd = IntPtr.Zero;
            while (winHwnd == IntPtr.Zero)
            {
                winHwnd = FindWindowByCaption(IntPtr.Zero, "Mensagem da página da web");
                vqtdeLooping++;
                if (vqtdeLooping > 100000)
                {
                    vqtdeLooping = 1;
                    Thread.Sleep(2500);
                    return "";
                }
            }
            Thread.Sleep(1000);

            AutomationElement janela;
            AutomationElementCollection textos;
            String retorno = "";

            janela = AutomationElement.FromHandle(winHwnd);
            textos = janela.FindAll(TreeScope.Children, new PropertyCondition(AutomationElement.ClassNameProperty, "Static"));

            foreach (AutomationElement item in textos)
            {
                if (item.Current.LocalizedControlType.Equals("text"))
                {
                    retorno += item.Current.Name.ToString().Replace("\n","");
                }
            }
            
            return retorno;
        }


        public static bool mataPossivelMsgBox()
        {
            Thread.Sleep(1000);
            IntPtr winHwnd = IntPtr.Zero;
            while (winHwnd == IntPtr.Zero)
            {
                winHwnd = FindWindowByCaption(IntPtr.Zero, "Mensagem da página da web");
                if (instancia.Busy == false)
                {
                    Thread.Sleep(1000);
                    return false;
                }
            }

            textMsgBox = lerMsgBox();

            Thread.Sleep(1000);
            IntPtr btn = FindWindowEx(winHwnd, IntPtr.Zero, "Button", "OK");
            SendMessage(btn, WM_ACTIVATE, WA_ACTIVE, IntPtr.Zero);
            SendMessage(btn, BM_CLICK, 0, IntPtr.Zero);
            return true;
        }

        public static bool ExecutarJS(String comando)
        {
            if (telaCompleta)
            {
                instancia.Document.frames(2).Document.parentWindow.execScript(comando, "JavaScript");
            }
            else
            {
                instancia.Document.parentWindow.execScript(comando, "JavaScript");
            }
            return true;
        }

        public static String retornaValor(String nome)
        {
            if (telaCompleta)
            {
                return instancia.Document.frames(2).Document.forms(0).elements(nome).innertext();
            }
            else
            {
                return instancia.Document.forms(0).elements(nome).innertext();
            }

        }

        public static String retornaValue(String nome)
        {
            if (telaCompleta)
            {
                return instancia.Document.frames(2).Document.forms(0).elements(nome).value();
            }
            else
            {
                return instancia.Document.forms(0).elements(nome).value();
            }

        }

        public static String clicaPrimeiroObjeto(String tag)
        {
            string ret;

            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection elementos;
            elementos= instancia.Document.all.tags(tag);
            foreach (mshtml.IHTMLElement elemento in elementos)
            {
                ret = elemento.innerText.ToString();
                elemento.click();
                //albano: apos o click nao estava esperando carregar a tela
                Automacao.espera();
                return ret;
            }
            return "";
        }

        public static String clicaPrimeiroObjeto(String tag, String excecao)
        {

            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection elementos;
            elementos = instancia.Document.all.tags(tag);
            foreach (mshtml.IHTMLElement elemento in elementos)
            {
                if (!elemento.innerText.ToString().Contains(excecao))
                {
                    elemento.click();
                    return elemento.innerText.ToString();
                }
            }
            return "";
        }

        public static void onBlur(String elemento)
        {
            if (telaCompleta)
            {
                instancia.Document.frames(2).Document.forms(0).elements(elemento).onblur();
            }
            else
            {
                instancia.Document.forms(0).elements(elemento).onblur();
            }
            espera();

        }

    
        public static void onKeyUp(String elemento)
        {
            if (telaCompleta)
            {
                instancia.Document.frames(2).Document.forms(0).elements(elemento).onkeyup();
            }
            else
            {
                instancia.Document.forms(0).elements(elemento).onkeyup();
            }
            espera();

        }

        public static void selecionaPrimeiroCombo(String nome)
        {
            if (instancia.Document.forms(0).elements(nome)(1).innertext == "")
            {
                instancia.Document.forms(0).elements(nome)(2).selected = true;
                instancia.Document.forms(0).elements(nome).onblur();
                espera();
                instancia.Document.forms(0).elements(nome).onchange();
                espera();
            } else
            {
                instancia.Document.forms(0).elements(nome)(1).selected = true;
                instancia.Document.forms(0).elements(nome).onblur();
                espera();
                instancia.Document.forms(0).elements(nome).onchange();
                espera();
            }

        }

        public static void selecionaSegundoCombo(String nome)
        {
            
            instancia.Document.forms(0).elements(nome)(2).selected = true;
            instancia.Document.forms(0).elements(nome).onblur();
            espera();
            instancia.Document.forms(0).elements(nome).onchange();
            espera();
            

        }

        public static void selecionarRadio(int sequencia, string componente)
        {
            try
            {
                instancia.Document.forms(0).elements(componente)(sequencia).SetAttribute("checked", "true");
            }
            catch (Exception)
            {
                instancia.Document.forms(0).elements(componente).SetAttribute("checked", "true");
            }

        }
        public static void selecionarRadio2(int sequencia, string componente)
        {
            try
            {
                instancia.Document.forms(0).elements(componente)(sequencia).selected= true;
            }
            catch (Exception)
            {
                instancia.Document.forms(0).elements(componente).selected = true;
                throw;
            }

        }

        public static void selecionaCombo(String nome, String valor, String chave = "")
        {
            if (telaCompleta)
            {
                for (int x = 0; x <= 99; x++)
                {
                    if (chave == "")
                    {
                        if (instancia.Document.frames(2).Document.forms(0).elements(nome)(x).innertext() == valor)
                        {
                            instancia.Document.frames(2).Document.forms(0).elements(nome)(x).selected = true;
                            instancia.Document.frames(2).Document.forms(0).elements(nome).onblur();
                            espera();
                            instancia.Document.frames(2).Document.forms(0).elements(nome).onchange();
                            espera();
                            return;
                        }

                    }
                    else
                    {
                        if (instancia.Document.frames(2).Document.forms(0).elements(nome)(x).getAttribute(chave) == valor)
                        {
                            instancia.Document.frames(2).Document.forms(0).elements(nome)(x).selected = true;
                            instancia.Document.frames(2).Document.forms(0).elements(nome).onblur();
                            espera();
                            instancia.Document.frames(2).Document.forms(0).elements(nome).onchange();
                            espera();
                            return;
                        }
                    }
                }
            }
            else
            {
                for (int x = 0; x <= 99; x++)
                {
                    if (chave == "")
                    {
                        if (instancia.Document.forms(0).elements(nome)(x).innertext() == valor)
                        {
                            instancia.Document.forms(0).elements(nome)(x).selected = true;
                            instancia.Document.forms(0).elements(nome).onblur();
                            espera();
                            instancia.Document.forms(0).elements(nome).onchange();
                            espera();
                            return;
                        }


                    }
                    else
                    {
                        if (instancia.Document.forms(0).elements(nome)(x).getAttribute(chave) == valor)
                        {
                            instancia.Document.forms(0).elements(nome)(x).selected = true;
                            instancia.Document.forms(0).elements(nome).onblur();
                            espera();
                            instancia.Document.forms(0).elements(nome).onchange();
                            espera();
                            return;
                        }
                    }
                }
            }


        }
        
        

        public static void checaCampo(string nome, int x)
        {
            if (x == 0 || x == 1)
            {
                try
                {
                    instancia.Document.forms(0).elements(nome)(x).@checked = true;
                    instancia.Document.forms(0).elements(nome).onblur();
                    espera();
                    instancia.Document.forms(0).elements(nome).onchange();
                }
                catch (Exception)
                {
                    try
                    {
                        instancia.Document.forms(0).elements(nome).@checked = true;
                        instancia.Document.forms(0).elements(nome).onblur();
                        espera();
                        instancia.Document.forms(0).elements(nome).onchange();
                    }
                    catch (Exception)
                    {
                        //nada
                    }
                    
                }
            }

            else
            {
                try
                {
                    instancia.Document.forms(0).elements(nome)(x).@checked = true;
                    instancia.Document.forms(0).elements(nome).onblur();
                    espera();
                    instancia.Document.forms(0).elements(nome).onchange();
                }
                catch (Exception)
                {
                    //se erro nada a fazer
                }
                
            }
        } 

        public static string retornaLocal()
        {
            return instancia.LocationURL.ToString();
        }

        //Willian / Albvano - Verificar se o botão Continuar está desabilitado
        //public static Boolean elementoAtivo_Capiroto(String nome)
        //{
        //    mshtml.HTMLDocument corpo = instancia.Document;
        //    mshtml.IHTMLElementCollection elementos;
        //    elementos = instancia.Document.all.tags("input");
        //    foreach (mshtml.IHTMLElement elemento in elementos)
        //    {
        //        if (elemento.getAttribute("name") == nome)
        //        {
        //            if (elemento.getAttribute("disabled") == true)
        //            {
        //                return true;
        //            }
        //            //MessageBox.Show(elemento.getAttribute("disabled"));
        //            //MessageBox.Show(elemento.getAttribute("name"));
        //        }
        //    }
        //    return false;
        //}

        // Versão anterior (com o log de diagnóstico), substituída pelo estadoBotao abaixo:
        //public static Boolean elementoAtivo_Capiroto(String nome)
        //{
        //    mshtml.HTMLDocument corpo = instancia.Document;
        //
        //    mshtml.IHTMLElementCollection elementos;
        //    elementos = instancia.Document.all.tags("input");
        //
        //    foreach (mshtml.IHTMLElement elemento in elementos)
        //    {
        //        if (elemento.getAttribute("name") != null &&
        //            elemento.getAttribute("name").ToString() == nome)
        //        {
        //            var disabled = elemento.getAttribute("disabled");
        //
        //            try
        //            {
        //                System.IO.File.AppendAllText(
        //                    @"C:\Temp\AutoEncerramento.log",
        //                    DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") +
        //                    " | Nome=" + nome +
        //                    " | Valor=" + (disabled == null ? "NULL" : disabled.ToString()) +
        //                    " | Tipo=" + (disabled == null ? "NULL" : disabled.GetType().FullName) +
        //                    Environment.NewLine);
        //            }
        //            catch
        //            {
        //            }
        //
        //            if (disabled != null)
        //            {
        //                return true;
        //            }
        //        }
        //    }
        //
        //    return false;
        //}

        // Estado de um botão na tela do GCPJ:
        //   -1 = o botão NÃO EXISTE na tela
        //    0 = o botão existe e está HABILITADO (dá para clicar)
        //    1 = o botão existe e está DESABILITADO (cinza)
        // Lê a propriedade "disabled" do botão, que é sempre Sim/Não (true/false) em qualquer
        // modo do Internet Explorer. O getAttribute("disabled") muda de tipo conforme o modo do IE
        // (true/false, "disabled", "" ou null), e era isso que confundia a checagem antiga.
        public static int estadoBotao(String nome)
        {
            string[] tags = { "input", "button" };
            foreach (string tag in tags)
            {
                mshtml.IHTMLElementCollection elementos = instancia.Document.all.tags(tag);
                foreach (mshtml.IHTMLElement elemento in elementos)
                {
                    object nomeElemento = elemento.getAttribute("name");
                    if (nomeElemento == null || nomeElemento.ToString() != nome)
                        continue;

                    object propriedade = null;
                    object atributo = null;
                    bool desabilitado;
                    try
                    {
                        propriedade = ((dynamic)elemento).disabled;
                        desabilitado = valorDesabilitado(propriedade);
                    }
                    catch
                    {
                        atributo = elemento.getAttribute("disabled");
                        desabilitado = valorDesabilitado(atributo);
                    }

                    registrarLogBotao(nome, propriedade, atributo, desabilitado ? 1 : 0);
                    return desabilitado ? 1 : 0;
                }
            }

            registrarLogBotao(nome, null, null, -1);
            return -1;
        }

        // Interpreta o valor de "disabled" sem dar erro, qualquer que seja o tipo.
        public static bool valorDesabilitado(object valor)
        {
            if (valor == null) return false;
            if (valor is bool) return (bool)valor;
            string texto = valor.ToString().Trim().ToLower();
            return texto == "" || texto == "disabled" || texto == "true";
        }

        // Log geral de diagnóstico (mesmo arquivo do log dos botões). Se a pasta não existir, ignora.
        public static void registrarLog(string texto)
        {
            try
            {
                System.IO.File.AppendAllText(@"C:\Temp\AutoEncerramento.log",
                    DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + " | " + texto + Environment.NewLine);
            }
            catch
            {
            }
        }

        // Endereço da página aberta no GCPJ, sem dar erro (para o log e para a OBS).
        public static string paginaAtual()
        {
            try
            {
                string url = instancia.LocationURL.ToString();
                int i = url.IndexOf("/servlet/");
                if (i >= 0) url = url.Substring(i + 9);
                return url;
            }
            catch
            {
                return "NAO IDENTIFICADA";
            }
        }

        // Clica no primeiro link de pendência de evento que o robô sabe tratar (decisão, valor ou preposto),
        // ignorando o link do próprio processo. Devolve o texto do link clicado, ou "" se não houver.
        // Antes era usado o clicaPrimeiroObjeto("a", gcpj), que clicava em QUALQUER link da página
        // (outro evento, menu...) e fazia o robô se perder e travar.
        public static String clicaLinkPendenciaEvento(String excecao)
        {
            mshtml.IHTMLElementCollection elementos = instancia.Document.all.tags("a");
            string outros = "";
            foreach (mshtml.IHTMLElement elemento in elementos)
            {
                string texto = elemento.innerText == null ? "" : elemento.innerText.ToString();
                if (texto.Contains(excecao)) continue;
                if (texto.Contains("decis") || texto.Contains("valor") || texto.Contains("preposto"))
                {
                    elemento.click();
                    return texto;
                }
                if (texto.Trim() != "" && outros.Length < 300) outros += " [" + texto.Trim() + "]";
            }
            if (outros != "") registrarLog("Nenhuma pendência de evento conhecida na tela " + paginaAtual() + ". Links que o robô NÃO clicou:" + outros);
            return "";
        }

        // Log de diagnóstico (mesmo arquivo do log que já existia). Se a pasta não existir, ignora.
        private static void registrarLogBotao(string nome, object propriedade, object atributo, int estado)
        {
            try
            {
                System.IO.File.AppendAllText(
                    @"C:\Temp\AutoEncerramento.log",
                    DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") +
                    " | Nome=" + nome +
                    " | Estado=" + (estado == -1 ? "NAO EXISTE" : estado == 1 ? "DESABILITADO" : "HABILITADO") +
                    " | Propriedade=" + (propriedade == null ? "NULL" : propriedade.ToString() + " (" + propriedade.GetType().Name + ")") +
                    " | Atributo=" + (atributo == null ? "NULL" : atributo.ToString() + " (" + atributo.GetType().Name + ")") +
                    Environment.NewLine);
            }
            catch
            {
            }
        }

        // true = botão DESABILITADO (o nome é antigo e engana: "Ativo" aqui quer dizer "desativado").
        // Se o botão não existir, devolve false, como antes. Para saber se ele existe, use estadoBotao.
        public static Boolean elementoAtivo_Capiroto(String nome)
        {
            return estadoBotao(nome) == 1;
        }

        public static Boolean elementoAtivo(String nome)
        {
            try
            {
                if (instancia.Document.forms(0).elements(nome).getAttribute("disabled") == "disabled" || instancia.Document.forms(0).elements(nome).getAttribute("disabled") == "" || instancia.Document.forms(0).elements(nome).getAttribute("disabled"))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
           catch (Exception)
            {

                return false;
            }

        }

        public static void criarJanelaAnexo(String gcpj)
        {
            instAnexo = new InternetExplorer();
            instAnexo.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadProcsAnexosAction?acao=carregar&cdNumeroProcessoBradesco=" + gcpj + "&permitirSalvar=1&tituloPagina=Automação Captura de Iniciais");
            instAnexo.Visible = true;
            Thread.Sleep(2000);
        }

        public static bool inserirAnexo(String nomeDocumento, int tipoAnexo, string Diretorio, string CaminhoArquivo, String gcpj)
        {
            instAnexo = new InternetExplorer();
            instAnexo.Navigate("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadProcsAnexosAction?acao=carregar&cdNumeroProcessoBradesco=" + gcpj + "&permitirSalvar=1&tituloPagina=Automação Captura de Iniciais");

            Thread.Sleep(2000);

            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationURL.IndexOf("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadProcsAnexosAction?acao=carregar&cdNumeroProcessoBradesco=" + gcpj) >= 0)
                {
                    instAnexo = ie;
                    break;
                }
            }
            esperaAnexo();

            Thread tr2 = new Thread(clicarAnexar);
        denovo:
            instAnexo.Document.forms(0).elements("nmAnexoProcesso").innertext = nomeDocumento;
            for (int x = 1; x <= 999; x++)
            {
                if (instAnexo.Document.forms(0).elements("cmdAnexos")(x).getAttribute("cdTipoAnexo") == tipoAnexo.ToString())
                {
                    instAnexo.Document.forms(0).elements("cmdAnexos")(x).selected = true;
                    instAnexo.Document.forms(0).elements("cmdAnexos").onblur();
                    esperaAnexo();
                    instAnexo.Document.forms(0).elements("cmdAnexos").onchange();
                    esperaAnexo();
                    instAnexo.Document.forms(0).elements("cdSelecionadoAnexo").value = tipoAnexo.ToString();
                    instAnexo.Document.forms(0).elements("dsTipoAnexo").value = instAnexo.Document.forms(0).elements("cmdAnexos")(x).innertext();
                    break;
                }
            }

            //TRATAMENTO DO NOME DO ARQUIVO
            String extensao;
            try
            {
                extensao = "pdf";
                Double.Parse(CaminhoArquivo.Split('_')[0]);
                DirectoryInfo dirbase = new DirectoryInfo(Diretorio);
                FileInfo[] taskFiles = dirbase.GetFiles(CaminhoArquivo.Split('_')[0] + "*." + extensao);
                taskFiles[0].CopyTo(Diretorio + gcpj + "." + extensao);
            }
            catch (Exception)
            {
                try
                {
                    extensao = Path.GetExtension(Diretorio + CaminhoArquivo);
                    extensao.Replace(".", "");
                    File.Copy(Diretorio + CaminhoArquivo, Diretorio + gcpj + "." + extensao);
                }
                catch (Exception)
                {

                    //NAO LOCALIZEI A INICIAL
                    //Conexao.executar("UPDATE SYS_IMPORTACAO SET PRE_CADASTRADO = TRUE, GCPJ = 9999999 WHERE IDENTIFICADOR_ANEXO = " + CaminhoArquivo.Split('_')[0]);
                    instAnexo.Quit();
                    return false;
                }

            }

            tr2.Start();
            Thread.Sleep(2000);
        again:
            try
            {
                aeDesktop = AutomationElement.RootElement;
                frmSelecionar = aeDesktop.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "Escolher arquivo a carregar"));
                arquivo = frmSelecionar.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.ClassNameProperty, "Edit"));

                arquivoTexto = (ValuePattern)arquivo.GetCurrentPattern(ValuePattern.Pattern);
                arquivoTexto.SetValue(Diretorio + gcpj + "." + extensao);

                btnAbrir = frmSelecionar.FindFirst(TreeScope.Children, new PropertyCondition(AutomationElement.NameProperty, "Abrir"));
                btnAbrirClick = (InvokePattern)btnAbrir.GetCurrentPattern(InvokePattern.Pattern);
                btnAbrirClick.Invoke();
            }
            catch (Exception)
            {
                goto again;
            }

            instAnexo.Document.forms(0).elements("btoIncluir").click();
            if (mataPossivelMsgBox())
            {
                goto denovo;
            }
            File.Delete(Diretorio + gcpj + ".pdf");
            //GARANTIR A ROTINA.... E DEPOIS DELETAR TUDO!
            //File.Delete(Diretorio + CaminhoArquivo);
            // instAnexo.Document.forms(0).elements("btoSalvar").click();
            // mataMsgBox();
            instAnexo.Quit();
            return true;
        }

        public static void clicarAnexar()
        {
            instAnexo.Document.forms(0).elements("formFile").click();
        }

        public static void fecharJanelaAnexo()
        {
            instAnexo.Quit();
        }

        public static void cadastrarPF(String nome, double cpf, int digito)
        {
            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationURL.IndexOf("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&modulo=tramite&origem=origemCivel&dsTipoPessoa=PESSOA FISICA") >= 0)
                {
                    instCad = ie;
                    instCad.Visible = true;
                    break;
                }
            }

            //iniciando o cadastro
            instCad.Document.forms(0).elements("nmPessoaExternaProcesso").innertext = nome;
            if (cpf != 0)
            {
                instCad.Document.forms(0).elements("cdCpfPessoaExterna").innertext = cpf.ToString().PadLeft(9, '0');
                instCad.Document.forms(0).elements("cdControleCpfPessoaExterna").innertext = digito.ToString().PadLeft(2, '0');
            }

            instCad.Document.forms(0).elements("btoSalvar").click();
            mataMsgBox();
            instCad.Quit();

            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationURL.IndexOf("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&modulo=tramite&origem=origemCivel&dsTipoPessoa=PESSOA FISICA") >= 0)
                {
                    instCad = ie;
                    instCad.Quit();
                    break;
                }
            }
        }

        public static void cadastrarPJ(String nome, double cpf, int filial, int digito)
        {
            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationURL.IndexOf("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&modulo=tramite&origem=origemCivel&dsTipoPessoa=PESSOA JURIDICA") >= 0)
                {
                    instCad = ie;
                    instCad.Visible = true;
                    break;
                }
            }

            //iniciando o cadastro
            instCad.Document.forms(0).elements("nmPessoaExternaProcesso").innertext = nome;

            if (cpf != 0)
            {
                instCad.Document.forms(0).elements("cdCnpjPessoaExterna").innertext = cpf.ToString().PadLeft(8, '0');
                instCad.Document.forms(0).elements("cdFilialCnpjPessoaExterna").innertext = filial.ToString().PadLeft(4, '0');
                instCad.Document.forms(0).elements("cdControleCnpjPessoaExterna").innertext = digito.ToString().PadLeft(2, '0');
            }
            instCad.Document.forms(0).elements("btoSalvar").click();
            mataMsgBox();
            instCad.Quit();

            foreach (InternetExplorer ie in new ShellWindows())
            {
                if (ie.LocationURL.IndexOf("https://intranet85.net.bradesco.com.br/gcpj/servlet/cadMantemCadProcTrabAdmReuAction?acao=novaPessoaExterna&cdIndicadorOrigemChamado=S&cdIndicativoPopUp=C&modulo=tramite&origem=origemCivel&dsTipoPessoa=PESSOA JURIDICA") >= 0)
                {
                    instCad = ie;
                    instCad.Quit();
                    break;
                }
            }

        }

        public static bool localizaValorTabela(String classe, String pesquisa)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.all.tags("table");
            foreach (mshtml.HTMLTable Tabela in Tabelas)
            {
                if (Tabela.className != null)
                {
                    if (Tabela.className.ToString().Equals(classe))
                    {
                        foreach (mshtml.HTMLTableRow Linha in Tabela.rows)
                        {
                            foreach (mshtml.HTMLTableCell Celula in Linha.cells)
                            {
                                if (Celula.innerText != null)
                                {

                                    if (Celula.innerText.ToString().Trim().Equals(pesquisa))
                                    {
                                            return true;                                       
                                    }
                                }
                            }
                        }
                    }
                }

            }
            return false;
        }

        public static bool selecionarTabela(String classe, String pesquisa)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.all.tags("table");
            foreach (mshtml.HTMLTable Tabela in Tabelas)
            {
                if (Tabela.className != null)
                {
                    if (Tabela.className.ToString().Equals(classe))
                    {
                        foreach (mshtml.HTMLTableRow Linha in Tabela.rows)
                        {
                            foreach (mshtml.HTMLTableCell Celula in Linha.cells)
                            {
                                if (Celula.innerText != null)
                                {
                                    if (Celula.innerText.ToString().Trim().Equals(pesquisa))
                                    {
                                        mshtml.IHTMLElementCollection checkboxes = Linha.getElementsByTagName("input");
                                        foreach (mshtml.HTMLInputElement checkbox in checkboxes)
                                        {
                                            checkbox.setAttribute("checked", "true");
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
            return false;
        }

        public static bool clicaTabela(String classe, String pesquisa)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;

            Tabelas = instancia.Document.all.tags("a");
            
            var i = 0;
            string nome = "";

            for( i = 0;i <= Tabelas.length; i += 1){                           
                if (Tabelas.item(i).className == classe)
                {                   
                    Tabelas.item(i).click();
                    return true;

                }
            }

            return false;

        }

        public static bool clicaContaTabela(String classe, String conta, String digito)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.all.tags("table");
            foreach (mshtml.HTMLTable Tabela in Tabelas)
            {
                if (Tabela.className != null)
                {
                    if (Tabela.className.ToString().Equals(classe))
                    {
                        foreach (mshtml.HTMLTableRow Linha in Tabela.rows)
                        {                            
                            foreach (mshtml.HTMLTableCell Celula in Linha.cells)
                            {
                                if (Celula.innerText == conta + "-" + digito)
                                {
                                    string href = Celula.innerHTML.ToString().Trim();
                                    href = href.Replace("<A href=\"", "");
                                    href = href.Replace("\">" + Celula.innerText.ToString() + "</A>", "");                                    
                                    Automacao.ExecutarJS(href);

                                    return true;
                                }
                            }
                        }
                    }
                }

            }
            return false;
        }


        public static bool buscarValorTabela(String classe, String pesquisa)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.all.tags("table");
            foreach (mshtml.HTMLTable Tabela in Tabelas)
            {
                //if (Tabela.className != null)
                //{
                    //if (Tabela.className.ToString().Equals(classe))
                    //{
                        foreach (mshtml.HTMLTableRow Linha in Tabela.rows)
                        {
                            foreach (mshtml.HTMLTableCell Celula in Linha.cells)
                            {
                                if (Celula.innerText != null)
                                {
                                    string documentocompleto = classe.Substring(0, 3) + "." + classe.Substring(3, 3) + "." + classe.Substring(6, 3) + "-" + pesquisa;
                                    if (Celula.innerText.ToString().Trim() == documentocompleto.Trim())
                                    {                                   
                                            return true;                                        
                                    }
                                }
                            }
                        }
                    //}
                //}

            }
            return false;
        }


        public static bool selecionarTabela(String classe, String pesquisa, String pesquisaOu)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.getElementsByTagName("table");
            foreach (mshtml.HTMLTable Tabela in Tabelas)
            {
                if (Tabela.className != null)
                {
                    if (Tabela.className.ToString().Equals(classe))
                    {
                        foreach (mshtml.HTMLTableRow Linha in Tabela.rows)
                        {
                            foreach (mshtml.HTMLTableCell Celula in Linha.cells)
                            {
                                if (Celula.innerText != null)
                                {
                                    if (Celula.innerText.ToString().Trim().Equals(pesquisa) || Celula.innerText.ToString().Trim().Equals(pesquisaOu))
                                    {
                                        mshtml.IHTMLElementCollection checkboxes = Linha.getElementsByTagName("input");
                                        foreach (mshtml.HTMLInputElement checkbox in checkboxes)
                                        {
                                            checkbox.setAttribute("checked", "true");
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
            return false;
        }

        public static bool selecionarTabelaMult(String classe, String pesquisa1, String pesquisa2)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.getElementsByTagName("table");
            foreach (mshtml.HTMLTable Tabela in Tabelas)
            {
                if (Tabela.className != null)
                {
                    if (Tabela.className.ToString().Equals(classe))
                    {
                        foreach (mshtml.HTMLTableRow Linha in Tabela.rows)
                        {
                            bool localizado1 = false;
                            bool localizado2 = false;
                            foreach (mshtml.HTMLTableCell Celula in Linha.cells)
                            {
                                if (Celula.innerText != null)
                                {
                                    if (Celula.innerText.ToString().Trim().Equals(pesquisa1))
                                    {
                                        localizado1 = true;
                                    }
                                    if (Celula.innerText.ToString().Trim().Equals(pesquisa2))
                                    {
                                        localizado2 = true;
                                    }
                                    if (localizado1 == true && localizado2 == true)
                                    {
                                        mshtml.IHTMLElementCollection checkboxes = Linha.getElementsByTagName("input");
                                        foreach (mshtml.HTMLInputElement checkbox in checkboxes)
                                        {
                                            checkbox.setAttribute("checked", "true");
                                            return true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
            return false;
        }

        public static string RetornaPrimeiro(String classe)
        {
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection Tabelas;
            Tabelas = instancia.Document.getElementsByTagName("table");
            foreach (mshtml.HTMLTable Tabela in Tabelas)
            {
                if (Tabela.className != null)
                {
                    if (Tabela.className.ToString().Equals(classe))
                    {
                        foreach (mshtml.HTMLTableRow Linha in Tabela.rows)
                        {
                            foreach (mshtml.HTMLTableCell Celula in Linha.cells)
                            {
                                if (Celula.innerText != null)
                                {
                                    try
                                    {
                                        decimal.Parse(Celula.innerText);
                                        return Celula.innerText;
                                    }
                                    catch (Exception)
                                    {
                                        //erro segue
                                    }
                                }
                            }
                        }
                    }
                }

            }
            return "";
        }

        public static bool ValidaDigitoDeposito(int idBanco, string idJudicial)
        {
            if (idBanco == 1)
            {
                //criar nova janela
                InternetExplorer valida = new InternetExplorer();
                valida.Visible = true;
                valida.Navigate("https://www63.bb.com.br/portalbb/djo/id/comprovante/consultaDepositoJudicial,802,4647,4650,0,1.bbx");
                while (valida.Busy)
                {
                    //espera
                }
                valida.Document.getElementById("formulario:numPreDeposito").innertext = idJudicial;
                valida.Document.getElementById("formulario:numPreDeposito").onKeyUp();
                while (valida.Busy)
                {
                    //espera
                }
                //''
                valida.Document.getElementById("formulario:btnContinuar").click();
                while (valida.Busy)
                {
                    //espera
                }
                try
                {
                    valida.Document.getElementById("formulario:btnContinuar").click();
                }
                catch (Exception)
                {
                    valida.Quit();
                    return true;
                }
                valida.Quit();
                return false;
                
            }
            return true;
        }

        public static void acessarSistema(String usuario, String senha)
        {
            IntPtr winHwnd = IntPtr.Zero;
            while (winHwnd == IntPtr.Zero)
            {
                winHwnd = FindWindowByCaption(IntPtr.Zero, "Segurança do Windows");
            }
            Thread.Sleep(1000);

            AutomationElement janela;
            AutomationElement Tusuario;
            AutomationElement Tsenha;
            AutomationElement ok;

            janela = AutomationElement.FromHandle(winHwnd);

            Tusuario = janela.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "Nome de usuário"));
            Tsenha = janela.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "Senha"));
            ok = janela.FindFirst(TreeScope.Descendants, new PropertyCondition(AutomationElement.NameProperty, "OK"));

            //usuario
            arquivoTexto = (ValuePattern)Tusuario.GetCurrentPattern(ValuePattern.Pattern);
            arquivoTexto.SetValue(usuario);

            //senha
            arquivoTexto = (ValuePattern)Tsenha.GetCurrentPattern(ValuePattern.Pattern);
            arquivoTexto.SetValue(senha);

            //botao ok
            btnAbrirClick = (InvokePattern)ok.GetCurrentPattern(InvokePattern.Pattern);
            btnAbrirClick.Invoke();
        }

        public static String retornaValorTela(String tag)
        {

            String gcpjTela;
            decimal numero;
            mshtml.HTMLDocument corpo = instancia.Document;
            mshtml.IHTMLElementCollection elementos;
            elementos = instancia.Document.getElementsByTagName(tag);
            foreach (mshtml.IHTMLElement elemento in elementos)
            {
                gcpjTela = elemento.innerText.ToString();
                if (decimal.TryParse(gcpjTela, out numero))
                {
                    return gcpjTela;
                }
                //elemento.click();
                //return elemento.innerText.ToString();
            }
            return "";

        }
    }
}
