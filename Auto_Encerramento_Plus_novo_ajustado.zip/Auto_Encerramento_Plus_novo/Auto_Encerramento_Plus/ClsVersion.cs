﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auto_Encerramento_Plus
{
    public static class ClsVersion
    {
        public static string VersionGIT { get; set; } = "1.1.3";
    }
}
