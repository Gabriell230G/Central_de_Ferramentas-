# Sistema Atualiza Envolvidos (aajr-cmn-atualizaenvolvidos)

Robô que lê uma planilha de envolvidos e atualiza o cadastro deles nos processos do GCPJ: corrige CPF/CNPJ, inclui autores e inclui réus pessoa jurídica.

| Item | Valor |
|---|---|
| Códigos no inventário | **D@KQ** Atualizar CPF/CNPJ Envolvido · **D@KV** Inserir Demais Autores · **D@LM** Inserir PJ Réu |
| Área | 4040 Dejur / COLDA - Collab Dev's & Analytics |
| Linguagem | C# (Windows Forms) |
| Framework | .NET Framework 4.8 |
| Sistema alvo | GCPJ (Internet Explorer, via SHDocVw / mshtml) |
| Base local | `BD\BD_DADOS.accdb` (subpasta `BD` ao lado do executável) |
| Log | tabela `TB_LOG` (usuário, ação, data e hora) |
| Controle S5 | Implementado (limite de **5.000** registros por execução) |

---

## Sumário

1. [O que o sistema faz](#1-o-que-o-sistema-faz)
2. [Como rodar](#2-como-rodar)
3. [Estrutura do projeto](#3-estrutura-do-projeto)
4. [Controle S5: Limitador de Operações](#4-controle-s5-limitador-de-operações)
5. [Guia rápido: quero mudar X, onde vou?](#5-guia-rápido-quero-mudar-x-onde-vou)
6. [Pontos de atenção](#6-pontos-de-atenção)
7. [Histórico](#7-histórico)

---

## 1. O que o sistema faz

```
Importar planilha ➜ (opcional) distribuir entre máquinas ➜ conectar no GCPJ
   ➜ escolher a ação ➜ o robô processa registro por registro
   ➜ cada registro recebe ATUALIZADO = TRUE e uma observação (OBS) com o resultado
```

| Botão | O que faz | Código |
|---|---|---|
| **Importar planilha** | Limpa a `TB_ENVOLVIDOS` e importa a planilha (colunas `BRADESCO | ENVOLVIDO | CPF_CNPJ | FILIAL | DIGITO`) | - |
| **Distribuir Máquinas** | Divide os registros pendentes entre N máquinas (campo Máquina) | - |
| **Conectar GCPJ** | Procura o GCPJ aberto ou abre uma nova janela | - |
| **Atualizar CPF/CNPJ Envolvido** | Localiza o envolvido no processo e grava o documento correto | D@KQ |
| **Inserir Demais Autores** | Inclui o envolvido como autor (cadastra no INFRA se não existir) | D@KV |
| **Inserir PJ RÉU** | Inclui o envolvido como réu (cadastra no INFRA se não existir) | D@LM |
| **Exportar para Excel** (link) | Abre a grade no Excel | - |

O resultado de cada registro fica na coluna **OBS** (ex.: *ATUALIZAÇÃO EFETUADA COM SUCESSO*, *NOME DO ENVOLVIDO NÃO LOCALIZADO*, *DOCUMENTO INVALIDO*).

Entre **23h e 6h** o robô fica parado esperando, para não rodar fora do horário.

## 2. Como rodar

1. Abra `ComplementaCadastro.sln` no Visual Studio.
2. Instale o **Microsoft Access Database Engine** (ACE OLEDB 12.0) e o **Excel** (usado na exportação).
3. Garanta a pasta `BD\BD_DADOS.accdb` ao lado do executável.
4. Coloque a planilha no diretório do sistema, clique em **Importar planilha**, depois **Conectar GCPJ** e escolha a ação.

## 3. Estrutura do projeto

Projeto: `ComplementaCadastro\ATUALIZA_ENVOLVIDOS.csproj`

| Arquivo | Para que serve |
|---|---|
| `Form1.cs` | Tela principal e as **três rotinas de automação** |
| `Form1.Designer.cs` | Layout da tela |
| `Automacao.cs` | Funções que controlam o Internet Explorer (navegar, preencher, clicar, cadastrar PF/PJ) |
| `Conexao.cs` | Conexão com o Access e execução das procedures de importação |
| `LimitadorS5.cs` | **Controle S5**: limite de operações por execução |

## 4. Controle S5: Limitador de Operações

Exigência do normativo **05.1073** para aplicativos com C10 = Sim. Os três códigos (D@KQ, D@KV, D@LM) foram apontados pela área de Riscos Digitais como **Risco Inerente Moderado sem S5**; com esta alteração os três passam a ter o controle.

### Como funciona

```
Clique na ação ➜ contador = 0
   Para cada registro pendente da TB_ENVOLVIDOS:
      contador já chegou no limite?  ➜ SIM: avisa, grava no TB_LOG e para
                                      ➜ NÃO: soma 1 e processa o registro
```

Ao atingir o limite:

- aparece a mensagem **"Processamento Limitado - Controle S5"**;
- a grade mostra *"Controle S5: limite de 5.000 registros atingido. Processamento interrompido."*;
- o `TB_LOG` recebe *"CONTROLE S5 - LIMITE DE OPERACOES ATINGIDO - (ação) - MÁQUINA (n)"*;
- os registros não tratados continuam com `ATUALIZADO = FALSE` e entram na próxima execução.

### Onde mexer

| O que | Arquivo | Onde |
|---|---|---|
| **Valor do limite** | `LimitadorS5.cs` | constante `LIMITE_OPERACOES` (linha 28) |
| Mensagem exibida ao usuário | `LimitadorS5.cs` | método `LimiteAtingido` |
| D@KQ Atualizar CPF/CNPJ | `Form1.cs` | `btnAtualizaCPF_Click`, bloco `[S5]` na linha 255 |
| D@KV Inserir Demais Autores | `Form1.cs` | `btn_InsereEnvolvido_Click`, bloco `[S5]` na linha 532 |
| D@LM Inserir PJ Réu | `Form1.cs` | `btn_InserePjReu_Click`, bloco `[S5]` na linha 809 |

> Dica: **Ctrl+Shift+F** e pesquise `[S5]`.

### Documento de evidências

O Word com as evidências do Controle S5 (trechos do código alterado, resultado dos testes e espaço para os prints do ambiente) fica em [`docs/Evidencias_S5_AtualizaEnvolvidos.docx`](docs/Evidencias_S5_AtualizaEnvolvidos.docx).

### Como testar e gerar a evidência

1. Em `LimitadorS5.cs`, troque temporariamente `LIMITE_OPERACOES = 5000` para `2`.
2. Importe uma planilha com pelo menos 3 linhas e rode a ação desejada.
3. Confira: 2 registros ficam com `ATUALIZADO = TRUE`, o restante continua pendente e aparece o aviso.
4. Tire os prints com o **relógio do Windows aparecendo**: código, mensagem na tela e a linha no `TB_LOG`.
5. **Volte o valor para 5000** antes de gerar a versão final.

## 5. Guia rápido: quero mudar X, onde vou?

| Quero... | Vá em |
|---|---|
| Mudar o limite do Controle S5 | `LimitadorS5.cs` ➜ `LIMITE_OPERACOES` |
| Mudar as colunas da planilha importada | procedure `001_ACRESCIMO_TB_ENVOLVIDOS` no Access |
| Mudar o horário de pausa (23h às 6h) | `Form1.cs` ➜ início do `while (dr.Read())` de cada ação |
| Mudar como o nome do envolvido é comparado | `Form1.cs` ➜ `ObterStringSemAcentosECaracteresEspeciais` e `Automacao.selecionarTabelaEnvolvido` |
| Mudar o cadastro no INFRA | `Automacao.cs` ➜ `cadastrarPF` / `cadastrarPJ` |

## 6. Pontos de atenção

- Cada máquina processa só os registros com o seu número no campo **Máquina** (`MAQUINA = n`). O limite S5 vale **por máquina e por execução**.
- As consultas SQL são montadas por concatenação de texto. Nomes com aspas simples podem dar erro ao gravar a OBS.
- A pasta `obj` está versionada; ela é gerada na compilação e pode ser ignorada.

## 7. Histórico

| Data | Autor | Alteração |
|---|---|---|
| 10/2025 | Beatriz Santos | Migração do Bitbucket |
| 07/2026 | Kaylane Machado | `Trim` na seleção do tipo de envolvido |
| 10/2026 | Gabriel Vasconcellos Gomes | Implementação do **Controle S5** (`LimitadorS5.cs`) e novo README |

---

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="docs/legalops-logo-dark.png">
    <img src="docs/legalops-logo.png" alt="Legal Ops Bradesco" width="220">
  </picture>
  <br>
  <sub>Legal Operations • Banco Bradesco S.A. • Classificação: Interna</sub>
</p>
